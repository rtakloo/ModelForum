#!/usr/bin/env python3
"""Model Forum team service. Stdlib development server; see README for deployment requirements."""
import argparse
import collections
import contextlib
import getpass
import hashlib
import hmac
import http.server
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

MAX_BODY = 524288
SESSION_SECONDS = 12 * 3600
INVITE_SECONDS = 48 * 3600
ROLES = {"owner", "editor", "viewer"}

class Failure(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message

def require(condition, status=400, message="Invalid request."):
    if not condition:
        raise Failure(status, message)

def text(value, limit=254):
    require(isinstance(value, str) and 0 < len(value) <= limit and not any(ord(c) < 32 or ord(c) == 127 for c in value))
    return value

def email(value):
    value = text(value).strip().lower()
    require(bool(re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", value)))
    return value

def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()

def password_hash(password, salt=None):
    require(isinstance(password, str) and 12 <= len(password) <= 256, message="Use a password of 12–256 characters.")
    salt = salt or secrets.token_bytes(16)
    result = hashlib.scrypt(password.encode(), salt=salt, n=16384, r=8, p=1, dklen=32)
    return salt.hex() + ":" + result.hex()

def password_matches(password, stored):
    if not isinstance(password, str) or not 12 <= len(password) <= 256:
        return False
    salt, _ = stored.split(":")
    return hmac.compare_digest(password_hash(password, bytes.fromhex(salt)), stored)

def origin(value, https=True):
    p = urllib.parse.urlsplit(value)
    require(p.scheme == ("https" if https else "http") and p.hostname and not p.username and not p.password
            and p.path in ("", "/") and not p.query and not p.fragment, message="Configure an origin without a path, credentials, query or fragment.")
    return value.rstrip("/")

class Config:
    def __init__(self, environ=None):
        e = os.environ if environ is None else environ
        self.production = e.get("MF_ENV", "development") == "production"
        require(e.get("MF_ENV", "development") in ("development", "production"))
        self.port = int(e.get("MF_PORT", "8765"))
        self.public_origin = e.get("MF_PUBLIC_ORIGIN", "")
        self.stripe_key = e.get("STRIPE_SECRET_KEY", "")
        self.webhook_secret = e.get("STRIPE_WEBHOOK_SECRET", "")
        self.price = e.get("STRIPE_PRICE_ID", "")
        self.require_license = e.get("MF_REQUIRE_LICENSE", "0") == "1"
        require(e.get("MF_REQUIRE_LICENSE", "0") in ("0", "1"))
        self.origins = {origin(x.strip()) for x in e.get("MF_ALLOWED_ORIGINS", "").split(",") if x.strip()}
        if self.public_origin:
            self.public_origin = origin(self.public_origin)
        if self.production:
            require(self.public_origin and self.origins and self.public_origin in self.origins,
                    message="Production requires an HTTPS public origin and explicit allowed origins including it.")
        any_stripe = any([self.stripe_key, self.webhook_secret, self.price])
        require(not any_stripe or all([self.stripe_key, self.webhook_secret, self.price, self.public_origin]),
                message="Stripe configuration is incomplete; secret, webhook secret, price and HTTPS public origin are required.")
        self.billing = bool(any_stripe)
        require(not self.require_license or self.billing, message="License enforcement requires configured Stripe billing.")
        if self.billing:
            require(self.stripe_key.startswith(("sk_test_", "sk_live_")) and self.webhook_secret.startswith("whsec_")
                    and re.fullmatch(r"price_[A-Za-z0-9]+", self.price), message="Invalid Stripe configuration.")
        self.hosts = {urllib.parse.urlsplit(x).netloc for x in self.origins}
        if not self.production:
            self.hosts |= {f"127.0.0.1:{self.port}", f"localhost:{self.port}"}

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise Failure(502, "Billing service redirected unexpectedly.")

class Stripe:
    def __init__(self, config):
        self.config = config
    def request(self, method, path, fields=None, idempotency=None):
        require(re.fullmatch(r"/[A-Za-z0-9_/]+", path), 500)
        data = urllib.parse.urlencode(fields or {}).encode() if method == "POST" else None
        headers = {"Authorization": "Bearer " + self.config.stripe_key, "Content-Type": "application/x-www-form-urlencoded",
                   "Stripe-Version": "2025-06-30.basil"}
        if idempotency:
            headers["Idempotency-Key"] = idempotency
        request = urllib.request.Request("https://api.stripe.com/v1" + path, data=data, headers=headers, method=method)
        try:
            with urllib.request.build_opener(NoRedirect()).open(request, timeout=15) as response:
                body = response.read(MAX_BODY + 1)
            require(len(body) <= MAX_BODY, 502)
            result = json.loads(body)
            require(isinstance(result, dict), 502)
            return result
        except (urllib.error.URLError, ValueError, TimeoutError):
            raise Failure(502, "Billing service unavailable. No entitlement was changed; retry manually.") from None

class Service:
    def __init__(self, path, config=None, stripe=None, clock=time.time):
        self.config = config or Config()
        self.clock = clock
        self.lock = threading.RLock()
        self.rates = collections.OrderedDict()
        self.db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,disabled INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS teams(id TEXT PRIMARY KEY,name TEXT NOT NULL,customer TEXT UNIQUE,subscription TEXT,status TEXT NOT NULL DEFAULT 'none',valid_until REAL NOT NULL DEFAULT 0,checkout TEXT,checkout_url TEXT,checkout_expiry REAL);
        CREATE TABLE IF NOT EXISTS members(team TEXT REFERENCES teams(id),user TEXT REFERENCES users(id),role TEXT NOT NULL,PRIMARY KEY(team,user));
        CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user TEXT REFERENCES users(id),expires REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS invitations(id TEXT PRIMARY KEY,token TEXT UNIQUE NOT NULL,team TEXT REFERENCES teams(id),email TEXT NOT NULL,role TEXT NOT NULL,expires REAL NOT NULL,used INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS documents(team TEXT REFERENCES teams(id),id TEXT NOT NULL,revision INTEGER NOT NULL,snapshot TEXT NOT NULL,PRIMARY KEY(team,id));
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,created REAL NOT NULL,actor TEXT,team TEXT,action TEXT NOT NULL,resource TEXT,revision INTEGER);
        CREATE TABLE IF NOT EXISTS stripe_events(id TEXT PRIMARY KEY,created REAL NOT NULL);
        ''')
        self.dummy_password = password_hash(secrets.token_urlsafe(32))
        self.stripe = stripe or Stripe(self.config)

    @contextlib.contextmanager
    def transaction(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def audit(self, actor, team, action, resource=None, revision=None):
        # Deliberately no request bodies, titles, prompts, email, tokens, passwords or IPs.
        self.db.execute("INSERT INTO audit(created,actor,team,action,resource,revision) VALUES(?,?,?,?,?,?)",
                        (self.clock(), actor, team, action, resource, revision))

    def throttle(self, key, limit, interval=60):
        now = self.clock()
        window = self.rates.setdefault(key, collections.deque())
        while window and window[0] <= now - interval:
            window.popleft()
        require(len(window) < limit, 429, "Too many requests. Wait and retry.")
        window.append(now)
        self.rates.move_to_end(key)
        while len(self.rates) > 4096:
            self.rates.popitem(last=False)

    def bootstrap(self, address, password, name):
        with self.lock, self.transaction():
            require(self.db.execute("SELECT 1 FROM users LIMIT 1").fetchone() is None, 409, "Bootstrap is only available on an empty database.")
            user, team = str(uuid.uuid4()), str(uuid.uuid4())
            self.db.execute("INSERT INTO users VALUES(?,?,?,0)", (user, email(address), password_hash(password)))
            self.db.execute("INSERT INTO teams(id,name) VALUES(?,?)", (team, text(name, 100)))
            self.db.execute("INSERT INTO members VALUES(?,?,'owner')", (team, user))
            self.audit(user, team, "bootstrap")
            return team

    def session(self, user):
        token = secrets.token_urlsafe(32)
        self.db.execute("DELETE FROM sessions WHERE expires<=?", (self.clock(),))
        self.db.execute("INSERT INTO sessions VALUES(?,?,?)", (digest(token), user, self.clock() + SESSION_SECONDS))
        return {"token": token, "expires": self.clock() + SESSION_SECONDS}

    def actor(self, authorization):
        require(isinstance(authorization, str) and authorization.startswith("Bearer ") and len(authorization) < 512, 401, "Sign in again.")
        row = self.db.execute("SELECT u.id FROM sessions s JOIN users u ON u.id=s.user WHERE s.token=? AND s.expires>? AND u.disabled=0",
                              (digest(authorization[7:]), self.clock())).fetchone()
        require(row is not None, 401, "Sign in again.")
        return row["id"]

    def member(self, user, team, roles=ROLES):
        row = self.db.execute("SELECT role FROM members WHERE user=? AND team=?", (user, team)).fetchone()
        require(row and row["role"] in roles, 403, "Your team role does not permit this action.")
        return row["role"]

    def entitlement(self, team):
        row = self.db.execute("SELECT status,valid_until FROM teams WHERE id=?", (team,)).fetchone()
        active = row["status"] in ("active", "trialing") and row["valid_until"] > self.clock()
        return {"active": active, "status": row["status"], "validUntil": row["valid_until"], "billingConfigured": self.config.billing,
                "licenseRequired": self.config.require_license}

    def snapshot(self, value):
        require(isinstance(value, dict) and set(value) == {"title", "messages"})
        text(value["title"], 160)
        require(isinstance(value["messages"], list) and len(value["messages"]) <= 500)
        for message in value["messages"]:
            require(isinstance(message, dict) and set(message) <= {"role", "author", "content", "model"} and {"role", "author", "content"} <= set(message))
            require(message["role"] in ("user", "assistant", "system"))
            text(message["author"], 160)
            require(isinstance(message["content"], str) and len(message["content"]) <= 200000)
            if "model" in message:
                text(message["model"], 512)
        raw = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
        require(len(raw.encode()) <= MAX_BODY - 2048, 413, "Selected conversation is too large to share.")
        return raw

    def handle(self, method, path, body=b"", headers=None, peer="local"):
        headers = {k.lower(): v for k, v in (headers or {}).items()}
        with self.lock:
            require(len(body) <= MAX_BODY, 413, "Request is too large.")
            require("?" not in path and "#" not in path and "%" not in path)
            if path == "/v1/stripe/webhook":
                require(method == "POST", 405)
                return self.webhook(body, headers.get("stripe-signature", ""))
            self.throttle(("requests", peer), 300)
            try:
                data = json.loads(body) if body else {}
            except (ValueError, UnicodeError):
                raise Failure(400, "Invalid JSON.") from None
            require(isinstance(data, dict))
            if path in ("/v1/auth/login", "/v1/auth/join"):
                require(method == "POST", 405)
                self.throttle(("auth-ip", peer), 10)
                address = email(data.get("email"))
                self.throttle(("auth-account", digest(address)), 10, 900)
                if path.endswith("login"):
                    row = self.db.execute("SELECT * FROM users WHERE email=?", (address,)).fetchone()
                    valid = password_matches(data.get("password"), row["password"] if row else self.dummy_password)
                    require(row and valid and not row["disabled"], 401, "Email or password is incorrect.")
                    require(self.db.execute("SELECT 1 FROM members WHERE user=?", (row["id"],)).fetchone(), 403, "No active team membership.")
                    with self.transaction():
                        self.audit(row["id"], None, "login")
                        return self.session(row["id"])
                with self.transaction():
                    invitation = self.db.execute("SELECT * FROM invitations WHERE token=? AND used=0 AND expires>?", (digest(text(data.get("invitation"), 128)), self.clock())).fetchone()
                    require(invitation and hmac.compare_digest(invitation["email"], address), 403, "Invitation is invalid or expired.")
                    row = self.db.execute("SELECT * FROM users WHERE email=?", (address,)).fetchone()
                    if row:
                        require(not row["disabled"] and password_matches(data.get("password"), row["password"]), 401, "Email or password is incorrect.")
                        user = row["id"]
                    else:
                        user = str(uuid.uuid4())
                        self.db.execute("INSERT INTO users VALUES(?,?,?,0)", (user, address, password_hash(data.get("password"))))
                    require(not self.db.execute("SELECT 1 FROM members WHERE team=? AND user=?", (invitation["team"], user)).fetchone(), 409, "Already a member.")
                    self.db.execute("INSERT INTO members VALUES(?,?,?)", (invitation["team"], user, invitation["role"]))
                    self.db.execute("UPDATE invitations SET used=1 WHERE id=?", (invitation["id"],))
                    self.audit(user, invitation["team"], "invitation.accepted", invitation["id"])
                    return self.session(user)
            user = self.actor(headers.get("authorization"))
            if path == "/v1/auth/logout" and method == "POST":
                self.db.execute("DELETE FROM sessions WHERE token=?", (digest(headers["authorization"][7:]),))
                return {"ok": True}
            if path == "/v1/me" and method == "GET":
                memberships = self.db.execute("SELECT t.id,t.name,m.role FROM teams t JOIN members m ON m.team=t.id WHERE m.user=? ORDER BY t.name", (user,)).fetchall()
                return {"userID": user, "teams": [dict(x) for x in memberships]}
            parts = path.strip("/").split("/")
            require(len(parts) >= 4 and parts[:2] == ["v1", "teams"], 404, "Not found.")
            team, resource = parts[2:4]
            require(bool(re.fullmatch(r"[a-f0-9-]{36}", team)), 404)
            role = self.member(user, team)
            if resource == "entitlement" and len(parts) == 4 and method == "GET":
                return self.entitlement(team)
            if resource == "members" and len(parts) == 4 and method == "GET":
                self.member(user, team, {"owner"})
                rows = self.db.execute("SELECT u.id,u.email,m.role FROM members m JOIN users u ON u.id=m.user WHERE m.team=?", (team,)).fetchall()
                return {"members": [dict(x) for x in rows]}
            if resource == "members" and len(parts) == 5 and method in ("DELETE", "PUT"):
                self.member(user, team, {"owner"})
                target = parts[4]
                old = self.member(target, team)
                new = data.get("role") if method == "PUT" else None
                require(method == "DELETE" or new in ROLES)
                if old == "owner" and new != "owner":
                    require(self.db.execute("SELECT count(*) FROM members WHERE team=? AND role='owner'", (team,)).fetchone()[0] > 1, 409, "A team must retain an owner.")
                with self.transaction():
                    if method == "DELETE":
                        self.db.execute("DELETE FROM members WHERE team=? AND user=?", (team, target))
                        address = self.db.execute("SELECT email FROM users WHERE id=?", (target,)).fetchone()[0]
                        self.db.execute("UPDATE invitations SET used=1 WHERE team=? AND email=?", (team, address))
                    else:
                        self.db.execute("UPDATE members SET role=? WHERE team=? AND user=?", (new, team, target))
                    self.db.execute("DELETE FROM sessions WHERE user=?", (target,))
                    self.audit(user, team, "member.removed" if method == "DELETE" else "member.role_changed", target)
                return {"ok": True}
            if resource == "invitations" and len(parts) == 4:
                self.member(user, team, {"owner"})
                if method == "GET":
                    rows = self.db.execute("SELECT id,email,role,expires FROM invitations WHERE team=? AND used=0 AND expires>?", (team, self.clock())).fetchall()
                    return {"invitations": [dict(x) for x in rows]}
                require(method == "POST", 405)
                target_email, target_role = email(data.get("email")), data.get("role")
                require(target_role in {"editor", "viewer"}, message="Invite an editor or viewer; promote an existing member to owner separately.")
                token, identifier = secrets.token_urlsafe(32), str(uuid.uuid4())
                with self.transaction():
                    self.db.execute("UPDATE invitations SET used=1 WHERE team=? AND email=?", (team, target_email))
                    self.db.execute("INSERT INTO invitations VALUES(?,?,?,?,?,?,0)", (identifier, digest(token), team, target_email, target_role, self.clock() + INVITE_SECONDS))
                    self.audit(user, team, "invitation.created", identifier)
                return {"id": identifier, "token": token, "expires": self.clock() + INVITE_SECONDS}
            if resource == "invitations" and len(parts) == 5 and method == "DELETE":
                self.member(user, team, {"owner"})
                with self.transaction():
                    self.db.execute("UPDATE invitations SET used=1 WHERE team=? AND id=?", (team, parts[4]))
                    self.audit(user, team, "invitation.revoked", parts[4])
                return {"ok": True}
            if resource == "audit" and len(parts) == 4 and method == "GET":
                self.member(user, team, {"owner"})
                rows = self.db.execute("SELECT id,created,actor,action,resource,revision FROM audit WHERE team=? ORDER BY id DESC LIMIT 100", (team,)).fetchall()
                return {"events": [dict(x) for x in rows]}
            if resource == "documents":
                if len(parts) == 4 and method == "GET":
                    rows = self.db.execute("SELECT id,revision FROM documents WHERE team=? ORDER BY id LIMIT 200", (team,)).fetchall()
                    return {"documents": [dict(x) for x in rows]}
                require(len(parts) == 5 and re.fullmatch(r"[A-Za-z0-9_-]{1,80}", parts[4]), 404)
                identifier = parts[4]
                if method == "GET":
                    row = self.db.execute("SELECT revision,snapshot FROM documents WHERE team=? AND id=?", (team, identifier)).fetchone()
                    require(row, 404, "Shared conversation not found.")
                    self.audit(user, team, "document.read", identifier, row["revision"])
                    return {"id": identifier, "revision": row["revision"], "snapshot": json.loads(row["snapshot"])}
                require(method == "PUT", 405)
                self.member(user, team, {"owner", "editor"})
                require(not self.config.require_license or self.entitlement(team)["active"], 402, "An active team license is required to publish. Reading and export remain available.")
                expected = data.get("expectedRevision")
                require(type(expected) is int and 0 <= expected < 2**53)
                snapshot = self.snapshot(data.get("snapshot"))
                with self.transaction():
                    row = self.db.execute("SELECT revision FROM documents WHERE team=? AND id=?", (team, identifier)).fetchone()
                    current = row["revision"] if row else 0
                    require(current == expected, 409, "Revision conflict. Pull the current shared conversation before publishing again.")
                    require(row or self.db.execute("SELECT count(*) FROM documents WHERE team=?", (team,)).fetchone()[0] < 200, 409, "Team document limit reached.")
                    revision = current + 1
                    self.db.execute("INSERT INTO documents VALUES(?,?,?,?) ON CONFLICT(team,id) DO UPDATE SET revision=excluded.revision,snapshot=excluded.snapshot", (team, identifier, revision, snapshot))
                    self.audit(user, team, "document.published", identifier, revision)
                return {"id": identifier, "revision": revision}
            if resource in ("checkout", "portal") and method == "POST" and len(parts) == 4:
                self.member(user, team, {"owner"})
                self.throttle(("billing", team), 5, 300)
                require(self.config.billing, 503, "Billing is not configured on this server. No checkout is available.")
                return self.billing(team, resource)
            raise Failure(404, "Not found.")

    def billing(self, team, action):
        row = self.db.execute("SELECT * FROM teams WHERE id=?", (team,)).fetchone()
        customer = row["customer"]
        if not customer:
            require(action == "checkout", 409, "This team has no billing customer yet.")
            result = self.stripe.request("POST", "/customers", {"metadata[team_id]": team}, "customer-" + team)
            customer = text(result.get("id"), 100)
            require(re.fullmatch(r"cus_[A-Za-z0-9]+", customer), 502)
            self.db.execute("UPDATE teams SET customer=? WHERE id=?", (customer, team))
        if action == "portal":
            result = self.stripe.request("POST", "/billing_portal/sessions", {"customer": customer, "return_url": self.config.public_origin + "/billing/return"})
            return {"url": self.billing_url(result.get("url"), "billing.stripe.com")}
        require(not row["subscription"], 409, "This team already has a subscription record. Use the billing portal or ask the operator to reconcile it before starting another subscription.")
        if row["checkout"]:
            existing = self.stripe.request("GET", "/checkout/sessions/" + row["checkout"])
            require(existing.get("status") != "complete", 409, "Checkout completed. Refresh entitlement status or ask the operator to reconcile the webhook; do not purchase again.")
            if existing.get("status") == "open" and row["checkout_expiry"] and row["checkout_expiry"] > self.clock():
                return {"url": self.billing_url(row["checkout_url"], "checkout.stripe.com")}
            require(existing.get("status") == "expired", 409, "The existing checkout needs reconciliation before another can be created.")
        # Reuse the same key after response loss; advance only after a saved prior checkout is verified expired.
        result = self.stripe.request("POST", "/checkout/sessions", {"mode": "subscription", "customer": customer,
            "client_reference_id": team, "subscription_data[metadata][team_id]": team,
            "line_items[0][price]": self.config.price, "line_items[0][quantity]": "1",
            "success_url": self.config.public_origin + "/billing/return", "cancel_url": self.config.public_origin + "/billing/return"},
            "checkout-" + team + "-" + digest(row["checkout"] or "first"))
        url = self.billing_url(result.get("url"), "checkout.stripe.com")
        require(isinstance(result.get("expires_at"), (int, float)), 502)
        self.db.execute("UPDATE teams SET checkout=?,checkout_url=?,checkout_expiry=? WHERE id=?", (self.checkout_id(result.get("id")), url, result["expires_at"], team))
        return {"url": url}

    @staticmethod
    def checkout_id(value):
        value = text(value, 120)
        require(re.fullmatch(r"cs_[A-Za-z0-9_]+", value), 502)
        return value

    @staticmethod
    def billing_url(value, host):
        value = text(value, 4096)
        p = urllib.parse.urlsplit(value)
        require(p.scheme == "https" and p.hostname == host and not p.username and not p.password and p.port is None, 502, "Unexpected billing destination.")
        return value

    def webhook(self, body, signature):
        require(self.config.billing, 503, "Billing is not configured.")
        require(len(signature) < 4096, 400)
        fields = collections.defaultdict(list)
        for piece in signature.split(","):
            key, _, value = piece.partition("=")
            fields[key].append(value)
        require(len(fields["t"]) == 1 and fields["t"][0].isdigit(), 400, "Invalid webhook signature.")
        stamp = int(fields["t"][0])
        require(abs(self.clock() - stamp) <= 300, 400, "Expired webhook signature.")
        expected = hmac.new(self.config.webhook_secret.encode(), str(stamp).encode() + b"." + body, hashlib.sha256).hexdigest()
        require(any(re.fullmatch(r"[0-9a-f]{64}", value) and hmac.compare_digest(expected, value) for value in fields["v1"]), 400, "Invalid webhook signature.")
        try:
            event = json.loads(body)
            identifier = text(event["id"], 120)
            kind = event["type"]
            obj = event["data"]["object"]
        except (ValueError, KeyError, TypeError):
            raise Failure(400, "Invalid webhook event.") from None
        if self.db.execute("SELECT 1 FROM stripe_events WHERE id=?", (identifier,)).fetchone():
            return {"ok": True}
        if kind in ("customer.subscription.created", "customer.subscription.updated", "customer.subscription.deleted"):
            subscription = text(obj.get("id"), 120)
            require(re.fullmatch(r"sub_[A-Za-z0-9]+", subscription), 400)
            # Fetch current state rather than trusting event order or a client redirect as proof of payment.
            current = self.stripe.request("GET", "/subscriptions/" + subscription)
            customer = current.get("customer")
            row = self.db.execute("SELECT id,subscription FROM teams WHERE customer=?", (customer,)).fetchone()
            if row:
                require(row["subscription"] in (None, subscription), 409, "A different subscription is already attached; operator reconciliation is required.")
                items = current.get("items", {}).get("data", [])
                matching = [x for x in items if x.get("price", {}).get("id") == self.config.price]
                status = current.get("status", "unknown") if matching else "wrong_price"
                deadlines = [x.get("current_period_end", 0) for x in matching]
                deadline = min(deadlines) if deadlines else 0
                require(isinstance(deadline, (int, float)), 502)
                with self.transaction():
                    self.db.execute("UPDATE teams SET subscription=?,status=?,valid_until=? WHERE id=?", (subscription, status, deadline, row["id"]))
                    self.audit(None, row["id"], "billing.subscription_updated", subscription)
                    self.db.execute("INSERT INTO stripe_events VALUES(?,?)", (identifier, self.clock()))
                return {"ok": True}
        self.db.execute("INSERT INTO stripe_events VALUES(?,?)", (identifier, self.clock()))
        return {"ok": True}

class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "ModelForumTeam/0.6"
    def log_message(self, *args):
        pass  # URLs, bodies, Authorization and invitation tokens are never logged.
    def setup(self):
        super().setup()
        self.connection.settimeout(10)
    def do_GET(self): self.dispatch()
    def do_POST(self): self.dispatch()
    def do_PUT(self): self.dispatch()
    def do_DELETE(self): self.dispatch()
    def dispatch(self):
        try:
            service = self.server.service
            require(self.headers.get("Host", "") in service.config.hosts, 400, "Unexpected Host.")
            supplied_origin = self.headers.get("Origin")
            require(not supplied_origin or supplied_origin in service.config.origins, 403, "Origin is not allowed.")
            require(not self.headers.get("Transfer-Encoding"), 400, "Chunked requests are not accepted.")
            lengths = self.headers.get_all("Content-Length", [])
            require(len(lengths) <= 1 and (not lengths or lengths[0].isdigit()), 400)
            size = int(lengths[0]) if lengths else 0
            require(size <= MAX_BODY, 413, "Request is too large.")
            if size:
                require(self.headers.get_content_type() == "application/json", 415, "Use JSON.")
            body = self.rfile.read(size)
            require(len(body) == size, 400)
            if self.path == "/billing/return" and self.command == "GET":
                result = {"message": "Return to Model Forum and refresh license status. This page is not proof of payment."}
            else:
                result = service.handle(self.command, self.path, body, dict(self.headers), self.client_address[0])
            self.respond(200, result)
        except Failure as error:
            self.respond(error.status, {"error": error.message})
        except Exception:
            self.respond(500, {"error": "The service could not complete this request."})
    def respond(self, status, value):
        body = json.dumps(value, ensure_ascii=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)
        self.close_connection = True

class Server(http.server.HTTPServer):
    # Single request at a time bounds expensive password hashing and threads. Reverse proxy must limit connections.
    def __init__(self, service):
        super().__init__(("127.0.0.1", service.config.port), Handler)
        self.service = service

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["bootstrap", "serve"])
    parser.add_argument("--database", default="team-data/team.sqlite3")
    args = parser.parse_args()
    os.umask(0o077)
    path = Path(args.database)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    try:
        service = Service(str(path))
        if args.command == "bootstrap":
            address, name = input("Owner email: "), input("Team name: ")
            password = getpass.getpass("Owner password (12+ characters): ")
            require(hmac.compare_digest(password, getpass.getpass("Confirm password: ")), message="Passwords differ.")
            print("Created team", service.bootstrap(address, password, name))
        else:
            print(f"Model Forum team service listening on 127.0.0.1:{service.config.port}")
            Server(service).serve_forever()
    except (Failure, ValueError) as error:
        raise SystemExit(error.message if isinstance(error, Failure) else "Invalid configuration.") from None
