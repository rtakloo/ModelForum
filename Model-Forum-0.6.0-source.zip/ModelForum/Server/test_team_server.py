import hashlib
import hmac
import http.client
import json
from pathlib import Path
import tempfile
import threading
import unittest
from team_server import Config, Failure, Service, Server, MAX_BODY

PASSWORD = 'synthetic-owner-password'
class FakeStripe:
    def __init__(self):
        self.calls = []
        self.checkout_status = 'open'
        self.subscription = {'customer': 'cus_fake', 'status': 'active', 'items': {'data': [{'price': {'id': 'price_fake'}, 'current_period_end': 2000000}]}}
    def request(self, method, path, fields=None, idempotency=None):
        self.calls.append((method, path, fields, idempotency))
        if path.startswith('/subscriptions/'):
            return self.subscription
        if path.startswith('/checkout/sessions/'):
            return {'status': self.checkout_status}
        if path == '/customers':
            return {'id': 'cus_fake'}
        if path == '/checkout/sessions':
            return {'id': 'cs_fake', 'url': 'https://checkout.stripe.com/c/pay/fake', 'expires_at': 1003600}
        if path == '/billing_portal/sessions':
            return {'url': 'https://billing.stripe.com/p/session/fake'}
        raise AssertionError(path)

def billing_config(require=False):
    return Config({'STRIPE_SECRET_KEY': 'sk_test_synthetic', 'STRIPE_WEBHOOK_SECRET': 'whsec_synthetic', 'STRIPE_PRICE_ID': 'price_fake',
                   'MF_PUBLIC_ORIGIN': 'https://team.example.test', 'MF_REQUIRE_LICENSE': '1' if require else '0'})

class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.now = 1000000
        self.service = Service(str(Path(self.tmp.name) / 'team.db'), Config({}), clock=lambda: self.now)
        self.team = self.service.bootstrap('owner@example.test', PASSWORD, 'Test team')
        self.owner = self.call('POST', '/v1/auth/login', {'email': 'owner@example.test', 'password': PASSWORD})['token']
        self.base = '/v1/teams/' + self.team
        self.snapshot = {'title': 'Shared', 'messages': [{'role': 'user', 'author': 'You', 'content': 'private prompt sentinel'}]}
    def tearDown(self):
        self.service.db.close()
        self.tmp.cleanup()
    def call(self, method, path, body=None, token=None, **kwargs):
        return self.service.handle(method, path, json.dumps(body).encode() if body is not None else b'', {'Authorization': 'Bearer ' + token} if token else {}, **kwargs)
    def failure(self, status, fn):
        with self.assertRaises(Failure) as error:
            fn()
        self.assertEqual(error.exception.status, status)
    def join(self, role='viewer', address='member@example.test'):
        invite = self.call('POST', self.base + '/invitations', {'email': address, 'role': role}, self.owner)
        session = self.call('POST', '/v1/auth/join', {'email': address, 'password': PASSWORD, 'invitation': invite['token']})
        return session['token'], invite
    def test_bootstrap_hashes_password_and_never_stores_session_or_invitation_plaintext(self):
        stored = self.service.db.execute('SELECT password FROM users').fetchone()[0]
        self.assertNotIn(PASSWORD, stored)
        self.assertEqual(len(stored.split(':')[0]), 32)
        token, invitation = self.join()
        dump = '\n'.join(self.service.db.iterdump())
        self.assertNotIn(token, dump); self.assertNotIn(self.owner, dump); self.assertNotIn(invitation['token'], dump)
        self.failure(409, lambda: self.service.bootstrap('another@example.test', PASSWORD, 'Other'))
    def test_viewer_read_only_editor_cas_and_conflict_does_not_overwrite(self):
        viewer, _ = self.join()
        editor, _ = self.join('editor', 'editor@example.test')
        route = self.base + '/documents/thread'
        self.failure(403, lambda: self.call('PUT', route, {'expectedRevision': 0, 'snapshot': self.snapshot}, viewer))
        self.assertEqual(self.call('PUT', route, {'expectedRevision': 0, 'snapshot': self.snapshot}, editor)['revision'], 1)
        self.failure(409, lambda: self.call('PUT', route, {'expectedRevision': 0, 'snapshot': {'title': 'Wrong', 'messages': []}}, editor))
        self.assertEqual(self.call('GET', route, token=viewer)['snapshot'], self.snapshot)
        self.assertEqual(self.call('PUT', route, {'expectedRevision': 1, 'snapshot': self.snapshot}, editor)['revision'], 2)
    def test_server_does_not_trust_client_role_or_extra_snapshot_fields(self):
        viewer, _ = self.join()
        self.failure(403, lambda: self.call('POST', self.base + '/invitations', {'email': 'x@example.test', 'role': 'owner'}, viewer))
        self.failure(400, lambda: self.call('POST', self.base + '/invitations', {'email': 'x@example.test', 'role': 'owner'}, self.owner))
        for extra in ['requestContext', 'apiKey', 'globalInstructions', 'providerAccountLabels']:
            bad = dict(self.snapshot, **{extra: 'must not upload'})
            self.failure(400, lambda: self.call('PUT', self.base + '/documents/thread', {'expectedRevision': 0, 'snapshot': bad}, self.owner))
    def test_invitation_email_binding_one_use_expiry_and_revocation(self):
        _, invite = self.join()
        self.failure(403, lambda: self.call('POST', '/v1/auth/join', {'email': 'member@example.test', 'password': PASSWORD, 'invitation': invite['token']}))
        pending = self.call('POST', self.base + '/invitations', {'email': 'new@example.test', 'role': 'viewer'}, self.owner)
        self.failure(403, lambda: self.call('POST', '/v1/auth/join', {'email': 'other@example.test', 'password': PASSWORD, 'invitation': pending['token']}))
        self.call('DELETE', self.base + '/invitations/' + pending['id'], token=self.owner)
        self.failure(403, lambda: self.call('POST', '/v1/auth/join', {'email': 'new@example.test', 'password': PASSWORD, 'invitation': pending['token']}))
        expiring = self.call('POST', self.base + '/invitations', {'email': 'later@example.test', 'role': 'viewer'}, self.owner)
        self.now += 48 * 3600 + 1
        self.failure(403, lambda: self.call('POST', '/v1/auth/join', {'email': 'later@example.test', 'password': PASSWORD, 'invitation': expiring['token']}))
    def test_revocation_invalidates_all_sessions_and_outstanding_invitations(self):
        member, _ = self.join()
        me = self.call('GET', '/v1/me', token=member)
        second = self.call('POST', '/v1/auth/login', {'email': 'member@example.test', 'password': PASSWORD})['token']
        invite = self.call('POST', self.base + '/invitations', {'email': 'member@example.test', 'role': 'editor'}, self.owner)
        self.call('DELETE', self.base + '/members/' + me['userID'], token=self.owner)
        for token in [member, second]:
            self.failure(401, lambda: self.call('GET', self.base + '/documents', token=token))
        self.failure(403, lambda: self.call('POST', '/v1/auth/join', {'email': 'member@example.test', 'password': PASSWORD, 'invitation': invite['token']}))
        self.failure(403, lambda: self.call('POST', '/v1/auth/login', {'email': 'member@example.test', 'password': PASSWORD}))
    def test_role_change_invalidates_session_and_last_owner_is_protected(self):
        me = self.call('GET', '/v1/me', token=self.owner)
        self.failure(409, lambda: self.call('DELETE', self.base + '/members/' + me['userID'], token=self.owner))
        editor, _ = self.join('editor')
        member = self.call('GET', '/v1/me', token=editor)['userID']
        self.call('PUT', self.base + '/members/' + member, {'role': 'viewer'}, self.owner)
        self.failure(401, lambda: self.call('GET', '/v1/me', token=editor))
    def test_no_cross_team_access_or_unauthenticated_read(self):
        self.failure(401, lambda: self.call('GET', self.base + '/documents'))
        self.failure(403, lambda: self.call('GET', '/v1/teams/00000000-0000-0000-0000-000000000000/documents', token=self.owner))
    def test_session_expiry_logout_and_auth_limits(self):
        self.call('POST', '/v1/auth/logout', token=self.owner)
        self.failure(401, lambda: self.call('GET', '/v1/me', token=self.owner))
        for _ in range(9):
            self.failure(401, lambda: self.call('POST', '/v1/auth/login', {'email': 'absent@example.test', 'password': PASSWORD}))
        self.failure(429, lambda: self.call('POST', '/v1/auth/login', {'email': 'owner@example.test', 'password': PASSWORD}))
        self.now += 901
        token = self.call('POST', '/v1/auth/login', {'email': 'owner@example.test', 'password': PASSWORD})['token']
        self.now += 12 * 3600 + 1
        self.failure(401, lambda: self.call('GET', '/v1/me', token=token))
    def test_audit_contains_metadata_only_and_request_limits(self):
        self.call('PUT', self.base + '/documents/thread', {'expectedRevision': 0, 'snapshot': self.snapshot}, self.owner)
        events = self.call('GET', self.base + '/audit', token=self.owner)['events']
        raw = json.dumps(events)
        for private in ['private prompt sentinel', PASSWORD, self.owner, 'owner@example.test', 'Shared']:
            self.assertNotIn(private, raw)
        self.failure(413, lambda: self.service.handle('POST', '/v1/auth/login', b'x' * (MAX_BODY + 1)))
        self.failure(400, lambda: self.call('PUT', self.base + '/documents/thread', {'expectedRevision': True, 'snapshot': self.snapshot}, self.owner))
    def test_billing_unconfigured_is_honest_and_never_calls_provider(self):
        entitlement = self.call('GET', self.base + '/entitlement', token=self.owner)
        self.assertFalse(entitlement['billingConfigured']); self.assertFalse(entitlement['active'])
        self.failure(503, lambda: self.call('POST', self.base + '/checkout', token=self.owner))
    def configure_billing(self, require=False):
        self.service.config = billing_config(require)
        self.stripe = FakeStripe()
        self.service.stripe = self.stripe
    def webhook(self, identifier='evt_test', stamp=None, bad=False):
        body = json.dumps({'id': identifier, 'type': 'customer.subscription.updated', 'data': {'object': {'id': 'sub_fake'}}}).encode()
        stamp = self.now if stamp is None else stamp
        signature = hmac.new(b'whsec_synthetic', str(stamp).encode() + b'.' + body, hashlib.sha256).hexdigest()
        return self.service.handle('POST', '/v1/stripe/webhook', body, {'Stripe-Signature': f't={stamp},v1={"bad" if bad else signature}'})
    def test_checkout_owner_only_fixed_price_and_cached_idempotent(self):
        self.configure_billing()
        viewer, _ = self.join()
        self.failure(403, lambda: self.call('POST', self.base + '/checkout', token=viewer))
        first = self.call('POST', self.base + '/checkout', token=self.owner)
        second = self.call('POST', self.base + '/checkout', token=self.owner)
        self.assertEqual(first, second)
        checkout_calls = [call for call in self.stripe.calls if call[:2] == ('POST', '/checkout/sessions')]
        self.assertEqual(len(checkout_calls), 1)
        fields = checkout_calls[0][2]
        self.assertEqual(fields['line_items[0][price]'], 'price_fake')
        self.assertEqual(fields['subscription_data[metadata][team_id]'], self.team)
        self.assertEqual(fields['success_url'], 'https://team.example.test/billing/return')
    def test_signed_webhook_replay_timestamp_authoritative_state_and_license_enforcement(self):
        self.configure_billing(require=True)
        route = self.base + '/documents/thread'
        self.failure(402, lambda: self.call('PUT', route, {'expectedRevision': 0, 'snapshot': self.snapshot}, self.owner))
        self.call('POST', self.base + '/checkout', token=self.owner)
        self.failure(400, lambda: self.webhook(bad=True))
        self.failure(400, lambda: self.service.handle('POST', '/v1/stripe/webhook', b'{}', {'Stripe-Signature': f't={self.now},v1=nonasciié'}))
        self.failure(400, lambda: self.webhook(stamp=self.now - 301))
        self.webhook()
        before = len(self.stripe.calls)
        self.webhook()
        self.assertEqual(len(self.stripe.calls), before)
        self.assertTrue(self.call('GET', self.base + '/entitlement', token=self.owner)['active'])
        self.call('PUT', route, {'expectedRevision': 0, 'snapshot': self.snapshot}, self.owner)
        self.stripe.subscription['status'] = 'canceled'
        self.webhook('evt_stale_delivery')  # Fetches current state, rather than granting from the event body.
        self.assertFalse(self.call('GET', self.base + '/entitlement', token=self.owner)['active'])
        self.assertEqual(self.call('GET', route, token=self.owner)['revision'], 1)
        self.failure(402, lambda: self.call('PUT', route, {'expectedRevision': 1, 'snapshot': self.snapshot}, self.owner))
    def test_canceled_subscription_and_unprocessed_completed_checkout_cannot_create_duplicate_purchase(self):
        self.configure_billing()
        self.call('POST', self.base + '/checkout', token=self.owner)
        self.stripe.checkout_status = 'complete'
        self.failure(409, lambda: self.call('POST', self.base + '/checkout', token=self.owner))
        self.stripe.subscription['status'] = 'canceled'
        self.webhook()
        self.failure(409, lambda: self.call('POST', self.base + '/checkout', token=self.owner))
        purchases = [call for call in self.stripe.calls if call[:2] == ('POST', '/checkout/sessions')]
        self.assertEqual(len(purchases), 1)
        self.assertTrue(self.call('POST', self.base + '/portal', token=self.owner)['url'].startswith('https://billing.stripe.com/'))
    def test_wrong_price_expiry_and_customer_cannot_grant_license(self):
        self.configure_billing()
        self.call('POST', self.base + '/checkout', token=self.owner)
        self.stripe.subscription['items']['data'][0]['price']['id'] = 'price_other'
        self.webhook()
        self.assertFalse(self.call('GET', self.base + '/entitlement', token=self.owner)['active'])
        self.stripe.subscription['items']['data'][0]['price']['id'] = 'price_fake'
        self.stripe.subscription['items']['data'][0]['current_period_end'] = self.now - 1
        self.webhook('evt_expired')
        self.assertFalse(self.call('GET', self.base + '/entitlement', token=self.owner)['active'])
    def test_production_requires_explicit_https_allowlist(self):
        for settings in [{'MF_ENV': 'production'}, {'MF_ENV': 'production', 'MF_PUBLIC_ORIGIN': 'http://team.test'}, {'MF_REQUIRE_LICENSE': '1'}, {'STRIPE_SECRET_KEY': 'sk_test_synthetic'}]:
            with self.assertRaises(Failure): Config(settings)
        c = Config({'MF_ENV': 'production', 'MF_PUBLIC_ORIGIN': 'https://team.test', 'MF_ALLOWED_ORIGINS': 'https://team.test'})
        self.assertEqual(c.hosts, {'team.test'})
        self.assertNotIn('localhost:8765', c.hosts)

class HTTPTests(unittest.TestCase):
    setUp = ServiceTests.setUp
    tearDown = ServiceTests.tearDown
    call = ServiceTests.call
    def test_ephemeral_loopback_http_auth_host_and_origin(self):
        self.service.config.port = 0
        try:
            server = Server(self.service)
        except PermissionError:
            self.skipTest('Environment prohibits loopback listeners; service handler integration tests still run.')
        port = server.server_address[1]
        self.service.config.hosts = {f'127.0.0.1:{port}'}
        thread = threading.Thread(target=server.serve_forever, daemon=True); thread.start()
        try:
            def request(headers):
                conn = http.client.HTTPConnection('127.0.0.1', port, timeout=5)
                conn.request('GET', '/v1/me', headers=headers)
                response = conn.getresponse(); body = response.read(); conn.close()
                return response.status, json.loads(body)
            status, result = request({'Authorization': 'Bearer ' + self.owner})
            self.assertEqual(status, 200); self.assertEqual(result['teams'][0]['id'], self.team)
            self.assertEqual(request({'Host': 'attacker.test'})[0], 400)
            self.assertEqual(request({'Origin': 'https://attacker.test'})[0], 403)
        finally:
            server.shutdown(); server.server_close(); thread.join()

if __name__ == '__main__': unittest.main()
