# Local team service (0.6 preview)

This is a locally runnable SQLite/HTTP service plus native Mac client. It enforces owner/editor/viewer permissions, expiring invitation tokens and sessions, revision-checked conversation publication, membership revocation and metadata-only audit records. This preview is **not a production security certification or deployment**. No Stripe account, subscription, email or cloud resource is created by installation or tests.

## Start locally

Use Python 3.10 or later with OpenSSL/scrypt support. In the ModelForum project directory:

```sh
python3 Server/team_server.py bootstrap --database /absolute/private/path/model-forum-team/team.sqlite3
python3 Server/team_server.py serve --database /absolute/private/path/model-forum-team/team.sqlite3
```

Bootstrap prompts for an owner email, team name and password in your own terminal. Password entry is hidden and is not supplied to Codex. Use a unique password of at least 12 characters. Bootstrap only works on an empty database. The service creates a private directory/database using umask 077; choose a private parent directory. Back up the database and SQLite WAL safely while stopped or with SQLite's backup facility.

The listener binds **127.0.0.1:8765 only**. `MF_PORT` changes the port, not the bind address. In the Mac app's Team settings, use `http://127.0.0.1:8765`, then sign in with the locally created owner account. Team authentication is separate from OpenAI/Claude credentials. Session tokens are kept in a separate macOS Keychain service scoped to the exact server origin; server-side tokens are stored only as SHA-256 hashes and expire after 12 hours.

For a two-account local test: create a viewer invitation as owner, copy its token, sign out, then join with the invited email, a new unique password and that token. Tokens expire after 48 hours, are bound to the invited email, can be used once, and are not emailed by the application. Email is an account identifier; email ownership is not independently verified. Existing accounts must supply their existing password when accepting an invitation. Owners may promote existing members to owner. The last owner cannot be removed or demoted.

Choose a shared conversation ID and preview the selected local conversation before publishing. Only its title, visible messages, authors and model names are sent. Workspace settings, provider keys, account labels, global instructions, message requestContext/provenance, files and other conversations are excluded. **Visible text can itself contain private information or pasted secrets; inspect the preview.** Pull fetches one server snapshot, and Import creates a new local conversation. Publishing an existing ID requires pulling its latest revision; conflicts return 409 and do not overwrite data. Limits: 500 messages, roughly 510 KB per document, 200 documents per team. This is explicit snapshot sharing, not realtime merging.

Removing a member or changing their role invalidates all their current sessions. Removal also revokes their pending invitations for that team. Permissions are checked on every request; a subsequent sign-in cannot restore removed membership. Revocation cannot erase previously downloaded copies. Owners see the last 100 audit entries containing action, actor ID, team/document ID, revision and time, never prompt bodies, titles, credentials, invitation tokens or email. Audit storage is not tamper-proof against the server/database operator.

## Tests

```sh
python3 -m unittest discover -s Server -v
```

Tests use temporary databases, synthetic credentials, direct service requests and a fake Stripe adapter. They never create charges or call Stripe. An additional ephemeral loopback HTTP test skips explicitly when the execution environment prohibits listeners. Swift `TeamClientTests` cover sharing exclusions and origin/path/billing URL validation; run them through the parent Swift suite.

## Later deployment (requires review and external setup)

Keep this process loopback-bound behind a separately operated HTTPS reverse proxy. Set `MF_ENV=production`, `MF_PUBLIC_ORIGIN=https://your-reviewed-host` and `MF_ALLOWED_ORIGINS=https://your-reviewed-host` (comma-separated exact HTTPS origins). Startup rejects missing/unsafe production settings. The proxy must preserve the public `Host`, terminate valid TLS, restrict access to the loopback backend, enforce body/header/concurrent-connection limits and timeouts, and suppress sensitive request logging. Host is allowlisted; supplied browser Origin is allowlisted; no CORS access is granted. Native requests have no Origin. The service deliberately does not trust X-Forwarded-For or forwarded scheme headers.

The stdlib server serializes requests and has a 10-second socket timeout; it is a small-team development baseline. The in-memory per-peer auth throttle is 10 attempts/minute and per-account 10/15 minutes; behind a loopback proxy the peer throttle is **shared across all clients**. General requests are limited to 300/minute per peer. Configure operational edge controls and review a production transport before public rollout. Limits reset on process restart; single-process SQLite and in-memory throttling are not a distributed deployment design. There is currently no MFA, SSO, email verification, self-service password reset, password-change UI, automated retention/deletion, tenant provisioning UI, secret rotation workflow, backup scheduler or security audit certification. Plan these, monitoring, restore drills, privacy/legal terms and incident response before selling public access. Existing owner loss requires operator-assisted database recovery, not a hidden default account.

## Optional Stripe plumbing (disabled by default)

Without billing configuration the app says checkout is unavailable; local sharing remains usable without a paid license. Do not configure live keys until the product, prices, policies and deployment have been reviewed. Configure all of these **server-only** values through your secret manager/process environment, not source control or the Mac client:

- `STRIPE_SECRET_KEY`: Stripe test secret for initial integration, later an explicitly approved live secret.
- `STRIPE_WEBHOOK_SECRET`: signing secret for the configured endpoint.
- `STRIPE_PRICE_ID`: fixed recurring team price. The client cannot choose price/customer/quantity.
- `MF_PUBLIC_ORIGIN`: reviewed HTTPS origin used for fixed `/billing/return` URLs.
- Optionally `MF_REQUIRE_LICENSE=1`: server-enforced publishing gate. Reads/imports remain available. This setting fails startup if Stripe is incomplete.

Configure a Stripe snapshot webhook at `/v1/stripe/webhook` for `customer.subscription.created`, `.updated`, and `.deleted`, and activate the customer portal in Stripe. Stripe calls are server-only, fixed to `api.stripe.com`, refuse redirects and use a pinned API version (`2025-06-30.basil`). Verify your account supports this version before external deployment. Owner checkout creates a subscription with the configured price/customer and team metadata. Open checkout sessions are reused; completed checkout without reconciled entitlement blocks a second purchase. Any existing subscription record, including a canceled one, blocks replacement checkout: use the portal or operator reconciliation rather than risk duplicate subscriptions. No account credentials or prompts are sent as Stripe metadata.

Webhook HMAC-SHA256 verification uses the exact raw body, constant-time comparisons, a five-minute timestamp tolerance and persisted event IDs. The handler retrieves the current subscription from Stripe before changing entitlement, so stale event deliveries cannot re-grant a canceled subscription. Only the configured price and mapped customer can grant active/trialing entitlement, bounded by the item's current-period end. Webhook failures return an error for Stripe retry; the application does not accept the checkout redirect as proof of payment. A delayed webhook can temporarily deny publishing; monitor/reconcile failed events. Subscription replacement and pricing migrations require operator review. A failed network response may leave a created customer/session; idempotency keys prevent ordinary retry duplication, but production reconciliation/monitoring remains required.

Primary implementation references: [Checkout session creation](https://docs.stripe.com/api/checkout/sessions/create), [customer portal sessions](https://docs.stripe.com/api/customer_portal/sessions/create), [webhook verification and duplicate handling](https://docs.stripe.com/events/manage-webhook-endpoints), and [subscription events](https://docs.stripe.com/billing/subscriptions/webhooks). Read and test the current Stripe account configuration before enabling payment; no live configuration was performed here.
