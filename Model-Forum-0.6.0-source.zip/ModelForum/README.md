# Model Forum 0.6.0 — local commercial preview

A native SwiftUI workspace for conversations across OpenAI, Claude, local Ollama, and an installed Claude Code CLI. Requires macOS 14 or later. This is a working local preview, not a production team release.

## Start

Extract `Model-Forum-0.6.0-macOS.zip` into a local folder, open `Model Forum.app`, then **Settings → Connections** (⌘,). Choose the ChatGPT account route, the official Claude tool, or API-key access. For API access, paste your existing key into that provider's secure field and click **Save to Keychain**. Click **Load models**, then choose a model from the dropdown. You can also choose **Enter a model ID…** for a custom identifier. Keys are not stored in the source, workspace JSON, UserDefaults, or chat history. Saving a key does not validate it or incur an API charge. Load models makes a catalog request; Send and Generate image make generation requests billed to your provider account. Do not share keys in chat.

Before your first generation request, review **Settings → Instructions & Privacy → Privacy**, confirm the data settings for your provider account, and click **Save settings**. Replacing or removing an API key clears its saved confirmation. Each person uses their own provider credentials. The app does not bundle a developer key. Optional team and licensing services are separate from provider billing. Keychain entries use service `com.modelforum.desktop.credentials`, with a separate account for each API provider. The local preview uses an ad-hoc signature; rebuilds can cause Keychain to ask for access again.

## Use

- Start a message with `@gpt`, `@claude`, `@local`, or `@claude-code`. The selected recipient is used if no leading mention is present.
- Use `@gpt @claude <question>` or **Compare** for independent answers using the same conversation context and their respective saved agent instructions. Calls run sequentially; the second model does not receive the first answer in that comparison.
- Click **Critique** under an answer and choose another recipient. Use conversation context or only the selected answer.
- **Preview context** shows the exact text and recipients before sending. Provider credentials are separate.
- **Attach GitHub** accepts repository links such as `https://github.com/rtakloo/Chatgpt`, as well as issue and pull-request links. Repository imports contain an overview, default-branch revision, README excerpt, and top-level file listing. They do not load the full codebase. Issue/PR imports contain the title/body and PR revision metadata. Review the context, then attach. It is sent to models only on your next Send with conversation context enabled. The separate Review/create PR action previews bounded diffs between existing branches; this context importer does not attach diffs, comments, or individual source files. Local code edits are not implemented. This import action is read-only; channel file autosave is configured separately.
- **Stop** cancels locally. A provider may still bill a request already received. OpenAI API and ChatGPT responses stream into a temporary reply preview; Anthropic and Ollama replies currently appear when complete. Incomplete output is not saved as a completed reply or extracted into files.

## Account labels and response limits

**Settings → Connections** shows each provider's connection type, email, and account ID. Expand **Edit local account labels**, enter optional email/ID/organization/project notes, then click **Save account labels**. The conversation composer also has **Current model accounts**. API labels remain explicitly unverified and user-entered. ChatGPT sign-in displays the verified identity returned by OpenAI; the Claude tool displays the email and account ID it reports, or explicitly marks missing fields unavailable. Local Ollama models need no account, and cloud routing/account identity is not verified.

Labels are stored locally, excluded from prompts and generated-file uploads, and never used as organization/project routing headers. Replacing/removing a key inside Model Forum clears the corresponding labels and privacy confirmation before changing Keychain. Claude tool identity is checked before generation and changed identities reset privacy confirmation. External API-key account changes cannot be reliably detected; review API labels and confirmations yourself. Labels describe current connections, not the accounts that produced historical messages. Never enter credentials in label fields.

**Request limits → Output token cap per request** offers 1,024 through 32,768 tokens and preserves existing/custom settings. A larger cap may increase costs and remains subject to model limits. OpenAI reasoning tokens count toward this cap, potentially leaving no visible text. The app now distinguishes a reported output/context limit from content filtering and unknown incomplete responses; an incomplete answer is not saved as a completed answer or extracted into files. No automatic retry or spending increase is performed.

ChatGPT/Codex credits do not fund this app's OpenAI API connection. Use **Open OpenAI API billing** to inspect the organization/project associated with your API key. HTTP 429 errors distinguish recognized exhausted-credit, spending-limit, usage-limit, and traffic-limit codes without displaying provider error prose. The old message “The output limit may have been reached” was generic and does not prove either a token limit or an exhausted account balance. The next request in this version will show a more specific reason when supplied by OpenAI.

## Formatted replies and equations

Assistant replies render Markdown headings, emphasis, lists, tables, quotes, links, and code blocks. LaTeX math renders inline with `\( ... \)` or `$...$`, and in display equations with `\[ ... \]` or `$$...$$`. A `math` code fence also renders as a display equation. Other code fences, including `latex` and `tex` source files, remain literal. New requests tell models to use these conventions. In table cells, write absolute-value bars as `\lvert x\rvert` and norm bars as `\Vert x\Vert`; raw `|` characters are Markdown column separators.

Click **Source** beneath an answer to inspect its original text, and **Formatted** to return. **Copy**, saved history, artifacts, and later conversation context retain the original text. Existing Markdown and LaTeX replies render immediately; old plain-text formulas such as `sqrt(...)` remain as written. Ask the model to restate those in LaTeX to typeset them.

Rendering uses bundled Markdown, sanitization, math, and font resources without a rendering service or remote assets. Raw HTML is sanitized; remote images are not loaded. Explicit HTTP(S) links open in the default browser. Unsupported math stays readable as source. Very large messages or rendering failures show the full original source with a notice. Long formatted replies scroll within their card. Rendering equations does not compile or create a PDF; use **Compile PDF** on a generated `.tex` file for that.

## Channels and generated files

1. Click **+** next to **CHANNELS**, enter a channel name and optionally a GitHub repository URL or `owner/repository`.
2. Enable **Automatically save new files to GitHub** and save. This authorizes the app to create the `model-forum-artifacts` branch when needed and commit generated files there using the connection selected in Settings → GitHub (GitHub App or the existing GitHub CLI). The repository must already have a default-branch commit and your account must have Contents write access.
3. Select the channel and click **New conversation**. To file an existing conversation, use **Move** in its header or right-click it in the sidebar. Use the channel's **…** button to rename it or change settings.
4. Ask a model to produce a complete file, for example `@gpt Create a standalone LaTeX document named paper.tex explaining this argument.` Complete named text files become file cards. **Image** opens an OpenAI image-model dropdown and an explicit billed generation action; one medium-quality 1024×1024 PNG is requested. Image generation sends the entered description only, not the conversation or its files.
5. Each card shows local, queued, uploaded, paused, or failed status. **Show in Finder** reveals the local file, **View on GitHub** opens the saved revision, and **Retry upload** retries a failure at its original destination.

Files are saved locally before they are queued for upload. The first file creates its GitHub folder automatically; no empty placeholder directory is created. Paths use stable IDs:

```text
model-forum/channels/<channel-id>/conversations/<conversation-id>/<file-id>/paper.tex
```

Renaming a channel preserves its folder. Moving a conversation or changing its repository affects **future generated files**; existing files retain their original destination. Disabling autosave or changing the linked repository pauses pending uploads to the former destination. Restoring its original settings resumes them. A write already accepted by GitHub can finish even after cancellation. Failed uploads require Retry; interrupted pending uploads resume on launch. Each file uses a unique path and a retry checks content before writing, so it cannot overwrite a different file.

Text deliverables use fenced blocks such as ` ```latex filename=paper.tex ` followed by complete file contents and a closing fence. Standalone LaTeX documents are also recognized. Ordinary code snippets and remote image links are not downloaded or saved as files. A reply supports up to eight files, each up to 8 MiB. LaTeX is saved as `.tex` source, with an optional **Compile PDF** action described below. Generated files are never executed automatically. PDF compilation runs only when you click Compile PDF. Files on disk are not automatically included in later model prompts. Conversation transcripts are not uploaded to GitHub.

## Recoverable channel deletion

Choose **Delete channel** in the channel's context menu or settings. This hides the channel and pauses its automatic uploads while preserving all conversations, local artifacts, stable folders, and GitHub files. Open **Recently deleted** in the sidebar and click **Restore** to recover it. Settings → Data offers retention reminders and explicit permanent deletion of selected already-deleted channels. Recently deleted also has a permanent-delete confirmation. Permanent deletion removes local conversations/files, but does not erase recovery backups, GitHub copies, or team snapshots. Retention reminders do not delete automatically. Restoration leaves automatic uploads off; re-enable them in channel settings when desired. An upload already accepted by GitHub may finish even if the channel is deleted. Names of deleted channels remain reserved so restoration cannot create ambiguous names.

## Instructions and privacy settings

**Settings → Instructions & Privacy → Instructions** contains a shared instruction editor and an agent dropdown for individual instructions. Click **Save settings**. Each new text request receives shared instructions plus only the addressed agent's individual instructions. Compare and critique preserve the same behavior; **Preview context** and answer **Details** show the actual recipient-specific text. Image generation receives global instructions plus the GPT agent instructions. Each instruction field supports 20 KB; total text request context supports 240 KB. These preferences guide responses and do not grant tool permissions or change provider policies.

**Require no-training account settings** is enabled by default. It blocks sending or image generation until you review the relevant provider's external controls and save your confirmation. The app does not train models or send telemetry. It cannot inspect or change the provider's account settings: confirmations are user declarations, not verified guarantees. Turning the check off removes this app's preflight gate; it does not opt into training.

- OpenAI API data is excluded from training by default unless an account opts into sharing. Review organization/project controls. Text requests always use `store: false`; this controls response storage and does not establish zero retention.
- Anthropic commercial API content is excluded from training by default, subject to opt-in programs/feedback and applicable agreements.
- Claude Code account type and data/privacy settings apply even though the executable is local. Configured gateways/providers may have different policies.
- Ollama's loopback server can still route to cloud models. Review server and model routing, or disable its cloud features for local-only operation.

Key changes require a durable reset of the corresponding confirmation before Keychain is changed. Stale settings drafts cannot re-enable a confirmation for a changed account. Claude tool identity changes are checked before requests. Other external account-policy/API-key changes cannot be detected reliably; review confirmations after those changes. No-training is different from retention, local history, and public GitHub exports. Existing exported content and requests already sent cannot be recalled by this setting.

## Compile LaTeX to PDF

Click **Compile PDF** on a `.tex` file card. Compilation runs locally through installed MacTeX/BasicTeX `pdflatex` and macOS `sandbox-exec`. **Settings → PDF** shows installed-tool status. A successful two-pass compilation adds a new PDF card to the source conversation and applies that conversation's channel autosave destination. The original `.tex` is preserved. **Stop** cancels compilation.

The compiler uses an isolated temporary job, no shell escape, no first-line command parsing, no network, and no child processes. Reads are restricted to the job and trusted TeX/system runtime directories; writes are restricted to seven expected job outputs. CPU, elapsed time, output, and file-size limits apply. Sources must be UTF-8 and at most 2 MiB; resulting PDFs are limited to 8 MiB. Only the selected source is supplied: external images, BibTeX/Biber, user packages and automatically downloaded packages are not supported. Failures retain the source and show an error. There is no unsandboxed fallback.

Installed-engine detection does not prove that the macOS sandbox can start. The development environment denied sandbox creation (`sandbox_apply: Operation not permitted`), so actual compilation and sandbox enforcement were not verified there. Mocked compiler and application integration tests cover handling, limits and storage behavior. Live compilation remains to be checked when running the app directly on your Mac.

## Installed tools

GitHub uses an existing authenticated `gh` installation at `/opt/homebrew/bin/gh` or `/usr/local/bin/gh`. Configure the CLI outside the app with your own account. Issue/PR imports use `issue view` and `pr view` with fixed JSON fields. Repository imports use fixed read-only API requests; channel autosave uses branch and Contents API writes. File data is passed as JSON through stdin. Repository text never becomes a shell command.

Claude Code uses a user-authenticated executable at `/opt/homebrew/bin/claude`, `/usr/local/bin/claude`, or `~/.local/bin/claude`. It requires a recent version supporting the security flags in `LocalTools.swift`; unsupported flags cause failure rather than weaker execution. Prompts go over stdin. The CLI runs in an isolated temporary working directory with ordinary tools, user/project settings, MCP servers, and ordinary hooks disabled. Managed administrator policies/hooks can still apply. This is not an OS sandbox, and the app trusts the installed CLI and its authentication system. Codex CLI is not integrated in this preview.

Ollama must already be running locally with the named model downloaded. The endpoint is fixed to `http://127.0.0.1:11434`. Selecting a cloud model in Ollama may still send data remotely.

## Storage and privacy

Conversations and model configuration are saved in `~/Library/Application Support/ModelForum/workspace.json` with owner-only file permissions. The channel migration backs up older history to `workspace-before-channels.json`; this settings/recovery upgrade backs up the previous workspace bytes to `workspace-before-settings.json`. The account-label upgrade preserves previous bytes in `workspace-before-account-labels.json`; schema 5 preserves them in `workspace-before-commercial-preview.json`. Generated files live in the sibling `artifacts/` directory with owner-only permissions. The JSON and artifacts are not encrypted. Provider prompts include the selected context; providers apply their own retention policies. OpenAI requests use `store: false`, which is not a promise of zero retention. No analytics backend is implemented. Avoid attaching secrets as conversation content.

API requests use fixed origins, no cookies, ephemeral sessions, and blocked redirects. HTTP error bodies are not shown or persisted. Models are never given tool definitions by the API adapters, and model-generated mentions never schedule requests. Output token/context limits bound API requests. Settings → Usage adds local API cost reservations and caps using prices you enter; these are estimates rather than provider balances or a guarantee of the final bill.

## Build and test

Install Xcode or a compatible Swift toolchain, then:

```sh
swift test
bash build-app.sh
```

The script builds a release executable for the current Mac architecture and produces `../Model-Forum-0.6.0-macOS.zip` containing the app with an ad-hoc signature. The unpackaged app stays in the temporary build directory. Debug symbols are omitted from this preview. Set `MODEL_FORUM_BUILD_ROOT` to put compiler caches/build products outside the source folder. No package dependencies or credential-bearing configuration files are required to build or run the mocked tests.

Renderer regression tests and their local jsdom setup are described in `Tests/RendererTests/README.txt`. On a Mac that can start WebKit child processes, run `MODEL_FORUM_TEST_WEBKIT=1 swift test --filter RendererIntegrationTests` to check bundled file loading, math, code preservation, local fonts, and the native message bridge. The ordinary suite skips this environment-dependent test.

## Account connections in 0.6

**Settings → Connections** explicitly selects API-key access or **Continue with ChatGPT** for GPT. Browser sign-in uses the official PKCE/loopback flow, verifies the returned identity, and stores refresh credentials in a separate Keychain service. Identity consent and eligible plan inference are separate: an identity-only sign-in does not authorize model use. Switching mode/account clears that provider's saved privacy confirmation. The app never silently falls back to paid API access. OpenAI availability and commercial approval still apply; no partner approval or live login has been obtained for this project. ChatGPT plan requests do not support an output-token cap, so the app rejects token-budget workflows on that route; choose fixed rounds or explicitly use API access. Image generation remains API-only.

The Claude tool section opens `claude auth login` in Terminal and can check or sign out of that tool's current account. Sign-out also affects other uses of the installed tool. No Claude browser cookies or unofficial session credentials are imported. A supported recent official CLI and the provider's applicable eligibility/approval are required. API-key mode remains separate. The app never invents account IDs or a remaining-credit balance.

Primary references: [OpenAI Sign in with ChatGPT](https://developers.openai.com/siwc/quickstart), [token-sharing limitations](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations), [Claude CLI reference](https://code.claude.com/docs/en/cli-reference). Implemented protocol support is not evidence of approval to commercially distribute an integration.

## GitHub App, workflows, and usage

Settings → GitHub offers an explicit GitHub App route. Register your own app, enable device flow, configure selected-repository access and permissions, then enter its public client ID. The user token is kept in Keychain; no client secret is embedded. Imports require read access; generated-file uploads require Contents write; PR creation requires Pull requests write. Installation/repository permissions are checked. Existing authenticated CLI access remains selectable. Connection changes pause channel autosave until you review and re-enable it.

Review/create PR previews a bounded diff between two **existing branches in the same repository**, then requires explicit Create PR. It does not create commits or push local changes. Oversized diffs are rejected rather than silently approved. No GitHub app was registered and no live PR/upload was performed during development.

Settings → Workflows saves draft → critique → revise sequences with selected models, 1–5 rounds, optional output-token budgets, and an exact critic stop marker. Each completed step is saved before the next request. The selected context scope and shared/per-agent instructions apply. Generated files follow the channel's authorized autosave settings. Errors stop the sequence; there is no autonomous retry. Compare answers opens two saved answers side by side.

Settings → Usage records requests and estimates API costs from your price entries. Per-request, per-conversation and UTC-month caps reserve a conservative input estimate plus the output cap before generation. Failed/interrupted requests retain their reservation; unknown prices or costs prevent additional capped API requests. A differently resolved model invalidates its price estimate. Subscription use is identified separately and no currency charge is fabricated. Unknown external/local billing cannot use currency caps. Image generation is blocked while currency caps are enabled because image pricing is not yet modeled. These controls cover this local workspace, not other applications, users, accounts, or server-enforced organization budgets.

## Teams, billing, data, and support

[Server/README.md](Server/README.md) contains the local server bootstrap, two-account test and deployment requirements. The user has selected local development and later deployment after review. No hosting or payment account is configured. Settings → Team connects to a manually started local service, authenticates individual members, enforces owner/editor/viewer roles, offers invitations/offboarding/audit history, and shares explicit conversation snapshots with revision conflict checks. Provider credentials, request context, instructions and generated files are excluded from that share operation. Visible message text is still shared and must be reviewed. This is not realtime co-editing or full workspace synchronization.

Settings → Billing has configurable Stripe checkout/portal and server-validated entitlement plumbing. Without operator configuration it reports unavailable. No live payment, merchant account or license was created. Password recovery, email verification, MFA/SSO, multi-tenant onboarding, production transport/monitoring and legal review remain required for public distribution.

Search filters conversations in the selected channel by title or message text. Export saves Markdown/source or a portable JSON conversation. A full backup contains the local workspace and generated file bytes, including private request context and account labels; it contains no provider credentials. Keep backups private. Restore validates bounded contents and hashes, preserves the preceding workspace for recovery, resets privacy confirmations/account labels, and pauses GitHub autosave. Local deletion does not remove already shared remote copies or backups. Settings → PDF now provides an explicit on-device compiler smoke test; real sandboxed PDF compilation still needs verification outside the development sandbox.

First-run onboarding explains connections, privacy and conversation controls. About & updates shows data handling, configuration status and sanitized diagnostics that can be copied for support. A publisher support address, customer terms, refund policy and incident response process have not been invented; those require business setup and review.

## Distribution and signed updates

`build-app.sh` builds for the current architecture. Without a signing identity it produces an ad-hoc development app; this release is **not notarized** and Keychain may ask again after replacement. Keep the bundle identifier and future Developer ID team stable. Optional `MODEL_FORUM_SIGNING_IDENTITY` selects a Developer ID Application identity already in your Keychain. `MODEL_FORUM_NOTARY_PROFILE` selects a previously configured notarytool Keychain profile and triggers upload, wait, stapling and Gatekeeper verification. Those external actions were not run for this preview. See [Apple distribution guidance](https://developer.apple.com/macos/distribution/).

Optional public build settings `MODEL_FORUM_UPDATE_FEED`, `MODEL_FORUM_UPDATE_PUBLIC_KEY` (base64 Ed25519 public key) and `MODEL_FORUM_UPDATE_HOST` pin a signed update feed and ZIP download host. `scripts/sign-update.swift` signs a release manifest using a separate owner-readable private key file; never embed that key in the app/repository. The client validates the signature, version/build, OS requirement, expiry, HTTPS host, size and SHA-256 before saving. ZIPs stream to private temporary files; installation remains a deliberate quit-and-replace action. No feed, hosting, publisher key, automatic installer, downgrade recovery drill, universal build, or production update service has been activated. The previous workspace is backed up before schema migration; quit older Model Forum copies before using the new build.

## Remaining release gates

- Obtain provider approvals/eligible account access; exercise real sign-in, refresh, account switching, generation and Keychain behavior.
- Register/install the GitHub App and test selected-repository permissions and branch policies with a controlled repository.
- Obtain Apple Developer credentials; notarize and test upgrades/Gatekeeper across supported macOS versions and Intel hardware.
- Choose hosting/payment/identity operations, review the server limits in its README, perform security and restore testing, then review deployment separately.
- Verify native UI, local WebKit and sandboxed PDF behavior on a normally launched Mac app. Mocked tests do not establish those runtime behaviors.

## 0.1.1 update

Repository-root URLs are now accepted in Attach GitHub. Connections now has model dropdowns, provider catalog loading, and custom-ID entry. Loading a model list sends a metadata request, not a generation request; it does not share conversation context. OpenAI catalog filtering uses known text-model naming families because the catalog does not provide endpoint-capability metadata. A listed model may still be subject to account or endpoint restrictions; custom IDs remain supported. Ollama lists installed models, and Claude Code offers built-in aliases. Existing conversation storage and Keychain service identifiers are unchanged. Quit the old app before opening the new version; macOS may ask to grant the rebuilt app access to its saved Keychain entries. The import preview describes the scope so models are not presented with an overview as if it were the complete repository.

## 0.2.0 update

Adds named channels, conversation moves, generated-file storage, OpenAI image generation, and durable automatic GitHub uploads on `model-forum-artifacts`. Quit the older app before opening this build. Existing history and Keychain identifiers are preserved; the old workspace is backed up before migration. The preview remains ad-hoc signed, and macOS may request Keychain access again. Live account access and native UI interaction still require verification on your Mac.

## 0.3.0 update

Adds optional local LaTeX compilation, recoverable channel deletion, shared and individual agent instructions, and a no-training account confirmation gate. Quit the previous app before opening this version. History, credentials, channel IDs, and existing artifact destinations are preserved. Settings are backed up before schema migration. The preview is locally ad-hoc signed and not notarized for public distribution.

## 0.4.0 update

Adds offline Markdown and LaTeX display for assistant replies, a Source/Formatted toggle, and formatting instructions for new responses. Quit the previous app before opening this version. Existing history and Keychain identifiers are preserved. Bundled renderer assets and fonts are included in the app archive. The preview remains locally ad-hoc signed.

## 0.4.1 update

Selecting a rendered formula and copying it puts LaTeX on the clipboard, including when the selection starts or ends inside the formula. Inline formulas use `\( ... \)` and display formulas use `\[ ... \]`. Mixed prose and formulas retain readable text around the LaTeX. The whole-answer **Copy** button continues to copy the original Markdown/source.

Mouse-wheel and trackpad scrolling over reply text now passes to the conversation when the reply has no further vertical content to scroll. Very long replies retain their internal scrolling, with handoff to the conversation at the top and bottom. Horizontal scrolling in wide code, tables, and equations remains available.

## 0.5.0 update

Adds local, explicitly unverified account labels for each provider and a current-account list in the composer. Improves OpenAI incomplete-response and billing/rate-limit messages and adds larger per-request cap choices. Existing limits remain unchanged. Quit the previous app before opening this version; schema 4 migration backs up existing workspace bytes and preserves conversation/settings data. This preview remains ad-hoc signed; macOS may request Keychain access again. Automatic verified account discovery and live billing-balance retrieval are not implemented.

## 0.6.0 update

Adds official account-connection plumbing, optional GitHub App authentication and reviewed PR creation, bounded workflows, OpenAI streaming, local usage estimates/caps, explicit team snapshot sharing, configurable billing, data export/backup/restore, permanent channel deletion, onboarding, and signed-update verification. Schema 5 keeps a byte-for-byte migration backup. Restore uses a durable journal so a process interruption recovers the prior workspace. Credential refresh locking lives outside the replaceable workspace directory. Quit all older app copies before opening this build. External services are unconfigured and live provider, GUI, PDF, payment and public distribution checks remain release gates.
