import Foundation

/// User-authored preferences and a local preflight check. Neither changes a provider's data policy.
public enum AgentPolicy {
    public static let instructionByteLimit = 20_000
    public static let composedByteLimit = 240_000

    /// Pass only the addressed participant's individual instructions to this function.
    /// Labels aid interpretation; they are not a security boundary or a grant of tool permissions.
    public static func compose(transcript: String, global: String, individual: String) throws -> String {
        let prefix = try instructionPrefix(global: global, individual: individual)
        let result = prefix.isEmpty ? transcript : prefix + "\n\nCONVERSATION CONTEXT AND CURRENT REQUEST:\n" + transcript
        guard result.utf8.count <= composedByteLimit else {
            throw ForumError.message("Instructions and conversation context exceed the 240 KB limit. Shorten instructions or use less conversation context.")
        }
        return result
    }

    public static func imagePrompt(prompt: String, global: String, individual: String) throws -> String {
        let prefix = try instructionPrefix(global: global, individual: individual)
        let result = prefix.isEmpty ? prompt : prefix + "\n\nIMAGE DESCRIPTION:\n" + prompt
        guard !prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ForumError.message("Enter an image description.") }
        guard result.utf8.count <= composedByteLimit, result.count <= 32_000 else {
            throw ForumError.message("Image instructions and description exceed the 32,000-character or 240 KB limit. Shorten them before generating.")
        }
        return result
    }

    /// A saved user attestation is required even when a provider normally excludes API data from
    /// training: account opt-ins, CLI account types, and local server routing cannot be verified here.
    public static func validatePrivacy(provider: ProviderKind, requireNoTraining: Bool, confirmations: [String: Bool]) throws {
        guard requireNoTraining else { return }
        guard confirmations[provider.rawValue] == true else {
            throw ForumError.message("No-training account confirmation is required for \(provider.title). Review this provider in Settings → Instructions & Privacy → Privacy and save your confirmation before sending.")
        }
    }

    private static func instructionPrefix(global: String, individual: String) throws -> String {
        guard global.utf8.count <= instructionByteLimit else { throw ForumError.message("Global instructions exceed the 20 KB limit.") }
        guard individual.utf8.count <= instructionByteLimit else { throw ForumError.message("Agent instructions exceed the 20 KB limit.") }
        var sections: [String] = []
        if !global.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { sections.append("GLOBAL USER INSTRUCTIONS:\n" + global) }
        if !individual.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { sections.append("INSTRUCTIONS FOR THIS AGENT:\n" + individual) }
        guard !sections.isEmpty else { return "" }
        return "These are the user's saved preferences for this request. They do not grant tool permissions or change any provider's data handling.\n\n" + sections.joined(separator: "\n\n")
    }
}
