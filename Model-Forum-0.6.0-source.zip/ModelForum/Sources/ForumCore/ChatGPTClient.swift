import Foundation

public enum ChatGPTSessionError: LocalizedError {
    case renewableSessionExpired
    public var errorDescription: String? { "The ChatGPT session can no longer be renewed. Sign in again with this saved account." }
}

/// Dedicated SIWC transport. Never accepts API keys or calls ChatGPT backend-api endpoints.
public final class ChatGPTClient: @unchecked Sendable {
    private let session: URLSession
    private let ownsSession: Bool
    private static let issuer = "https://auth.openai.com"
    private static let tokenURL = URL(string: "https://auth.openai.com/api/accounts/oauth/token")!
    public init(session: URLSession = .shared) {
        if session === URLSession.shared {
            let config = URLSessionConfiguration.ephemeral
            config.urlCache = nil; config.httpCookieStorage = nil; config.urlCredentialStorage = nil
            config.timeoutIntervalForRequest = 60; config.timeoutIntervalForResource = 180
            self.session = URLSession(configuration: config); ownsSession = true
        } else { self.session = session; ownsSession = false }
    }
    deinit { if ownsSession { session.invalidateAndCancel() } }

    public func exchange(code: String, clientID: String, authorization: ChatGPTAuthorization) async throws -> (ChatGPTCredentials, ChatGPTIdentity) {
        let json = try await token(["grant_type": "authorization_code", "client_id": clientID, "code": code,
                                    "code_verifier": authorization.verifier, "redirect_uri": authorization.redirectURI.absoluteString,
                                    "resource": "https://api.openai.com/v1"])
        let credentials = try Self.credentials(json)
        guard let idToken = credentials.idToken else { throw ForumError.message("ChatGPT did not return an identity token. Start sign-in again.") }
        let identity = try await verify(idToken, clientID: clientID, nonce: authorization.nonce)
        return (credentials, identity)
    }

    public func refresh(_ previous: ChatGPTCredentials, clientID: String, expectedIdentity: ChatGPTIdentity) async throws -> ChatGPTCredentials {
        guard let refreshToken = previous.refreshToken else { throw ChatGPTSessionError.renewableSessionExpired }
        let json = try await token(["grant_type": "refresh_token", "client_id": clientID, "refresh_token": refreshToken,
                                    "resource": "https://api.openai.com/v1"], refreshing: true)
        let refreshed = try Self.credentials(json, previous: previous)
        guard refreshed.refreshToken != nil else { throw ForumError.message("ChatGPT did not return a renewable session. Sign in again.") }
        if let idToken = json["id_token"] as? String {
            let identity = try await verify(idToken, clientID: clientID, nonce: nil)
            guard identity.subject == expectedIdentity.subject else { throw ForumError.message("The refreshed ChatGPT identity did not match the saved account.") }
        }
        return refreshed
    }

    public func revoke(_ credentials: ChatGPTCredentials, clientID: String) async throws {
        guard let refreshToken = credentials.refreshToken else { return }
        let discovery = try await discover()
        guard let endpoint = discovery["revocation_endpoint"] as? String, let url = URL(string: endpoint), Self.trustedAuthURL(url) else {
            throw ForumError.message("ChatGPT did not publish a trusted session revocation endpoint.")
        }
        _ = try await fetch(Self.formRequest(url, ["token": refreshToken, "token_type_hint": "refresh_token", "client_id": clientID]), limit: 65_536)
    }

    public func models(credentials: ChatGPTCredentials) async throws -> [ModelOption] {
        try Self.requirePermission(credentials)
        let data = try await fetch(Self.apiRequest("models", credentials: credentials), limit: 2 * 1024 * 1024)
        guard let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any], let rows = json["models"] as? [[String: Any]], rows.count <= 1000 else {
            throw ForumError.message("ChatGPT returned an invalid account model catalog.")
        }
        var seen = Set<String>()
        return try rows.filter { $0["visibility"] as? String == "list" }.compactMap { row in
            guard let slug = Self.label(row["slug"]), let name = Self.label(row["display_name"]) else { throw ForumError.message("ChatGPT returned invalid model metadata.") }
            return seen.insert(slug).inserted ? ModelOption(id: slug, name: name) : nil
        }
    }

    public func reply(model: String, transcript: String, credentials: ChatGPTCredentials, onText: (@Sendable (String) async -> Void)? = nil) async throws -> ModelReply {
        try Self.requirePermission(credentials)
        guard Self.label(model) != nil, !transcript.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, transcript.utf8.count <= 240_000 else {
            throw ForumError.message("Choose a ChatGPT model and keep the request within the 240 KB context limit.")
        }
        var request = Self.apiRequest("responses", credentials: credentials)
        request.httpMethod = "POST"; request.setValue("text/event-stream", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        // SIWC preview forbids max_output_tokens; this route has a local response bound instead.
        request.httpBody = try JSONSerialization.data(withJSONObject: ["model": model, "input": [["role": "user", "content": transcript]], "store": false, "stream": true])
        do {
            let (bytes, response) = try await session.bytes(for: request, delegate: ProviderRedirectGuard())
            defer { bytes.task.cancel() }
            guard let http = response as? HTTPURLResponse else { throw ForumError.message("ChatGPT returned an invalid HTTP response.") }
            if !(200..<300).contains(http.statusCode) {
                let data = try await Self.collect(bytes, limit: 65_536)
                throw Self.serverError(status: http.statusCode, data: data)
            }
            guard http.value(forHTTPHeaderField: "Content-Type")?.lowercased().hasPrefix("text/event-stream") == true else {
                throw ForumError.message("ChatGPT did not open a response stream.")
            }
            return try await withTaskCancellationHandler {
                var decoder = ChatGPTEventDecoder()
                var total = 0; var textBytes = 0
                for try await byte in bytes {
                    total += 1
                    if total.isMultiple(of: 16_384) { try Task.checkCancellation() }
                    guard total <= 4 * 1024 * 1024 else { throw ForumError.message("ChatGPT output exceeded the local 4 MB response limit and was stopped. Generated tokens may still count toward your plan or credits.") }
                    if let event = try decoder.append(byte) {
                        let result = try Self.process(event, requestedModel: model)
                        if let delta = result.delta {
                            textBytes += delta.utf8.count
                            guard textBytes <= 200_000 else { throw ForumError.message("ChatGPT output exceeded the local 200 KB text limit and was stopped. Generated tokens may still count toward your plan or credits.") }
                            await onText?(delta)
                        }
                        if let reply = result.reply { try Task.checkCancellation(); return reply }
                    }
                }
                throw ForumError.message("ChatGPT's stream ended before a completed response. No completed answer was accepted.")
            } onCancel: { bytes.task.cancel() }
        } catch { throw Self.safe(error) }
    }

    private func verify(_ idToken: String, clientID: String, nonce: String?) async throws -> ChatGPTIdentity {
        let discovery = try await discover()
        guard let value = discovery["jwks_uri"] as? String, let url = URL(string: value), Self.trustedAuthURL(url) else {
            throw ForumError.message("ChatGPT did not publish a trusted identity verification endpoint.")
        }
        let jwks = try await fetch(URLRequest(url: url), limit: 512 * 1024)
        return try ChatGPTTokenValidation.identity(idToken: idToken, jwks: jwks, clientID: clientID, nonce: nonce)
    }
    private func discover() async throws -> [String: Any] {
        let data = try await fetch(URLRequest(url: URL(string: Self.issuer + "/.well-known/openid-configuration")!), limit: 65_536)
        guard let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any], json["issuer"] as? String == Self.issuer,
              json["authorization_endpoint"] as? String == Self.issuer + "/api/accounts/authorize",
              json["token_endpoint"] as? String == Self.tokenURL.absoluteString else { throw ForumError.message("ChatGPT identity configuration could not be verified.") }
        return json
    }
    private func token(_ values: [String: String], refreshing: Bool = false) async throws -> [String: Any] {
        let data = try await fetch(Self.formRequest(Self.tokenURL, values), limit: 512 * 1024, refreshing: refreshing)
        guard let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else { throw ForumError.message("ChatGPT returned an invalid sign-in response.") }
        return json
    }
    private func fetch(_ request: URLRequest, limit: Int, refreshing: Bool = false) async throws -> Data {
        do {
            try Task.checkCancellation()
            let (bytes, response) = try await session.bytes(for: request, delegate: ProviderRedirectGuard())
            defer { bytes.task.cancel() }
            guard let http = response as? HTTPURLResponse else { throw ForumError.message("ChatGPT returned an invalid HTTP response.") }
            let data = try await Self.collect(bytes, limit: limit)
            guard (200..<300).contains(http.statusCode) else { throw Self.serverError(status: http.statusCode, data: data, refreshing: refreshing) }
            return data
        } catch { throw Self.safe(error) }
    }
    private static func collect(_ bytes: URLSession.AsyncBytes, limit: Int) async throws -> Data {
        try await withTaskCancellationHandler {
            var data = Data()
            for try await byte in bytes {
                if data.count.isMultiple(of: 16_384) { try Task.checkCancellation() }
                guard data.count < limit else { throw ForumError.message("ChatGPT's response exceeded the local size limit.") }
                data.append(byte)
            }
            try Task.checkCancellation(); return data
        } onCancel: { bytes.task.cancel() }
    }
    private static func credentials(_ json: [String: Any], previous: ChatGPTCredentials? = nil) throws -> ChatGPTCredentials {
        guard json["token_type"] as? String == "Bearer", let access = tokenString(json["access_token"]),
              let seconds = json["expires_in"] as? Double, seconds.isFinite, seconds > 0, seconds <= 86_400 else {
            throw ForumError.message("ChatGPT returned incomplete session credentials.")
        }
        let scopes: [String]
        if let scope = json["scope"] as? String, scope.utf8.count <= 8192 { scopes = scope.split(separator: " ").map(String.init) }
        else if let previous { scopes = previous.scopes }
        else { scopes = [] }
        return ChatGPTCredentials(accessToken: access, refreshToken: tokenString(json["refresh_token"]), idToken: tokenString(json["id_token"]) ?? previous?.idToken,
                                  expiresAt: Date().addingTimeInterval(seconds), scopes: scopes)
    }
    private static func tokenString(_ value: Any?) -> String? {
        guard let value = value as? String, !value.isEmpty, value.utf8.count <= 65_536, value.utf8.allSatisfy({ (33...126).contains($0) }) else { return nil }
        return value
    }
    private static func label(_ value: Any?) -> String? {
        guard let value = value as? String, !value.isEmpty, value.utf8.count <= 512, !value.unicodeScalars.contains(where: CharacterSet.controlCharacters.contains) else { return nil }
        return value
    }
    private static func requirePermission(_ credentials: ChatGPTCredentials) throws {
        guard credentials.permitsInference else { throw ForumError.message("This account has not granted ChatGPT plan usage. Enable it through Continue with ChatGPT or select the separate API connection.") }
    }
    private static func trustedAuthURL(_ url: URL) -> Bool {
        url.scheme == "https" && url.host == "auth.openai.com" && (url.port == nil || url.port == 443) && url.user == nil && url.password == nil && url.fragment == nil && url.query == nil
    }
    private static func formRequest(_ url: URL, _ values: [String: String]) -> URLRequest {
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 60)
        request.httpMethod = "POST"; request.httpShouldHandleCookies = false
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let allowed = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~")
        request.httpBody = Data(values.sorted { $0.key < $1.key }.map { $0.key.addingPercentEncoding(withAllowedCharacters: allowed)! + "=" + $0.value.addingPercentEncoding(withAllowedCharacters: allowed)! }.joined(separator: "&").utf8)
        return request
    }
    private static func apiRequest(_ path: String, credentials: ChatGPTCredentials) -> URLRequest {
        var request = URLRequest(url: URL(string: "https://api.openai.com/v1/" + path)!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 120)
        request.httpShouldHandleCookies = false; request.setValue("Bearer \(credentials.accessToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept"); return request
    }
    private static func safe(_ error: Error) -> Error {
        if Task.isCancelled || error is CancellationError || (error as? URLError)?.code == .cancelled { return CancellationError() }
        if error is ForumError || error is ChatGPTSessionError { return error }
        if (error as? URLError)?.code == .timedOut { return ForumError.message("The ChatGPT connection timed out. Retry manually.") }
        return ForumError.message("Could not connect to ChatGPT. Check your connection and retry manually.")
    }
    private static func serverError(status: Int, data: Data, refreshing: Bool = false) -> Error {
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        let error = json?["error"] as? [String: Any]
        let code = (error?["code"] as? String) ?? (json?["error"] as? String)
        if refreshing, let code, ["invalid_grant", "invalid_refresh_token", "token_expired", "refresh_token_expired", "refresh_token_invalidated", "refresh_token_reused"].contains(code) { return ChatGPTSessionError.renewableSessionExpired }
        let reason: String
        switch code {
        case "subscription_sharing_usage_limit_exceeded": reason = "This app's ChatGPT usage limit was reached. Review ChatGPT Settings → Usage; the whole plan may still have usage available."
        case "subscription_sharing_user_not_eligible": reason = "ChatGPT plan usage is unavailable for this account, workspace, or policy."
        case "subscription_sharing_usage_unavailable", "subscription_sharing_user_unavailable": reason = "ChatGPT usage or account availability could not be checked. Retry later."
        case "subscription_sharing_unsupported_capability": reason = "The ChatGPT route does not support this request's model or capabilities."
        case "subscription_sharing_route_not_supported", "chatpass_v2_scope_not_authorized", "chatpass_v2_invalid_authorization_context": reason = "The ChatGPT integration or granted permissions do not authorize this request."
        case "invalid_grant": reason = "The authorization code expired or was already used. Start sign-in again with this saved registration."
        case "invalid_client": reason = "ChatGPT rejected the client registration. Review the integration configuration."
        default:
            switch status {
            case 401: reason = "ChatGPT did not accept this session. Check the selected account and sign in again if needed."
            case 403: reason = "ChatGPT account, workspace, regional, or integration permissions prevented this request."
            case 429: reason = "ChatGPT limited this request. Review ChatGPT Settings → Usage and retry later."
            case 503: reason = "ChatGPT plan routing is temporarily unavailable or not enabled for this integration."
            case 300..<400: reason = "Redirects were blocked to protect this session."
            default: reason = "ChatGPT could not complete this request. Retry manually."
            }
        }
        return ForumError.message("ChatGPT request failed (HTTP \(status)). \(reason)")
    }
    private static func process(_ data: Data, requestedModel: String) throws -> (delta: String?, reply: ModelReply?) {
        guard let event = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any], let type = event["type"] as? String else { throw ForumError.message("ChatGPT returned an invalid stream event.") }
        if type == "response.output_text.delta" {
            guard let delta = event["delta"] as? String else { throw ForumError.message("ChatGPT returned an invalid text event.") }
            return (delta, nil)
        }
        if type == "response.failed" || type == "error" {
            let response = event["response"] as? [String: Any] ?? event
            throw serverError(status: 200, data: try JSONSerialization.data(withJSONObject: response))
        }
        if type == "response.incomplete" { throw ForumError.message("ChatGPT returned an incomplete response. No completed answer was accepted; the preview route does not support a per-request output token cap.") }
        guard type == "response.completed" else { return (nil, nil) }
        guard let response = event["response"] as? [String: Any], response["status"] as? String == "completed", let output = response["output"] as? [[String: Any]] else { throw ForumError.message("ChatGPT did not confirm a completed response.") }
        var parts: [String] = []
        for item in output where item["type"] as? String == "message" && item["role"] as? String == "assistant" {
            guard item["status"] as? String == "completed" else { throw ForumError.message("ChatGPT returned an incomplete message.") }
            for block in item["content"] as? [[String: Any]] ?? [] {
                if block["type"] as? String == "output_text", let text = block["text"] as? String { parts.append(text) }
                if block["type"] as? String == "refusal", let text = block["refusal"] as? String { parts.append(text) }
            }
        }
        let text = parts.joined(separator: "\n\n")
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, text.utf8.count <= 200_000 else { throw ForumError.message("ChatGPT returned empty text or exceeded the local 200 KB text limit. Generated tokens may still count toward your plan or credits.") }
        let usage = response["usage"] as? [String: Any] ?? [:]
        let input = (usage["input_tokens"] as? Int).flatMap { $0 >= 0 ? $0 : nil }
        let outputTokens = (usage["output_tokens"] as? Int).flatMap { $0 >= 0 ? $0 : nil }
        return (nil, ModelReply(text: text, model: response["model"] as? String ?? requestedModel, inputTokens: input, outputTokens: outputTokens))
    }
}

/// Bounded SSE parser; multiple data lines are joined according to the event-stream format.
struct ChatGPTEventDecoder {
    private var line = Data()
    private var event = Data()
    mutating func append(_ byte: UInt8) throws -> Data? {
        if byte != 10 {
            guard line.count < 2 * 1024 * 1024 else { throw ForumError.message("ChatGPT stream event exceeded the local size limit.") }
            line.append(byte); return nil
        }
        if line.last == 13 { line.removeLast() }
        defer { line.removeAll(keepingCapacity: true) }
        if line.isEmpty {
            guard !event.isEmpty else { return nil }
            let completed = event; event.removeAll(keepingCapacity: true)
            if completed == Data("[DONE]".utf8) { return nil }
            return completed
        }
        let prefix = Data("data:".utf8)
        if line.starts(with: prefix) {
            var data = line.dropFirst(prefix.count)
            if data.first == 32 { data = data.dropFirst() }
            if !event.isEmpty { event.append(10) }
            guard event.count + data.count <= 2 * 1024 * 1024 else { throw ForumError.message("ChatGPT stream event exceeded the local size limit.") }
            event.append(contentsOf: data)
        }
        return nil
    }
}
