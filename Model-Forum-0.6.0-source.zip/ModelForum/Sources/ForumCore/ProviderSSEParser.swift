import Foundation

/// Byte-oriented framing bounds even a malicious stream with no newline. UTF-8 is decoded only
/// after a complete line, so arbitrary network chunks cannot split a Unicode scalar incorrectly.
struct ProviderSSEEvent {
    var name: String
    var data: Data
}
struct ProviderSSEParser {
    static let maximumLineBytes = 8 * 1024 * 1024
    static let maximumEventBytes = 8 * 1024 * 1024
    private let lineLimit: Int
    private let eventLimit: Int
    private let totalLimit: Int
    init(lineLimit: Int = maximumLineBytes, eventLimit: Int = maximumEventBytes, totalLimit: Int = ProviderClient.maximumResponseBytes) {
        self.lineLimit = lineLimit; self.eventLimit = eventLimit; self.totalLimit = totalLimit
    }
    private var line = Data()
    private var eventData = Data()
    private var eventName = ""
    private var totalBytes = 0
    private var previousCR = false
    mutating func append(_ byte: UInt8) throws -> ProviderSSEEvent? {
        totalBytes += 1
        guard totalBytes <= totalLimit else { throw ForumError.message("The provider stream exceeded the local size limit.") }
        if previousCR && byte == 10 { previousCR = false; return nil }
        previousCR = byte == 13
        if byte == 10 || byte == 13 { return try finishLine() }
        guard line.count < lineLimit else { throw ForumError.message("The provider stream line exceeded the local size limit.") }
        line.append(byte)
        return nil
    }
    private mutating func finishLine() throws -> ProviderSSEEvent? {
        guard let text = String(data: line, encoding: .utf8) else { throw ForumError.message("The provider stream contains invalid text encoding.") }
        line.removeAll(keepingCapacity: true)
        if text.isEmpty {
            defer { eventData.removeAll(keepingCapacity: true); eventName = "" }
            guard !eventData.isEmpty else { return nil }
            return ProviderSSEEvent(name: eventName, data: eventData)
        }
        if text.hasPrefix(":") { return nil }
        let pair = text.split(separator: ":", maxSplits: 1, omittingEmptySubsequences: false)
        let field = String(pair[0])
        var value = pair.count > 1 ? String(pair[1]) : ""
        if value.hasPrefix(" ") { value.removeFirst() }
        if field == "data" {
            if !eventData.isEmpty { eventData.append(10) }
            guard eventData.count + value.utf8.count <= eventLimit else { throw ForumError.message("The provider stream event exceeded the local size limit.") }
            eventData.append(contentsOf: value.utf8)
        } else if field == "event" {
            guard value.utf8.count <= 256 else { throw ForumError.message("The provider stream event type exceeded the local size limit.") }
            eventName = value
        }
        return nil
    }
}
