import Foundation

public struct ModelOption: Identifiable, Equatable, Sendable {
    public let id: String
    public let name: String
    public init(id: String, name: String) { self.id = id; self.name = name }
}

/// Fetches provider metadata only; listing models never requests model inference.
public final class ModelCatalog: @unchecked Sendable {
    private let session: URLSession
    private let ownsSession: Bool
    private static let byteLimit = 2 * 1024 * 1024
    private static let entryLimit = 1_000

    public init(session: URLSession = .shared) {
        if session === URLSession.shared {
            let configuration = URLSessionConfiguration.ephemeral
            configuration.urlCache = nil
            configuration.httpCookieStorage = nil
            configuration.urlCredentialStorage = nil
            configuration.timeoutIntervalForRequest = 20
            configuration.timeoutIntervalForResource = 30
            self.session = URLSession(configuration: configuration)
            ownsSession = true
        } else { self.session = session; ownsSession = false }
    }
    deinit { if ownsSession { session.invalidateAndCancel() } }

    /// Lists only actual GPT image model IDs returned by the user's OpenAI account.
    public func imageModels(apiKey: String?) async throws -> [ModelOption] {
        try Task.checkCancellation()
        let key = apiKey?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !key.isEmpty, key.utf8.count <= 4_096, key.utf8.allSatisfy({ (33...126).contains($0) }) else {
            throw ForumError.message("Save a valid OpenAI API key before loading image models.")
        }
        var request = URLRequest(url: URL(string: "https://api.openai.com/v1/models")!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
        request.httpMethod = "GET"
        request.httpShouldHandleCookies = false
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        let json = try await fetch(request)
        guard let rows = json["data"] as? [[String: Any]] else { throw ForumError.message("The provider returned an unreadable model list.") }
        guard rows.count <= Self.entryLimit else { throw ForumError.message("The model list exceeds the 1,000-entry limit. Enter a custom model ID instead.") }
        var seen = Set<String>()
        var options: [ModelOption] = []
        for row in rows {
            guard let id = Self.validString(row["id"]) else { throw ForumError.message("The provider returned an invalid model identifier.") }
            if ImageGenerationClient.isSupportedModel(id), seen.insert(id).inserted { options.append(ModelOption(id: id, name: id)) }
        }
        return Self.sorted(options)
    }

    public func models(for provider: ProviderKind, apiKey: String?) async throws -> [ModelOption] {
        try Task.checkCancellation()
        if provider == .claudeCode {
            // Official CLI aliases resolve using the user's installed CLI and account.
            return [ModelOption(id: "sonnet", name: "Sonnet"), ModelOption(id: "opus", name: "Opus"), ModelOption(id: "haiku", name: "Haiku")]
        }
        let key = apiKey?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if provider.needsKey {
            guard !key.isEmpty, key.utf8.count <= 4_096, key.utf8.allSatisfy({ (33...126).contains($0) }) else {
                throw ForumError.message("Save a valid API key for this provider before loading models.")
            }
        }
        var options: [ModelOption] = []
        var seenIDs = Set<String>()
        var cursors = Set<String>()
        var cursor: String?
        var receivedEntries = 0
        for page in 0..<10 {
            try Task.checkCancellation()
            let endpoint: String
            switch provider {
            case .openAI: endpoint = "https://api.openai.com/v1/models"
            case .anthropic: endpoint = "https://api.anthropic.com/v1/models"
            case .ollama: endpoint = "http://127.0.0.1:11434/api/tags"
            case .claudeCode: fatalError("Handled above")
            }
            var components = URLComponents(string: endpoint)!
            if provider == .anthropic {
                components.queryItems = [URLQueryItem(name: "limit", value: "100")]
                if let cursor { components.queryItems?.append(URLQueryItem(name: "after_id", value: cursor)) }
            }
            var request = URLRequest(url: components.url!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
            request.httpMethod = "GET"
            request.httpShouldHandleCookies = false
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            if provider == .openAI { request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization") }
            if provider == .anthropic {
                request.setValue(key, forHTTPHeaderField: "x-api-key")
                request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
            }
            let json = try await fetch(request)
            guard let rows = json[provider == .ollama ? "models" : "data"] as? [[String: Any]] else {
                throw ForumError.message("The provider returned an unreadable model list.")
            }
            receivedEntries += rows.count
            guard receivedEntries <= Self.entryLimit else { throw ForumError.message("The model list exceeds the 1,000-entry limit. Enter a custom model ID instead.") }
            for row in rows {
                guard let id = Self.validString(row[provider == .ollama ? "name" : "id"]) else {
                    throw ForumError.message("The provider returned an invalid model identifier.")
                }
                if provider == .openAI && !Self.isLikelyTextModel(id) { continue }
                let name = provider == .anthropic ? Self.validString(row["display_name"]) ?? id : id
                if seenIDs.insert(id).inserted { options.append(ModelOption(id: id, name: name)) }
            }
            if provider != .anthropic { return Self.sorted(options) }
            guard let hasMore = json["has_more"] as? Bool else { throw ForumError.message("The provider returned invalid model pagination metadata.") }
            if !hasMore { return Self.sorted(options) }
            guard page < 9 else { throw ForumError.message("The model list exceeds the 10-page limit. Enter a custom model ID instead.") }
            guard !rows.isEmpty, let next = Self.validString(json["last_id"]), cursors.insert(next).inserted else {
                throw ForumError.message("The provider returned invalid model pagination metadata.")
            }
            cursor = next
        }
        return Self.sorted(options)
    }

    private func fetch(_ request: URLRequest) async throws -> [String: Any] {
        do {
            let (bytes, response) = try await session.bytes(for: request, delegate: ProviderRedirectGuard())
            defer { bytes.task.cancel() }
            guard let http = response as? HTTPURLResponse else { throw ForumError.message("The provider returned an invalid HTTP response.") }
            guard (200..<300).contains(http.statusCode) else {
                let explanation: String
                switch http.statusCode {
                case 401, 403: explanation = "Check the saved API key and account permissions."
                case 429: explanation = "The provider's rate limit was reached. Try again later."
                case 300..<400: explanation = "Redirects are blocked to protect credentials."
                default: explanation = "Check the provider connection and try again."
                }
                throw ForumError.message("Model listing failed (HTTP \(http.statusCode)). \(explanation)")
            }
            guard response.expectedContentLength <= Int64(Self.byteLimit) else { throw ForumError.message("The model list exceeds the response size limit.") }
            let data = try await withTaskCancellationHandler {
                var data = Data()
                for try await byte in bytes {
                    if data.count.isMultiple(of: 16_384) { try Task.checkCancellation() }
                    guard data.count < Self.byteLimit else { throw ForumError.message("The model list exceeds the response size limit.") }
                    data.append(byte)
                }
                try Task.checkCancellation()
                return data
            } onCancel: { bytes.task.cancel() }
            guard let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
                throw ForumError.message("The provider returned an unreadable model list.")
            }
            return json
        } catch {
            if Task.isCancelled || error is CancellationError || (error as? URLError)?.code == .cancelled { throw CancellationError() }
            if let safeError = error as? ForumError { throw safeError }
            if (error as? URLError)?.code == .timedOut { throw ForumError.message("Loading models timed out. Try again later.") }
            throw ForumError.message("Could not load models. Check the provider connection and setup.")
        }
    }

    private static func validString(_ value: Any?) -> String? {
        guard let value = value as? String, !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              value.utf8.count <= 512, !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else { return nil }
        return value
    }

    /// OpenAI's models endpoint provides no capability/endpoint metadata. This is deliberately
    /// a naming heuristic, not a compatibility guarantee. The UI must retain custom model IDs.
    private static func isLikelyTextModel(_ id: String) -> Bool {
        let id = id.lowercased()
        let excluded = ["audio", "realtime", "transcri", "tts", "image", "search", "embedding", "moderation", "chat-latest", "o1-mini", "o1-preview"]
        guard !excluded.contains(where: id.contains) else { return false }
        return ["gpt-4.1", "gpt-4o", "gpt-5", "gpt-6", "o1", "o3", "o4"].contains { prefix in
            id == prefix || id.hasPrefix(prefix + "-") || id.hasPrefix(prefix + ".")
        }
    }

    private static func sorted(_ options: [ModelOption]) -> [ModelOption] {
        options.sorted { $0.name == $1.name ? $0.id < $1.id : $0.name < $1.name }
    }
}
