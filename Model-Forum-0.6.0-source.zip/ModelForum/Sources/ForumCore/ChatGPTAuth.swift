import Foundation
import CryptoKit
import Security

public struct ChatGPTIdentity: Codable, Equatable, Sendable {
    public let subject: String
    public let email: String?
    public let emailVerified: Bool
    public init(subject: String, email: String?, emailVerified: Bool) {
        self.subject = subject; self.email = email; self.emailVerified = emailVerified
    }
}

public struct ChatGPTCredentials: Codable, Equatable, Sendable {
    public let accessToken: String
    public let refreshToken: String?
    public let idToken: String?
    public let expiresAt: Date
    public let scopes: [String]
    public var permitsInference: Bool { scopes.contains("chatgpt.tokens.use.direct") && scopes.contains("resource.invoke") }
}

public struct ChatGPTAuthorization: Sendable {
    public let state: String
    public let nonce: String
    public let verifier: String
    public let redirectURI: URL
    public let clientID: String?
    public let createdAt: Date

    public init(redirectURI: URL, clientID: String? = nil) throws {
        guard redirectURI.scheme == "http", redirectURI.host == "127.0.0.1", redirectURI.port != nil,
              redirectURI.path == "/auth/callback", redirectURI.query == nil, redirectURI.fragment == nil,
              redirectURI.user == nil, redirectURI.password == nil else { throw ForumError.message("Invalid local sign-in callback.") }
        state = try Self.random(); nonce = try Self.random(); verifier = try Self.random(count: 64)
        self.redirectURI = redirectURI; self.clientID = clientID; createdAt = Date()
    }

    public func browserURL(hostID: String, idTokenHint: String? = nil, emailHint: String? = nil, requestConsent: Bool = false) -> URL {
        var url = URLComponents(string: "https://auth.openai.com/api/accounts/authorize")!
        var values = ["client_id": clientID ?? "dynamic_agent_client", "ext_agent_host_id": hostID,
                      "response_type": "code", "redirect_uri": redirectURI.absoluteString,
                      "scope": "openid profile email offline_access resource.invoke chatgpt.tokens.use.direct",
                      "resource": "https://api.openai.com/v1", "state": state, "nonce": nonce,
                      "code_challenge_method": "S256", "code_challenge": Data(SHA256.hash(data: Data(verifier.utf8))).base64URL]
        if clientID == nil { values["agent_name_hint"] = "Model Forum" }
        if clientID != nil { values["id_token_hint"] = idTokenHint; values["login_hint"] = emailHint }
        if requestConsent { values["prompt"] = "consent" }
        url.queryItems = values.sorted { $0.key < $1.key }.map { URLQueryItem(name: $0.key, value: $0.value) }
        return url.url!
    }

    public func validateCallback(_ url: URL, now: Date = Date()) throws -> (code: String, clientID: String) {
        guard now.timeIntervalSince(createdAt) >= -5, now.timeIntervalSince(createdAt) < 600,
              url.scheme == redirectURI.scheme, url.host == redirectURI.host, url.port == redirectURI.port,
              url.path == redirectURI.path, url.user == nil, url.password == nil, url.fragment == nil,
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false) else { throw ForumError.message("Sign-in callback could not be verified. Start sign-in again.") }
        let items = components.queryItems ?? []
        guard items.count <= 20, Set(items.map(\.name)).count == items.count,
              items.first(where: { $0.name == "state" })?.value == state else { throw ForumError.message("Sign-in state did not match. Start sign-in again.") }
        if items.contains(where: { $0.name == "error" }) { throw ForumError.message("ChatGPT sign-in was declined or could not be completed.") }
        let issued = items.first(where: { $0.name == "client_id" })?.value ?? clientID
        guard let issued, !issued.isEmpty, issued != "dynamic_agent_client", issued.utf8.count <= 512,
              issued.utf8.allSatisfy({ (33...126).contains($0) }), clientID == nil || clientID == issued,
              let code = items.first(where: { $0.name == "code" })?.value, !code.isEmpty, code.utf8.count <= 8192 else {
            throw ForumError.message("ChatGPT registration was incomplete or did not match the selected account.")
        }
        return (code, issued)
    }

    private static func random(count: Int = 32) throws -> String {
        var bytes = [UInt8](repeating: 0, count: count)
        guard SecRandomCopyBytes(kSecRandomDefault, count, &bytes) == errSecSuccess else { throw ForumError.message("Could not create secure sign-in state.") }
        return Data(bytes).base64URL
    }
}

public enum ChatGPTTokenValidation {
    /// RS256 only: rejects algorithm confusion, unknown keys, and unverified identity claims.
    public static func identity(idToken: String, jwks: Data, clientID: String, nonce: String?, now: Date = Date()) throws -> ChatGPTIdentity {
        let failure = ForumError.message("ChatGPT identity could not be verified. Sign in again.")
        let parts = idToken.split(separator: ".", omittingEmptySubsequences: false)
        guard idToken.utf8.count <= 65_536, parts.count == 3,
              let headerData = Data(base64URL: String(parts[0])), let payloadData = Data(base64URL: String(parts[1])),
              let signature = Data(base64URL: String(parts[2])),
              let header = (try? JSONSerialization.jsonObject(with: headerData)) as? [String: Any],
              header["alg"] as? String == "RS256", header["crit"] == nil,
              let kid = header["kid"] as? String, !kid.isEmpty,
              let keySet = (try? JSONSerialization.jsonObject(with: jwks)) as? [String: Any],
              let keys = keySet["keys"] as? [[String: Any]], keys.count <= 100 else { throw failure }
        let matching = keys.filter { $0["kid"] as? String == kid }
        guard matching.count == 1, let jwk = matching.first, jwk["kty"] as? String == "RSA",
              jwk["alg"] == nil || jwk["alg"] as? String == "RS256",
              jwk["use"] == nil || jwk["use"] as? String == "sig",
              let n = jwk["n"] as? String, let e = jwk["e"] as? String,
              let modulus = Data(base64URL: n), (256...1024).contains(modulus.count),
              let exponent = Data(base64URL: e), (1...8).contains(exponent.count) else { throw failure }
        if let operations = jwk["key_ops"] as? [String], !operations.contains("verify") { throw failure }
        let der = sequence(integer(modulus) + integer(exponent))
        guard let key = SecKeyCreateWithData(der as CFData, [kSecAttrKeyType: kSecAttrKeyTypeRSA, kSecAttrKeyClass: kSecAttrKeyClassPublic] as CFDictionary, nil),
              SecKeyVerifySignature(key, .rsaSignatureMessagePKCS1v15SHA256, Data("\(parts[0]).\(parts[1])".utf8) as CFData, signature as CFData, nil),
              let claims = (try? JSONSerialization.jsonObject(with: payloadData)) as? [String: Any],
              claims["iss"] as? String == "https://auth.openai.com",
              let subject = claims["sub"] as? String, !subject.isEmpty, subject.utf8.count <= 512,
              let expiry = claims["exp"] as? Double, expiry.isFinite, expiry > now.timeIntervalSince1970 - 5,
              let issued = claims["iat"] as? Double, issued.isFinite, issued <= now.timeIntervalSince1970 + 5 else { throw failure }
        let audiences = (claims["aud"] as? [String]) ?? (claims["aud"] as? String).map { [$0] } ?? []
        guard audiences.contains(clientID), audiences.count == 1 || claims["azp"] as? String == clientID else { throw failure }
        if let authorizedParty = claims["azp"] as? String, authorizedParty != clientID { throw failure }
        if let nonce, claims["nonce"] as? String != nonce { throw failure }
        if let notBefore = claims["nbf"] as? Double, !notBefore.isFinite || notBefore > now.timeIntervalSince1970 + 5 { throw failure }
        let email = (claims["email"] as? String).flatMap { $0.utf8.count <= 512 && !$0.unicodeScalars.contains(where: CharacterSet.controlCharacters.contains) ? $0 : nil }
        return ChatGPTIdentity(subject: subject, email: email, emailVerified: claims["email_verified"] as? Bool == true)
    }

    private static func length(_ count: Int) -> Data {
        if count < 128 { return Data([UInt8(count)]) }
        var value = count; var bytes: [UInt8] = []
        while value > 0 { bytes.insert(UInt8(value & 255), at: 0); value >>= 8 }
        return Data([0x80 | UInt8(bytes.count)] + bytes)
    }
    private static func integer(_ data: Data) -> Data {
        var bytes = data
        while bytes.count > 1 && bytes.first == 0 { bytes.removeFirst() }
        if let first = bytes.first, first & 0x80 != 0 { bytes.insert(0, at: 0) }
        return Data([0x02]) + length(bytes.count) + bytes
    }
    private static func sequence(_ data: Data) -> Data { Data([0x30]) + length(data.count) + data }
}

extension Data {
    var base64URL: String { base64EncodedString().replacingOccurrences(of: "+", with: "-").replacingOccurrences(of: "/", with: "_").replacingOccurrences(of: "=", with: "") }
    init?(base64URL: String) {
        guard !base64URL.isEmpty, base64URL.utf8.allSatisfy({ (65...90).contains($0) || (97...122).contains($0) || (48...57).contains($0) || $0 == 45 || $0 == 95 }) else { return nil }
        var value = base64URL.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        value += String(repeating: "=", count: (4 - value.count % 4) % 4)
        self.init(base64Encoded: value)
    }
}
