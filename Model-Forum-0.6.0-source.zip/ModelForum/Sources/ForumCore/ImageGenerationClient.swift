import Foundation

/// One explicit image request. This client never follows returned URLs or executes model tools.
public final class ImageGenerationClient: @unchecked Sendable {
    private let session: URLSession
    private let ownsSession: Bool
    private static let responseByteLimit = 16 * 1024 * 1024
    private static let imageByteLimit = 8 * 1024 * 1024

    public init(session: URLSession = .shared) {
        if session === URLSession.shared {
            let configuration = URLSessionConfiguration.ephemeral
            configuration.urlCache = nil
            configuration.httpCookieStorage = nil
            configuration.urlCredentialStorage = nil
            configuration.timeoutIntervalForRequest = 120
            configuration.timeoutIntervalForResource = 180
            self.session = URLSession(configuration: configuration)
            ownsSession = true
        } else { self.session = session; ownsSession = false }
    }

    deinit { if ownsSession { session.invalidateAndCancel() } }

    public func generate(prompt: String, model: String, apiKey: String) async throws -> ArtifactDraft {
        try Task.checkCancellation()
        let model = model.trimmingCharacters(in: .whitespacesAndNewlines)
        guard Self.isSupportedModel(model) else { throw ForumError.message("Choose a GPT image model before generating an image.") }
        guard !prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, prompt.count <= 32_000 else {
            throw ForumError.message("Enter an image prompt between 1 and 32,000 characters.")
        }
        let key = apiKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, key.utf8.count <= 4_096, key.utf8.allSatisfy({ (33...126).contains($0) }) else {
            throw ForumError.message("Save a valid OpenAI API key before generating an image.")
        }
        var request = URLRequest(url: URL(string: "https://api.openai.com/v1/images/generations")!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 120)
        request.httpMethod = "POST"
        request.httpShouldHandleCookies = false
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "model": model, "prompt": prompt, "n": 1, "size": "1024x1024",
            "quality": "medium", "output_format": "png", "stream": false
        ])
        do {
            let (bytes, response) = try await session.bytes(for: request, delegate: ProviderRedirectGuard())
            defer { bytes.task.cancel() }
            guard let http = response as? HTTPURLResponse else { throw ForumError.message("The image provider returned an invalid HTTP response.") }
            guard (200..<300).contains(http.statusCode) else {
                let detail: String
                switch http.statusCode {
                case 401, 403: detail = "Check your API key, image model access, and account verification."
                case 429: detail = "Check your provider quota and rate limits before retrying."
                case 300..<400: detail = "Redirects are blocked to protect credentials and your prompt."
                default: detail = "Check your model selection and provider status before retrying."
                }
                throw ForumError.message("Image generation failed (HTTP \(http.statusCode)). \(detail)")
            }
            guard response.expectedContentLength <= Int64(Self.responseByteLimit) else { throw ForumError.message("The image response exceeds the 16 MiB download limit.") }
            let data = try await withTaskCancellationHandler {
                var data = Data()
                for try await byte in bytes {
                    if data.count.isMultiple(of: 16_384) { try Task.checkCancellation() }
                    guard data.count < Self.responseByteLimit else { throw ForumError.message("The image response exceeds the 16 MiB download limit.") }
                    data.append(byte)
                }
                try Task.checkCancellation()
                return data
            } onCancel: { bytes.task.cancel() }
            return try Self.decodeResponse(data)
        } catch {
            if Task.isCancelled || error is CancellationError || (error as? URLError)?.code == .cancelled { throw CancellationError() }
            if let safeError = error as? ForumError { throw safeError }
            if (error as? URLError)?.code == .timedOut { throw ForumError.message("Image generation timed out. Check your provider usage before retrying; generation may already have been billed.") }
            throw ForumError.message("Could not complete image generation. Check your connection and provider usage before retrying.")
        }
    }

    // Model IDs are selected from provider metadata; this validates the supported family and syntax.
    static func isSupportedModel(_ model: String) -> Bool {
        guard model.utf8.count <= 128, model.hasPrefix("gpt-image-"), model.count > "gpt-image-".count else { return false }
        return model.utf8.allSatisfy { (97...122).contains($0) || (48...57).contains($0) || [45, 46, 95].contains($0) }
    }

    static func decodeResponse(_ data: Data) throws -> ArtifactDraft {
        guard data.count <= responseByteLimit else { throw ForumError.message("The image response exceeds the 16 MiB download limit.") }
        guard let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let images = json["data"] as? [[String: Any]], images.count == 1,
              let encoded = images.first?["b64_json"] as? String, !encoded.isEmpty else {
            throw ForumError.message("The provider returned no supported image data. URL downloads are not supported.")
        }
        // Check encoded size before allocating decoded image data. No permissive base64 options.
        guard encoded.utf8.count <= ((imageByteLimit + 2) / 3) * 4 else { throw ForumError.message("The generated image exceeds the 8 MiB file limit.") }
        guard let png = Data(base64Encoded: encoded) else { throw ForumError.message("The provider returned invalid image encoding.") }
        guard png.count <= imageByteLimit else { throw ForumError.message("The generated image exceeds the 8 MiB file limit.") }
        guard png.count > 8, png.starts(with: [137, 80, 78, 71, 13, 10, 26, 10]) else {
            throw ForumError.message("The provider returned a file without a valid PNG signature.")
        }
        return ArtifactDraft(filename: "image.png", mimeType: "image/png", data: png)
    }
}
