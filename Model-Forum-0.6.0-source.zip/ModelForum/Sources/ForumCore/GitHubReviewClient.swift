import Foundation

public struct GitHubDiffReview: Sendable {
    public let repository: String
    public let base: String
    public let head: String
    public let baseSHA: String
    public let headSHA: String
    public let diff: String
    public let connectionLabel: String
    let generation: String
}
public struct GitHubPullRequestResult: Sendable { public let url: URL; public let alreadyExists: Bool }
public struct GitHubReviewClient: Sendable {
    typealias Transport = @Sendable (String, String, Data, String) async throws -> Data
    private let transport: Transport?
    public init() { transport = nil }
    init(transport: @escaping Transport) { self.transport = transport }
    private func connection() throws -> (Transport, GitHubAccessSession?) {
        if let transport { return (transport, nil) }
        let session = try GitHubAccessSession.selected()
        return ({ @Sendable path, method, body, accept in
            try await session.api(path, method: method, input: body, accept: accept)
        }, session)
    }
    public func pullRequestDiff(url: String) async throws -> String {
        let request = try GitHubRequest(url)
        guard request.arguments.first == "pr", let number = request.canonicalURL.split(separator: "/").last else { throw GitHubAppError.configuration }
        let (send, session) = try connection()
        try await session?.require(repository: request.repository, permission: "pull_requests")
        let data = try await send("repos/\(request.repository)/pulls/\(number)", "GET", Data(), "application/vnd.github.diff")
        try session?.checkCurrent()
        return try Self.diff(data)
    }
    public func preview(repository: String, base: String, head: String) async throws -> GitHubDiffReview {
        try Self.validate(repository: repository, base: base, head: head)
        let (send, session) = try connection()
        try await session?.require(repository: repository, permission: "contents")
        let baseSHA = try await Self.reference(repository, branch: base, send: send)
        let headSHA = try await Self.reference(repository, branch: head, send: send)
        let diff = try Self.diff(await send("repos/\(repository)/compare/\(baseSHA)...\(headSHA)", "GET", Data(), "application/vnd.github.diff"))
        guard !diff.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ForumError.message("These branches have no reviewable text diff. No pull request was created.") }
        try session?.checkCurrent()
        return .init(repository: repository, base: base, head: head, baseSHA: baseSHA, headSHA: headSHA, diff: diff,
                     connectionLabel: GitHubAccess.connectionLabel, generation: session?.generation ?? "fixture")
    }
    public func create(review: GitHubDiffReview, title: String, body: String, draft: Bool = true) async throws -> GitHubPullRequestResult {
        try Self.validate(repository: review.repository, base: review.base, head: review.head)
        guard !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, title.utf8.count <= 256, body.utf8.count <= 60_000 else {
            throw ForumError.message("Enter a pull-request title up to 256 bytes and a description up to 60 KB.")
        }
        let (send, session) = try connection()
        guard session == nil || session?.generation == review.generation else { throw GitHubAppError.changed }
        try await session?.require(repository: review.repository, permission: "pull_requests", write: true)
        let baseSHA = try await Self.reference(review.repository, branch: review.base, send: send)
        let headSHA = try await Self.reference(review.repository, branch: review.head, send: send)
        guard baseSHA == review.baseSHA, headSHA == review.headSHA else { throw ForumError.message("A branch changed since this review. Load and review the diff again before creating the pull request.") }
        let owner = String(review.repository.split(separator: "/")[0])
        let existingData = try await send("repos/\(review.repository)/pulls?state=open&head=\(GitHubAccess.encode(owner + ":" + review.head))&base=\(GitHubAccess.encode(review.base))&per_page=100", "GET", Data(), "application/vnd.github+json")
        let existing: [Pull] = try Self.decode(existingData)
        if let found = existing.first {
            guard found.number > 0 else { throw GitHubAppError.invalidResponse }
            return .init(url: URL(string: "https://github.com/\(review.repository)/pull/\(found.number)")!, alreadyExists: true)
        }
        try Task.checkCancellation(); try session?.checkCurrent()
        let payload = try JSONSerialization.data(withJSONObject: ["title": title, "body": body, "head": review.head, "base": review.base, "draft": draft])
        let created: Pull = try Self.decode(await send("repos/\(review.repository)/pulls", "POST", payload, "application/vnd.github+json"))
        guard created.number > 0 else { throw GitHubAppError.invalidResponse }
        return .init(url: URL(string: "https://github.com/\(review.repository)/pull/\(created.number)")!, alreadyExists: false)
    }
    private struct Pull: Decodable { let number: Int }
    private static func reference(_ repo: String, branch: String, send: Transport) async throws -> String {
        struct Reference: Decodable { struct Object: Decodable { let sha: String; let type: String }; let object: Object }
        let value: Reference = try decode(await send("repos/\(repo)/git/ref/heads/\(GitHubAccess.encode(branch))", "GET", Data(), "application/vnd.github+json"))
        guard value.object.type == "commit", value.object.sha.range(of: #"\A[0-9a-fA-F]{40}\z"#, options: .regularExpression) != nil else { throw GitHubAppError.invalidResponse }
        return value.object.sha
    }
    static func validate(repository: String, base: String, head: String) throws {
        guard let request = try? GitHubRequest("https://github.com/\(repository)"), request.isRepository,
              request.repository == repository, base != head else { throw GitHubAppError.configuration }
        for branch in [base, head] {
            guard branch.utf8.count <= 200, branch.range(of: #"\A[A-Za-z0-9][A-Za-z0-9._/-]*\z"#, options: .regularExpression) != nil,
                  !branch.contains(".."), !branch.contains("//"), !branch.hasSuffix("/"), !branch.hasSuffix("."),
                  !branch.split(separator: "/").contains(where: { $0.hasPrefix(".") || $0.hasSuffix(".lock") }) else { throw GitHubAppError.configuration }
        }
    }
    private static func diff(_ data: Data) throws -> String {
        guard data.count <= 524_288 else { throw GitHubAppError.tooLarge }
        guard let text = String(data: data, encoding: .utf8) else { throw GitHubAppError.invalidResponse }
        return text
    }
    private static func decode<T: Decodable>(_ data: Data) throws -> T {
        do { return try JSONDecoder().decode(T.self, from: data) } catch { throw GitHubAppError.invalidResponse }
    }
}
