import Foundation
import Security

public enum GitHubConnectionMode: String, CaseIterable, Sendable { case cli, app }
public enum GitHubAppError: LocalizedError, Equatable {
    case configuration, disconnected, expired, denied, permissions, invalidResponse, tooLarge, unavailable, keychain, changed
    public var errorDescription: String? {
        switch self {
        case .configuration: return "Enter a GitHub App client ID and enable Device flow in that app's GitHub registration. No client secret is needed."
        case .disconnected: return "Connect your GitHub App account in Settings → GitHub, or explicitly select GitHub CLI."
        case .expired: return "GitHub authorization expired. Reconnect in Settings → GitHub."
        case .denied: return "GitHub denied this request. Check the connected account, app installation and repository access; reconnect if needed."
        case .permissions: return "The selected GitHub App installation or your account lacks the repository permission required for this action."
        case .invalidResponse: return "GitHub returned an unexpected response. Retry the read operation or reconnect."
        case .tooLarge: return "GitHub's response exceeds this preview's bounded download or listing limit. Narrow the repository or diff."
        case .unavailable: return "GitHub could not complete the request. Check your connection. A write may have succeeded; inspect GitHub before retrying."
        case .keychain: return "The GitHub credential could not be read or saved in Keychain. Unlock Keychain and try again."
        case .changed: return "The GitHub connection changed. Review again using the current connection before continuing."
        }
    }
}

struct GitHubHTTPResponse: Sendable { let status: Int; let data: Data }
typealias GitHubHTTPTransport = @Sendable (URLRequest, Int) async throws -> GitHubHTTPResponse
final class GitHubRedirectBlocker: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}

enum GitHubHTTP {
    static func send(_ request: URLRequest, limit: Int) async throws -> GitHubHTTPResponse {
        let delegate = GitHubRedirectBlocker()
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil; configuration.httpShouldSetCookies = false
        configuration.urlCredentialStorage = nil
        configuration.urlCache = nil; configuration.timeoutIntervalForRequest = 45; configuration.timeoutIntervalForResource = 90
        let session = URLSession(configuration: configuration, delegate: delegate, delegateQueue: nil)
        defer { session.invalidateAndCancel() }
        do {
            let (bytes, response) = try await session.bytes(for: request)
            guard let response = response as? HTTPURLResponse else { throw GitHubAppError.invalidResponse }
            guard response.expectedContentLength <= Int64(limit) else { throw GitHubAppError.tooLarge }
            var data = Data()
            for try await byte in bytes {
                try Task.checkCancellation()
                guard data.count < limit else { throw GitHubAppError.tooLarge }
                data.append(byte)
            }
            return GitHubHTTPResponse(status: response.statusCode, data: data)
        } catch is CancellationError { throw CancellationError() }
        catch let error as GitHubAppError { throw error }
        catch { if Task.isCancelled { throw CancellationError() }; throw GitHubAppError.unavailable }
    }
}

public struct GitHubAccount: Codable, Equatable, Sendable { public let id: Int; public let login: String }
struct GitHubAppCredential: Codable, Sendable {
    let token: String; let clientID: String; let account: GitHubAccount; let expiresAt: Date?
}
public struct GitHubDeviceAuthorization: Sendable {
    public let userCode: String
    public let expiresAt: Date
    let deviceCode: String; let interval: Int; let clientID: String
    public var verificationURL: URL { URL(string: "https://github.com/login/device")! }
}
public struct GitHubAccessibleRepository: Identifiable, Sendable {
    public let id: Int
    public let fullName: String
    public let installationID: Int
    public let contents: String
    public let pullRequests: String
    public let issues: String
    public let userCanPush: Bool
}

public struct GitHubAppClient: Sendable {
    private let token: String?
    private let transport: GitHubHTTPTransport
    public init() { token = nil; transport = { @Sendable request, limit in try await GitHubHTTP.send(request, limit: limit) } }
    init(token: String? = nil, transport: @escaping GitHubHTTPTransport) { self.token = token; self.transport = transport }
    func authenticated(_ token: String) -> Self { Self(token: token, transport: transport) }
    public func begin(clientID: String) async throws -> GitHubDeviceAuthorization {
        guard clientID.range(of: #"\A[A-Za-z0-9_.-]{10,100}\z"#, options: .regularExpression) != nil else { throw GitHubAppError.configuration }
        struct Reply: Decodable { let device_code: String; let user_code: String; let expires_in: Int; let interval: Int; let verification_uri: String }
        let reply: Reply = try decode(await oauth(path: "device/code", values: ["client_id": clientID]))
        guard reply.verification_uri == "https://github.com/login/device", (1...1800).contains(reply.expires_in),
              (1...60).contains(reply.interval), reply.device_code.count <= 256,
              reply.user_code.range(of: #"\A[A-Z0-9]{4}-[A-Z0-9]{4}\z"#, options: .regularExpression) != nil else { throw GitHubAppError.invalidResponse }
        return GitHubDeviceAuthorization(userCode: reply.user_code, expiresAt: Date().addingTimeInterval(Double(reply.expires_in)),
                                         deviceCode: reply.device_code, interval: reply.interval, clientID: clientID)
    }
    func finish(_ authorization: GitHubDeviceAuthorization,
                sleep: @Sendable (UInt64) async throws -> Void = { try await Task.sleep(nanoseconds: $0) }) async throws -> GitHubAppCredential {
        struct Reply: Decodable { let access_token: String?; let token_type: String?; let expires_in: Int?; let error: String? }
        var interval = authorization.interval
        while Date() < authorization.expiresAt {
            try await sleep(UInt64(interval) * 1_000_000_000)
            try Task.checkCancellation()
            guard Date() < authorization.expiresAt else { throw GitHubAppError.expired }
            let reply: Reply = try decode(await oauth(path: "oauth/access_token", values: [
                "client_id": authorization.clientID, "device_code": authorization.deviceCode,
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code"]))
            if let error = reply.error {
                switch error {
                case "authorization_pending": continue
                case "slow_down": interval = min(interval + 5, 120); continue
                case "expired_token": throw GitHubAppError.expired
                case "access_denied": throw GitHubAppError.denied
                default: throw GitHubAppError.configuration
                }
            }
            guard let token = reply.access_token, token.hasPrefix("ghu_"), token.count <= 512,
                  token.rangeOfCharacter(from: .whitespacesAndNewlines) == nil, reply.token_type?.lowercased() == "bearer",
                  reply.expires_in == nil || reply.expires_in! > 0 else { throw GitHubAppError.invalidResponse }
            let account: GitHubAccount = try decode(await authenticated(token).api("user"))
            guard account.id > 0, !account.login.isEmpty else { throw GitHubAppError.invalidResponse }
            return GitHubAppCredential(token: token, clientID: authorization.clientID, account: account,
                                       expiresAt: reply.expires_in.map { Date().addingTimeInterval(Double($0)) })
        }
        throw GitHubAppError.expired
    }
    private func oauth(path: String, values: [String: String]) async throws -> Data {
        var request = URLRequest(url: URL(string: "https://github.com/login/\(path)")!)
        request.httpMethod = "POST"; request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: values)
        let response = try await transport(request, 32_768)
        guard response.data.count <= 32_768 else { throw GitHubAppError.tooLarge }
        guard response.status == 200 else { throw GitHubAppError.denied }
        return response.data
    }
    func api(_ path: String, method: String = "GET", input: Data = Data(), accept: String = "application/vnd.github+json",
             limit: Int = 2_097_152) async throws -> Data {
        guard let token, !token.isEmpty else { throw GitHubAppError.disconnected }
        guard !path.hasPrefix("/"), !path.contains("#"), !path.contains("://"),
              let url = URL(string: "https://api.github.com/\(path)"), url.host == "api.github.com", url.user == nil,
              ["GET", "POST", "PUT"].contains(method) else { throw GitHubAppError.invalidResponse }
        var request = URLRequest(url: url); request.httpMethod = method
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue(accept, forHTTPHeaderField: "Accept")
        request.setValue("2022-11-28", forHTTPHeaderField: "X-GitHub-Api-Version")
        request.setValue("Model-Forum", forHTTPHeaderField: "User-Agent")
        if !input.isEmpty { request.httpBody = input; request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
        let result = try await transport(request, limit)
        guard result.data.count <= limit else { throw GitHubAppError.tooLarge }
        guard (200..<300).contains(result.status) else {
            if result.status == 401 { throw GitHubAppError.expired }
            throw GitHubFetchError.http(result.status)
        }
        return result.data
    }
    public func repositories() async throws -> [GitHubAccessibleRepository] {
        struct Installation: Decodable { let id: Int; let permissions: [String: String]; let suspended_at: String? }
        struct Installations: Decodable { let installations: [Installation] }
        struct Repo: Decodable { let id: Int; let full_name: String; let permissions: [String: Bool]? }
        struct Repos: Decodable { let repositories: [Repo] }
        var installations = [Installation]()
        for page in 1...20 {
            let response: Installations = try decode(await api("user/installations?per_page=100&page=\(page)"))
            installations += response.installations
            if response.installations.count < 100 { break }
            if page == 20 { throw GitHubAppError.tooLarge }
        }
        var result = [GitHubAccessibleRepository]()
        for installation in installations where installation.suspended_at == nil {
            for page in 1...20 {
                let response: Repos = try decode(await api("user/installations/\(installation.id)/repositories?per_page=100&page=\(page)"))
                for repo in response.repositories {
                    guard (try? GitHubRequest("https://github.com/\(repo.full_name)"))?.isRepository == true else { throw GitHubAppError.invalidResponse }
                    result.append(.init(id: repo.id, fullName: repo.full_name, installationID: installation.id,
                                        contents: installation.permissions["contents"] ?? "none",
                                        pullRequests: installation.permissions["pull_requests"] ?? "none",
                                        issues: installation.permissions["issues"] ?? "none", userCanPush: repo.permissions?["push"] == true))
                }
                guard result.count <= 5_000 else { throw GitHubAppError.tooLarge }
                if response.repositories.count < 100 { break }
                if page == 20 { throw GitHubAppError.tooLarge }
            }
        }
        return result.sorted { $0.fullName < $1.fullName }
    }
    func require(repository: String, permission: String, write: Bool = false) async throws {
        guard let repo = try await repositories().first(where: { $0.fullName.lowercased() == repository.lowercased() }) else { throw GitHubAppError.permissions }
        let level = permission == "contents" ? repo.contents : permission == "issues" ? repo.issues : repo.pullRequests
        guard write ? level == "write" && repo.userCanPush : ["read", "write"].contains(level) else { throw GitHubAppError.permissions }
    }
    private func decode<T: Decodable>(_ data: Data) throws -> T {
        do { return try JSONDecoder().decode(T.self, from: data) } catch { throw GitHubAppError.invalidResponse }
    }
}

/// Credentials are read only when the user invokes a GitHub operation; no secret enters workspace history.
public enum GitHubAppConnection {
    private static let service = "com.modelforum.desktop.github-app"
    private static let account = "user-access-token"
    public static var mode: GitHubConnectionMode { GitHubConnectionMode(rawValue: UserDefaults.standard.string(forKey: "GitHubConnectionMode") ?? "cli") ?? .cli }
    public static var clientID: String { UserDefaults.standard.string(forKey: "GitHubAppClientID") ?? "" }
    /// Persists across launches; also honors the stamp written by earlier preview builds.
    public static var revision: String {
        UserDefaults.standard.string(forKey: "GitHubConnectionRevision")
            ?? UserDefaults.standard.string(forKey: "GitHubConnectionGeneration") ?? "legacy-cli"
    }
    public static var generation: String { revision }
    public static var accountLabel: String { UserDefaults.standard.string(forKey: "GitHubAppAccountLabel") ?? "Not connected" }
    public static func select(_ mode: GitHubConnectionMode) { UserDefaults.standard.set(mode.rawValue, forKey: "GitHubConnectionMode"); changed() }
    public static func setClientID(_ value: String) throws {
        if value != clientID { try disconnect(); UserDefaults.standard.set(value, forKey: "GitHubAppClientID"); changed() }
    }
    public static func connect(_ authorization: GitHubDeviceAuthorization) async throws {
        let originalGeneration = generation
        let credential = try await GitHubAppClient().finish(authorization)
        try Task.checkCancellation()
        guard clientID == authorization.clientID, generation == originalGeneration else { throw GitHubAppError.changed }
        try save(credential)
        UserDefaults.standard.set("\(credential.account.login) (ID \(credential.account.id))", forKey: "GitHubAppAccountLabel")
        select(.app)
    }
    public static func disconnect() throws {
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw GitHubAppError.keychain }
        UserDefaults.standard.removeObject(forKey: "GitHubAppAccountLabel"); changed()
    }
    public static func connectedClient() throws -> GitHubAppClient {
        let credential = try load()
        guard credential.clientID == clientID else { throw GitHubAppError.disconnected }
        guard credential.expiresAt.map({ $0 > Date() }) ?? true else { throw GitHubAppError.expired }
        return GitHubAppClient().authenticated(credential.token)
    }
    private static var query: [String: Any] { [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account] }
    private static func load() throws -> GitHubAppCredential {
        var request = query; request[kSecReturnData as String] = true; request[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(request as CFDictionary, &result)
        if status == errSecItemNotFound { throw GitHubAppError.disconnected }
        guard status == errSecSuccess, let data = result as? Data,
              let credential = try? JSONDecoder().decode(GitHubAppCredential.self, from: data) else { throw GitHubAppError.keychain }
        return credential
    }
    private static func save(_ credential: GitHubAppCredential) throws {
        let data = try JSONEncoder().encode(credential)
        let attributes: [String: Any] = [kSecValueData as String: data]
        let result = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if result == errSecItemNotFound {
            var item = query; item[kSecValueData as String] = data
            item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            guard SecItemAdd(item as CFDictionary, nil) == errSecSuccess else { throw GitHubAppError.keychain }
        } else if result != errSecSuccess { throw GitHubAppError.keychain }
    }
    private static func changed() {
        let value = UUID().uuidString
        UserDefaults.standard.set(value, forKey: "GitHubConnectionRevision")
        UserDefaults.standard.set(value, forKey: "GitHubConnectionGeneration")
        NotificationCenter.default.post(name: Notification.Name("ModelForumGitHubConnectionChanged"), object: nil)
    }
}
