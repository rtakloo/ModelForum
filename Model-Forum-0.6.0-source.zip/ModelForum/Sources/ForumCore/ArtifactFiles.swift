import Foundation
#if canImport(Darwin)
import Darwin
#else
import Glibc
#endif

public struct ArtifactFiles: Sendable {
    public static let maximumBytes = 8 * 1024 * 1024
    public let root: URL
    private static let textTypes = ["tex": "application/x-tex", "md": "text/markdown", "txt": "text/plain", "json": "application/json", "csv": "text/csv", "tsv": "text/tab-separated-values", "svg": "image/svg+xml", "html": "text/html", "css": "text/css", "js": "text/javascript", "py": "text/x-python", "swift": "text/plain", "yaml": "text/yaml", "yml": "text/yaml", "xml": "application/xml"]
    private static let binaryExtensions: Set<String> = ["png", "jpg", "jpeg", "gif", "webp", "pdf"]
    public init(root: URL) { self.root = root }

    public static func validateFilename(_ filename: String) throws {
        let ext = (filename as NSString).pathExtension.lowercased()
        guard filename.utf8.count <= 160,
              filename.range(of: #"^[A-Za-z0-9][A-Za-z0-9._ -]*$"#, options: .regularExpression) != nil,
              !filename.contains(".."), !filename.hasSuffix(" "),
              textTypes[ext] != nil || binaryExtensions.contains(ext) else {
            throw ForumError.message("Generated file names must be safe basenames with a supported file extension; folders and paths are not allowed.")
        }
    }
    private static func components(_ relativePath: String) throws -> (String, String) {
        let parts = relativePath.split(separator: "/", omittingEmptySubsequences: false)
        guard parts.count == 2, let id = UUID(uuidString: String(parts[0])), id.uuidString.lowercased() == parts[0] else {
            throw ForumError.message("Invalid local artifact path.")
        }
        let filename = String(parts[1]); try validateFilename(filename)
        return (String(parts[0]), filename)
    }
    private static func failure() -> ForumError { .message("The local artifact could not be accessed safely. Check folder permissions and available disk space.") }

    // Traverse directories by descriptor: a symlink cannot redirect a subsequent file access.
    private func rootDescriptor(create: Bool) throws -> Int32 {
        guard root.isFileURL, root.path.hasPrefix("/") else { throw Self.failure() }
        let components = root.path.split(separator: "/").map(String.init)
        guard !components.isEmpty, !components.contains(".."), !components.contains(".") else { throw Self.failure() }
        var fd = open("/", O_RDONLY | O_DIRECTORY | O_CLOEXEC)
        guard fd >= 0 else { throw Self.failure() }
        do {
            for component in components {
                var next = openat(fd, component, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC)
                if next < 0, errno == ENOENT, create {
                    guard mkdirat(fd, component, 0o700) == 0 || errno == EEXIST else { throw Self.failure() }
                    next = openat(fd, component, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC)
                }
                guard next >= 0 else { throw Self.failure() }
                close(fd); fd = next
            }
            var info = stat()
            guard fstat(fd, &info) == 0, info.st_uid == getuid(), fchmod(fd, 0o700) == 0 else { throw Self.failure() }
            return fd
        } catch { close(fd); throw error }
    }
    private func directory(rootFD: Int32, name: String, create: Bool) throws -> Int32 {
        if create { guard mkdirat(rootFD, name, 0o700) == 0 || errno == EEXIST else { throw Self.failure() } }
        let fd = openat(rootFD, name, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC)
        guard fd >= 0 else { throw Self.failure() }
        var info = stat()
        guard fstat(fd, &info) == 0, info.st_uid == getuid(), fchmod(fd, 0o700) == 0 else { close(fd); throw Self.failure() }
        return fd
    }
    private func readFile(directoryFD: Int32, filename: String) throws -> Data {
        let fd = openat(directoryFD, filename, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC)
        guard fd >= 0 else { throw Self.failure() }
        defer { close(fd) }
        var info = stat()
        guard fstat(fd, &info) == 0, (info.st_mode & S_IFMT) == S_IFREG, info.st_uid == getuid(),
              info.st_nlink == 1, info.st_size <= Self.maximumBytes, fchmod(fd, 0o600) == 0 else { throw Self.failure() }
        var result = Data(), buffer = [UInt8](repeating: 0, count: 64 * 1024)
        while true {
            let count = buffer.withUnsafeMutableBytes { bytes in
                #if canImport(Darwin)
                Darwin.read(fd, bytes.baseAddress!, bytes.count)
                #else
                Glibc.read(fd, bytes.baseAddress!, bytes.count)
                #endif
            }
            if count < 0, errno == EINTR { continue }
            guard count >= 0 else { throw Self.failure() }
            if count == 0 { break }
            guard result.count + count <= Self.maximumBytes else { throw ForumError.message("Generated files must be at most 8 MiB.") }
            result.append(contentsOf: buffer.prefix(count))
        }
        return result
    }
    @discardableResult
    public func store(draft: ArtifactDraft, id: UUID) throws -> String {
        try Self.validateFilename(draft.filename)
        guard draft.data.count <= Self.maximumBytes else { throw ForumError.message("Generated files must be at most 8 MiB.") }
        let directoryName = id.uuidString.lowercased(), relativePath = directoryName + "/" + draft.filename
        let rootFD = try rootDescriptor(create: true); defer { close(rootFD) }
        let dirFD = try directory(rootFD: rootFD, name: directoryName, create: true); defer { close(dirFD) }
        var info = stat()
        if fstatat(dirFD, draft.filename, &info, AT_SYMLINK_NOFOLLOW) == 0 {
            guard try readFile(directoryFD: dirFD, filename: draft.filename) == draft.data else { throw ForumError.message("An artifact already exists at this path with different content.") }
            return relativePath
        }
        guard errno == ENOENT else { throw Self.failure() }
        let temporary = ".pending-" + UUID().uuidString
        let fd = openat(dirFD, temporary, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0o600)
        guard fd >= 0 else { throw Self.failure() }
        defer { close(fd); unlinkat(dirFD, temporary, 0) }
        try draft.data.withUnsafeBytes { bytes in
            var offset = 0
            while offset < bytes.count {
                #if canImport(Darwin)
                let count = Darwin.write(fd, bytes.baseAddress!.advanced(by: offset), bytes.count - offset)
                #else
                let count = Glibc.write(fd, bytes.baseAddress!.advanced(by: offset), bytes.count - offset)
                #endif
                if count < 0, errno == EINTR { continue }
                guard count > 0 else { throw Self.failure() }
                offset += count
            }
        }
        guard fsync(fd) == 0 else { throw Self.failure() }
        // A hard-link installation is atomic and refuses to replace an existing path.
        if linkat(dirFD, temporary, dirFD, draft.filename, 0) != 0 {
            guard errno == EEXIST, try readFile(directoryFD: dirFD, filename: draft.filename) == draft.data else {
                throw ForumError.message("The artifact could not be saved without replacing existing content.")
            }
        }
        guard unlinkat(dirFD, temporary, 0) == 0 else { throw Self.failure() }
        _ = fsync(dirFD)
        return relativePath
    }
    public func read(relativePath: String) throws -> Data {
        let (directoryName, filename) = try Self.components(relativePath)
        let rootFD = try rootDescriptor(create: false); defer { close(rootFD) }
        let dirFD = try directory(rootFD: rootFD, name: directoryName, create: false); defer { close(dirFD) }
        return try readFile(directoryFD: dirFD, filename: filename)
    }
    /// Remove only an explicitly authorized file through descriptor-relative, no-symlink traversal.
    public func remove(relativePath: String) throws {
        let (directoryName, filename) = try Self.components(relativePath)
        let rootFD = try rootDescriptor(create: false); defer { close(rootFD) }
        let dirFD = try directory(rootFD: rootFD, name: directoryName, create: false); defer { close(dirFD) }
        var info = stat()
        if fstatat(dirFD, filename, &info, AT_SYMLINK_NOFOLLOW) != 0 {
            if errno == ENOENT { return }
            throw Self.failure()
        }
        guard (info.st_mode & S_IFMT) == S_IFREG, info.st_uid == getuid(), info.st_nlink == 1,
              unlinkat(dirFD, filename, 0) == 0 else { throw Self.failure() }
        _ = fsync(dirFD)
    }
    public func url(relativePath: String) throws -> URL {
        _ = try read(relativePath: relativePath)
        return root.appendingPathComponent(relativePath)
    }
    public static func destination(channel: Channel, conversationID: UUID, artifactID: UUID, filename: String) throws -> ArtifactDestination? {
        guard channel.deletedAt == nil, channel.autoSave, let repository = try SavedWorkspace.normalizedRepository(channel.repository) else { return nil }
        try validateFilename(filename)
        guard channel.folder == "model-forum/channels/" + channel.id.uuidString.lowercased() else { throw ForumError.message("The channel artifact folder is invalid.") }
        return ArtifactDestination(repository: repository, path: channel.folder + "/conversations/" + conversationID.uuidString.lowercased() + "/" + artifactID.uuidString.lowercased() + "/" + filename)
    }

    public static func extract(from text: String) throws -> [ArtifactDraft] {
        var drafts = [ArtifactDraft](), filenames = Set<String>()
        func append(_ filename: String, _ contents: String) throws {
            try validateFilename(filename)
            guard let mime = textTypes[(filename as NSString).pathExtension.lowercased()] else { throw ForumError.message("Text output cannot be saved as a binary image or PDF.") }
            guard filenames.insert(filename.lowercased()).inserted else { throw ForumError.message("Generated output contains duplicate file names. Give each file a unique name.") }
            guard drafts.count < 8 else { throw ForumError.message("A reply may generate at most eight files.") }
            let data = Data(contents.utf8)
            guard data.count <= maximumBytes else { throw ForumError.message("Generated files must be at most 8 MiB.") }
            drafts.append(ArtifactDraft(filename: filename, mimeType: mime, data: data))
        }
        func standalone(_ contents: String) -> Bool {
            contents.contains("\\documentclass") && contents.contains("\\begin{document}") && contents.contains("\\end{document}")
        }
        let lines = text.components(separatedBy: "\n")
        var header: String?, body = [String](), fenceLength = 0
        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            if let active = header {
                if trimmed.count >= fenceLength && trimmed.allSatisfy({ $0 == "`" }) {
                    let contents = body.joined(separator: "\n") + "\n"
                    if let range = active.range(of: "filename=") {
                        let raw = String(active[range.upperBound...]).trimmingCharacters(in: .whitespaces)
                        let filename: String
                        if raw.hasPrefix("\"") {
                            guard raw.count >= 2, raw.hasSuffix("\"") else { throw ForumError.message("Generated filename has an incomplete quote.") }
                            filename = String(raw.dropFirst().dropLast())
                        } else { filename = raw }
                        try append(filename, contents)
                    } else if ["latex", "tex"].contains(active.lowercased()), standalone(contents) {
                        try append("document.tex", contents)
                    }
                    header = nil; body = []; fenceLength = 0
                } else { body.append(line) }
            } else if trimmed.hasPrefix("```") {
                fenceLength = trimmed.prefix(while: { $0 == "`" }).count
                header = String(trimmed.dropFirst(fenceLength)).trimmingCharacters(in: .whitespaces)
            }
        }
        if let header, header.contains("filename=") || ["tex", "latex"].contains(header.lowercased()) && standalone(body.joined(separator: "\n")) {
            throw ForumError.message("Generated file has an unclosed code fence; it was not saved.")
        }
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if drafts.isEmpty, !text.contains("```"), trimmed.hasPrefix("\\documentclass"), standalone(trimmed), trimmed.hasSuffix("\\end{document}") {
            try append("document.tex", trimmed + "\n")
        }
        return drafts
    }
}
