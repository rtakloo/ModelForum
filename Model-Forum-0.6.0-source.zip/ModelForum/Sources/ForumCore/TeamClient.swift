import Foundation

/// Deliberate sharing format, not a serialized workspace or ChatMessage provenance record.
public struct TeamSharedMessage: Codable, Sendable {
    public let role: String
    public let author: String
    public let content: String
    public let model: String?
    public init(_ message: ChatMessage) {
        role = message.role; author = message.author; content = message.content; model = message.model
    }
}
public struct TeamSharedConversation: Codable, Sendable {
    public let title: String
    public let messages: [TeamSharedMessage]
    public init(_ conversation: Conversation) throws {
        title = conversation.title
        messages = conversation.messages.map(TeamSharedMessage.init)
        try validate()
    }
    public func validate() throws {
        guard !title.isEmpty, title.count <= 160, messages.count <= 500,
              messages.allSatisfy({ ["user", "assistant", "system"].contains($0.role) && !$0.author.isEmpty && $0.author.count <= 160 && $0.content.count <= 200_000 }),
              try JSONEncoder().encode(self).count <= 510_000 else {
            throw ForumError.message("The selected conversation exceeds the team sharing limits.")
        }
    }
    public func localCopy() throws -> Conversation {
        try validate()
        // Import copies visible text; no channel IDs, account labels, instructions, or remote provenance.
        return Conversation(title: title, messages: messages.map { ChatMessage(role: $0.role, author: $0.author, content: $0.content, model: $0.model) })
    }
}
public struct TeamMembership: Codable, Identifiable, Sendable {
    public let id: String
    public let name: String
    public let role: String
}
public struct TeamIdentity: Codable, Sendable { public let userID: String; public let teams: [TeamMembership] }
public struct TeamSession: Codable, Sendable { public let token: String; public let expires: Double }
public struct TeamMember: Codable, Identifiable, Sendable { public let id: String; public let email: String; public let role: String }
public struct TeamMembers: Codable, Sendable { public let members: [TeamMember] }
public struct TeamInvitation: Codable, Identifiable, Sendable { public let id: String; public let email: String; public let role: String; public let expires: Double }
public struct TeamInvitations: Codable, Sendable { public let invitations: [TeamInvitation] }
public struct TeamInviteToken: Codable, Sendable { public let id: String; public let token: String; public let expires: Double }
public struct TeamDocumentSummary: Codable, Identifiable, Sendable { public let id: String; public let revision: Int }
public struct TeamDocuments: Codable, Sendable { public let documents: [TeamDocumentSummary] }
public struct TeamDocument: Codable, Sendable { public let id: String; public let revision: Int; public let snapshot: TeamSharedConversation }
public struct TeamLicense: Codable, Sendable { public let active: Bool; public let status: String; public let validUntil: Double; public let billingConfigured: Bool; public let licenseRequired: Bool }
public struct TeamBillingDestination: Codable, Sendable { public let url: String }
public struct TeamOK: Codable, Sendable { public let ok: Bool }
public struct TeamAuditEvent: Codable, Identifiable, Sendable { public let id: Int; public let created: Double; public let actor: String?; public let action: String; public let resource: String?; public let revision: Int? }
public struct TeamAudit: Codable, Sendable { public let events: [TeamAuditEvent] }

public enum TeamEndpoint {
    public static func normalized(_ raw: String) throws -> URL {
        guard var parts = URLComponents(string: raw.trimmingCharacters(in: .whitespacesAndNewlines)),
              let host = parts.host, !host.isEmpty, parts.user == nil, parts.password == nil,
              parts.query == nil, parts.fragment == nil, parts.path.isEmpty || parts.path == "/",
              parts.scheme == "https" || (parts.scheme == "http" && ["127.0.0.1", "localhost", "::1"].contains(host)) else {
            throw ForumError.message("Use an HTTPS server origin, or http://127.0.0.1:8765 for local development. Paths and credentials are not allowed.")
        }
        parts.path = ""
        guard let url = parts.url else { throw ForumError.message("Invalid team server URL.") }
        return url
    }
    public static func pathID(_ raw: String) throws -> String {
        guard raw.range(of: #"^[A-Za-z0-9_-]{1,80}$"#, options: .regularExpression) != nil else { throw ForumError.message("Use a shared ID containing 1–80 letters, digits, underscores or hyphens.") }
        return raw
    }
    public static func billingURL(_ raw: String) throws -> URL {
        guard let parts = URLComponents(string: raw), parts.scheme == "https", ["checkout.stripe.com", "billing.stripe.com"].contains(parts.host ?? ""),
              parts.user == nil, parts.password == nil, parts.port == nil, let url = parts.url else { throw ForumError.message("Unexpected billing destination.") }
        return url
    }
}

public final class TeamClient: @unchecked Sendable {
    public let endpoint: URL
    private let session: URLSession
    public init(endpoint: String) throws {
        self.endpoint = try TeamEndpoint.normalized(endpoint)
        let config = URLSessionConfiguration.ephemeral
        config.urlCache = nil; config.httpCookieStorage = nil; config.urlCredentialStorage = nil
        config.timeoutIntervalForRequest = 25; config.timeoutIntervalForResource = 40
        session = URLSession(configuration: config)
    }
    deinit { session.invalidateAndCancel() }
    public func request<T: Decodable & Sendable>(_ method: String, path: String, token: String? = nil, body: Data? = nil, as type: T.Type) async throws -> T {
        guard path.hasPrefix("/v1/"), path.range(of: #"^/v1/[A-Za-z0-9_/-]+$"#, options: .regularExpression) != nil,
              (body?.count ?? 0) <= 524_288 else { throw ForumError.message("Invalid team request.") }
        var request = URLRequest(url: endpoint.appendingPathComponent(String(path.dropFirst())))
        request.httpMethod = method; request.httpBody = body; request.httpShouldHandleCookies = false
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token { request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization") }
        do {
            let (bytes, response) = try await session.bytes(for: request, delegate: TeamRedirectGuard())
            guard let http = response as? HTTPURLResponse else { throw ForumError.message("Invalid team response.") }
            guard (200..<300).contains(http.statusCode) else {
                let message: String
                switch http.statusCode {
                case 401: message = "Sign in again; the session or credentials are invalid."
                case 402: message = "Publishing requires an active team license. Reading and import remain available."
                case 403: message = "Your membership, invitation or role does not allow this action."
                case 404: message = "The shared item or endpoint was not found."
                case 409: message = "The server rejected a conflicting change. Pull the latest revision; a team must also retain an owner."
                case 413: message = "This conversation exceeds the team sharing size limit."
                case 429: message = "Too many team requests. Wait before retrying."
                case 503: message = "This server feature is not configured or is unavailable."
                default: message = "The team server rejected the request (HTTP \(http.statusCode))."
                }
                throw ForumError.message(message)
            }
            var data = Data()
            for try await byte in bytes {
                guard data.count < 600_000 else { throw ForumError.message("Team response exceeds the size limit.") }
                data.append(byte)
            }
            try Task.checkCancellation()
            return try JSONDecoder().decode(type, from: data)
        } catch is CancellationError { throw CancellationError() }
        catch let error as ForumError { throw error }
        catch {
            if Task.isCancelled { throw CancellationError() }
            throw ForumError.message("Could not complete the team request. Check the server address and connection. No automatic retry was sent.")
        }
    }
    public static func body(_ value: [String: Any]) throws -> Data { try JSONSerialization.data(withJSONObject: value) }
}
private final class TeamRedirectGuard: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
