import Foundation

public enum UsageRecordStatus: String, Codable, Sendable { case reserved, completed, uncertain }

public struct UsageRecord: Identifiable, Codable, Sendable {
    public var id: UUID
    public var sessionID: UUID
    public var date: Date
    public var provider: ProviderKind
    public var model: String
    public var billingMode: UsageBillingMode
    public var status: UsageRecordStatus
    public var estimatedInputTokens: Int
    public var maxOutputTokens: Int
    public var inputTokens: Int?
    public var outputTokens: Int?
    public var price: ModelPrice?
    public var reservedUSD: Double?
    public var estimatedCostUSD: Double?
    /// Missing usage and uncertain requests retain their original reservation.
    public var accountedUSD: Double? { estimatedCostUSD ?? reservedUSD }

    public func validate() throws {
        let invalid = ForumError.message("The saved usage ledger contains invalid accounting data. Restore a valid backup before sending more requests.")
        guard date.timeIntervalSinceReferenceDate.isFinite,
              !model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              (0...(8 * 1024 * 1024 + 1024)).contains(estimatedInputTokens),
              (1...65_536).contains(maxOutputTokens),
              inputTokens.map({ $0 >= 0 }) ?? true,
              outputTokens.map({ $0 >= 0 }) ?? true else { throw invalid }
        for amount in [reservedUSD, estimatedCostUSD].compactMap({ $0 }) {
            guard amount.isFinite, amount >= 0 else { throw invalid }
        }
        if let price {
            try price.validate()
            guard billingMode == .api, price.provider == provider, price.model == model,
                  reservedUSD == price.estimate(input: estimatedInputTokens, output: maxOutputTokens) else { throw invalid }
        } else if reservedUSD != nil || estimatedCostUSD != nil { throw invalid }
        if let estimatedCostUSD {
            guard status == .completed, let price, let inputTokens, let outputTokens,
                  estimatedCostUSD == price.estimate(input: inputTokens, output: outputTokens) else { throw invalid }
        }
    }
}

public struct UsageLedger: Codable, Sendable {
    public var records: [UsageRecord]
    public init(records: [UsageRecord] = []) { self.records = records }
    private enum CodingKeys: String, CodingKey { case records }
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        records = try container.decode([UsageRecord].self, forKey: .records)
        try validate()
    }
    public func encode(to encoder: Encoder) throws {
        try validate()
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(records, forKey: .records)
    }
    /// Also called by request authorization and backup import, since callers can mutate records.
    public func validate() throws {
        guard Set(records.map(\.id)).count == records.count else { throw ForumError.message("The saved usage ledger contains duplicate request IDs.") }
        for record in records { try record.validate() }
    }

    /// UTF-8 bytes plus envelope overhead intentionally overestimates ordinary text token counts.
    public static func conservativeInputTokens(_ transcript: String) throws -> Int {
        guard transcript.utf8.count <= 8 * 1024 * 1024 else { throw ForumError.message("The request context exceeds the local size limit.") }
        return transcript.utf8.count + 1024
    }

    /// Persist the returned reservation before initiating the network request.
    @discardableResult public mutating func reserve(participant: Participant, transcript: String, maxOutputTokens: Int, sessionID: UUID, billingMode: UsageBillingMode, policy: SpendingPolicy, date: Date = Date()) throws -> UsageRecord {
        try policy.validate()
        try validate()
        guard date.timeIntervalSinceReferenceDate.isFinite else { throw ForumError.message("The request date is invalid.") }
        guard (1...65_536).contains(maxOutputTokens) else { throw ForumError.message("The output token cap must be between 1 and 65,536.") }
        let input = try Self.conservativeInputTokens(transcript)
        let price = billingMode == .api ? policy.price(for: participant) : nil
        let estimate = price?.estimate(input: input, output: maxOutputTokens)
        if billingMode == .localOrUnknown && policy.hasCaps {
            throw ForumError.message("This connection's billing is unknown. A spending cap cannot safely authorize a locally routed or external-tool request.")
        }
        if billingMode == .api && policy.hasCaps && estimate == nil {
            throw ForumError.message("This model's API price is unknown. Set input and output prices before using a spending cap.")
        }
        if billingMode == .api, let estimate {
            if let cap = policy.requestCapUSD, estimate > cap { throw ForumError.message("The full request reservation exceeds the per-request spending cap.") }
            if let cap = policy.sessionCapUSD {
                try Self.check(records.filter { $0.sessionID == sessionID && $0.billingMode == .api }, additional: estimate, cap: cap, name: "session")
            }
            if let cap = policy.monthlyCapUSD {
                let month = Self.monthKey(date)
                try Self.check(records.filter { Self.monthKey($0.date) == month && $0.billingMode == .api }, additional: estimate, cap: cap, name: "monthly")
            }
        }
        let record = UsageRecord(id: UUID(), sessionID: sessionID, date: date, provider: participant.provider, model: participant.model, billingMode: billingMode, status: .reserved, estimatedInputTokens: input, maxOutputTokens: maxOutputTokens, inputTokens: nil, outputTokens: nil, price: price, reservedUSD: estimate, estimatedCostUSD: nil)
        try record.validate()
        records.append(record)
        return record
    }

    public mutating func settle(id: UUID, reply: ModelReply) {
        guard let i = records.firstIndex(where: { $0.id == id }), records[i].status != .completed else { return }
        records[i].status = .completed
        records[i].inputTokens = reply.inputTokens.flatMap { $0 >= 0 ? $0 : nil }
        records[i].outputTokens = reply.outputTokens.flatMap { $0 >= 0 ? $0 : nil }
        // A provider may resolve an alias to a differently priced model. Do not silently apply the old rate.
        if reply.model != records[i].model {
            records[i].model = reply.model
            records[i].price = nil
            records[i].reservedUSD = nil
            records[i].estimatedCostUSD = nil
        }
        if let input = records[i].inputTokens, let output = records[i].outputTokens,
           let price = records[i].price, price.model == reply.model, records[i].billingMode == .api {
            records[i].estimatedCostUSD = price.estimate(input: input, output: output)
        }
    }
    public mutating func markUncertain(id: UUID) {
        guard let i = records.firstIndex(where: { $0.id == id }), records[i].status != .completed else { return }
        records[i].status = .uncertain
    }
    /// On startup, interrupted requests are not assumed free or automatically retried.
    public mutating func recoverInterruptedRequests() {
        for i in records.indices where records[i].status == .reserved { records[i].status = .uncertain }
    }
    public static func monthKey(_ date: Date) -> String {
        var calendar = Calendar(identifier: .gregorian); calendar.timeZone = TimeZone(secondsFromGMT: 0)!
        let parts = calendar.dateComponents([.year, .month], from: date)
        return "\(parts.year ?? 0)-\(parts.month ?? 0)"
    }
    private static func check(_ records: [UsageRecord], additional: Double, cap: Double, name: String) throws {
        for record in records { try record.validate() }
        guard records.allSatisfy({ $0.accountedUSD != nil }) else { throw ForumError.message("An earlier API request has unknown cost. The \(name) cap cannot safely authorize another request.") }
        let total = records.compactMap(\.accountedUSD).reduce(0, +)
        guard total.isFinite, total + additional <= cap else { throw ForumError.message("The full request reservation exceeds the \(name) spending cap.") }
    }
}
