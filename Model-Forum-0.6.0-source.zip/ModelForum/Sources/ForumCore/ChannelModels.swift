import Foundation

public struct Channel: Identifiable, Codable, Equatable, Sendable {
    public var id: UUID
    public var name: String
    public var repository: String?
    public var autoSave: Bool
    public var folder: String
    public var deletedAt: Date?
    public init(id: UUID = UUID(), name: String, repository: String? = nil, autoSave: Bool = false, deletedAt: Date? = nil) {
        self.id = id; self.name = name; self.repository = repository; self.autoSave = autoSave
        self.folder = "model-forum/channels/" + id.uuidString.lowercased()
        self.deletedAt = deletedAt
    }
}

public struct ArtifactDestination: Codable, Equatable, Sendable {
    public var repository: String
    public var branch: String
    public var path: String
    public init(repository: String, branch: String = "model-forum-artifacts", path: String) {
        self.repository = repository; self.branch = branch; self.path = path
    }
}

public enum ArtifactSyncState: String, Codable, Sendable {
    case localOnly, pending, uploading, uploaded, failed
}

public struct ArtifactRecord: Identifiable, Codable, Sendable {
    public var id: UUID
    public var conversationID: UUID
    public var messageID: UUID
    public var filename: String
    public var mimeType: String
    public var relativePath: String
    public var byteCount: Int
    public var createdAt: Date
    public var destination: ArtifactDestination?
    public var syncState: ArtifactSyncState
    public var remoteURL: String?
    public var commitSHA: String?
    public var syncError: String?
    public init(id: UUID = UUID(), conversationID: UUID, messageID: UUID, filename: String, mimeType: String, relativePath: String, byteCount: Int, destination: ArtifactDestination? = nil) {
        self.id = id; self.conversationID = conversationID; self.messageID = messageID
        self.filename = filename; self.mimeType = mimeType; self.relativePath = relativePath; self.byteCount = byteCount
        self.createdAt = Date(); self.destination = destination; self.syncState = destination == nil ? .localOnly : .pending
    }
}

public struct ArtifactDraft: Sendable {
    public let filename: String
    public let mimeType: String
    public let data: Data
    public init(filename: String, mimeType: String, data: Data) { self.filename = filename; self.mimeType = mimeType; self.data = data }
}

public struct ArtifactUploadResult: Sendable {
    public let url: String
    public let commitSHA: String?
    public init(url: String, commitSHA: String?) { self.url = url; self.commitSHA = commitSHA }
}
