import Foundation
import Darwin

/// Read-only integrations with executables installed and authenticated by the user.
/// This is a tool restriction, not an operating-system sandbox. Managed CLI policy still applies.
public enum LocalTools {
    public static func githubContext(url: String) async throws -> String {
        let request = try GitHubRequest(url)
        let executable = try trustedExecutable(named: "gh", paths: ["/opt/homebrew/bin/gh", "/usr/local/bin/gh"])
        let directory = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: directory) }
        var environment = baseEnvironment
        environment["GH_PROMPT_DISABLED"] = "1"
        environment["GH_PAGER"] = "cat"
        return try await githubContext(request: request) { arguments in
            let result = try await Subprocess.run(executable: executable, arguments: arguments,
                input: Data(), directory: directory, environment: environment, timeout: 30, outputLimit: 2_097_152)
            return try GitHubRepository.responseBody(result, includesHeaders: arguments.first == "api")
        }
    }

    /// Injectable read-only transport for deterministic fixture tests; never exposed to model tool calls.
    static func githubContext(url: String, fetch: ([String]) async throws -> Data) async throws -> String {
        try await githubContext(request: GitHubRequest(url), fetch: fetch)
    }

    private static func githubContext(request: GitHubRequest, fetch: ([String]) async throws -> Data) async throws -> String {
        if request.isRepository { return try await GitHubRepository.context(request: request, fetch: fetch) }
        let data = try await fetch(request.arguments)
        let value = try JSONDecoder().decode(GitHubDocument.self, from: data)
        let revision = value.headRefOid.map { "\nPR head commit: \($0)" } ?? ""
        return "GitHub source: \(request.canonicalURL)\(revision)\nTitle: \(value.title)\n\n\(value.body ?? "")"
    }

    public static func claudeReply(model: String, transcript: String, maxOutputTokens: Int) async throws -> ModelReply {
        guard model.range(of: "^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$", options: .regularExpression) != nil,
              (1...32_768).contains(maxOutputTokens) else {
            throw ForumError.message("Choose a valid Claude model and output limit from 1 to 32768 tokens.")
        }
        let executable = try trustedExecutable(named: "claude", paths: [
            "/opt/homebrew/bin/claude", "/usr/local/bin/claude",
            FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent(".local/bin/claude").path
        ])
        let directory = try temporaryDirectory()
        defer { try? FileManager.default.removeItem(at: directory) }
        var environment = baseEnvironment
        environment["CLAUDE_CODE_MAX_OUTPUT_TOKENS"] = String(maxOutputTokens)
        environment["CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"] = "1"
        environment["CLAUDE_CODE_DISABLE_CLAUDE_MDS"] = "1"
        environment["CLAUDE_CODE_SKIP_PROMPT_HISTORY"] = "1"
        let result = try await Subprocess.run(executable: executable, arguments: claudeArguments(model: model),
            input: Data(transcript.utf8), directory: directory, environment: environment, timeout: 180, outputLimit: 2_097_152)
        guard result.status == 0 else {
            throw ForumError.message("Claude Code failed (exit \(result.status)). Use a current CLI with support for restricted/safe mode and sign in from Terminal. Security flags are never silently removed.")
        }
        return try decodeClaude(result.stdout, model: model)
    }

    static func claudeArguments(model: String) -> [String] {
        ["--print", "--output-format", "json", "--input-format", "text",
         "--model", model, "--tools", "", "--disallowedTools", "*",
         "--strict-mcp-config", "--mcp-config", "{\"mcpServers\":{}}",
         "--disable-slash-commands", "--no-session-persistence", "--no-chrome",
         "--setting-sources", "", "--settings", "{\"disableAllHooks\":true}",
         "--safe-mode", "--restricted", "--max-turns", "1"]
    }

    static func decodeClaude(_ data: Data, model: String) throws -> ModelReply {
        struct Response: Decodable {
            struct Usage: Decodable { let input_tokens: Int?; let output_tokens: Int? }
            struct ModelUsage: Decodable {}
            let result: String?
            let is_error: Bool?
            let subtype: String?
            let stop_reason: String?
            let model: String?
            let modelUsage: [String: ModelUsage]?
            let usage: Usage?
        }
        let response = try JSONDecoder().decode(Response.self, from: data)
        // CLI result subtypes other than success include max-turn/budget and execution failures.
        // Never accept their partial text as a completed answer, even if is_error is missing or false.
        guard response.subtype == nil || response.subtype == "success",
              response.stop_reason == nil || ["end_turn", "stop_sequence", "refusal"].contains(response.stop_reason!) else {
            throw ForumError.message("Claude Code did not complete its answer. It may have reached a token, turn, or budget limit. Adjust the limit or shorten the request and try again.")
        }
        guard response.is_error != true, let text = response.result, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw ForumError.message("Claude Code returned an error or an empty answer.")
        }
        let reportedModel = response.model?.trimmingCharacters(in: .whitespacesAndNewlines)
        let usageModels = response.modelUsage?.keys.filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty } ?? []
        let actualModel: String
        if let reportedModel, !reportedModel.isEmpty { actualModel = reportedModel }
        else if usageModels.count == 1 { actualModel = usageModels[0] }
        else { actualModel = "\(model) (requested; actual model unresolved)" }
        return ModelReply(text: text, model: actualModel, inputTokens: response.usage?.input_tokens, outputTokens: response.usage?.output_tokens)
    }

    private struct GitHubDocument: Decodable { let title: String; let body: String?; let headRefOid: String? }

    static var baseEnvironment: [String: String] {
        // Do not inherit API tokens, proxy overrides, shell startup, dynamic-loader or runtime injection variables.
        ["HOME": FileManager.default.homeDirectoryForCurrentUser.path,
         "PATH": "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin",
         "LANG": "en_US.UTF-8", "TMPDIR": FileManager.default.temporaryDirectory.path]
    }

    private static func temporaryDirectory() throws -> URL {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("ModelForum-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        return directory
    }

    static func trustedExecutable(named name: String, paths: [String]) throws -> URL {
        for path in paths {
            let url = URL(fileURLWithPath: path).resolvingSymlinksInPath()
            guard FileManager.default.isExecutableFile(atPath: url.path),
                  let attributes = try? FileManager.default.attributesOfItem(atPath: url.path),
                  attributes[.type] as? FileAttributeType == .typeRegular,
                  let owner = attributes[.ownerAccountID] as? NSNumber,
                  owner.uint32Value == 0 || owner.uint32Value == getuid(),
                  let mode = attributes[.posixPermissions] as? NSNumber,
                  mode.intValue & 0o022 == 0 else { continue }
            return url
        }
        throw ForumError.message("Install and authenticate \(name) in a standard location first. Executables writable by other users are not accepted.")
    }
}

struct GitHubRequest {
    let canonicalURL: String
    let arguments: [String]
    let repository: String
    let isRepository: Bool
    init(_ raw: String) throws {
        // Match the raw URL, rejecting encoded path separators, credentials, query strings and alternate hosts.
        let pattern = #"^https://github\.com/([A-Za-z0-9][A-Za-z0-9-]{0,38})/([A-Za-z0-9_.-]{1,100})(?:/(issues|pull)/([1-9][0-9]{0,9}))?/?$"#
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(in: raw, range: NSRange(raw.startIndex..., in: raw)),
              match.range.length == raw.utf16.count else {
            throw ForumError.message("Use an https://github.com/owner/repository URL, optionally ending in /issues/123 or /pull/123, without query parameters.")
        }
        func part(_ index: Int) -> String { String(raw[Range(match.range(at: index), in: raw)!]) }
        let owner = part(1), repo = part(2)
        guard repo != ".", repo != "..", !owner.hasSuffix("-") else { throw ForumError.message("Invalid GitHub repository URL.") }
        repository = "\(owner)/\(repo)"
        isRepository = match.range(at: 3).location == NSNotFound
        if isRepository {
            canonicalURL = "https://github.com/\(repository)"
            arguments = ["repo", "view", canonicalURL, "--json", "nameWithOwner,description,isPrivate,isEmpty,defaultBranchRef"]
            return
        }
        let kind = part(3), number = part(4)
        canonicalURL = "https://github.com/\(owner)/\(repo)/\(kind)/\(number)"
        arguments = [kind == "pull" ? "pr" : "issue", "view", canonicalURL, "--json",
                     kind == "pull" ? "title,body,url,headRefOid,baseRefName" : "title,body,url"]
    }
}

struct SubprocessResult { let stdout: Data; let stderr: Data; let status: Int32 }

enum SubprocessError: LocalizedError, Equatable {
    case timedOut, outputTooLarge, inputTooLarge, inputFailed, invalidLimits

    var errorDescription: String? {
        switch self {
        case .timedOut: return "The local CLI exceeded its time limit and was stopped. Check its authentication and connection, or shorten the request before retrying."
        case .outputTooLarge: return "The local CLI exceeded the output size limit and was stopped. Request a shorter answer or import a smaller GitHub item."
        case .inputTooLarge: return "The request exceeds the local CLI input size limit. Remove some context and try again."
        case .inputFailed: return "The local CLI closed its input before receiving the full request. Check its installation and authentication in Terminal."
        case .invalidLimits: return "The local CLI was not started because its timeout or output limit is invalid."
        }
    }
}

private final class ProcessCancellation: @unchecked Sendable {
    private let lock = NSLock()
    private var flag = false
    func cancel() { lock.lock(); flag = true; lock.unlock() }
    var cancelled: Bool { lock.lock(); defer { lock.unlock() }; return flag }
}

enum Subprocess {
    /// Multiplexed, nonblocking stdin/stdout/stderr avoids pipe deadlocks and bounds total output.
    /// Cancellation terminates the direct executable; this runner must not be used for arbitrary agent shell commands.
    static func run(executable: URL, arguments: [String], input: Data = Data(), directory: URL? = nil,
                    environment: [String: String] = [:], timeout: TimeInterval = 30, outputLimit: Int = 1_048_576,
                    inputLimit: Int = 2_097_152) async throws -> SubprocessResult {
        guard timeout > 0, timeout.isFinite, outputLimit > 0, inputLimit > 0 else { throw SubprocessError.invalidLimits }
        guard input.count <= inputLimit else { throw SubprocessError.inputTooLarge }
        let cancellation = ProcessCancellation()
        return try await withTaskCancellationHandler(operation: {
            try Task.checkCancellation()
            return try await withCheckedThrowingContinuation { continuation in
                DispatchQueue.global(qos: .userInitiated).async {
                    do { continuation.resume(returning: try execute(executable: executable, arguments: arguments,
                        input: input, directory: directory, environment: environment, timeout: timeout,
                        outputLimit: outputLimit, cancellation: cancellation)) }
                    catch { continuation.resume(throwing: error) }
                }
            }
        }, onCancel: { cancellation.cancel() })
    }

    private static func execute(executable: URL, arguments: [String], input: Data, directory: URL?,
                                environment: [String: String], timeout: TimeInterval, outputLimit: Int,
                                cancellation: ProcessCancellation) throws -> SubprocessResult {
        if cancellation.cancelled { throw CancellationError() }
        let process = Process()
        let stdin = Pipe(), stdout = Pipe(), stderr = Pipe()
        process.executableURL = executable; process.arguments = arguments
        process.environment = environment; process.currentDirectoryURL = directory
        process.standardInput = stdin; process.standardOutput = stdout; process.standardError = stderr
        let inputHandle = stdin.fileHandleForWriting
        let handles = [stdout.fileHandleForReading, stderr.fileHandleForReading]
        defer {
            try? inputHandle.close()
            for handle in handles { try? handle.close() }
        }
        try process.run()
        // Close our copies of the child endpoints so EOF is observable.
        try? stdin.fileHandleForReading.close()
        try? stdout.fileHandleForWriting.close()
        try? stderr.fileHandleForWriting.close()
        let inputFD = inputHandle.fileDescriptor
        _ = fcntl(inputFD, F_SETFL, fcntl(inputFD, F_GETFL) | O_NONBLOCK)
        _ = fcntl(inputFD, F_SETNOSIGPIPE, 1)
        for handle in handles { _ = fcntl(handle.fileDescriptor, F_SETFL, fcntl(handle.fileDescriptor, F_GETFL) | O_NONBLOCK) }
        let started = ProcessInfo.processInfo.systemUptime
        var buffers = [Data(), Data()]
        var ended = [false, false]
        var offset = 0
        var inputClosed = false
        func stop() {
            if process.isRunning { process.terminate() }
            let deadline = ProcessInfo.processInfo.systemUptime + 0.25
            while process.isRunning && ProcessInfo.processInfo.systemUptime < deadline { usleep(5_000) }
            if process.isRunning { _ = kill(process.processIdentifier, SIGKILL) }
            process.waitUntilExit()
        }
        do {
            while true {
                if cancellation.cancelled { throw CancellationError() }
                if ProcessInfo.processInfo.systemUptime - started > timeout { throw SubprocessError.timedOut }
                if !inputClosed {
                    if offset == input.count { try? inputHandle.close(); inputClosed = true }
                    else {
                        let count = input.withUnsafeBytes { bytes in
                            Darwin.write(inputFD, bytes.baseAddress!.advanced(by: offset), min(input.count - offset, 16_384))
                        }
                        if count > 0 { offset += count }
                        else if count < 0 && errno != EAGAIN && errno != EINTR { throw SubprocessError.inputFailed }
                    }
                }
                for index in 0..<2 where !ended[index] {
                    // Read one chunk from each pipe per cycle so noisy stdout cannot starve stderr or cancellation.
                    var chunk = [UInt8](repeating: 0, count: 16_384)
                    let count = Darwin.read(handles[index].fileDescriptor, &chunk, chunk.count)
                    if count > 0 {
                        guard buffers[0].count + buffers[1].count + count <= outputLimit else { throw SubprocessError.outputTooLarge }
                        buffers[index].append(contentsOf: chunk.prefix(count))
                    } else if count == 0 { ended[index] = true }
                    else if errno != EAGAIN && errno != EINTR { ended[index] = true }
                }
                if !process.isRunning && ended.allSatisfy({ $0 }) { break }
                usleep(1_000)
            }
            process.waitUntilExit()
            return SubprocessResult(stdout: buffers[0], stderr: buffers[1], status: process.terminationStatus)
        } catch { stop(); throw error }
    }
}
