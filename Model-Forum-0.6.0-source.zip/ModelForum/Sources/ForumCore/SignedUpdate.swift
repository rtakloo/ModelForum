import Foundation
import CryptoKit

public struct UpdateRelease: Codable, Sendable {
    public var version: String
    public var build: Int
    public var minimumMacOSMajor: Int
    public var downloadURL: URL
    public var sha256: String
    public var byteCount: Int
    public var expiresAt: Date
    public var notes: String
    public init(version: String, build: Int, minimumMacOSMajor: Int, downloadURL: URL, sha256: String, byteCount: Int, expiresAt: Date, notes: String) {
        self.version = version; self.build = build; self.minimumMacOSMajor = minimumMacOSMajor; self.downloadURL = downloadURL
        self.sha256 = sha256; self.byteCount = byteCount; self.expiresAt = expiresAt; self.notes = notes
    }
}
public struct SignedUpdateEnvelope: Codable {
    public var payload: Data
    public var signature: Data
    public init(payload: Data, signature: Data) { self.payload = payload; self.signature = signature }
}
public enum SignedUpdate {
    public static func verify(_ data: Data, publicKey: Data, currentBuild: Int, allowedHost: String, now: Date = Date(), macOSMajor: Int = ProcessInfo.processInfo.operatingSystemVersion.majorVersion) throws -> UpdateRelease {
        guard data.count <= 256 * 1024, let key = try? Curve25519.Signing.PublicKey(rawRepresentation: publicKey),
              let envelope = try? JSONDecoder().decode(SignedUpdateEnvelope.self, from: data),
              key.isValidSignature(envelope.signature, for: envelope.payload),
              let release = try? JSONDecoder().decode(UpdateRelease.self, from: envelope.payload) else { throw ForumError.message("The update manifest signature is invalid. No update was downloaded.") }
        guard release.build > currentBuild, release.expiresAt > now,
              release.minimumMacOSMajor <= macOSMajor, release.downloadURL.scheme == "https",
              release.downloadURL.host?.lowercased() == allowedHost.lowercased(), release.downloadURL.user == nil, release.downloadURL.password == nil,
              release.downloadURL.port == nil || release.downloadURL.port == 443,
              release.downloadURL.path.hasSuffix(".zip"), (1...536_870_912).contains(release.byteCount),
              release.sha256.range(of: "^[a-f0-9]{64}$", options: .regularExpression) != nil,
              release.version.utf8.count <= 64, release.notes.utf8.count <= 16_384 else { throw ForumError.message("No newer compatible, unexpired update is available, or its download metadata is invalid.") }
        return release
    }
    public static func verifyDownload(_ data: Data, release: UpdateRelease) throws {
        guard data.count == release.byteCount, WorkspaceArchive.hash(data) == release.sha256 else { throw ForumError.message("The downloaded update failed its integrity check.") }
    }
}
