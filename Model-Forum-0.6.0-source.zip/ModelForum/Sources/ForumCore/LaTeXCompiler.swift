import Foundation
import Darwin

enum LaTeXCompilationError: LocalizedError, Equatable {
    case unavailable, invalidSource, failed, sandboxUnavailable, timedOut, invalidPDF, tooLarge
    var errorDescription: String? {
        switch self {
        case .unavailable: return "Local PDF compilation requires a trusted MacTeX pdfLaTeX installation and macOS sandbox-exec. Compilation never runs without the sandbox."
        case .invalidSource: return "Choose a .tex basename and UTF-8 LaTeX source no larger than 2 MiB."
        case .failed: return "LaTeX compilation failed. Check the source and installed packages. External files, shell commands, automatic package installation and network access are disabled."
        case .sandboxUnavailable: return "macOS could not establish the required compiler sandbox. No unsandboxed fallback was attempted."
        case .timedOut: return "LaTeX compilation exceeded its time or output limit and was stopped. Simplify the source and try again."
        case .invalidPDF: return "The compiler did not produce a valid PDF file. The source is retained."
        case .tooLarge: return "The compiled PDF exceeds the 8 MiB artifact limit. Reduce its size and try again."
        }
    }
}

/// Local compilation only. Runtime sandbox failures are fatal; installed-tool detection does not prove sandbox availability.
public struct LaTeXCompiler: Sendable {
    struct Configuration: Sendable { let engine: URL; let texRoot: URL; let sandbox: URL }
    struct Invocation: Sendable {
        let executable: URL
        let arguments: [String]
        let directory: URL
        let environment: [String: String]
        let timeout: TimeInterval
        let outputLimit: Int
    }
    typealias Runner = @Sendable (Invocation) async throws -> SubprocessResult
    private let configuration: Configuration?
    private let runner: Runner

    public init() {
        configuration = Self.discover()
        runner = { @Sendable invocation in
            try await Subprocess.run(executable: invocation.executable, arguments: invocation.arguments,
                directory: invocation.directory, environment: invocation.environment,
                timeout: invocation.timeout, outputLimit: invocation.outputLimit)
        }
    }
    init(configuration: Configuration?, runner: @escaping Runner) {
        self.configuration = configuration; self.runner = runner
    }
    public static var isAvailable: Bool { discover() != nil }
    public static var status: String {
        isAvailable ? "Local pdfLaTeX detected. Compilation requires the macOS sandbox to start successfully."
                    : "Local PDF compilation needs MacTeX pdfLaTeX and macOS sandbox-exec."
    }

    public func compile(source: Data, filename: String) async throws -> ArtifactDraft {
        guard source.count <= 2_097_152, !source.isEmpty, String(data: source, encoding: .utf8) != nil,
              filename.utf8.count <= 160, filename.lowercased().hasSuffix(".tex"), !filename.contains(".."),
              filename.range(of: #"\A[A-Za-z0-9][A-Za-z0-9._ -]*\.tex\z"#, options: [.regularExpression, .caseInsensitive]) != nil else {
            throw LaTeXCompilationError.invalidSource
        }
        guard let configuration else { throw LaTeXCompilationError.unavailable }
        try Task.checkCancellation()
        // Use a canonical system path so Foundation cannot turn /private/var into a sandbox-mismatched /var alias.
        let directory = URL(fileURLWithPath: "/private/tmp", isDirectory: true).appendingPathComponent("ModelForum-TeX-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        defer { try? FileManager.default.removeItem(at: directory) }
        // A fixed name avoids command-line interpretation of user filenames and keeps the writable set finite.
        try source.write(to: directory.appendingPathComponent("document.tex"), options: [.withoutOverwriting])
        let invocation = Self.invocation(configuration: configuration, directory: directory)
        for _ in 0..<2 {
            try Task.checkCancellation()
            let result: SubprocessResult
            do { result = try await runner(invocation) }
            catch is CancellationError { throw CancellationError() }
            catch SubprocessError.timedOut { throw LaTeXCompilationError.timedOut }
            catch SubprocessError.outputTooLarge { throw LaTeXCompilationError.timedOut }
            catch { throw LaTeXCompilationError.failed }
            guard result.status == 0 else {
                let diagnostics = String(decoding: result.stderr, as: UTF8.self)
                if diagnostics.contains("sandbox") { throw LaTeXCompilationError.sandboxUnavailable }
                throw LaTeXCompilationError.failed
            }
        }
        try Task.checkCancellation()
        let pdf = try Self.readPDF(directory.appendingPathComponent("document.pdf"))
        return ArtifactDraft(filename: String(filename.dropLast(4)) + ".pdf", mimeType: "application/pdf", data: pdf)
    }

    static func invocation(configuration: Configuration, directory: URL) -> Invocation {
        let root = configuration.texRoot.path
        let job = directory.path
        let profile = sandboxProfile(configuration: configuration, directory: directory)
        // This fixed wrapper handles resource limits before exec'ing sandbox-exec. No source text or user
        // filename is interpolated into shell code. Failure to set either limit prevents the engine launch.
        let wrapper = "ulimit -f 16384 && ulimit -t 30 && exec \"$@\""
        let arguments = ["-c", wrapper, "model-forum-latex", configuration.sandbox.path, "-p", profile,
                         configuration.engine.path, "-progname=pdflatex", "-fmt=pdflatex", "-no-shell-escape",
                         "-no-parse-first-line", "-interaction=nonstopmode", "-halt-on-error", "-file-line-error",
                         "-no-mktex=tex", "-no-mktex=tfm", "-no-mktex=pk", "-output-format=pdf",
                         "-jobname=document", "-output-directory=\(job)", "document.tex"]
        let environment = [
            "TMPDIR": job, "PATH": "/usr/bin:/bin", "LANG": "en_US.UTF-8",
            "TEXMFCNF": "\(root):\(root)/texmf-dist/web2c", "TEXMFHOME": "\(job)/texmf",
            "TEXMFCONFIG": "\(job)/texmf-config", "TEXMFVAR": "\(job)/texmf-var", "TEXMFOUTPUT": job,
            "openin_any": "p", "openout_any": "p", "shell_escape": "f",
            "MKTEXTEX": "0", "MKTEXTFM": "0", "MKTEXPK": "0", "MKTEXFMT": "0"
        ]
        return Invocation(executable: URL(fileURLWithPath: "/bin/sh"), arguments: arguments, directory: directory,
                          environment: environment, timeout: 40, outputLimit: 1_048_576)
    }

    static func sandboxProfile(configuration: Configuration, directory: URL) -> String {
        func quote(_ value: String) -> String {
            "\"" + value.replacingOccurrences(of: "\\", with: "\\\\").replacingOccurrences(of: "\"", with: "\\\"") + "\""
        }
        let job = directory.path
        // Fixed dyld cache locations from Apple's dyld-support.sb; never map the job or TeX data tree.
        let runtimeRoots = ["/System/Library", "/usr/lib",
                            "/System/Volumes/Preboot/Cryptexes/App/System",
                            "/System/Volumes/Preboot/Cryptexes/Incoming/OS",
                            "/System/Volumes/Preboot/Cryptexes/OS",
                            "/System/Cryptexes/App", "/System/Cryptexes/OS"]
        let readableRoots = [configuration.texRoot.path, job] + runtimeRoots
        let readRules = readableRoots.map { "(subpath \(quote($0)))" }.joined(separator: " ")
        let mapRules = (["(literal \(quote(configuration.engine.path)))"] + runtimeRoots.map {
            "(subpath \(quote($0)))"
        }).joined(separator: " ")
        // Only expected output files are writable. A source cannot exhaust disk with arbitrary filenames.
        let writableFiles = ["aux", "log", "pdf", "out", "toc", "lof", "lot"]
        let writeRules = writableFiles.map { "(literal \(quote(job + "/document." + $0)))" }.joined(separator: " ")
        var metadata = Set<String>(["/", "/dev", "/usr", "/System"])
        for path in readableRoots {
            var ancestor = URL(fileURLWithPath: path)
            while ancestor.path != "/" {
                ancestor.deleteLastPathComponent(); metadata.insert(ancestor.path)
            }
        }
        let metadataRules = metadata.sorted().map { "(literal \(quote($0)))" }.joined(separator: " ")
        return """
        (version 1)
        (deny default)
        (deny network*)
        (deny process-fork)
        (allow process-exec (literal \(quote(configuration.engine.path))))
        (allow sysctl-read)
        (allow file-read* \(readRules) (literal "/dev/null") (literal "/dev/urandom"))
        (allow file-map-executable \(mapRules))
        (allow file-read-metadata \(metadataRules))
        (allow file-write* \(writeRules))
        """
    }

    private static func discover() -> Configuration? {
        let engine = URL(fileURLWithPath: "/Library/TeX/texbin/pdflatex").resolvingSymlinksInPath()
        let sandbox = URL(fileURLWithPath: "/usr/bin/sandbox-exec")
        let root = engine.deletingLastPathComponent().deletingLastPathComponent().deletingLastPathComponent()
        guard engine.lastPathComponent == "pdftex", root.deletingLastPathComponent().path == "/usr/local/texlive",
              trusted(engine), trusted(sandbox), trusted(URL(fileURLWithPath: "/bin/sh")), trustedDirectory(root) else { return nil }
        return Configuration(engine: engine, texRoot: root, sandbox: sandbox)
    }
    private static func trusted(_ url: URL) -> Bool {
        guard FileManager.default.isExecutableFile(atPath: url.path),
              let attributes = try? FileManager.default.attributesOfItem(atPath: url.path),
              attributes[.type] as? FileAttributeType == .typeRegular,
              (attributes[.ownerAccountID] as? NSNumber)?.uint32Value == 0,
              let mode = attributes[.posixPermissions] as? NSNumber else { return false }
        return mode.intValue & 0o022 == 0
    }
    private static func trustedDirectory(_ url: URL) -> Bool {
        guard let attributes = try? FileManager.default.attributesOfItem(atPath: url.path),
              attributes[.type] as? FileAttributeType == .typeDirectory,
              (attributes[.ownerAccountID] as? NSNumber)?.uint32Value == 0,
              let mode = attributes[.posixPermissions] as? NSNumber else { return false }
        return mode.intValue & 0o022 == 0
    }

    private static func readPDF(_ url: URL) throws -> Data {
        let fd = open(url.path, O_RDONLY | O_NOFOLLOW | O_NONBLOCK | O_CLOEXEC)
        guard fd >= 0 else { throw LaTeXCompilationError.invalidPDF }
        defer { close(fd) }
        var info = stat()
        guard fstat(fd, &info) == 0, info.st_mode & S_IFMT == S_IFREG, info.st_nlink == 1 else { throw LaTeXCompilationError.invalidPDF }
        guard info.st_size <= 8 * 1_024 * 1_024 else { throw LaTeXCompilationError.tooLarge }
        guard info.st_size >= 12 else { throw LaTeXCompilationError.invalidPDF }
        var result = Data()
        var bytes = [UInt8](repeating: 0, count: 32_768)
        while result.count < info.st_size {
            let count = read(fd, &bytes, min(bytes.count, Int(info.st_size) - result.count))
            guard count > 0 else { throw LaTeXCompilationError.invalidPDF }
            result.append(contentsOf: bytes.prefix(count))
        }
        guard result.starts(with: Data("%PDF-".utf8)),
              result.suffix(1_024).range(of: Data("%%EOF".utf8)) != nil else { throw LaTeXCompilationError.invalidPDF }
        return result
    }
}
