import Foundation

/// A snapshot prevents one operation from mixing GitHub App and CLI accounts.
struct GitHubAccessSession: Sendable {
    let client: GitHubAppClient?
    let generation: String
    static func selected() throws -> Self {
        let generation = GitHubAppConnection.generation
        let client = GitHubAppConnection.mode == .app ? try GitHubAppConnection.connectedClient() : nil
        guard generation == GitHubAppConnection.generation else { throw GitHubAppError.changed }
        return .init(client: client, generation: generation)
    }
    func checkCurrent() throws { guard generation == GitHubAppConnection.generation else { throw GitHubAppError.changed } }
    func require(repository: String, permission: String, write: Bool = false) async throws {
        try checkCurrent()
        if let client { try await client.require(repository: repository, permission: permission, write: write) }
    }
    func api(_ path: String, method: String = "GET", input: Data = Data(), accept: String = "application/vnd.github+json") async throws -> Data {
        try checkCurrent()
        if let client { return try await client.api(path, method: method, input: input, accept: accept) }
        var arguments = ["api", path, "--hostname", "github.com", "--method", method, "--include",
                         "--header", "Accept: \(accept)", "--header", "X-GitHub-Api-Version: 2022-11-28"]
        if !input.isEmpty { arguments += ["--input", "-"] }
        return try await Self.cli(arguments, input: input)
    }
    func arguments(_ arguments: [String], input: Data = Data()) async throws -> Data {
        try checkCurrent()
        guard let client else { return try await Self.cli(arguments, input: input) }
        guard arguments.count >= 2 else { throw GitHubAppError.invalidResponse }
        if arguments.first == "api" {
            var path = arguments[1]
            var method = "GET", accept = "application/vnd.github+json"
            for index in arguments.indices.dropLast() {
                if arguments[index] == "--method" { method = arguments[index + 1] }
                if arguments[index] == "--header", arguments[index + 1].hasPrefix("Accept: ") { accept = String(arguments[index + 1].dropFirst(8)) }
                if arguments[index] == "--raw-field" {
                    let field = arguments[index + 1].split(separator: "=", maxSplits: 1).map(String.init)
                    guard field.count == 2, field[0] == "ref" else { throw GitHubAppError.invalidResponse }
                    path += "\(path.contains("?") ? "&" : "?")ref=\(GitHubAccess.encode(field[1]))"
                }
            }
            return try await client.api(path, method: method, input: input, accept: accept)
        }
        guard arguments.count > 2 else { throw GitHubAppError.invalidResponse }
        let request = try GitHubRequest(arguments[2])
        if request.isRepository {
            struct Repo: Decodable { let description: String?; let `private`: Bool; let default_branch: String?; let size: Int? }
            let data = try await client.api("repos/\(request.repository)")
            let repo: Repo
            do { repo = try JSONDecoder().decode(Repo.self, from: data) } catch { throw GitHubAppError.invalidResponse }
            var empty = false
            if let branch = repo.default_branch {
                do { _ = try await client.api("repos/\(request.repository)/git/ref/heads/\(GitHubAccess.encode(branch))") }
                catch GitHubFetchError.http(409) { empty = true }
                catch GitHubFetchError.http(404) where repo.size == 0 { empty = true }
            } else { empty = true }
            return try JSONSerialization.data(withJSONObject: ["description": repo.description ?? "", "isPrivate": repo.private,
                "isEmpty": empty, "defaultBranchRef": repo.default_branch.map { ["name": $0] } as Any? ?? NSNull()])
        }
        let number = request.canonicalURL.split(separator: "/").last!
        let isPR = arguments.first == "pr"
        let data = try await client.api("repos/\(request.repository)/\(isPR ? "pulls" : "issues")/\(number)")
        struct Document: Decodable { struct Head: Decodable { let sha: String }; let title: String; let body: String?; let head: Head? }
        let value: Document
        do { value = try JSONDecoder().decode(Document.self, from: data) } catch { throw GitHubAppError.invalidResponse }
        var object: [String: Any] = ["title": value.title, "body": value.body ?? ""]
        if let sha = value.head?.sha { object["headRefOid"] = sha }
        return try JSONSerialization.data(withJSONObject: object)
    }
    static func cli(_ arguments: [String], input: Data) async throws -> Data {
        let executable = try LocalTools.trustedExecutable(named: "gh", paths: ["/opt/homebrew/bin/gh", "/usr/local/bin/gh"])
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("ModelForum-GitHub-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        defer { try? FileManager.default.removeItem(at: directory) }
        var environment = LocalTools.baseEnvironment
        environment["GH_PROMPT_DISABLED"] = "1"; environment["GH_PAGER"] = "cat"
        let result = try await Subprocess.run(executable: executable, arguments: arguments, input: input,
            directory: directory, environment: environment, timeout: 90, outputLimit: 2_097_152, inputLimit: 12 * 1_024 * 1_024)
        return try GitHubRepository.responseBody(result, includesHeaders: arguments.first == "api")
    }
}

public enum GitHubAccess {
    public static var connectionLabel: String {
        GitHubAppConnection.mode == .app ? "GitHub App: \(GitHubAppConnection.accountLabel)" : "GitHub CLI (account managed in Terminal)"
    }
    public static func context(url: String) async throws -> String {
        let request = try GitHubRequest(url)
        let session = try GitHubAccessSession.selected()
        try await session.require(repository: request.repository, permission: request.isRepository ? "contents" : request.arguments.first == "pr" ? "pull_requests" : "issues")
        let result = try await LocalTools.githubContext(url: url) { try await session.arguments($0) }
        try session.checkCurrent()
        return result
    }
    static func encode(_ value: String) -> String {
        value.addingPercentEncoding(withAllowedCharacters: CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")) ?? ""
    }
}
