import Foundation

public enum UsageBillingMode: String, Codable, Sendable {
    case api, subscription, localOrUnknown
}

public struct ModelPrice: Codable, Equatable, Sendable, Identifiable {
    public var provider: ProviderKind
    public var model: String
    public var inputPerMillionUSD: Double
    public var outputPerMillionUSD: Double
    public var id: String { provider.rawValue + ":" + model }
    public init(provider: ProviderKind, model: String, inputPerMillionUSD: Double, outputPerMillionUSD: Double) {
        self.provider = provider; self.model = model
        self.inputPerMillionUSD = inputPerMillionUSD; self.outputPerMillionUSD = outputPerMillionUSD
    }
    public func validate() throws {
        guard !model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              inputPerMillionUSD.isFinite, outputPerMillionUSD.isFinite,
              inputPerMillionUSD >= 0, outputPerMillionUSD >= 0,
              inputPerMillionUSD <= 1_000_000, outputPerMillionUSD <= 1_000_000 else {
            throw ForumError.message("Enter a model and valid nonnegative prices per million tokens.")
        }
    }
    public func estimate(input: Int, output: Int) -> Double {
        (Double(input) * inputPerMillionUSD + Double(output) * outputPerMillionUSD) / 1_000_000
    }
}

/// Local estimates, not provider balances or a guarantee of the provider's final bill.
public struct SpendingPolicy: Codable, Equatable, Sendable {
    public var prices: [ModelPrice]
    public var requestCapUSD: Double?
    public var sessionCapUSD: Double?
    public var monthlyCapUSD: Double?
    public init(prices: [ModelPrice] = [], requestCapUSD: Double? = nil, sessionCapUSD: Double? = nil, monthlyCapUSD: Double? = nil) {
        self.prices = prices; self.requestCapUSD = requestCapUSD; self.sessionCapUSD = sessionCapUSD; self.monthlyCapUSD = monthlyCapUSD
    }
    public func validate() throws {
        for price in prices { try price.validate() }
        guard Set(prices.map(\.id)).count == prices.count else { throw ForumError.message("Keep one price entry per provider and model.") }
        for cap in [requestCapUSD, sessionCapUSD, monthlyCapUSD].compactMap({ $0 }) {
            guard cap.isFinite, cap >= 0, cap <= 1_000_000 else { throw ForumError.message("Spending caps must be finite, nonnegative USD amounts.") }
        }
    }
    public func price(for participant: Participant) -> ModelPrice? {
        prices.first { $0.provider == participant.provider && $0.model == participant.model }
    }
    public var hasCaps: Bool { requestCapUSD != nil || sessionCapUSD != nil || monthlyCapUSD != nil }
}
