import Foundation

/// Optional, user-entered notes about a connection. These are never verified identity or routing settings.
public struct ProviderAccountLabel: Codable, Equatable, Sendable {
    public static let maximumFieldLength = 254
    public var email: String?
    public var accountID: String?
    public var organization: String?
    public var project: String?

    public init(email: String? = nil, accountID: String? = nil, organization: String? = nil, project: String? = nil) {
        self.email = email; self.accountID = accountID; self.organization = organization; self.project = project
    }
    public var isEmpty: Bool { [email, accountID, organization, project].allSatisfy { $0 == nil || $0?.isEmpty == true } }
    public var summary: String? {
        var parts: [String] = []
        if let email, !email.isEmpty { parts.append(email) }
        if let accountID, !accountID.isEmpty { parts.append("ID: " + accountID) }
        if parts.isEmpty {
            if let organization, !organization.isEmpty { parts.append("Organization: " + organization) }
            if let project, !project.isEmpty { parts.append("Project: " + project) }
        }
        guard !parts.isEmpty else { return nil }
        return parts.joined(separator: " · ") + " · unverified labels"
    }

    public func validated() throws -> ProviderAccountLabel {
        func field(_ raw: String?) throws -> String? {
            guard let raw else { return nil }
            let secretPattern = #"(?i)(?:^|[^a-z0-9])(?:sk-[a-z0-9_-]{4,}|gh[pousr]_[a-z0-9]+|github_pat_[a-z0-9_]+|bearer\s+\S+)|-----BEGIN"#
            guard raw.count <= Self.maximumFieldLength,
                  !raw.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) || CharacterSet.newlines.contains($0) || $0.properties.generalCategory == .format }),
                  raw.range(of: secretPattern, options: .regularExpression) == nil else {
                throw ForumError.message("Account labels must be at most 254 characters and cannot contain credentials, newlines, or control characters.")
            }
            let result = raw.trimmingCharacters(in: .whitespaces)
            return result.isEmpty ? nil : result
        }
        return try ProviderAccountLabel(email: field(email), accountID: field(accountID), organization: field(organization), project: field(project))
    }

    private enum CodingKeys: String, CodingKey { case email, accountID, organization, project }
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self = try ProviderAccountLabel(email: container.decodeIfPresent(String.self, forKey: .email),
                                        accountID: container.decodeIfPresent(String.self, forKey: .accountID),
                                        organization: container.decodeIfPresent(String.self, forKey: .organization),
                                        project: container.decodeIfPresent(String.self, forKey: .project)).validated()
    }
    public func encode(to encoder: Encoder) throws {
        let value = try validated()
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(value.email, forKey: .email)
        try container.encodeIfPresent(value.accountID, forKey: .accountID)
        try container.encodeIfPresent(value.organization, forKey: .organization)
        try container.encodeIfPresent(value.project, forKey: .project)
    }
}

public extension ProviderKind {
    var connectionDescription: String {
        switch self {
        case .openAI: return "OpenAI API"
        case .anthropic: return "Claude API"
        case .claudeCode: return "Claude Code session"
        case .ollama: return "Ollama local endpoint · cloud routing not verified"
        }
    }
    var manualIdentityStatus: String {
        switch self {
        case .openAI, .anthropic: return "Account identity is not retrieved from the API key. Optional labels below are entered by you and are unverified."
        case .claudeCode: return "CLI account identity is not retrieved. Optional labels are unverified; update them when your CLI account changes."
        case .ollama: return "Local models need no account. Cloud account identity and model routing are not verified here."
        }
    }
}
