import Foundation
import CryptoKit

public struct WorkspaceArchive: Codable {
    public struct FileEntry: Codable { public var id: UUID; public var filename: String; public var mimeType: String; public var data: Data; public var sha256: String }
    public var format: Int = 1
    public var createdAt: Date = Date()
    public var workspace: SavedWorkspace
    public var files: [FileEntry]
    public static let maximumEncodedBytes = 128 * 1024 * 1024
    public init(workspace: SavedWorkspace, artifacts: ArtifactFiles) throws {
        self.workspace = workspace
        guard workspace.artifacts.count <= 10_000 else { throw ForumError.message("Too many files for a single backup.") }
        var declaredBytes = 0
        for record in workspace.artifacts {
            guard (0...ArtifactFiles.maximumBytes).contains(record.byteCount), declaredBytes <= 64 * 1024 * 1024 - record.byteCount else { throw ForumError.message("Backup files exceed the 64 MiB content limit.") }
            declaredBytes += record.byteCount
        }
        var actualBytes = 0
        files = try workspace.artifacts.map { record in
            let bytes = try artifacts.read(relativePath: record.relativePath)
            guard actualBytes <= 64 * 1024 * 1024 - bytes.count else { throw ForumError.message("Backup files exceed the 64 MiB content limit.") }
            actualBytes += bytes.count
            guard record.relativePath == record.id.uuidString.lowercased() + "/" + record.filename,
                  record.byteCount == bytes.count else { throw ForumError.message("An artifact record does not match its file; backup was not created.") }
            return FileEntry(id: record.id, filename: record.filename, mimeType: record.mimeType, data: bytes, sha256: Self.hash(bytes))
        }
        try validate()
    }
    public static func decode(_ data: Data) throws -> WorkspaceArchive {
        guard data.count <= maximumEncodedBytes else { throw ForumError.message("This backup exceeds the 128 MiB limit.") }
        let archive: WorkspaceArchive
        do { archive = try JSONDecoder().decode(Self.self, from: data) }
        catch { throw ForumError.message("This is not a supported Model Forum backup.") }
        try archive.validate(); return archive
    }
    public func encoded() throws -> Data {
        try validate()
        let data = try JSONEncoder().encode(self)
        guard data.count <= Self.maximumEncodedBytes else { throw ForumError.message("This backup exceeds 128 MiB. Export individual conversations instead.") }
        return data
    }
    public func validate() throws {
        guard format == 1, (1...5).contains(workspace.schemaVersion), files.count <= 10_000,
              Set(files.map(\.id)).count == files.count, Set(workspace.artifacts.map(\.id)).count == workspace.artifacts.count,
              Set(workspace.conversations.map(\.id)).count == workspace.conversations.count,
              Set(workspace.channels.map(\.id)).count == workspace.channels.count,
              files.count == workspace.artifacts.count,
              files.reduce(0, { $0 + $1.data.count }) <= 64 * 1024 * 1024 else { throw ForumError.message("The backup has invalid records, duplicates, or exceeds its supported limits.") }
        var textBytes = 0
        for conversation in workspace.conversations {
            for message in conversation.messages {
                let count = message.content.utf8.count + (message.requestContext?.utf8.count ?? 0)
                guard count <= 32 * 1024 * 1024, textBytes <= 32 * 1024 * 1024 - count else { throw ForumError.message("Conversation text exceeds the backup limit. Export individual conversations instead.") }
                textBytes += count
            }
        }
        try workspace.spendingPolicy.validate()
        try workspace.usageLedger.validate()
        for run in workspace.workflowRuns {
            for text in [run.originalInput] + run.steps.flatMap({ [$0.transcript, $0.text] }) {
                let count = text.utf8.count
                guard count <= 32 * 1024 * 1024, textBytes <= 32 * 1024 * 1024 - count else { throw ForumError.message("Workflow text exceeds the backup limit.") }
                textBytes += count
            }
        }
        for workflow in workspace.workflows { try workflow.validate() }
        for channel in workspace.channels {
            guard channel.folder == "model-forum/channels/" + channel.id.uuidString.lowercased() else { throw ForumError.message("The backup has an invalid channel folder.") }
            _ = try SavedWorkspace.normalizedRepository(channel.repository)
        }
        for conversation in workspace.conversations {
            guard conversation.channelID == nil || workspace.channels.contains(where: { $0.id == conversation.channelID }) else { throw ForumError.message("The backup has a conversation with a missing channel.") }
        }
        for file in files {
            try ArtifactFiles.validateFilename(file.filename)
            guard file.data.count <= ArtifactFiles.maximumBytes, Self.hash(file.data) == file.sha256,
                  let record = workspace.artifacts.first(where: { $0.id == file.id }),
                  record.relativePath == file.id.uuidString.lowercased() + "/" + file.filename,
                  record.filename == file.filename, record.mimeType == file.mimeType, record.byteCount == file.data.count,
                  let conversation = workspace.conversations.first(where: { $0.id == record.conversationID }),
                  conversation.messages.contains(where: { $0.id == record.messageID }) else { throw ForumError.message("Backup file integrity or ownership validation failed.") }
        }
    }
    public static func hash(_ data: Data) -> String { SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() }
}

public enum ConversationExport {
    public static func markdown(_ conversation: Conversation) -> String {
        "# " + conversation.title + "\n\n" + conversation.messages.map { message in
            "## " + message.author + "\n\n" + message.content + "\n"
        }.joined(separator: "\n")
    }
    /// A portable transcript contains visible messages, never hidden request context or connection labels.
    public static func portable(_ conversation: Conversation) -> Conversation {
        Conversation(id: conversation.id, title: conversation.title, messages: conversation.messages.map {
            ChatMessage(id: $0.id, role: $0.role, author: $0.author, content: $0.content, date: $0.date, model: $0.model, inputTokens: $0.inputTokens, outputTokens: $0.outputTokens, provider: $0.provider)
        })
    }
}
