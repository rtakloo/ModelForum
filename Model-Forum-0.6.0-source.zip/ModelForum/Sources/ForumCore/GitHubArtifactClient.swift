import Foundation
import CryptoKit

enum ArtifactUploadError: LocalizedError, Equatable {
    case invalidDestination, tooLarge, conflict, emptyRepository, invalidResponse, branchRace
    case accessDenied, notFound, protectedBranch, unavailable, cliUnavailable
    var errorDescription: String? {
        switch self {
        case .invalidDestination: return "The artifact destination is invalid. Use its saved channel folder on the model-forum-artifacts branch."
        case .tooLarge: return "This artifact exceeds the 8 MiB upload limit. The local file is retained."
        case .conflict: return "A different file already exists at this artifact path. It was not overwritten; the local file is retained."
        case .emptyRepository: return "The repository has no readable default-branch commit. Initialize the repository on GitHub, then retry. The local file is retained."
        case .invalidResponse: return "GitHub returned an unexpected artifact response. The upload could not be confirmed. Retry will check the saved destination before writing."
        case .branchRace: return "The artifact branch was created or changed concurrently. Retry to inspect its current state before uploading."
        case .accessDenied: return "GitHub denied access. Check the selected connection in Settings → GitHub and repository Contents write access, then retry. The local file is retained."
        case .notFound: return "The GitHub repository or branch is unavailable. Check the saved repository and account access, then retry."
        case .protectedBranch: return "GitHub rejected the write. Check branch protection and repository write permissions, then retry. The local file is retained."
        case .unavailable: return "The GitHub upload could not be confirmed. Check the connection and retry; the saved destination will be checked before another write. The local file is retained."
        case .cliUnavailable: return "Install and sign in to GitHub CLI (gh) in a standard location, then retry. The local file is retained."
        }
    }
}

/// Uploads only to the user-selected artifact branch and fixed, UUID-scoped artifact folders.
/// Each retry inspects the destination first; existing different bytes are never overwritten.
public actor GitHubArtifactClient {
    typealias Transport = @Sendable (_ arguments: [String], _ input: Data) async throws -> Data
    private let injectedTransport: Transport?
    private var transport: Transport = { _, _ in throw GitHubAppError.disconnected }
    private var busy = false
    private var waiters = [CheckedContinuation<Void, Never>]()
    public init() { injectedTransport = nil }
    init(transport: @escaping Transport) { injectedTransport = transport }

    public func upload(data: Data, destination: ArtifactDestination) async throws -> ArtifactUploadResult {
        try Self.validate(data: data, destination: destination)
        await acquire()
        defer { release() }
        try Task.checkCancellation()
        if let injectedTransport { transport = injectedTransport }
        else {
            let session = try GitHubAccessSession.selected()
            try await session.require(repository: destination.repository, permission: "contents", write: true)
            transport = { @Sendable arguments, input in try await session.arguments(arguments, input: input) }
        }
        defer { transport = { _, _ in throw GitHubAppError.disconnected } }
        do { return try await performUpload(data: data, destination: destination) }
        catch is CancellationError { throw CancellationError() }
        catch let error as ArtifactUploadError { throw error }
        catch let error as GitHubAppError { throw error }
        catch { throw Self.safeError(error) }
    }

    // Actors are reentrant across awaits; explicitly serialize entire uploads, including different files.
    private func acquire() async {
        if busy { await withCheckedContinuation { waiters.append($0) } }
        else { busy = true }
    }
    private func release() {
        if waiters.isEmpty { busy = false }
        else { waiters.removeFirst().resume() }
    }

    private func performUpload(data: Data, destination: ArtifactDestination) async throws -> ArtifactUploadResult {
        let base = "repos/\(destination.repository)"
        let branchSHA = try await ensureBranch(base: base, branch: destination.branch)
        let blobSHA = Self.gitBlobSHA(data)
        let endpoint = "\(base)/contents/\(try Self.encodedPath(destination.path))"
        if let existing = try await existingContent(endpoint: endpoint, ref: branchSHA) {
            guard existing.type == "file", existing.path == destination.path,
                  existing.sha.lowercased() == blobSHA, existing.size == data.count else { throw ArtifactUploadError.conflict }
            return try result(destination: destination, commit: branchSHA)
        }
        try Task.checkCancellation()
        // No sha field: the Contents API must reject a concurrent existing file instead of replacing it.
        let payload = try JSONSerialization.data(withJSONObject: [
            "message": "Save Model Forum artifact", "branch": destination.branch,
            "content": data.base64EncodedString()
        ], options: [.withoutEscapingSlashes])
        let responseData = try await transport(Self.arguments(endpoint, method: "PUT", body: true), payload)
        let response = try decode(WriteResponse.self, responseData)
        guard response.content.type == "file", response.content.path == destination.path,
              response.content.sha.lowercased() == blobSHA, response.content.size == data.count,
              Self.validSHA(response.commit.sha) else { throw ArtifactUploadError.invalidResponse }
        return try result(destination: destination, commit: response.commit.sha)
    }

    private func ensureBranch(base: String, branch: String) async throws -> String {
        let endpoint = "\(base)/git/ref/heads/\(branch)"
        do { return try await readReference(endpoint: endpoint, expectedRef: "refs/heads/\(branch)") }
        catch GitHubFetchError.http(404) { /* Only an absent branch permits branch creation. */ }
        catch GitHubFetchError.http(409) { throw ArtifactUploadError.emptyRepository }
        let repo = try decode(Repository.self, await transport(Self.arguments(base, method: "GET"), Data()))
        guard let defaultBranch = repo.default_branch, !defaultBranch.isEmpty, defaultBranch.utf8.count <= 1_024,
              let encoded = defaultBranch.addingPercentEncoding(withAllowedCharacters: Self.pathComponentCharacters) else {
            throw ArtifactUploadError.emptyRepository
        }
        let startingSHA: String
        do { startingSHA = try await readReference(endpoint: "\(base)/git/ref/heads/\(encoded)", expectedRef: "refs/heads/\(defaultBranch)") }
        catch GitHubFetchError.http(404) { throw ArtifactUploadError.emptyRepository }
        catch GitHubFetchError.http(409) { throw ArtifactUploadError.emptyRepository }
        let payload = try JSONSerialization.data(withJSONObject: ["ref": "refs/heads/\(branch)", "sha": startingSHA])
        let created: Data
        do { created = try await transport(Self.arguments("\(base)/git/refs", method: "POST", body: true), payload) }
        catch GitHubFetchError.http(let status) where status == 409 || status == 422 {
            // One read-only recovery for a branch-create race; never retry the mutation.
            let racedSHA = try await readReference(endpoint: endpoint, expectedRef: "refs/heads/\(branch)")
            guard racedSHA == startingSHA else { throw ArtifactUploadError.branchRace }
            return racedSHA
        }
        let ref = try decode(Reference.self, created)
        guard ref.ref == "refs/heads/\(branch)", ref.object.type == "commit", ref.object.sha == startingSHA else {
            throw ArtifactUploadError.invalidResponse
        }
        return startingSHA
    }

    private func readReference(endpoint: String, expectedRef: String) async throws -> String {
        let reference = try decode(Reference.self, await transport(Self.arguments(endpoint, method: "GET"), Data()))
        guard reference.ref == expectedRef, reference.object.type == "commit", Self.validSHA(reference.object.sha) else {
            throw ArtifactUploadError.invalidResponse
        }
        return reference.object.sha
    }

    private func existingContent(endpoint: String, ref: String) async throws -> Content? {
        var arguments = Self.arguments(endpoint, method: "GET", objectMedia: true)
        arguments += ["--raw-field", "ref=\(ref)", "--jq", "{type,path,sha,size}"]
        do { return try decode(Content.self, await transport(arguments, Data())) }
        catch GitHubFetchError.http(404) { return nil }
    }

    private func result(destination: ArtifactDestination, commit: String) throws -> ArtifactUploadResult {
        // The URL is constructed from validated identifiers, never a server-provided html_url.
        ArtifactUploadResult(url: "https://github.com/\(destination.repository)/blob/\(commit)/\(try Self.encodedPath(destination.path))", commitSHA: commit)
    }

    private struct Repository: Decodable { let default_branch: String? }
    private struct Reference: Decodable {
        struct Object: Decodable { let type: String; let sha: String }
        let ref: String; let object: Object
    }
    private struct Content: Decodable { let type: String; let path: String; let sha: String; let size: Int }
    private struct WriteResponse: Decodable {
        struct Commit: Decodable { let sha: String }
        let content: Content; let commit: Commit
    }
    private func decode<T: Decodable>(_ type: T.Type, _ data: Data) throws -> T {
        do { return try JSONDecoder().decode(type, from: data) }
        catch { throw ArtifactUploadError.invalidResponse }
    }

    static func validate(data: Data, destination: ArtifactDestination) throws {
        guard data.count <= 8 * 1_024 * 1_024 else { throw ArtifactUploadError.tooLarge }
        guard destination.branch == "model-forum-artifacts",
              let request = try? GitHubRequest("https://github.com/\(destination.repository)"), request.isRepository,
              request.repository == destination.repository else { throw ArtifactUploadError.invalidDestination }
        let parts = destination.path.split(separator: "/", omittingEmptySubsequences: false).map(String.init)
        guard parts.count == 7, parts[0] == "model-forum", parts[1] == "channels", parts[3] == "conversations",
              [parts[2], parts[4], parts[5]].allSatisfy({ value in
                  UUID(uuidString: value)?.uuidString.lowercased() == value.lowercased()
              }),
              parts[6].range(of: #"\A[A-Za-z0-9][A-Za-z0-9._ -]{0,159}\z"#, options: .regularExpression) != nil,
              !parts[6].contains(".."), !parts[6].hasSuffix(" ") else {
            throw ArtifactUploadError.invalidDestination
        }
    }

    static func gitBlobSHA(_ data: Data) -> String {
        var hash = Insecure.SHA1()
        hash.update(data: Data("blob \(data.count)\0".utf8))
        hash.update(data: data)
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }
    private static func validSHA(_ value: String) -> Bool {
        value.range(of: #"\A[0-9a-fA-F]{40}\z"#, options: .regularExpression) != nil
    }
    private static let pathComponentCharacters = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")

    private static func encodedPath(_ path: String) throws -> String {
        try path.split(separator: "/").map { component in
            guard let encoded = String(component).addingPercentEncoding(withAllowedCharacters: pathComponentCharacters) else {
                throw ArtifactUploadError.invalidDestination
            }
            return encoded
        }.joined(separator: "/")
    }

    private static func arguments(_ endpoint: String, method: String, body: Bool = false, objectMedia: Bool = false) -> [String] {
        var arguments = ["api", endpoint, "--hostname", "github.com", "--method", method, "--include",
            "--header", "Accept: application/vnd.github\(objectMedia ? ".object" : "")+json",
            "--header", "X-GitHub-Api-Version: 2022-11-28"]
        if body { arguments += ["--input", "-"] }
        return arguments
    }

    private static func safeError(_ error: Error) -> ArtifactUploadError {
        if case GitHubFetchError.http(let status) = error {
            switch status {
            case 401, 403: return .accessDenied
            case 404: return .notFound
            case 409, 422: return .protectedBranch
            default: return .unavailable
            }
        }
        return .unavailable
    }

    private static func liveTransport(arguments: [String], input: Data) async throws -> Data {
        let executable: URL
        do { executable = try LocalTools.trustedExecutable(named: "gh", paths: ["/opt/homebrew/bin/gh", "/usr/local/bin/gh"]) }
        catch { throw ArtifactUploadError.cliUnavailable }
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("ModelForum-artifact-\(UUID().uuidString)")
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        defer { try? FileManager.default.removeItem(at: directory) }
        var environment = LocalTools.baseEnvironment
        environment["GH_PROMPT_DISABLED"] = "1"; environment["GH_PAGER"] = "cat"
        let result = try await Subprocess.run(executable: executable, arguments: arguments, input: input,
            directory: directory, environment: environment, timeout: 120, outputLimit: 262_144, inputLimit: 12 * 1_024 * 1_024)
        return try GitHubRepository.responseBody(result, includesHeaders: true)
    }
}
