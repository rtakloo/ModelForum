import Foundation

public struct SavedWorkspace: Codable, Sendable {
    public var conversations: [Conversation]
    public var participants: [Participant]
    public var maxOutputTokens: Int
    public var channels: [Channel]
    public var artifacts: [ArtifactRecord]
    public var schemaVersion: Int
    public var globalInstructions: String
    public var agentInstructions: [String: String]
    public var requireNoTraining: Bool
    public var privacyConfirmations: [String: Bool]
    public var providerAccountLabels: [String: ProviderAccountLabel]
    public var workflows: [WorkflowDefinition]
    public var workflowRuns: [WorkflowRun]
    public var spendingPolicy: SpendingPolicy
    public var usageLedger: UsageLedger
    public var deletedChannelRetentionDays: Int
    public var githubConnectionStamp: String?
    public var pendingFileDeletions: [String]

    public init(conversations: [Conversation], participants: [Participant], maxOutputTokens: Int,
                channels: [Channel] = [], artifacts: [ArtifactRecord] = [], schemaVersion: Int = 5,
                globalInstructions: String = "", agentInstructions: [String: String] = [:],
                requireNoTraining: Bool = true, privacyConfirmations: [String: Bool] = [:],
                providerAccountLabels: [String: ProviderAccountLabel] = [:], workflows: [WorkflowDefinition] = [], workflowRuns: [WorkflowRun] = [],
                spendingPolicy: SpendingPolicy = SpendingPolicy(), usageLedger: UsageLedger = UsageLedger(),
                deletedChannelRetentionDays: Int = 0, pendingFileDeletions: [String] = [], githubConnectionStamp: String? = nil) {
        self.conversations = conversations; self.participants = participants; self.maxOutputTokens = maxOutputTokens
        self.channels = channels; self.artifacts = artifacts; self.schemaVersion = schemaVersion
        self.globalInstructions = globalInstructions; self.agentInstructions = agentInstructions
        self.requireNoTraining = requireNoTraining; self.privacyConfirmations = privacyConfirmations
        self.providerAccountLabels = providerAccountLabels
        self.workflows = workflows; self.workflowRuns = workflowRuns
        self.spendingPolicy = spendingPolicy; self.usageLedger = usageLedger
        self.githubConnectionStamp = githubConnectionStamp
        self.deletedChannelRetentionDays = deletedChannelRetentionDays; self.pendingFileDeletions = pendingFileDeletions
    }
    private enum CodingKeys: String, CodingKey { case conversations, participants, maxOutputTokens, channels, artifacts, schemaVersion, globalInstructions, agentInstructions, requireNoTraining, privacyConfirmations, providerAccountLabels, workflows, workflowRuns, spendingPolicy, usageLedger, deletedChannelRetentionDays, pendingFileDeletions, githubConnectionStamp }
    public init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        conversations = try values.decode([Conversation].self, forKey: .conversations)
        participants = try values.decode([Participant].self, forKey: .participants)
        maxOutputTokens = try values.decode(Int.self, forKey: .maxOutputTokens)
        channels = try values.decodeIfPresent([Channel].self, forKey: .channels) ?? []
        artifacts = try values.decodeIfPresent([ArtifactRecord].self, forKey: .artifacts) ?? []
        schemaVersion = try values.decodeIfPresent(Int.self, forKey: .schemaVersion) ?? 1
        globalInstructions = try values.decodeIfPresent(String.self, forKey: .globalInstructions) ?? ""
        agentInstructions = try values.decodeIfPresent([String: String].self, forKey: .agentInstructions) ?? [:]
        requireNoTraining = try values.decodeIfPresent(Bool.self, forKey: .requireNoTraining) ?? true
        privacyConfirmations = try values.decodeIfPresent([String: Bool].self, forKey: .privacyConfirmations) ?? [:]
        providerAccountLabels = try values.decodeIfPresent([String: ProviderAccountLabel].self, forKey: .providerAccountLabels) ?? [:]
        workflows = try values.decodeIfPresent([WorkflowDefinition].self, forKey: .workflows) ?? []
        workflowRuns = try values.decodeIfPresent([WorkflowRun].self, forKey: .workflowRuns) ?? []
        spendingPolicy = try values.decodeIfPresent(SpendingPolicy.self, forKey: .spendingPolicy) ?? SpendingPolicy()
        usageLedger = try values.decodeIfPresent(UsageLedger.self, forKey: .usageLedger) ?? UsageLedger()
        deletedChannelRetentionDays = try values.decodeIfPresent(Int.self, forKey: .deletedChannelRetentionDays) ?? 0
        githubConnectionStamp = try values.decodeIfPresent(String.self, forKey: .githubConnectionStamp)
        pendingFileDeletions = try values.decodeIfPresent([String].self, forKey: .pendingFileDeletions) ?? []
    }
    public static var initial: SavedWorkspace {
        SavedWorkspace(conversations: [Conversation()], participants: [
            Participant(alias: "gpt", provider: .openAI, model: ""),
            Participant(alias: "claude", provider: .anthropic, model: ""),
            Participant(alias: "local", provider: .ollama, model: ""),
            Participant(alias: "claude-code", provider: .claudeCode, model: "sonnet")
        ], maxOutputTokens: 2048)
    }
    @discardableResult
    public mutating func createChannel(name: String, repository: String?, autoSave: Bool) throws -> Channel {
        let name = try validatedName(name)
        let repository = try Self.normalizedRepository(repository)
        guard !autoSave || repository != nil else { throw ForumError.message("Choose a GitHub repository before enabling automatic saves.") }
        let channel = Channel(name: name, repository: repository, autoSave: autoSave)
        channels.append(channel); schemaVersion = max(schemaVersion, 5)
        return channel
    }
    public mutating func updateChannel(id: UUID, name: String, repository: String?, autoSave: Bool) throws {
        guard let index = channels.firstIndex(where: { $0.id == id }) else { throw ForumError.message("Channel no longer exists.") }
        guard channels[index].deletedAt == nil else { throw ForumError.message("Restore this channel before changing its settings.") }
        let name = try validatedName(name, excluding: id)
        let repository = try Self.normalizedRepository(repository)
        guard !autoSave || repository != nil else { throw ForumError.message("Choose a GitHub repository before enabling automatic saves.") }
        channels[index].name = name; channels[index].repository = repository; channels[index].autoSave = autoSave
        schemaVersion = max(schemaVersion, 5)
    }
    public mutating func deleteChannel(id: UUID) throws {
        guard let index = channels.firstIndex(where: { $0.id == id }) else { throw ForumError.message("Channel no longer exists.") }
        channels[index].deletedAt = channels[index].deletedAt ?? Date()
        channels[index].autoSave = false
        schemaVersion = max(schemaVersion, 5)
    }
    public mutating func restoreChannel(id: UUID) throws {
        guard let index = channels.firstIndex(where: { $0.id == id }) else { throw ForumError.message("Channel no longer exists.") }
        channels[index].deletedAt = nil
        channels[index].autoSave = false
        schemaVersion = max(schemaVersion, 5)
    }
    public mutating func moveConversation(id: UUID, channelID: UUID?) throws {
        guard let index = conversations.firstIndex(where: { $0.id == id }) else { throw ForumError.message("Conversation no longer exists.") }
        guard channelID == nil || channels.contains(where: { $0.id == channelID && $0.deletedAt == nil }) else { throw ForumError.message("Choose an active channel or restore the deleted channel first.") }
        conversations[index].channelID = channelID; schemaVersion = max(schemaVersion, 5)
    }
    public mutating func renameConversation(id: UUID, title: String) throws {
        guard let index = conversations.firstIndex(where: { $0.id == id }) else { throw ForumError.message("Conversation no longer exists.") }
        let title = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty, title.count <= 160, !title.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
            throw ForumError.message("Conversation titles must contain 1–160 characters without control characters.")
        }
        conversations[index].title = title
    }
    private func validatedName(_ raw: String, excluding id: UUID? = nil) throws -> String {
        let name = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, name.count <= 80, !name.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
            throw ForumError.message("Channel names must contain 1–80 characters without control characters.")
        }
        if let existing = channels.first(where: { $0.id != id && $0.name.caseInsensitiveCompare(name) == .orderedSame }) {
            if existing.deletedAt != nil {
                throw ForumError.message("A deleted channel has that name. Restore it to reuse the channel, or restore and rename it before creating another.")
            }
            throw ForumError.message("A channel with that name already exists.")
        }
        return name
    }
    public static func normalizedRepository(_ raw: String?) throws -> String? {
        guard let raw else { return nil }
        let value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }
        let repository: String
        if value.contains("://") {
            guard let url = URLComponents(string: value), url.scheme == "https", url.host == "github.com",
                  url.user == nil, url.password == nil, url.port == nil, url.query == nil, url.fragment == nil,
                  !url.percentEncodedPath.contains("%") else { throw ForumError.message("Use a GitHub repository URL or owner/repository.") }
            var path = url.path
            if path.hasSuffix("/") { path.removeLast() }
            guard path.hasPrefix("/") else { throw ForumError.message("Use a GitHub repository URL or owner/repository.") }
            repository = String(path.dropFirst())
        } else { repository = value }
        let parts = repository.split(separator: "/", omittingEmptySubsequences: false)
        guard parts.count == 2, parts[0].count <= 39, parts[1].count <= 100,
              parts[0].range(of: #"^[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$"#, options: .regularExpression) != nil,
              parts[1].range(of: #"^[A-Za-z0-9_.-]+$"#, options: .regularExpression) != nil,
              parts[1] != ".", parts[1] != ".." else { throw ForumError.message("Use a GitHub repository URL or owner/repository.") }
        return repository
    }
}
