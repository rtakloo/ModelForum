import Foundation

public struct ClaudeAccountStatus: Codable, Equatable, Sendable {
    public let loggedIn: Bool
    public let authMethod: String
    public let email: String?
    public let accountID: String?
    public let organizationID: String?
    public let subscriptionType: String?
    public var identityKey: String { [authMethod, email ?? "", accountID ?? "", organizationID ?? ""].joined(separator: "|") }
    public var summary: String {
        guard loggedIn else { return "Not signed in" }
        return [email ?? "Email not supplied", accountID.map { "ID: " + $0 } ?? "ID not supplied", authMethod].joined(separator: " · ")
    }
    public static func decode(_ data: Data) throws -> ClaudeAccountStatus {
        guard data.count <= 65_536, let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let loggedIn = object["loggedIn"] as? Bool else { throw ForumError.message("The installed Claude tool returned an unsupported account-status format. Update it and try again.") }
        let allowed = ["none", "claude.ai", "oauth_token", "api_key", "api_key_helper", "third_party"]
        let method = object["authMethod"] as? String ?? "none"
        guard allowed.contains(method) else { throw ForumError.message("The installed Claude tool returned an unknown authentication method.") }
        func field(_ name: String) -> String? {
            guard let s = object[name] as? String, !s.isEmpty, s.utf8.count <= 512,
                  !s.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) || $0.properties.generalCategory == .format }),
                  !s.lowercased().contains("sk-"), !s.lowercased().contains("bearer ") else { return nil }
            return s
        }
        return ClaudeAccountStatus(loggedIn: loggedIn, authMethod: method, email: field("email"), accountID: field("accountId"), organizationID: field("orgId"), subscriptionType: field("subscriptionType"))
    }
}

public enum ClaudeAccountTools {
    public static func executable() throws -> URL {
        try LocalTools.trustedExecutable(named: "claude", paths: ["/opt/homebrew/bin/claude", "/usr/local/bin/claude", FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent(".local/bin/claude").path])
    }
    public static func status() async throws -> ClaudeAccountStatus {
        let result = try await Subprocess.run(executable: executable(), arguments: ["auth", "status"], environment: LocalTools.baseEnvironment, timeout: 20, outputLimit: 65_536)
        guard result.status == 0 || result.status == 1 else { throw ForumError.message("Claude account check failed. Install a current official Claude CLI and sign in.") }
        return try ClaudeAccountStatus.decode(result.stdout)
    }
    public static func logout() async throws {
        let result = try await Subprocess.run(executable: executable(), arguments: ["auth", "logout"], environment: LocalTools.baseEnvironment, timeout: 20, outputLimit: 65_536)
        guard result.status == 0 else { throw ForumError.message("Claude sign-out failed. Use the official tool to sign out.") }
    }
}
