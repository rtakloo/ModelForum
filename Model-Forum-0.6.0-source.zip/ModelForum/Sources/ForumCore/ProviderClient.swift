import Foundation

/// Text-only, bounded calls. No provider tools are enabled or executed by this client.
public final class ProviderClient: @unchecked Sendable {
    private let session: URLSession
    private let ownsSession: Bool

    public init(session: URLSession = .shared) {
        if session === URLSession.shared {
            let configuration = URLSessionConfiguration.ephemeral
            configuration.urlCache = nil
            configuration.httpCookieStorage = nil
            configuration.urlCredentialStorage = nil
            configuration.timeoutIntervalForRequest = 120
            configuration.timeoutIntervalForResource = 180
            self.session = URLSession(configuration: configuration)
            ownsSession = true
        } else {
            self.session = session
            ownsSession = false
        }
    }

    deinit { if ownsSession { session.invalidateAndCancel() } }

    public func reply(participant: Participant, transcript: String, apiKey: String?, maxOutputTokens: Int, onDelta: (@Sendable (String) async -> Void)? = nil) async throws -> ModelReply {
        try Task.checkCancellation()
        let model = participant.model.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !model.isEmpty else { throw ForumError.message("Choose a model in participant settings first.") }
        guard !transcript.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ForumError.message("The context is empty.") }
        guard maxOutputTokens > 0 else { throw ForumError.message("The output token limit must be positive.") }
        let key = apiKey?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if participant.provider.needsKey && (key.isEmpty || key.contains(where: { $0.isWhitespace || $0.isNewline })) {
            throw ForumError.message("Set a valid API key in Settings for this provider.")
        }
        let streams = participant.provider == .openAI && onDelta != nil
        let endpoint: String
        var body: [String: Any] = ["model": model]
        switch participant.provider {
        case .openAI:
            endpoint = "https://api.openai.com/v1/responses"
            body.merge(["input": transcript, "max_output_tokens": maxOutputTokens, "store": false, "stream": streams]) { _, new in new }
        case .anthropic:
            endpoint = "https://api.anthropic.com/v1/messages"
            body.merge(["messages": [["role": "user", "content": transcript]], "max_tokens": maxOutputTokens, "stream": false]) { _, new in new }
        case .ollama:
            endpoint = "http://127.0.0.1:11434/api/chat"
            body.merge(["messages": [["role": "user", "content": transcript]], "stream": false, "options": ["num_predict": maxOutputTokens]]) { _, new in new }
        case .claudeCode:
            throw ForumError.message("Use the installed-tool adapter for Claude Code.")
        }
        var request = URLRequest(url: URL(string: endpoint)!, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 120)
        request.httpMethod = "POST"
        request.httpShouldHandleCookies = false
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(streams ? "text/event-stream" : "application/json", forHTTPHeaderField: "Accept")
        if participant.provider == .openAI { request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization") }
        if participant.provider == .anthropic {
            request.setValue(key, forHTTPHeaderField: "x-api-key")
            request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        }
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        if streams, let onDelta {
            return try await streamingReply(request: request, model: model, maxOutputTokens: maxOutputTokens, onDelta: onDelta)
        }
        let data: Data
        let response: URLResponse
        do {
            // Even same-origin redirects are declined: credentials and prompts go only to the explicit endpoint.
            let (bytes, received) = try await session.bytes(for: request, delegate: ProviderRedirectGuard())
            defer { bytes.task.cancel() }
            response = received
            data = try await withTaskCancellationHandler {
                var collected = Data()
                for try await byte in bytes {
                    try Task.checkCancellation()
                    guard collected.count < Self.maximumResponseBytes else { throw ForumError.message("The provider response exceeded the local size limit.") }
                    collected.append(byte)
                }
                return collected
            } onCancel: { bytes.task.cancel() }
        } catch {
            if error is ForumError { throw error }
            if Task.isCancelled || (error as? URLError)?.code == .cancelled { throw CancellationError() }
            if (error as? URLError)?.code == .timedOut { throw ForumError.message("The model request timed out. You may retry manually.") }
            throw ForumError.message("Could not connect to the provider. Check your connection and provider setup.")
        }
        try Task.checkCancellation()
        guard let http = response as? HTTPURLResponse else { throw ForumError.message("The provider returned an invalid HTTP response.") }
        guard (200..<300).contains(http.statusCode) else {
            // Never propagate the response body, which can echo a credential or private prompt.
            let detail: String
            switch http.statusCode {
            case 401, 403: detail = "Check your API key and model access."
            case 429: detail = Self.rateLimitDetail(data: data, provider: participant.provider)
            case 300..<400: detail = "Redirects are blocked to protect credentials and conversation context."
            default: detail = "Check the model name and provider status."
            }
            throw ForumError.message("Provider request failed (HTTP \(http.statusCode)). \(detail)")
        }
        guard let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] else {
            throw ForumError.message("The provider returned an unreadable response.")
        }
        return try Self.parse(json, provider: participant.provider, requestedModel: model, maxOutputTokens: maxOutputTokens)
    }

    public static let maximumResponseBytes = 16 * 1024 * 1024
    public static func supportsStreaming(_ provider: ProviderKind) -> Bool { provider == .openAI }

    private func streamingReply(request: URLRequest, model: String, maxOutputTokens: Int, onDelta: @Sendable (String) async -> Void) async throws -> ModelReply {
        do {
            let (bytes, response) = try await session.bytes(for: request, delegate: ProviderRedirectGuard())
            defer { bytes.task.cancel() }
            return try await withTaskCancellationHandler {
            guard let http = response as? HTTPURLResponse else { throw ForumError.message("The provider returned an invalid HTTP response.") }
            if !(200..<300).contains(http.statusCode) {
                var body = Data()
                for try await byte in bytes {
                    try Task.checkCancellation()
                    // Read one extra byte so an oversized error is never recognized as a valid prefix.
                    if body.count > 65_536 { break }
                    body.append(byte)
                }
                let detail: String
                switch http.statusCode {
                case 401, 403: detail = "Check your API key and model access."
                case 429: detail = Self.rateLimitDetail(data: body, provider: .openAI)
                case 300..<400: detail = "Redirects are blocked to protect credentials and conversation context."
                default: detail = "Check the model name and provider status."
                }
                throw ForumError.message("Provider request failed (HTTP \(http.statusCode)). \(detail)")
            }
            guard http.value(forHTTPHeaderField: "Content-Type")?.lowercased().hasPrefix("text/event-stream") == true else {
                throw ForumError.message("The provider did not return an event stream. No completed answer was accepted.")
            }
            var parser = ProviderSSEParser()
            var visibleBytes = 0
            for try await byte in bytes {
                try Task.checkCancellation()
                guard let event = try parser.append(byte) else { continue }
                guard let object = (try? JSONSerialization.jsonObject(with: event.data)) as? [String: Any],
                      let type = object["type"] as? String,
                      event.name.isEmpty || event.name == type else {
                    throw ForumError.message("The provider returned an unreadable stream event. No completed answer was accepted.")
                }
                switch type {
                case "response.output_text.delta", "response.refusal.delta":
                    guard let delta = object["delta"] as? String else { throw ForumError.message("The provider returned an invalid text event.") }
                    visibleBytes += delta.utf8.count
                    guard visibleBytes <= 8 * 1024 * 1024 else { throw ForumError.message("The provider response exceeded the local size limit.") }
                    if !delta.isEmpty { await onDelta(delta); try Task.checkCancellation() }
                case "response.completed":
                    guard let result = object["response"] as? [String: Any] else { throw ForumError.message("The provider returned an invalid completion event.") }
                    return try Self.parse(result, provider: .openAI, requestedModel: model, maxOutputTokens: maxOutputTokens)
                case "response.incomplete":
                    throw ForumError.message(Self.incompleteOpenAIDetail(object["response"] as? [String: Any] ?? [:], maxOutputTokens: maxOutputTokens))
                case "response.failed", "error":
                    throw ForumError.message("OpenAI interrupted the response. No completed answer was accepted. Check provider status and retry manually.")
                default: break // Reasoning, tool arguments, and unknown future events are never exposed as text.
                }
            }
            throw ForumError.message("The provider stream ended before completion. Partial text was not accepted as a completed answer.")
            } onCancel: { bytes.task.cancel() }
        } catch {
            if Task.isCancelled || error is CancellationError || (error as? URLError)?.code == .cancelled { throw CancellationError() }
            if error is ForumError { throw error }
            if (error as? URLError)?.code == .timedOut { throw ForumError.message("The model request timed out. Partial text was not accepted as a completed answer.") }
            throw ForumError.message("Could not complete the provider stream. Check your connection and provider setup. Partial text was not accepted as a completed answer.")
        }
    }

    /// Only allowlisted machine-readable values affect the message; provider prose is never displayed.
    private static func rateLimitDetail(data: Data, provider: ProviderKind) -> String {
        let unknown = "The provider rejected this request with HTTP 429. Check its rate limits and account usage or billing dashboard for the cause."
        guard provider == .openAI, data.count <= 65_536,
              let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let error = json["error"] as? [String: Any] else { return unknown }
        let recognized = ["insufficient_quota", "rate_limit_exceeded", "credit_balance_exhausted",
                          "organization_spend_limit_exceeded", "project_spend_limit_exceeded",
                          "organization_usage_limit_exceeded", "slow_down", "rate_limit_error"]
        // Prefer a recognized specific code; some billing codes use insufficient_quota as their broader type.
        let code = error["code"] as? String
        let type = error["type"] as? String
        let reason = code.flatMap { recognized.contains($0) ? $0 : nil }
            ?? type.flatMap { recognized.contains($0) ? $0 : nil }
        switch reason {
        case "credit_balance_exhausted":
            return "OpenAI reported exhausted API credits. Check the API billing dashboard and add credits before retrying. This is separate from this app's per-request output token limit."
        case "organization_spend_limit_exceeded":
            return "OpenAI reported an organization spending limit. Review the organization's API billing limit with its owner before retrying. This is separate from this app's per-request output token limit."
        case "project_spend_limit_exceeded":
            return "OpenAI reported a project spending limit. Review this API project's billing limit with its owner before retrying. This is separate from this app's per-request output token limit."
        case "organization_usage_limit_exceeded":
            return "OpenAI reported an organization usage limit. Review the organization's API usage limits and available limit increases before retrying. This is separate from this app's per-request output token limit."
        case "insufficient_quota":
            return "OpenAI reported insufficient account quota. Check API credits, billing, and project or organization usage limits. Retrying will not restore access until the account limit is resolved. This is separate from this app's per-request output token limit."
        case "slow_down":
            return "OpenAI asked this client to slow down its traffic. Wait, reduce request frequency and increase traffic gradually, then retry manually."
        case "rate_limit_exceeded", "rate_limit_error":
            return "OpenAI reported a request or token rate limit. Wait, reduce request frequency or token usage, then retry manually. Check your API rate limits if this continues."
        default: return unknown
        }
    }

    private static func incompleteOpenAIDetail(_ json: [String: Any], maxOutputTokens: Int?) -> String {
        guard json["status"] as? String == "incomplete" else {
            return "OpenAI did not complete the response. Check provider status and retry manually. No completed answer was accepted."
        }
        let reason = (json["incomplete_details"] as? [String: Any])?["reason"] as? String
        switch reason {
        case "max_output_tokens":
            let budget = maxOutputTokens.map { "This request allowed at most \($0) output tokens, including reasoning tokens." }
                ?? "The request's output token limit includes reasoning tokens."
            return "OpenAI stopped at an output-token or context-window limit. \(budget) Reasoning can use the budget before any visible answer appears. Increase the output token limit in Settings, request a shorter answer, or reduce conversation context. This is a per-request generation limit, not an account billing quota. No completed answer was accepted."
        case "content_filter":
            return "OpenAI stopped the response because of a content filter. Review and revise the request before retrying. No completed answer was accepted."
        default:
            return "OpenAI returned an incomplete response without a recognized reason. Check provider status and retry manually. No completed answer was accepted."
        }
    }

    private static func parse(_ json: [String: Any], provider: ProviderKind, requestedModel: String, maxOutputTokens: Int? = nil) throws -> ModelReply {
        var parts: [String] = []
        var input: Int?
        var output: Int?
        let usage = json["usage"] as? [String: Any] ?? [:]
        switch provider {
        case .openAI:
            guard json["status"] as? String == "completed" else {
                throw ForumError.message(incompleteOpenAIDetail(json, maxOutputTokens: maxOutputTokens))
            }
            for item in json["output"] as? [[String: Any]] ?? [] where item["type"] as? String == "message" && item["role"] as? String == "assistant" {
                guard item["status"] as? String == "completed" else { throw ForumError.message("OpenAI returned an incomplete message.") }
                for block in item["content"] as? [[String: Any]] ?? [] {
                    if block["type"] as? String == "output_text", let text = block["text"] as? String { parts.append(text) }
                    if block["type"] as? String == "refusal", let text = block["refusal"] as? String { parts.append(text) }
                }
            }
            input = tokenCount(usage["input_tokens"]); output = tokenCount(usage["output_tokens"])
        case .anthropic:
            guard let reason = json["stop_reason"] as? String, ["end_turn", "stop_sequence", "refusal"].contains(reason) else {
                throw ForumError.message("Claude did not complete a text response. The output may be truncated or require an unsupported tool.")
            }
            guard json["type"] as? String == "message", json["role"] as? String == "assistant" else { throw ForumError.message("Claude returned an unexpected response type.") }
            parts = (json["content"] as? [[String: Any]] ?? []).compactMap { $0["type"] as? String == "text" ? $0["text"] as? String : nil }
            input = tokenCount(usage["input_tokens"]); output = tokenCount(usage["output_tokens"])
        case .ollama:
            guard json["done"] as? Bool == true, json["done_reason"] as? String == "stop" else {
                throw ForumError.message("Ollama did not complete the response. The output may be truncated.")
            }
            if let message = json["message"] as? [String: Any], message["role"] as? String == "assistant", let text = message["content"] as? String { parts = [text] }
            input = tokenCount(json["prompt_eval_count"]); output = tokenCount(json["eval_count"])
        case .claudeCode: throw ForumError.message("Unsupported API provider.")
        }
        let text = parts.joined(separator: "\n\n")
        guard !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ForumError.message("The provider returned no displayable text.") }
        return ModelReply(text: text, model: json["model"] as? String ?? requestedModel, inputTokens: input, outputTokens: output)
    }

    private static func tokenCount(_ value: Any?) -> Int? {
        guard let count = value as? Int, count >= 0 else { return nil }
        return count
    }
}

final class ProviderRedirectGuard: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}
