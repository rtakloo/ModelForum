import Foundation

public enum ProviderKind: String, Codable, CaseIterable, Identifiable, Sendable {
    case openAI, anthropic, ollama, claudeCode
    public var id: String { rawValue }
    public var title: String {
        switch self { case .openAI: return "OpenAI"; case .anthropic: return "Claude API"; case .ollama: return "Ollama (local)"; case .claudeCode: return "Claude Code" }
    }
    public var needsKey: Bool { self == .openAI || self == .anthropic }
}

public struct Participant: Identifiable, Codable, Hashable, Sendable {
    public var id: UUID
    public var alias: String
    public var provider: ProviderKind
    public var model: String
    public init(id: UUID = UUID(), alias: String, provider: ProviderKind, model: String) {
        self.id = id; self.alias = alias; self.provider = provider; self.model = model
    }
}

public struct ChatMessage: Identifiable, Codable, Sendable {
    public var id: UUID
    public var role: String
    public var author: String
    public var content: String
    public var date: Date
    public var model: String?
    public var inputTokens: Int?
    public var outputTokens: Int?
    public var contextMessageIDs: [UUID]
    public var provider: ProviderKind?
    public var requestContext: String?
    public var critiqueMessageID: UUID?
    public init(id: UUID = UUID(), role: String, author: String, content: String, date: Date = Date(), model: String? = nil, inputTokens: Int? = nil, outputTokens: Int? = nil, contextMessageIDs: [UUID] = [], provider: ProviderKind? = nil, requestContext: String? = nil, critiqueMessageID: UUID? = nil) {
        self.id = id; self.role = role; self.author = author; self.content = content; self.date = date; self.model = model; self.inputTokens = inputTokens; self.outputTokens = outputTokens; self.contextMessageIDs = contextMessageIDs; self.provider = provider
        self.requestContext = requestContext; self.critiqueMessageID = critiqueMessageID
    }
}

public struct Conversation: Identifiable, Codable, Sendable {
    public var id: UUID
    public var title: String
    public var messages: [ChatMessage]
    public var channelID: UUID?
    public init(id: UUID = UUID(), title: String = "New conversation", messages: [ChatMessage] = [], channelID: UUID? = nil) {
        self.id = id; self.title = title; self.messages = messages
        self.channelID = channelID
    }
}

public struct ModelReply: Sendable {
    public var text: String
    public var model: String
    public var inputTokens: Int?
    public var outputTokens: Int?
    public init(text: String, model: String, inputTokens: Int? = nil, outputTokens: Int? = nil) {
        self.text = text; self.model = model; self.inputTokens = inputTokens; self.outputTokens = outputTokens
    }
}

public enum ForumError: LocalizedError {
    case message(String)
    public var errorDescription: String? { if case let .message(value) = self { return value }; return nil }
}
