import Foundation
import Darwin
import ForumCore

struct WorkspaceStorage {
    let file: URL
    let recoveryNotice: String?
    var artifacts: ArtifactFiles { ArtifactFiles(root: file.deletingLastPathComponent().appendingPathComponent("artifacts")) }
    init(folder suppliedFolder: URL? = nil) throws {
        let folder = try suppliedFolder ?? FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true).appendingPathComponent("ModelForum", isDirectory: true)
        recoveryNotice = try Self.recoverInterruptedRestore(folder: folder)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        file = folder.appendingPathComponent("workspace.json")
    }
    func load() throws -> SavedWorkspace {
        guard FileManager.default.fileExists(atPath: file.path) else { return .initial }
        let data = try Data(contentsOf: file)
        var workspace = try JSONDecoder().decode(SavedWorkspace.self, from: data)
        guard workspace.schemaVersion <= 5 else { throw ForumError.message("This workspace needs a newer version of Model Forum.") }
        if workspace.schemaVersion < 2 {
            let backup = file.deletingLastPathComponent().appendingPathComponent("workspace-before-channels.json")
            if !FileManager.default.fileExists(atPath: backup.path) {
                try data.write(to: backup, options: .withoutOverwriting)
                try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: backup.path)
            }
        }
        if workspace.schemaVersion < 3 {
            let backup = file.deletingLastPathComponent().appendingPathComponent("workspace-before-settings.json")
            if !FileManager.default.fileExists(atPath: backup.path) {
                try data.write(to: backup, options: .withoutOverwriting)
                try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: backup.path)
            }
        }
        if workspace.schemaVersion < 4 {
            let backup = file.deletingLastPathComponent().appendingPathComponent("workspace-before-account-labels.json")
            if !FileManager.default.fileExists(atPath: backup.path) {
                try data.write(to: backup, options: .withoutOverwriting)
                try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: backup.path)
            }
            workspace.schemaVersion = 4
        }
        if workspace.schemaVersion < 5 {
            let backup = file.deletingLastPathComponent().appendingPathComponent("workspace-before-commercial-preview.json")
            if !FileManager.default.fileExists(atPath: backup.path) {
                try data.write(to: backup, options: .withoutOverwriting)
                try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: backup.path)
            }
            workspace.schemaVersion = 5
        }
        return workspace
    }
    func save(_ workspace: SavedWorkspace) throws {
        let data = try JSONEncoder().encode(workspace)
        try data.write(to: file, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: file.path)
    }
}

extension WorkspaceStorage {
    /// A durable marker is written before moving either directory. Its absence is the commit point.
    struct RestoreJournal: Codable {
        let liveName: String
        let stageName: String
        let previousName: String
    }
    static func restoreJournalURL(folder: URL) -> URL {
        folder.deletingLastPathComponent().appendingPathComponent("." + folder.lastPathComponent + ".restore-journal.json")
    }
    private static func recoveryFailure() -> ForumError {
        .message("An interrupted workspace restore needs manual recovery. Existing directories and the restore journal were preserved; no empty workspace was created.")
    }
    private static func safeDirectoryExists(_ url: URL) throws -> Bool {
        var info = stat()
        if lstat(url.path, &info) != 0 {
            if errno == ENOENT { return false }
            throw recoveryFailure()
        }
        guard (info.st_mode & S_IFMT) == S_IFDIR, info.st_uid == getuid() else { throw recoveryFailure() }
        return true
    }
    private static func syncDirectory(_ url: URL) {
        let fd = open(url.path, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC)
        guard fd >= 0 else { return }
        defer { close(fd) }
        // Directory fsync availability varies; the marker still covers process interruption.
        _ = fsync(fd)
    }
    static func prepareRestoreJournal(folder: URL, stage: URL, previous: URL) throws {
        let parent = folder.deletingLastPathComponent()
        guard folder.lastPathComponent != "/", stage.deletingLastPathComponent() == parent,
              previous.deletingLastPathComponent() == parent,
              try safeDirectoryExists(folder), try safeDirectoryExists(stage),
              !(try safeDirectoryExists(previous)) else { throw recoveryFailure() }
        let journal = RestoreJournal(liveName: folder.lastPathComponent, stageName: stage.lastPathComponent, previousName: previous.lastPathComponent)
        try validateJournal(journal, folder: folder)
        let data = try JSONEncoder().encode(journal)
        let url = restoreJournalURL(folder: folder)
        let fd = open(url.path, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC, 0o600)
        guard fd >= 0 else { throw recoveryFailure() }
        defer { close(fd) }
        // If writing fails, leave the marker for fail-closed recovery; do not move the live folder.
        try data.withUnsafeBytes { bytes in
            var offset = 0
            while offset < bytes.count {
                let count = Darwin.write(fd, bytes.baseAddress!.advanced(by: offset), bytes.count - offset)
                if count < 0, errno == EINTR { continue }
                guard count > 0 else { throw recoveryFailure() }
                offset += count
            }
        }
        guard fsync(fd) == 0 else { throw recoveryFailure() }
        syncDirectory(parent)
    }
    private static func validateJournal(_ journal: RestoreJournal, folder: URL) throws {
        func namedUUID(_ name: String, prefix: String) -> Bool {
            name.hasPrefix(prefix) && UUID(uuidString: String(name.dropFirst(prefix.count))) != nil
        }
        guard journal.liveName == folder.lastPathComponent,
              namedUUID(journal.stageName, prefix: "ModelForum-restore-"),
              namedUUID(journal.previousName, prefix: "ModelForum-before-restore-"),
              ![journal.stageName, journal.previousName].contains(journal.liveName) else { throw recoveryFailure() }
    }
    static func acquireRestoreLock(folder: URL) throws -> Int32 {
        let lock = folder.deletingLastPathComponent().appendingPathComponent("." + folder.lastPathComponent + ".restore-lock")
        let fd = open(lock.path, O_RDWR | O_CREAT | O_NOFOLLOW | O_CLOEXEC, 0o600)
        guard fd >= 0 else { throw recoveryFailure() }
        var info = stat()
        guard fstat(fd, &info) == 0, (info.st_mode & S_IFMT) == S_IFREG, info.st_uid == getuid(),
              info.st_nlink == 1, flock(fd, LOCK_EX | LOCK_NB) == 0 else {
            close(fd)
            throw ForumError.message("Another Model Forum process may be restoring this workspace. Wait for it to finish before reopening.")
        }
        return fd
    }
    /// Roll back incomplete restores before init can create the live directory. Never delete recovered data.
    @discardableResult static func recoverInterruptedRestore(folder: URL) throws -> String? {
        var info = stat()
        guard lstat(restoreJournalURL(folder: folder).path, &info) == 0 else {
            if errno == ENOENT { return nil }
            throw recoveryFailure()
        }
        let lock = try acquireRestoreLock(folder: folder)
        defer { flock(lock, LOCK_UN); close(lock) }
        return try recoverRestoreHoldingLock(folder: folder)
    }
    private static func recoverRestoreHoldingLock(folder: URL) throws -> String? {
        let marker = restoreJournalURL(folder: folder)
        let fd = open(marker.path, O_RDONLY | O_NOFOLLOW | O_CLOEXEC)
        if fd < 0 {
            if errno == ENOENT { return nil }
            throw recoveryFailure()
        }
        defer { close(fd) }
        var info = stat()
        guard fstat(fd, &info) == 0, (info.st_mode & S_IFMT) == S_IFREG,
              info.st_uid == getuid(), info.st_nlink == 1, info.st_size > 0, info.st_size <= 4096 else { throw recoveryFailure() }
        var buffer = [UInt8](repeating: 0, count: 4097)
        let count = Darwin.read(fd, &buffer, buffer.count)
        guard count > 0, count <= 4096, let journal = try? JSONDecoder().decode(RestoreJournal.self, from: Data(buffer.prefix(count))) else { throw recoveryFailure() }
        try validateJournal(journal, folder: folder)
        let parent = folder.deletingLastPathComponent()
        let stage = parent.appendingPathComponent(journal.stageName, isDirectory: true)
        let previous = parent.appendingPathComponent(journal.previousName, isDirectory: true)
        let liveExists = try safeDirectoryExists(folder)
        let stageExists = try safeDirectoryExists(stage)
        let oldExists = try safeDirectoryExists(previous)
        if oldExists {
            if liveExists {
                guard !stageExists else { throw recoveryFailure() }
                // Installed new data before commit: keep it as the stage while rolling back the prior workspace.
                try FileManager.default.moveItem(at: folder, to: stage)
                syncDirectory(parent)
            }
            try FileManager.default.moveItem(at: previous, to: folder)
            syncDirectory(parent)
        } else {
            // A crash before the first move leaves the original live directory and prepared stage.
            guard liveExists, stageExists else { throw recoveryFailure() }
        }
        try FileManager.default.removeItem(at: marker)
        syncDirectory(parent)
        return "Recovered the previous workspace after an interrupted restore. Staged restore files remain at \(stage.path)."
    }
    /// Installs only a validated, fully written stage; callers update in-memory state after this succeeds.
    func installRestore(stage: URL, previous: URL) throws {
        let folder = file.deletingLastPathComponent()
        let lock = try Self.acquireRestoreLock(folder: folder)
        defer { flock(lock, LOCK_UN); close(lock) }
        try Self.prepareRestoreJournal(folder: folder, stage: stage, previous: previous)
        do {
            try FileManager.default.moveItem(at: folder, to: previous)
            Self.syncDirectory(folder.deletingLastPathComponent())
            try FileManager.default.moveItem(at: stage, to: folder)
            Self.syncDirectory(folder.deletingLastPathComponent())
            try FileManager.default.removeItem(at: Self.restoreJournalURL(folder: folder))
            Self.syncDirectory(folder.deletingLastPathComponent())
        } catch {
            do { _ = try Self.recoverRestoreHoldingLock(folder: folder) }
            catch { throw Self.recoveryFailure() }
            throw ForumError.message("Restore could not finish; the prior workspace was recovered.")
        }
    }
}
