import SwiftUI
import AppKit
import ForumCore

struct ChannelEditorView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    let channel: Channel?
    @State private var name: String
    @State private var repository: String
    @State private var autoSave: Bool

    init(channel: Channel?) {
        self.channel = channel
        _name = State(initialValue: channel?.name ?? "")
        _repository = State(initialValue: channel?.repository ?? "")
        _autoSave = State(initialValue: channel?.autoSave ?? false)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text(channel == nil ? "Create a channel" : "Channel settings")
                .font(.system(size: 25, weight: .semibold, design: .serif))
            Text("Group conversations and choose where their generated files are saved.")
                .font(.callout).foregroundStyle(.secondary)
            Form {
                TextField("Channel name", text: $name).textFieldStyle(.roundedBorder)
                TextField("GitHub repository", text: $repository, prompt: Text("owner/repository (optional)"))
                    .textFieldStyle(.roundedBorder)
                Toggle("Automatically save new files to GitHub", isOn: $autoSave)
            }
            VStack(alignment: .leading, spacing: 9) {
                Text("Generated files are kept on this Mac. When autosave is enabled, Model Forum also commits future files to the chosen repository on the model-forum-artifacts branch.")
                Text("Use a repository you can write to with your signed-in GitHub CLI account. Existing files keep their original destination when these settings change.")
                Text("Disabling autosave pauses queued files. A GitHub write already in progress may still finish.")
                Text("Channel folder").fontWeight(.medium)
                Text(channel?.folder ?? "model-forum/channels/<channel-id>/")
                    .font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                Text("The folder stays the same when you rename the channel. Each saved file has its own unique folder.")
            }.font(.caption).foregroundStyle(.secondary)
            if let error = store.error {
                Text(error).font(.caption).foregroundStyle(.red).textSelection(.enabled)
            }
            HStack {
                if let channel {
                    Button("Delete channel", role: .destructive) { if store.deleteChannel(channel.id) { dismiss() } }.disabled(store.busy)
                }
                Spacer()
                Button("Cancel") { dismiss() }.keyboardShortcut(.cancelAction)
                Button(channel == nil ? "Create channel" : "Save changes") {
                    if store.saveChannel(id: channel?.id, name: name, repository: repository, autoSave: autoSave) { dismiss() }
                }
                .keyboardShortcut(.defaultAction)
                .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || (autoSave && repository.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) || store.busy)
            }
        }.padding(26).frame(width: 560)
    }
}

struct GenerateImageView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var prompt = ""
    @State private var model = ""
    @State private var customModel = false
    @State private var models: [ModelOption] = []
    @State private var loading = false
    @State private var notice: String?
    @State private var failed = false
    @State private var modelTask: Task<Void, Never>?

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Generate an image").font(.system(size: 25, weight: .semibold, design: .serif))
            Text("Describe a photo, illustration, or other image. The finished PNG becomes a file in this conversation.")
                .font(.callout).foregroundStyle(.secondary)
            HStack {
                Picker("Image model", selection: modelChoice) {
                    Text("Choose an image model…").tag("")
                    ForEach(models) { item in Text(item.name).tag(item.id) }
                    Divider()
                    Text("Enter a model ID…").tag("__custom_image_model__")
                }.pickerStyle(.menu).disabled(loading)
                if loading {
                    ProgressView().controlSize(.small)
                    Button("Cancel loading") { modelTask?.cancel() }
                } else {
                    Button(models.isEmpty ? "Load models" : "Refresh", systemImage: "arrow.clockwise") { loadModels() }
                }
            }
            if customModel {
                TextField("GPT image model ID", text: $model)
                    .textFieldStyle(.roundedBorder).accessibilityLabel("Custom image model ID")
            }
            if let notice { Text(notice).font(.caption).foregroundStyle(failed ? Color.red : Color.secondary) }
            Text("Image description").font(.headline)
            TextEditor(text: $prompt)
                .font(.body).frame(height: 170).padding(6)
                .background(Color(nsColor: .textBackgroundColor))
                .clipShape(RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.primary.opacity(0.15)))
                .accessibilityLabel("Image description")
            Text("Generate sends this description and your saved global/GPT instructions to OpenAI using your saved key and bills your OpenAI API account. One 1024 × 1024 PNG at medium quality is requested. Channel autosave settings apply to the resulting file.")
                .font(.caption).foregroundStyle(.secondary)
            HStack {
                Spacer()
                Button("Cancel") { dismiss() }.keyboardShortcut(.cancelAction)
                Button("Generate image") {
                    store.generateImage(prompt: prompt, model: model)
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                .disabled(prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || loading || store.busy)
            }
        }.padding(26).frame(width: 600)
            .onAppear { loadModels() }
            .onDisappear { modelTask?.cancel() }
    }

    private var modelChoice: Binding<String> {
        Binding(get: { customModel ? "__custom_image_model__" : model }, set: { value in
            if value == "__custom_image_model__" { customModel = true }
            else { customModel = false; model = value }
        })
    }

    private func loadModels() {
        guard !loading else { return }
        loading = true; notice = nil
        modelTask = Task { @MainActor in
            defer { loading = false; modelTask = nil }
            do {
                guard let key = try KeychainStore.read(.openAI), !key.isEmpty else {
                    throw ForumError.message("Save your OpenAI API key in Connections, then load image models.")
                }
                let available = try await ModelCatalog().imageModels(apiKey: key)
                try Task.checkCancellation()
                models = available; failed = false
                if !customModel && !model.isEmpty && !available.contains(where: { $0.id == model }) { model = "" }
                notice = available.isEmpty ? "No GPT image models were returned. Check account access or enter an available image model ID." : "\(available.count) image models loaded. Choose a model to continue."
            } catch {
                if !Task.isCancelled { failed = true; notice = error.localizedDescription }
            }
        }
    }
}

struct ArtifactCard: View {
    @EnvironmentObject var store: AppStore
    let record: ArtifactRecord

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: record.mimeType.hasPrefix("image/") ? "photo" : "doc")
                    .font(.title2).foregroundStyle(.secondary)
                VStack(alignment: .leading, spacing: 3) {
                    Text(record.filename).font(.headline).textSelection(.enabled)
                    Text(ByteCountFormatter.string(fromByteCount: Int64(record.byteCount), countStyle: .file))
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Label(status, systemImage: statusSymbol).font(.caption)
                    .foregroundStyle(record.syncState == .failed ? Color.red : Color.secondary)
            }
            if let destination = record.destination {
                Text("\(destination.repository) · \(destination.branch)").font(.caption).foregroundStyle(.secondary)
            }
            if record.syncState == .failed, let error = record.syncError {
                Text(error).font(.caption).foregroundStyle(.red).textSelection(.enabled)
            }
            if (record.syncState == .pending || record.syncState == .failed) && !store.uploadEnabled(record) {
                Text("Upload paused. Enable autosave for this channel with the file’s original repository to resume.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            HStack {
                if (record.filename as NSString).pathExtension.lowercased() == "tex" {
                    Button("Compile PDF", systemImage: "doc.badge.gearshape") { store.compilePDF(record) }.disabled(store.busy).help(LaTeXCompiler.status)
                }
                Button("Show in Finder", systemImage: "folder") {
                    if let url = store.artifactURL(record) { NSWorkspace.shared.activateFileViewerSelecting([url]) }
                }
                if let url = githubURL { Link("View on GitHub", destination: url) }
                Spacer()
                if record.syncState == .failed || record.syncState == .pending {
                    Button("Retry upload", systemImage: "arrow.clockwise") { store.retryArtifact(record.id) }
                        .disabled(store.syncBusy || !store.uploadEnabled(record))
                }
            }.font(.caption)
        }.padding(12).background(Color.primary.opacity(0.035)).clipShape(RoundedRectangle(cornerRadius: 10))
    }

    private var status: String {
        switch record.syncState {
        case .localOnly: return "Saved on this Mac"
        case .pending: return store.uploadEnabled(record) ? "Waiting to upload" : "Upload paused"
        case .uploading: return "Uploading to GitHub"
        case .uploaded: return "Saved to GitHub"
        case .failed: return "Upload failed"
        }
    }
    private var statusSymbol: String {
        switch record.syncState {
        case .localOnly: return "internaldrive"
        case .pending: return store.uploadEnabled(record) ? "clock" : "pause.circle"
        case .uploading: return "arrow.up.circle"
        case .uploaded: return "checkmark.circle"
        case .failed: return "exclamationmark.triangle"
        }
    }
    private var githubURL: URL? {
        guard let raw = record.remoteURL, let url = URL(string: raw),
              url.scheme == "https", url.host == "github.com", url.user == nil, url.password == nil,
              url.port == nil || url.port == 443 else { return nil }
        return url
    }
}
