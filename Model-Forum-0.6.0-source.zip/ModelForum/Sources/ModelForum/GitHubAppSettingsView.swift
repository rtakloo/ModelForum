import SwiftUI
import ForumCore

struct GitHubSettingsView: View {
    @State private var mode = GitHubAppConnection.mode
    @State private var clientID = GitHubAppConnection.clientID
    @State private var account = GitHubAppConnection.accountLabel
    @State private var authorization: GitHubDeviceAuthorization?
    @State private var repositories: [GitHubAccessibleRepository] = []
    @State private var busy = false
    @State private var message: String?
    @State private var task: Task<Void, Never>?
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("GitHub connection").font(.title2.bold())
                Picker("Use for imports, artifact uploads and pull requests", selection: $mode) {
                    Text("Installed GitHub CLI").tag(GitHubConnectionMode.cli)
                    Text("GitHub App").tag(GitHubConnectionMode.app)
                }.pickerStyle(.segmented).disabled(busy)
                    .onChange(of: mode) { _, value in GitHubAppConnection.select(value); repositories = [] }
                Text("The selected connection is used consistently. An App authentication failure never switches to the CLI account. Changing connections pauses pending uploads; review their destination before retrying.").font(.caption).foregroundStyle(.secondary)
                if mode == .cli {
                    Text("Uses the account configured by gh in Terminal. Install and sign in to GitHub CLI separately. The app does not read or display its credentials.")
                } else {
                    Text("Connected account: \(account)").textSelection(.enabled)
                    Text("Register a GitHub App, enable Device flow, and install it on selected repositories. Enter its public Client ID, not its App ID or client secret. This preview does not include a registered vendor app.").font(.callout)
                    Link("GitHub App registrations", destination: URL(string: "https://github.com/settings/apps")!)
                    TextField("GitHub App public Client ID", text: $clientID).textFieldStyle(.roundedBorder).disabled(busy)
                    Text("Permissions: Contents read for repository context/diffs, Issues read for issue imports, Pull requests read for PR imports; Contents write for artifact uploads, Pull requests write for creation. Your own repository permissions also apply.").font(.caption).foregroundStyle(.secondary)
                    HStack {
                        Button("Connect / reconnect") { connect() }.disabled(busy || clientID.isEmpty)
                        Button("Refresh repositories") { refresh() }.disabled(busy)
                        Button("Disconnect locally") {
                            do { try GitHubAppConnection.disconnect(); account = GitHubAppConnection.accountLabel; repositories = []; message = "Local credential removed. Revoke the authorization on GitHub if it should no longer be valid anywhere." }
                            catch { message = error.localizedDescription }
                        }.disabled(busy)
                    }
                    if let authorization {
                        Text("Enter code: \(authorization.userCode)").font(.title3.monospaced()).textSelection(.enabled)
                        Link("Open GitHub device authorization", destination: authorization.verificationURL)
                        Text("Waiting for approval until \(authorization.expiresAt.formatted(date: .omitted, time: .shortened)).").font(.caption)
                    }
                    HStack {
                        Link("Manage installations and repository access", destination: URL(string: "https://github.com/settings/installations")!)
                        Link("Manage authorizations", destination: URL(string: "https://github.com/settings/apps/authorizations")!)
                    }.font(.caption)
                    Text("Expiring tokens require reconnecting. Client secrets and app private keys are never embedded or requested. Disconnect removes the local token; it does not revoke GitHub authorization.").font(.caption).foregroundStyle(.secondary)
                    ForEach(repositories) { repo in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(repo.fullName).font(.headline)
                            Text("Installation \(repo.installationID) · Contents \(repo.contents) · PRs \(repo.pullRequests) · Issues \(repo.issues) · Your write access: \(repo.userCanPush ? "yes" : "no")").font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
                if busy { HStack { ProgressView().controlSize(.small); Button("Cancel") { task?.cancel() } } }
                if let message { Text(message).font(.callout).textSelection(.enabled) }
            }.padding(24)
        }.onDisappear { task?.cancel() }
    }
    private func connect() {
        task?.cancel(); busy = true; message = nil; repositories = []
        task = Task {
            defer { busy = false; authorization = nil }
            do {
                try GitHubAppConnection.setClientID(clientID)
                let code = try await GitHubAppClient().begin(clientID: clientID)
                try Task.checkCancellation(); authorization = code
                try await GitHubAppConnection.connect(code)
                account = GitHubAppConnection.accountLabel; mode = .app
                repositories = try await GitHubAppConnection.connectedClient().repositories()
                message = repositories.isEmpty ? "Connected. Install the App on a repository, then refresh." : "Connected; repository access verified."
            } catch { if !Task.isCancelled { message = error.localizedDescription } }
        }
    }
    private func refresh() {
        busy = true; message = nil
        task = Task {
            defer { busy = false }
            do { repositories = try await GitHubAppConnection.connectedClient().repositories(); account = GitHubAppConnection.accountLabel }
            catch { if !Task.isCancelled { message = error.localizedDescription } }
        }
    }
}
