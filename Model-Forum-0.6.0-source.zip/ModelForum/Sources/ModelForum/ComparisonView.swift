import SwiftUI
import ForumCore

struct ComparisonView: View {
    let messages: [ChatMessage]
    @Environment(\.dismiss) private var dismiss
    @State private var first: UUID?
    @State private var second: UUID?
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack { Text("Compare answers").font(.title2.bold()); Spacer(); Button("Done") { dismiss() } }
            Text("Choose two saved answers. Agreement between models is not independent verification of a claim.").font(.caption).foregroundStyle(.secondary)
            HStack(alignment: .top, spacing: 20) { column(selection: $first); Divider(); column(selection: $second) }
        }.padding(24).frame(width: 1000, height: 680)
        .onAppear { first = messages.dropLast().last?.id; second = messages.last?.id }
    }
    private func column(selection: Binding<UUID?>) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Picker("Answer", selection: selection) {
                ForEach(messages) { message in Text("\(message.author) · \(message.model ?? "model") · \(message.date.formatted(date: .omitted, time: .shortened))").tag(Optional(message.id)) }
            }
            if let selected = messages.first(where: { $0.id == selection.wrappedValue }) {
                ScrollView { RichMessageView(text: selected.content).padding(8) }
            }
        }.frame(maxWidth: .infinity)
    }
}
