import SwiftUI
import ForumCore

struct GitHubReviewView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var mode = 0
    @State private var prURL = ""
    @State private var repository = ""
    @State private var base = "main"
    @State private var head = ""
    @State private var title = ""
    @State private var description = ""
    @State private var draft = true
    @State private var reviewed = false
    @State private var review: GitHubDiffReview?
    @State private var diff = ""
    @State private var message: String?
    @State private var result: GitHubPullRequestResult?
    @State private var busy = false
    @State private var task: Task<Void, Never>?
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("GitHub review").font(.title2.bold())
            Text(GitHubAccess.connectionLabel).font(.caption).foregroundStyle(.secondary)
            Picker("Action", selection: $mode) {
                Text("Read existing PR diff").tag(0)
                Text("Create PR from existing branches").tag(1)
            }.pickerStyle(.segmented).disabled(busy).onChange(of: mode) { _, _ in invalidate() }
            if mode == 0 {
                TextField("https://github.com/owner/repo/pull/123", text: $prURL).textFieldStyle(.roundedBorder).disabled(busy)
                Button("Load PR diff") { loadExisting() }.disabled(busy || prURL.isEmpty)
            } else {
                HStack {
                    TextField("owner/repository", text: $repository)
                    TextField("Base branch", text: $base)
                    TextField("Head branch", text: $head)
                }.textFieldStyle(.roundedBorder).disabled(busy)
                    .onChange(of: repository) { _, _ in invalidate() }.onChange(of: base) { _, _ in invalidate() }.onChange(of: head) { _, _ in invalidate() }
                Button("Review branch diff") { loadComparison() }.disabled(busy || repository.isEmpty || head.isEmpty)
                TextField("Pull-request title", text: $title).textFieldStyle(.roundedBorder).disabled(busy)
                TextField("Description", text: $description, axis: .vertical).lineLimit(2...4).textFieldStyle(.roundedBorder).disabled(busy)
                Toggle("Create as draft", isOn: $draft).disabled(busy)
            }
            if let review {
                Text("Reviewed base \(review.baseSHA)\nReviewed head \(review.headSHA)").font(.caption.monospaced()).textSelection(.enabled)
            }
            ScrollView([.vertical, .horizontal]) {
                Text(diff.isEmpty ? "Load a diff to inspect it here. Binary content may not be represented by a text diff." : diff)
                    .font(.system(.caption, design: .monospaced)).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding(12)
            }.frame(maxHeight: .infinity).background(Color(nsColor: .textBackgroundColor))
            if mode == 1 {
                Toggle("I reviewed this diff and want to create this pull request on GitHub", isOn: $reviewed).disabled(review == nil || busy)
                Text("No commits, pushes or merges are performed. Branches must already exist in this repository. Both tips are checked again before creation; GitHub branches can still move concurrently.").font(.caption).foregroundStyle(.secondary)
            }
            if let message { Text(message).font(.callout).foregroundStyle(.secondary).textSelection(.enabled) }
            if let result { Link(result.alreadyExists ? "Open existing pull request" : "Open created pull request", destination: result.url) }
            HStack {
                if busy { ProgressView().controlSize(.small); Button("Stop") { task?.cancel() } }
                Spacer()
                Button("Close") { task?.cancel(); dismiss() }.keyboardShortcut(.cancelAction)
                if mode == 1 {
                    Button("Create pull request") { create() }.buttonStyle(.borderedProminent)
                        .disabled(busy || !reviewed || review == nil || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || result != nil)
                }
            }
        }.padding(24).frame(width: 850, height: 720).onDisappear { task?.cancel() }
            .onReceive(NotificationCenter.default.publisher(for: Notification.Name("ModelForumGitHubConnectionChanged"))) { _ in task?.cancel(); invalidate() }
    }
    private func invalidate() { review = nil; reviewed = false; diff = ""; result = nil; message = nil }
    private func loadExisting() {
        invalidate(); busy = true
        task = Task {
            defer { busy = false }
            do { let value = try await GitHubReviewClient().pullRequestDiff(url: prURL); try Task.checkCancellation(); diff = value }
            catch { if !Task.isCancelled { message = error.localizedDescription } }
        }
    }
    private func loadComparison() {
        invalidate(); busy = true
        task = Task {
            defer { busy = false }
            do {
                let value = try await GitHubReviewClient().preview(repository: repository, base: base, head: head)
                try Task.checkCancellation(); review = value; diff = value.diff
            } catch { if !Task.isCancelled { message = error.localizedDescription } }
        }
    }
    private func create() {
        guard let review, reviewed else { return }
        busy = true; message = nil
        task = Task {
            defer { busy = false }
            do {
                result = try await GitHubReviewClient().create(review: review, title: title, body: description, draft: draft)
                message = result?.alreadyExists == true ? "A matching open pull request already exists; no new one was created." : "Pull request created."
            } catch { message = Task.isCancelled ? "Stopped locally. A request already received by GitHub may have succeeded; check GitHub before retrying." : error.localizedDescription }
        }
    }
}
