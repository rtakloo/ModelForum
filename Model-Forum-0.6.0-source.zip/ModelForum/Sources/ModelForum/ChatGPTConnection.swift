import AppKit
import Foundation
import ForumCore

struct ChatGPTProfile: Identifiable, Equatable {
    let id: UUID
    let clientID: String
    let identity: ChatGPTIdentity?
    let connected: Bool
    let permitsInference: Bool
    var label: String { (identity?.email ?? "ChatGPT account") + " · " + String(id.uuidString.prefix(8)) }
}

@MainActor final class ChatGPTConnection: ObservableObject {
    static let shared = ChatGPTConnection()
    @Published private(set) var profiles: [ChatGPTProfile] = []
    @Published private(set) var activeProfileID: UUID?
    @Published private(set) var useForOpenAI: Bool
    @Published private(set) var busy = false
    @Published private(set) var status: String?
    @Published private(set) var failed = false
    var activeProfile: ChatGPTProfile? { profiles.first { $0.id == activeProfileID } }
    private struct Registration: Codable, Equatable {
        var id: UUID
        var clientID: String
        var identity: ChatGPTIdentity?
        var credentials: ChatGPTCredentials?
    }
    private struct State: Codable, Equatable {
        var registrations: [Registration] = []
        var activeID: UUID?
    }
    private var state = State()
    private var storageReady = true
    private let client = ChatGPTClient()
    private var operation: Task<Void, Never>?
    private var refreshJobs: [UUID: Task<ChatGPTCredentials, Error>] = [:]
    private var revision = 0
    private let hostID: String

    private init() {
        let defaults = UserDefaults.standard
        useForOpenAI = defaults.bool(forKey: "ChatGPT.useForOpenAI")
        if let saved = defaults.string(forKey: "ChatGPT.hostID"), saved.hasPrefix("urn:uuid:"), UUID(uuidString: String(saved.dropFirst(9))) != nil { hostID = saved }
        else { hostID = "urn:uuid:" + UUID().uuidString.lowercased(); defaults.set(hostID, forKey: "ChatGPT.hostID") }
        do {
            if let data = try KeychainStore.readChatGPTState() {
                let saved = try JSONDecoder().decode(State.self, from: data)
                guard saved.registrations.count <= 20, Set(saved.registrations.map(\.id)).count == saved.registrations.count else { throw ForumError.message("Invalid saved account metadata.") }
                state = saved
            }
            publish()
        } catch { storageReady = false; status = "Saved ChatGPT accounts could not be opened. Unlock Keychain and restart the app."; failed = true }
    }

    /// Caller must durably invalidate the OpenAI privacy confirmation before changing connection settings.
    func setUseForOpenAI(_ enabled: Bool) {
        guard !busy else { return }
        useForOpenAI = enabled; UserDefaults.standard.set(enabled, forKey: "ChatGPT.useForOpenAI")
        revision += 1
    }
    func selectProfile(_ id: UUID?) {
        guard !busy, id == nil || state.registrations.contains(where: { $0.id == id }) else { return }
        do { var next = state; next.activeID = id; try save(next); revision += 1; status = nil }
        catch { show(error) }
    }
    func signIn(profileID: UUID? = nil, requestConsent: Bool = false, beforeCommit: @escaping @MainActor () -> Bool) {
        guard !busy, storageReady else { return }
        busy = true; failed = false; status = "Waiting for browser sign-in…"; revision += 1
        operation = Task { [weak self] in
            guard let self else { return }
            defer { busy = false; operation = nil }
            let listener = ChatGPTLoopback()
            defer { listener.cancel() }
            do {
                let registration = profileID.flatMap { id in self.state.registrations.first { $0.id == id } }
                if profileID != nil && registration == nil { throw ForumError.message("Select a saved ChatGPT account before signing in again.") }
                guard registration != nil || state.registrations.count < 20 else { throw ForumError.message("The local limit is 20 ChatGPT registrations.") }
                let redirect = try await listener.start()
                let pending = try ChatGPTAuthorization(redirectURI: redirect, clientID: registration?.clientID)
                let url = pending.browserURL(hostID: hostID, idTokenHint: registration?.credentials?.idToken, emailHint: registration?.identity?.email, requestConsent: requestConsent)
                guard NSWorkspace.shared.open(url) else { throw ForumError.message("Could not open the system browser for ChatGPT sign-in.") }
                let returned = try pending.validateCallback(try await listener.callback())
                try Task.checkCancellation()
                let id = registration?.id ?? UUID()
                // Retain an issued registration even if code exchange expires; do not activate it yet.
                if registration == nil {
                    var next = state
                    next.registrations.append(Registration(id: id, clientID: returned.clientID))
                    try save(next)
                }
                let (credentials, identity) = try await client.exchange(code: returned.code, clientID: returned.clientID, authorization: pending)
                try Task.checkCancellation()
                if let expected = registration?.identity, identity.subject != expected.subject { throw ForumError.message("The signed-in ChatGPT account did not match this registration. Add a different account instead.") }
                var next = state
                guard let index = next.registrations.firstIndex(where: { $0.id == id }) else { throw CancellationError() }
                next.registrations[index].identity = identity; next.registrations[index].credentials = credentials; next.activeID = id
                // Browser sign-in can outlive the settings pane. Recheck the app's idle state and
                // durably clear any confirmation saved during that wait immediately before commit.
                guard beforeCommit() else { throw ForumError.message("The ChatGPT account could not be activated. Wait for active requests to finish and resolve any workspace save error, then sign in again.") }
                try save(next)
                status = credentials.permitsInference ? "ChatGPT identity verified. Account plan usage is enabled." : "ChatGPT identity verified. Plan usage was not granted; enable it before sending requests."
                failed = false
            } catch {
                if error is CancellationError { status = "ChatGPT sign-in cancelled."; failed = false }
                else { show(error) }
            }
        }
    }
    func cancelSignIn() { operation?.cancel() }
    func signOut() {
        guard !busy, let id = activeProfileID, let registration = state.registrations.first(where: { $0.id == id }) else { return }
        busy = true; revision += 1; refreshJobs[id]?.cancel(); refreshJobs[id] = nil
        operation = Task { [weak self] in
            guard let self else { return }
            defer { busy = false; operation = nil }
            do {
                let credentialLock = try ChatGPTCredentialLock()
                let latest = try readState()
                guard latest.activeID == state.activeID,
                      let latestRegistration = latest.registrations.first(where: { $0.id == id }),
                      latestRegistration.clientID == registration.clientID,
                      latestRegistration.identity == registration.identity else {
                    throw ForumError.message("ChatGPT accounts changed in another app process. Restart Model Forum before signing out.")
                }
                state = latest; publish()
                var revoked = true
                if let credentials = latestRegistration.credentials {
                    do { try await client.revoke(credentials, clientID: latestRegistration.clientID) }
                    catch { revoked = false }
                }
                var next = state
                if let index = next.registrations.firstIndex(where: { $0.id == id }) { next.registrations[index].credentials = nil }
                try save(next, holding: credentialLock)
                status = revoked ? "Signed out. The account registration is retained for later sign-in." : "Signed out locally. Remote revocation was not confirmed; disconnect Model Forum in ChatGPT Settings → Usage."
                failed = !revoked
            } catch { show(error) }
        }
    }
    func loadModels() async throws -> [ModelOption] {
        let startRevision = revision
        let credentials = try await currentCredentials()
        try Task.checkCancellation()
        guard revision == startRevision, !busy else { throw CancellationError() }
        let models = try await client.models(credentials: credentials)
        guard revision == startRevision else { throw CancellationError() }
        return models
    }
    func reply(model: String, transcript: String, onText: (@Sendable (String) async -> Void)? = nil) async throws -> ModelReply {
        guard useForOpenAI, !busy else { throw ForumError.message("Select the ChatGPT connection and complete sign-in before sending.") }
        let startRevision = revision
        let credentials = try await currentCredentials()
        try Task.checkCancellation()
        guard revision == startRevision, !busy, useForOpenAI else { throw CancellationError() }
        let reply = try await client.reply(model: model, transcript: transcript, credentials: credentials, onText: onText)
        guard revision == startRevision else { throw CancellationError() }
        return reply
    }
    private func currentCredentials() async throws -> ChatGPTCredentials {
        guard storageReady, let id = activeProfileID, let registration = state.registrations.first(where: { $0.id == id }),
              let identity = registration.identity, let credentials = registration.credentials else { throw ForumError.message("Continue with ChatGPT to connect a verified account first.") }
        if credentials.expiresAt.timeIntervalSinceNow > 60 { return credentials }
        if let job = refreshJobs[id] { return try await job.value }
        let startRevision = revision
        let job = Task { @MainActor [self] in
            let credentialLock = try ChatGPTCredentialLock()
            // Another app process may already have rotated the token while this one was idle.
            let latest = try readState()
            guard latest.activeID == state.activeID,
                  let latestRegistration = latest.registrations.first(where: { $0.id == id }),
                  latestRegistration.clientID == registration.clientID, latestRegistration.identity == identity,
                  let latestCredentials = latestRegistration.credentials else {
                throw ForumError.message("ChatGPT accounts changed in another app process. Restart Model Forum before continuing.")
            }
            state = latest; publish()
            if latestCredentials.expiresAt.timeIntervalSinceNow > 60 { return latestCredentials }
            do {
                let fresh = try await client.refresh(latestCredentials, clientID: registration.clientID, expectedIdentity: identity)
                try Task.checkCancellation()
                guard revision == startRevision, let index = state.registrations.firstIndex(where: { $0.id == id }) else { throw CancellationError() }
                var next = state; next.registrations[index].credentials = fresh
                try save(next, holding: credentialLock); return fresh
            } catch {
                if error is ChatGPTSessionError, revision == startRevision, let index = state.registrations.firstIndex(where: { $0.id == id }) {
                    var next = state; next.registrations[index].credentials = nil
                    try save(next, holding: credentialLock)
                }
                throw error
            }
        }
        refreshJobs[id] = job
        defer { refreshJobs[id] = nil }
        return try await job.value
    }
    private func readState() throws -> State {
        guard let data = try KeychainStore.readChatGPTState() else { return State() }
        do { return try JSONDecoder().decode(State.self, from: data) }
        catch { throw ForumError.message("Saved ChatGPT accounts could not be read. Unlock Keychain and restart the app.") }
    }
    private func save(_ next: State, holding existingLock: ChatGPTCredentialLock? = nil) throws {
        guard storageReady else { throw ForumError.message("Unlock Keychain and restart before changing ChatGPT accounts.") }
        let credentialLock = try existingLock ?? ChatGPTCredentialLock()
        defer { withExtendedLifetime(credentialLock) {} }
        guard try readState() == state else { throw ForumError.message("ChatGPT accounts changed in another app process. Restart Model Forum before saving changes.") }
        try KeychainStore.saveChatGPTState(JSONEncoder().encode(next))
        state = next; publish()
    }
    private func publish() {
        activeProfileID = state.activeID
        profiles = state.registrations.map { ChatGPTProfile(id: $0.id, clientID: $0.clientID, identity: $0.identity, connected: $0.credentials != nil, permitsInference: $0.credentials?.permitsInference == true) }
    }
    private func show(_ error: Error) {
        failed = true
        if error is ForumError || error is ChatGPTSessionError { status = error.localizedDescription }
        else { status = "ChatGPT account changes could not be saved. Check Keychain and try again." }
    }
}
