import SwiftUI
import AppKit
import ForumCore
import CryptoKit

private final class UpdateRedirectGuard: NSObject, URLSessionTaskDelegate {
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) { completionHandler(nil) }
}
struct ReleaseSettingsView: View {
    @State private var checking = false
    @State private var release: UpdateRelease?
    @State private var notice: String?
    private var feed: URL? { (Bundle.main.object(forInfoDictionaryKey: "ModelForumUpdateFeed") as? String).flatMap(URL.init(string:)) }
    private var publicKey: Data? { (Bundle.main.object(forInfoDictionaryKey: "ModelForumUpdatePublicKey") as? String).flatMap { Data(base64Encoded: $0) } }
    private var downloadHost: String? { Bundle.main.object(forInfoDictionaryKey: "ModelForumUpdateHost") as? String }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("About & updates").font(.title2.bold())
                Text("Model Forum \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "development")")
                Text("This preview includes local app features and configurable services. Account approvals, registered apps, hosting, payment setup and public release signing must be completed by the publisher before commercial distribution.").font(.callout)
                Divider()
                Text("Signed updates").font(.headline)
                if feed == nil || publicKey == nil || downloadHost == nil {
                    Text("No release feed is configured in this build. The publisher must embed an HTTPS feed and update-verification public key in a signed release.").font(.caption)
                } else {
                    Button(checking ? "Checking…" : "Check for update") { check() }.disabled(checking)
                }
                if let release {
                    Text("Version \(release.version)").font(.headline)
                    Text(release.notes).textSelection(.enabled)
                    Button("Download verified update…") { download(release) }.disabled(checking)
                    Text("After verification, quit Model Forum and replace the old app with the downloaded version. Existing history migrates on next launch; use Data settings to back it up first.").font(.caption)
                }
                if let notice { Text(notice).font(.caption).textSelection(.enabled) }
                Divider()
                Text("Data handling").font(.headline)
                Text("Conversations and files are readable local data. Credentials are kept separately in Keychain or in the official provider tool. Sending shares selected context with the chosen provider. Team Push shares a reviewed conversation with the configured team server. GitHub autosave commits generated files to the linked repository. The no-training setting records your account-policy confirmation; it cannot change a provider's policy. Deletion from this working copy does not recall external copies.").font(.caption)
                Text("Support diagnostics").font(.headline)
                Button("Copy non-sensitive diagnostics") {
                    let text = "Model Forum version: \(Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "development")\nmacOS: \(ProcessInfo.processInfo.operatingSystemVersionString)\nPDF compiler: \(LaTeXCompiler.isAvailable ? "installed" : "not installed")\nUpdate feed configured: \(feed != nil)\nNo account, conversation, path, or credential data included."
                    NSPasteboard.general.clearContents(); NSPasteboard.general.setString(text, forType: .string)
                }
                Text("Customer-facing terms, a support address and a merchant account are publisher setup items. This preview does not claim a paid license or collect payments until a configured billing service confirms them.").font(.caption).foregroundStyle(.secondary)
            }.padding(26)
        }.frame(width: 650, height: 720)
    }
    private func fetch(_ url: URL, limit: Int) async throws -> Data {
        guard url.scheme == "https", url.user == nil, url.password == nil else { throw ForumError.message("Updates require an HTTPS URL.") }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.httpCookieStorage = nil; configuration.urlCredentialStorage = nil
        configuration.timeoutIntervalForRequest = 30; configuration.timeoutIntervalForResource = 300
        let session = URLSession(configuration: configuration); defer { session.invalidateAndCancel() }
        let (bytes, response) = try await session.bytes(for: URLRequest(url: url), delegate: UpdateRedirectGuard())
        guard (response as? HTTPURLResponse)?.statusCode == 200, response.expectedContentLength <= limit else { throw ForumError.message("The update server did not return a supported response.") }
        var data = Data()
        for try await byte in bytes { guard data.count < limit else { throw ForumError.message("The update exceeded its size limit.") }; data.append(byte) }
        return data
    }
    private func check() {
        guard let feed, let publicKey, let downloadHost else { return }
        checking = true; notice = nil; release = nil
        Task { @MainActor in
            defer { checking = false }
            do {
                let data = try await fetch(feed, limit: 256 * 1024)
                release = try SignedUpdate.verify(data, publicKey: publicKey, currentBuild: Int(Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "0") ?? 0, allowedHost: downloadHost)
            } catch { notice = "Update check failed: " + ((error as? ForumError)?.localizedDescription ?? "Check the connection and retry.") }
        }
    }
    private func download(_ release: UpdateRelease) {
        let panel = NSSavePanel(); panel.nameFieldStringValue = "Model-Forum-\(release.version).zip"
        guard panel.runModal() == .OK, let destination = panel.url else { return }
        checking = true
        Task { @MainActor in
            defer { checking = false }
            do {
                let transfer = Task.detached(priority: .utility) {
                    try await VerifiedUpdateDownload.save(release, to: destination)
                }
                try await withTaskCancellationHandler {
                    try await transfer.value
                } onCancel: { transfer.cancel() }
                notice = "Signature and download hash verified. The update is saved; quit and replace the app when ready."
                NSWorkspace.shared.activateFileViewerSelecting([destination])
            } catch { notice = "Update was not installed: " + ((error as? ForumError)?.localizedDescription ?? "Download or save failed.") }
        }
    }
}

/// Streams and hashes off the UI actor. Only verified bytes are moved to the chosen destination.
private enum VerifiedUpdateDownload {
    static func save(_ release: UpdateRelease, to destination: URL) async throws {
        try Task.checkCancellation()
        guard release.expiresAt > Date() else { throw ForumError.message("This update manifest expired. Check for updates again before downloading.") }
        guard release.downloadURL.scheme == "https", release.downloadURL.user == nil, release.downloadURL.password == nil,
              (1...536_870_912).contains(release.byteCount) else { throw ForumError.message("The verified update metadata is invalid.") }
        // Stage on the destination's volume so replacement is atomic even on external disks.
        let directory = destination.deletingLastPathComponent().appendingPathComponent(".model-forum-update-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        defer { try? FileManager.default.removeItem(at: directory) }
        let temporary = directory.appendingPathComponent("verified-update.zip")
        guard FileManager.default.createFile(atPath: temporary.path, contents: nil, attributes: [.posixPermissions: 0o600]) else { throw ForumError.message("Could not create a private temporary update file.") }
        let output = try FileHandle(forWritingTo: temporary)
        defer { try? output.close() }
        let configuration = URLSessionConfiguration.ephemeral
        configuration.urlCache = nil; configuration.httpCookieStorage = nil; configuration.urlCredentialStorage = nil
        configuration.timeoutIntervalForRequest = 30; configuration.timeoutIntervalForResource = 300
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }
        var request = URLRequest(url: release.downloadURL, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 30)
        request.httpShouldHandleCookies = false
        let (bytes, response) = try await session.bytes(for: request, delegate: UpdateRedirectGuard())
        defer { bytes.task.cancel() }
        guard (response as? HTTPURLResponse)?.statusCode == 200, response.expectedContentLength <= Int64(release.byteCount) else {
            throw ForumError.message("The update server did not return a supported response.")
        }
        try await withTaskCancellationHandler {
            var hash = SHA256(); var count = 0; var chunk = Data(); chunk.reserveCapacity(65_536)
            for try await byte in bytes {
                guard count < release.byteCount else { throw ForumError.message("The update exceeded its signed size limit.") }
                count += 1; chunk.append(byte)
                if chunk.count == 65_536 {
                    try Task.checkCancellation(); hash.update(data: chunk); try output.write(contentsOf: chunk)
                    chunk.removeAll(keepingCapacity: true)
                }
            }
            try Task.checkCancellation()
            if !chunk.isEmpty { hash.update(data: chunk); try output.write(contentsOf: chunk) }
            let digest = hash.finalize().map { String(format: "%02x", $0) }.joined()
            guard count == release.byteCount, digest == release.sha256 else { throw ForumError.message("The downloaded update failed its integrity check.") }
            try output.synchronize(); try output.close()
            guard release.expiresAt > Date() else { throw ForumError.message("The update manifest expired during download. Check for updates again.") }
            try Task.checkCancellation()
            if FileManager.default.fileExists(atPath: destination.path) {
                _ = try FileManager.default.replaceItemAt(destination, withItemAt: temporary)
            } else { try FileManager.default.moveItem(at: temporary, to: destination) }
        } onCancel: { bytes.task.cancel() }
    }
}
