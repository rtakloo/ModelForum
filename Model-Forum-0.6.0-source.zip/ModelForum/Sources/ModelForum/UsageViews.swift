import SwiftUI
import ForumCore

struct UsageSettingsView: View {
    let ledger: UsageLedger
    let onSave: (SpendingPolicy) -> Void
    @State private var draft: SpendingPolicy
    @State private var requestCap: String
    @State private var sessionCap: String
    @State private var monthlyCap: String
    @State private var provider: ProviderKind = .openAI
    @State private var model = ""
    @State private var inputPrice = ""
    @State private var outputPrice = ""
    @State private var error: String?
    init(policy: SpendingPolicy, ledger: UsageLedger, onSave: @escaping (SpendingPolicy) -> Void) {
        self.ledger = ledger; self.onSave = onSave
        _draft = State(initialValue: policy)
        _requestCap = State(initialValue: policy.requestCapUSD.map(String.init(describing:)) ?? "")
        _sessionCap = State(initialValue: policy.sessionCapUSD.map(String.init(describing:)) ?? "")
        _monthlyCap = State(initialValue: policy.monthlyCapUSD.map(String.init(describing:)) ?? "")
    }
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Usage and spending").font(.title2.bold())
                Text("Local estimates for requests managed by this app. These are not provider balances or billing guarantees. Unknown prices remain unknown. Subscription usage is not priced at API rates.")
                    .font(.callout).foregroundStyle(.secondary)
                GroupBox("API spending caps (USD)") {
                    VStack(alignment: .leading) {
                        TextField("Per request — blank means no cap", text: $requestCap)
                        TextField("Per conversation/session — blank means no cap", text: $sessionCap)
                        TextField("Per calendar month (UTC) — blank means no cap", text: $monthlyCap)
                        Text("Before each API call, the app reserves a conservative input estimate plus the full output cap. Interrupted or failed requests retain their reservation. A cap blocks requests with unknown API prices or unknown billing routes.")
                            .font(.caption).foregroundStyle(.secondary)
                    }.padding(4)
                }
                GroupBox("Your model prices, USD per million tokens") {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(draft.prices) { price in
                            HStack {
                                Text("\(price.provider.title) / \(price.model)")
                                Spacer()
                                Text("Input \(price.inputPerMillionUSD.formatted()) · output \(price.outputPerMillionUSD.formatted())")
                                Button("Remove") { draft.prices.removeAll { $0.id == price.id } }
                            }
                        }
                        Picker("Provider", selection: $provider) {
                            ForEach(ProviderKind.allCases.filter { $0 == .openAI || $0 == .anthropic }) { value in Text(value.title).tag(value) }
                        }
                        TextField("Exact model ID", text: $model)
                        HStack { TextField("Input price / million", text: $inputPrice); TextField("Output price / million", text: $outputPrice) }
                        Button("Add or update model price") { addPrice() }
                        Text("Use provider pricing for this exact model. Cached-input discounts and non-text charges are not estimated. Changing prices never rewrites prior reservation snapshots.")
                            .font(.caption).foregroundStyle(.secondary)
                    }.padding(4)
                }
                if let error { Text(error).foregroundStyle(.red) }
                Button("Save spending settings") { save() }.buttonStyle(.borderedProminent)
                Divider()
                UsageLedgerView(ledger: ledger)
            }.padding(20)
        }.frame(minWidth: 620, minHeight: 480)
    }
    private func addPrice() {
        guard let input = Double(inputPrice), let output = Double(outputPrice) else { error = "Enter both input and output prices; leave unknown models unpriced."; return }
        let value = ModelPrice(provider: provider, model: model.trimmingCharacters(in: .whitespacesAndNewlines), inputPerMillionUSD: input, outputPerMillionUSD: output)
        do { try value.validate(); draft.prices.removeAll { $0.id == value.id }; draft.prices.append(value); error = nil }
        catch { self.error = error.localizedDescription }
    }
    private func cap(_ value: String) throws -> Double? {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty { return nil }
        guard let parsed = Double(trimmed) else { throw ForumError.message("Enter a valid USD cap or leave it blank.") }
        return parsed
    }
    private func save() {
        do {
            draft.requestCapUSD = try cap(requestCap); draft.sessionCapUSD = try cap(sessionCap); draft.monthlyCapUSD = try cap(monthlyCap)
            try draft.validate(); onSave(draft); error = nil
        } catch { self.error = error.localizedDescription }
    }
}

struct UsageLedgerView: View {
    var ledger: UsageLedger
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Recent requests").font(.headline)
            if ledger.records.isEmpty { Text("No locally recorded requests yet.").foregroundStyle(.secondary) }
            ForEach(Array(ledger.records.suffix(100).reversed())) { record in
                VStack(alignment: .leading, spacing: 3) {
                    HStack { Text(record.model).font(.headline); Spacer(); Text(record.status.rawValue.capitalized) }
                    Text("\(record.provider.title) · \(record.date.formatted()) · \(record.billingMode.rawValue)").font(.caption)
                    Text("Input: \(record.inputTokens.map(String.init) ?? "unknown") · Output: \(record.outputTokens.map(String.init) ?? "unknown")")
                        .font(.caption)
                    Text(costLabel(record)).font(.caption).foregroundStyle(.secondary)
                }.padding(10).background(.quaternary.opacity(0.3), in: RoundedRectangle(cornerRadius: 8))
            }
        }
    }
    private func costLabel(_ record: UsageRecord) -> String {
        if record.billingMode == .subscription { return "Subscription usage · API cost not applicable; remaining allowance unknown" }
        if let cost = record.estimatedCostUSD { return "Estimated API cost: \(cost.formatted(.currency(code: "USD").precision(.fractionLength(2...6))))" }
        if let reservation = record.reservedUSD { return "Retained reservation estimate: \(reservation.formatted(.currency(code: "USD").precision(.fractionLength(2...6)))) · final cost unknown" }
        return "Cost unknown"
    }
}
