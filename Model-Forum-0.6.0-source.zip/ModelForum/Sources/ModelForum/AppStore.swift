import SwiftUI
import ForumCore

enum ContextScope: String, CaseIterable, Identifiable {
    case conversation = "Conversation"
    case selected = "Selected answer only"
    var id: String { rawValue }
}

struct PreparedTurn {
    let conversationID: UUID
    let targets: [Participant]
    let body: String
    let transcript: String
    let agentTranscripts: [String: String]
    let contextIDs: [UUID]
    let critiqueID: UUID?
    let channel: Channel?
}

@MainActor final class AppStore: ObservableObject {
    @Published var workspace = SavedWorkspace.initial
    @Published var selectedConversationID: UUID?
    @Published var selectedChannelID: UUID?
    @Published var syncBusy = false
    @Published var composer = ""
    @Published var selectedAlias = "gpt"
    @Published var comparisonAlias = "claude"
    @Published var compare = false
    @Published var contextScope: ContextScope = .conversation
    @Published var critiqueID: UUID?
    @Published var busy = false
    @Published var activity = ""
    @Published var error: String?
    @Published var settingsSection: String = "Connections"
    @Published var showSettings = false
    @Published var conversationSearch = ""
    @Published var liveReply = ""
    @Published var liveAlias = ""
    @Published var dataNotice: String?
    var textRequestOverride: (@Sendable (Participant, String, Int) async throws -> ModelReply)?
    @Published private(set) var privacyRevision = 0
    var storage: WorkspaceStorage?
    var syncTask: Task<Void, Never>?
    private let upload: (Data, ArtifactDestination) async throws -> ArtifactUploadResult
    private let compile: (Data, String) async throws -> ArtifactDraft
    private var shuttingDown = false
    var runningTask: Task<Void, Never>?

    init(storage suppliedStorage: WorkspaceStorage? = nil,
         upload: @escaping (Data, ArtifactDestination) async throws -> ArtifactUploadResult = { data, destination in
             try await GitHubArtifactClient().upload(data: data, destination: destination)
         },
         compile: @escaping (Data, String) async throws -> ArtifactDraft = { source, filename in
             try await LaTeXCompiler().compile(source: source, filename: filename)
         }) {
        self.upload = upload
        self.compile = compile
        do {
            let storage = try suppliedStorage ?? WorkspaceStorage()
            workspace = try storage.load()
            self.storage = storage
            self.dataNotice = storage.recoveryNotice
        } catch {
            self.error = "Saved workspace could not be opened. Existing data has been preserved; saving is disabled for this session. \(error.localizedDescription)"
        }
        if workspace.conversations.isEmpty { workspace.conversations = [Conversation()] }
        let first = workspace.conversations.first { conversation in
            conversation.channelID == nil || workspace.channels.contains { $0.id == conversation.channelID && $0.deletedAt == nil }
        }
        selectedConversationID = first?.id
        selectedChannelID = first?.channelID
        for index in workspace.artifacts.indices where workspace.artifacts[index].syncState == .uploading {
            workspace.artifacts[index].syncState = .pending
        }
        if workspace.githubConnectionStamp == nil { workspace.githubConnectionStamp = GitHubAppConnection.revision }
        workspace.usageLedger.recoverInterruptedRequests()
        Task { resumeUploads() }
    }
    var conversation: Conversation? { workspace.conversations.first { $0.id == selectedConversationID } }
    var selectedAnswer: ChatMessage? { conversation?.messages.first { $0.id == critiqueID } }
    var configuredCount: Int { workspace.participants.filter { !$0.model.isEmpty }.count }
    @discardableResult func persist() -> Bool {
        guard let storage else { error = "Saving is disabled because the workspace could not be opened."; return false }
        do { try storage.save(workspace); return true }
        catch { self.error = "Could not save the workspace: \(error.localizedDescription)"; return false }
    }
    func newConversation() {
        guard !busy else { return }
        guard selectedChannelID == nil || activeChannels.contains(where: { $0.id == selectedChannelID }) else { return }
        let new = Conversation(channelID: selectedChannelID)
        workspace.conversations.insert(new, at: 0)
        selectedConversationID = new.id
        composer = ""; critiqueID = nil; contextScope = .conversation
        persist()
    }
    func select(_ id: UUID) {
        guard !busy, let target = workspace.conversations.first(where: { $0.id == id }),
              target.channelID == nil || activeChannels.contains(where: { $0.id == target.channelID }) else { return }
        selectedConversationID = id; selectedChannelID = conversation?.channelID; critiqueID = nil; contextScope = .conversation; composer = ""
    }
    func critique(_ message: ChatMessage) {
        critiqueID = message.id
        composer = "Review this answer. Identify errors, unsupported claims, and concrete improvements."
        compare = false
    }
    func preparedTurn() throws -> PreparedTurn {
        guard let conversation else { throw ForumError.message("Create a conversation first.") }
        guard conversation.channelID == nil || activeChannels.contains(where: { $0.id == conversation.channelID }) else { throw ForumError.message("Restore this channel before sending messages.") }
        let routed = try ConversationPolicy.route(composer, knownAliases: workspace.participants.map(\.alias), fallback: selectedAlias)
        var aliases = routed.aliases
        if compare && aliases.count == 1 && !aliases.contains(comparisonAlias) { aliases.append(comparisonAlias) }
        if compare && aliases.count < 2 { throw ForumError.message("Choose two different participants to compare.") }
        let targets = try aliases.map { alias -> Participant in
            guard let participant = workspace.participants.first(where: { $0.alias == alias }) else { throw ForumError.message("Configure @\(alias) first.") }
            guard !participant.model.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw ForumError.message("Choose a model for @\(alias) in Connections before sending.") }
            guard participant.model.utf8.count <= 512 else { throw ForumError.message("The model ID for @\(alias) exceeds 512 bytes. Choose another model or correct the custom ID in Connections.") }
            return participant
        }
        let context: [ChatMessage]
        if contextScope == .selected {
            guard let answer = selectedAnswer else { throw ForumError.message("Choose an answer to critique before selecting this context mode.") }
            context = [answer]
        } else { context = conversation.messages }
        let transcript = try ConversationPolicy.transcript(messages: context, prompt: routed.body, critique: selectedAnswer)
        var agentTranscripts: [String: String] = [:]
        for target in targets {
            agentTranscripts[target.alias] = try AgentPolicy.compose(transcript: transcript, global: workspace.globalInstructions, individual: workspace.agentInstructions[target.alias] ?? "")
        }
        let preview = targets.map { "RECIPIENT @" + $0.alias + "\n" + (agentTranscripts[$0.alias] ?? transcript) }.joined(separator: "\n\n────────────────\n\n")
        return PreparedTurn(conversationID: conversation.id, targets: targets, body: routed.body, transcript: preview, agentTranscripts: agentTranscripts, contextIDs: context.map(\.id), critiqueID: critiqueID, channel: workspace.channels.first { $0.id == conversation.channelID })
    }
    func send() {
        guard !busy else { return }
        do {
            guard storage != nil else { throw ForumError.message("Local storage is unavailable. Resolve the workspace error before generating new replies.") }
            if conversation == nil {
                let draft = composer
                newConversation()
                composer = draft
            }
            let plan = try preparedTurn()
            for target in plan.targets {
                try AgentPolicy.validatePrivacy(provider: target.provider, requireNoTraining: workspace.requireNoTraining, confirmations: workspace.privacyConfirmations)
            }
            if usesChatGPT && ChatGPTConnection.shared.busy { throw ForumError.message("Finish or cancel ChatGPT sign-in before sending.") }
            let userMessage = ChatMessage(role: "user", author: "You", content: plan.body)
            append(userMessage, to: plan.conversationID)
            if let index = workspace.conversations.firstIndex(where: { $0.id == plan.conversationID }), workspace.conversations[index].title == "New conversation" {
                workspace.conversations[index].title = String(plan.body.prefix(48))
            }
            composer = ""; critiqueID = nil; contextScope = .conversation
            guard persist() else { return }
            busy = true; error = nil
            let tokenLimit = workspace.maxOutputTokens
            runningTask = Task {
                defer { busy = false; activity = ""; liveReply = ""; liveAlias = ""; runningTask = nil; persist() }
                for target in plan.targets {
                    if Task.isCancelled { break }
                    activity = "Waiting for @\(target.alias)…"
                    guard let transcript = plan.agentTranscripts[target.alias] else { continue }
                    do {
                        let reply = try await performTextRequest(target, transcript: transcript, tokenLimit: tokenLimit, sessionID: plan.conversationID)
                        try Task.checkCancellation()
                        let message = ChatMessage(role: "assistant", author: "@\(target.alias)", content: reply.text, model: reply.model, inputTokens: reply.inputTokens, outputTokens: reply.outputTokens, contextMessageIDs: plan.contextIDs + [userMessage.id], provider: target.provider, requestContext: transcript, critiqueMessageID: plan.critiqueID)
                        append(message, to: plan.conversationID)
                        do {
                            try saveArtifacts(ArtifactFiles.extract(from: reply.text), conversationID: plan.conversationID, messageID: message.id, channel: plan.channel)
                        } catch { self.error = "The answer was kept, but its files could not be saved: \(error.localizedDescription)" }
                    } catch {
                        if Task.isCancelled || error is CancellationError { break }
                        append(ChatMessage(role: "notice", author: "Connection", content: "@\(target.alias): \(error.localizedDescription)"), to: plan.conversationID)
                        self.error = "@\(target.alias): \(error.localizedDescription)"
                    }
                }
                if Task.isCancelled {
                    append(ChatMessage(role: "notice", author: "Stopped", content: "Stopped locally. A provider may still bill work already started."), to: plan.conversationID)
                }
            }
        } catch { self.error = error.localizedDescription }
    }
    func stop() { runningTask?.cancel(); activity = "Stopping…" }
    func append(_ message: ChatMessage, to id: UUID) {
        guard let index = workspace.conversations.firstIndex(where: { $0.id == id }) else { return }
        workspace.conversations[index].messages.append(message)
        persist()
    }
    func attachGitHub(_ text: String) {
        guard let id = selectedConversationID else { return }
        append(ChatMessage(role: "context", author: "GitHub", content: text), to: id)
    }
}

extension AppStore {
    var activeChannels: [Channel] { workspace.channels.filter { $0.deletedAt == nil } }
    var deletedChannels: [Channel] { workspace.channels.filter { $0.deletedAt != nil } }
    var selectedChannel: Channel? { workspace.channels.first { $0.id == selectedChannelID } }
    var visibleConversations: [Conversation] { workspace.conversations.filter { conversation in
        conversation.channelID == selectedChannelID && (conversationSearch.isEmpty || conversation.title.localizedCaseInsensitiveContains(conversationSearch) || conversation.messages.contains { $0.content.localizedCaseInsensitiveContains(conversationSearch) })
    } }
    var hasActiveWork: Bool { busy || syncBusy }

    func selectChannel(_ id: UUID?) {
        guard !busy, id == nil || activeChannels.contains(where: { $0.id == id }) else { return }
        selectedChannelID = id
        selectedConversationID = visibleConversations.first?.id
        composer = ""; critiqueID = nil; contextScope = .conversation
    }
    @discardableResult func saveChannel(id: UUID?, name: String, repository: String, autoSave: Bool) -> Bool {
        guard !busy else { return false }
        githubConnectionDidChange()
        let previous = workspace
        var createdID: UUID?
        do {
            if let id { try workspace.updateChannel(id: id, name: name, repository: repository, autoSave: autoSave) }
            else {
                let channel = try workspace.createChannel(name: name, repository: repository, autoSave: autoSave)
                createdID = channel.id
            }
            guard persist() else { workspace = previous; return false }
            error = nil
            if let createdID { selectedChannelID = createdID; selectedConversationID = nil }
            // A settings change cancels an in-flight upload; already accepted GitHub writes may finish.
            if syncBusy { syncTask?.cancel() } else { resumeUploads() }
            return true
        } catch { workspace = previous; self.error = error.localizedDescription; return false }
    }
    func moveConversation(_ id: UUID, to channelID: UUID?) {
        guard !busy else { return }
        do {
            try workspace.moveConversation(id: id, channelID: channelID)
            if selectedConversationID == id { selectedChannelID = channelID }
            persist()
        } catch { self.error = error.localizedDescription }
    }
    func artifactURL(_ artifact: ArtifactRecord) -> URL? {
        guard let files = storage?.artifacts else { return nil }
        do { return try files.url(relativePath: artifact.relativePath) }
        catch { self.error = error.localizedDescription; return nil }
    }
    func saveArtifacts(_ drafts: [ArtifactDraft], conversationID: UUID, messageID: UUID, channel: Channel?) throws {
        guard !drafts.isEmpty else { return }
        guard let files = storage?.artifacts else { throw ForumError.message("Local storage is unavailable. Files cannot be saved or uploaded.") }
        for draft in drafts {
            let id = UUID()
            let destination = try channel.flatMap { try ArtifactFiles.destination(channel: $0, conversationID: conversationID, artifactID: id, filename: draft.filename) }
            let path = try files.store(draft: draft, id: id)
            workspace.artifacts.append(ArtifactRecord(id: id, conversationID: conversationID, messageID: messageID,
                filename: draft.filename, mimeType: draft.mimeType, relativePath: path,
                byteCount: draft.data.count, destination: destination))
        }
        // The durable local file and outbox record must both exist before any network write.
        guard persist() else { throw ForumError.message("Files are on this Mac, but their workspace records could not be saved. GitHub upload has not started.") }
        resumeUploads()
    }
    func uploadEnabled(_ record: ArtifactRecord) -> Bool {
        guard workspace.githubConnectionStamp == GitHubAppConnection.revision else { return false }
        guard let destination = record.destination else { return false }
        return workspace.channels.contains { channel in
            channel.deletedAt == nil && channel.autoSave && channel.repository?.lowercased() == destination.repository.lowercased()
                && destination.path.hasPrefix(channel.folder + "/conversations/")
        }
    }
    func retryArtifact(_ id: UUID) {
        guard let index = workspace.artifacts.firstIndex(where: { $0.id == id }),
              workspace.artifacts[index].syncState == .failed || workspace.artifacts[index].syncState == .pending else { return }
        guard uploadEnabled(workspace.artifacts[index]) else {
            error = "This upload is paused. Restore its original channel repository and enable automatic saves to retry. Existing file destinations never change."
            return
        }
        workspace.artifacts[index].syncState = .pending
        workspace.artifacts[index].syncError = nil
        if persist() { resumeUploads() }
    }
    func resumeUploads() {
        githubConnectionDidChange()
        guard !syncBusy, !shuttingDown, storage != nil,
              workspace.artifacts.contains(where: { $0.syncState == .pending && uploadEnabled($0) }) else { return }
        guard persist() else { return }
        syncBusy = true
        syncTask = Task {
            defer {
                syncBusy = false; syncTask = nil
                if !shuttingDown { Task { resumeUploads() } }
            }
            while !Task.isCancelled && !shuttingDown {
                guard let index = workspace.artifacts.firstIndex(where: { $0.syncState == .pending && uploadEnabled($0) }),
                      let destination = workspace.artifacts[index].destination, let files = storage?.artifacts else { break }
                let record = workspace.artifacts[index]
                workspace.artifacts[index].syncState = .uploading
                guard persist() else {
                    workspace.artifacts[index].syncState = .failed
                    workspace.artifacts[index].syncError = "Workspace save failed. Retry after resolving the storage problem."
                    break
                }
                do {
                    let data = try files.read(relativePath: record.relativePath)
                    let result = try await upload(data, destination)
                    // Record confirmed success even if cancellation arrived immediately afterward.
                    workspace.artifacts[index].syncState = .uploaded
                    workspace.artifacts[index].remoteURL = result.url
                    workspace.artifacts[index].commitSHA = result.commitSHA
                    workspace.artifacts[index].syncError = nil
                } catch {
                    if Task.isCancelled || error is CancellationError {
                        workspace.artifacts[index].syncState = .pending
                    } else {
                        workspace.artifacts[index].syncState = .failed
                        workspace.artifacts[index].syncError = error.localizedDescription
                    }
                }
                guard persist() else { break }
            }
        }
    }
    func stopAll() {
        shuttingDown = true
        runningTask?.cancel(); syncTask?.cancel()
    }
    func generateImage(prompt: String, model: String) {
        guard !busy else { return }
        do {
            guard storage != nil else { throw ForumError.message("Local storage is unavailable. Image generation is disabled to avoid losing the result.") }
            guard !usesChatGPT else { throw ForumError.message("ChatGPT plan sign-in does not support image generation in this preview. Select the API-key connection explicitly to generate an API-billed image.") }
            guard !workspace.spendingPolicy.hasCaps else { throw ForumError.message("Image pricing is not included in the local spending ledger. Image generation is blocked while currency spending caps are enabled.") }
            let prompt = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !prompt.isEmpty else { throw ForumError.message("Describe the image first.") }
            try AgentPolicy.validatePrivacy(provider: .openAI, requireNoTraining: workspace.requireNoTraining, confirmations: workspace.privacyConfirmations)
            let effectivePrompt = try AgentPolicy.imagePrompt(prompt: prompt, global: workspace.globalInstructions, individual: workspace.agentInstructions["gpt"] ?? "")
            guard let key = try KeychainStore.read(.openAI), !key.isEmpty else { throw ForumError.message("Save your OpenAI API key in Connections first.") }
            if conversation == nil { newConversation() }
            guard let conversation else { return }
            let channel = workspace.channels.first { $0.id == conversation.channelID }
            let userMessage = ChatMessage(role: "user", author: "You", content: "Generate an image: " + prompt)
            append(userMessage, to: conversation.id)
            guard persist() else { return }
            busy = true; error = nil; activity = "Generating image with OpenAI…"
            runningTask = Task {
                defer { busy = false; activity = ""; liveReply = ""; liveAlias = ""; runningTask = nil; persist() }
                do {
                    let draft = try await ImageGenerationClient().generate(prompt: effectivePrompt, model: model, apiKey: key)
                    try Task.checkCancellation()
                    let message = ChatMessage(role: "assistant", author: "@gpt image", content: "Generated image", model: model,
                        contextMessageIDs: [userMessage.id], provider: .openAI, requestContext: effectivePrompt)
                    append(message, to: conversation.id)
                    try saveArtifacts([draft], conversationID: conversation.id, messageID: message.id, channel: channel)
                } catch {
                    let text = Task.isCancelled ? "Image generation stopped locally. The provider may still bill work already started." : error.localizedDescription
                    append(ChatMessage(role: "notice", author: "Image generation", content: text), to: conversation.id)
                    self.error = text
                }
            }
        } catch { self.error = error.localizedDescription }
    }
}

extension AppStore {
    @discardableResult func deleteChannel(_ id: UUID) -> Bool {
        guard !busy else { return false }
        let previous = workspace
        do {
            try workspace.deleteChannel(id: id)
            guard persist() else { workspace = previous; return false }
            error = nil
            if selectedChannelID == id { selectChannel(nil) }
            syncTask?.cancel()
            return true
        } catch { workspace = previous; self.error = error.localizedDescription; return false }
    }
    @discardableResult func restoreChannel(_ id: UUID) -> Bool {
        guard !busy else { return false }
        let previous = workspace
        do {
            try workspace.restoreChannel(id: id)
            guard persist() else { workspace = previous; return false }
            error = nil
            selectChannel(id)
            return true
        } catch { workspace = previous; self.error = error.localizedDescription; return false }
    }
    @discardableResult func savePreferences(global: String, agentInstructions: [String: String], requireNoTraining: Bool, confirmations: [String: Bool], expectedPrivacyRevision: Int = 0) -> Bool {
        guard !busy else { return false }
        guard expectedPrivacyRevision == privacyRevision else { error = "An account changed while these preferences were open. Review the current privacy confirmations before saving."; return false }
        do {
            // Validate each possible instruction combination before saving; the actual context is bounded again on Send.
            _ = try AgentPolicy.compose(transcript: "", global: global, individual: "")
            for text in agentInstructions.values { _ = try AgentPolicy.compose(transcript: "", global: global, individual: text) }
            let previous = workspace
            workspace.globalInstructions = global
            workspace.agentInstructions = agentInstructions
            workspace.requireNoTraining = requireNoTraining
            workspace.privacyConfirmations = confirmations
            guard persist() else { workspace = previous; return false }
            error = nil
            return true
        } catch { self.error = error.localizedDescription; return false }
    }
    func accountLabelSummary(for provider: ProviderKind) -> String {
        if provider == .openAI && usesChatGPT {
            guard let identity = ChatGPTConnection.shared.activeProfile?.identity else { return "ChatGPT · sign-in required" }
            return "ChatGPT · " + (identity.email ?? "Email unavailable") + " · ID " + identity.subject
        }
        if provider == .claudeCode, let status = ClaudeAccountConnection.shared.status { return status.summary }
        if let summary = workspace.providerAccountLabels[provider.rawValue]?.summary { return summary }
        return provider == .ollama ? "Local account not required · cloud identity not retrieved" : "Account label not provided"
    }
    @discardableResult func saveAccountLabel(_ label: ProviderAccountLabel, for provider: ProviderKind, expectedPrivacyRevision: Int) -> Bool {
        guard !busy else { return false }
        guard expectedPrivacyRevision == privacyRevision else {
            error = "An account changed while these labels were open. Review the current labels before saving."
            return false
        }
        do {
            let value = try label.validated()
            let previous = workspace
            if value.isEmpty { workspace.providerAccountLabels.removeValue(forKey: provider.rawValue) }
            else { workspace.providerAccountLabels[provider.rawValue] = value }
            workspace.schemaVersion = max(workspace.schemaVersion, 5)
            guard persist() else { workspace = previous; return false }
            error = nil
            return true
        } catch { self.error = error.localizedDescription; return false }
    }
    @discardableResult func credentialsWillChange(_ provider: ProviderKind) -> Bool {
        // Persist the invalidation before changing Keychain, so a crash cannot carry consent to a new account.
        workspace.privacyConfirmations[provider.rawValue] = false
        workspace.providerAccountLabels.removeValue(forKey: provider.rawValue)
        privacyRevision += 1
        return persist()
    }
    func compilePDF(_ artifact: ArtifactRecord) {
        guard !busy else { return }
        do {
            guard (artifact.filename as NSString).pathExtension.lowercased() == "tex",
                  let original = workspace.artifacts.first(where: { $0.id == artifact.id }),
                  let conversation = workspace.conversations.first(where: { $0.id == original.conversationID }),
                  let files = storage?.artifacts else { throw ForumError.message("Choose a saved LaTeX source file first.") }
            let channel = workspace.channels.first { $0.id == conversation.channelID }
            guard channel?.deletedAt == nil else { throw ForumError.message("Restore this channel before compiling its files.") }
            let source = try files.read(relativePath: original.relativePath)
            guard persist() else { return }
            busy = true; error = nil; activity = "Compiling LaTeX to PDF on this Mac…"
            runningTask = Task {
                defer { busy = false; activity = ""; liveReply = ""; liveAlias = ""; runningTask = nil; persist() }
                do {
                    let pdf = try await compile(source, original.filename)
                    try Task.checkCancellation()
                    let message = ChatMessage(role: "notice", author: "LaTeX compiler", content: "Compiled \(original.filename) to PDF on this Mac.", contextMessageIDs: [original.messageID])
                    append(message, to: original.conversationID)
                    try saveArtifacts([pdf], conversationID: original.conversationID, messageID: message.id, channel: channel)
                } catch {
                    let detail = Task.isCancelled ? "PDF compilation stopped. The LaTeX source was kept." : error.localizedDescription
                    self.error = detail
                    append(ChatMessage(role: "notice", author: "LaTeX compiler", content: detail), to: original.conversationID)
                }
            }
        } catch { self.error = error.localizedDescription }
    }
}
