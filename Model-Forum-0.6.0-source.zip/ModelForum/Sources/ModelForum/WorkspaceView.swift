import SwiftUI
import AppKit
import ForumCore

private let forest = Color(red: 0.18, green: 0.42, blue: 0.38)

struct WorkspaceView: View {
    @EnvironmentObject var store: AppStore
    @State private var showGitHub = false
    @State private var showGitHubReview = false
    @State private var showComparison = false
    @State private var showDeletedChannels = false
    @State private var showChannelEditor = false
    @State private var editingChannel: Channel?
    @State private var showImageGenerator = false
    @State private var preview: String?
    @State private var showPreview = false
    var body: some View {
        HStack(spacing: 0) {
            sidebar.frame(width: 240)
            Divider()
            VStack(spacing: 0) {
                header
                Divider()
                messageArea
                if let error = store.error {
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: "exclamationmark.circle.fill").foregroundStyle(.orange)
                        Text(error).font(.callout).textSelection(.enabled)
                        Spacer()
                        Button { store.error = nil } label: { Image(systemName: "xmark") }.buttonStyle(.plain)
                    }.padding(12).background(Color.orange.opacity(0.08))
                }
                if let notice = store.dataNotice {
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: "info.circle").foregroundStyle(forest)
                        Text(notice).font(.caption).textSelection(.enabled)
                        Spacer()
                        Button { store.dataNotice = nil } label: { Image(systemName: "xmark") }.buttonStyle(.plain)
                    }.padding(12).background(forest.opacity(0.06))
                }
                composer
            }
        }
        .background(Color(nsColor: .windowBackgroundColor))
        .sheet(isPresented: $showDeletedChannels) { DeletedChannelsView().environmentObject(store) }
        .sheet(isPresented: $showChannelEditor) { ChannelEditorView(channel: editingChannel).environmentObject(store) }
        .sheet(isPresented: $showImageGenerator) { GenerateImageView().environmentObject(store) }
        .sheet(isPresented: $showGitHubReview) { GitHubReviewView() }
        .sheet(isPresented: $showComparison) { ComparisonView(messages: store.conversation?.messages.filter { $0.role == "assistant" } ?? []) }
        .onReceive(NotificationCenter.default.publisher(for: Notification.Name("ModelForumGitHubConnectionChanged"))) { _ in store.githubConnectionDidChange() }
        .sheet(isPresented: $showGitHub) { GitHubContextView().environmentObject(store) }
        .sheet(isPresented: $showPreview) {
            VStack(alignment: .leading, spacing: 16) {
                Text("Context preview").font(.title2.bold())
                Text("This is the exact text sent to each selected participant. Credentials are added separately and never appear here.").foregroundStyle(.secondary)
                ScrollView { Text(preview ?? "").font(.system(.body, design: .monospaced)).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding() }
                    .background(Color(nsColor: .textBackgroundColor)).clipShape(RoundedRectangle(cornerRadius: 10))
                Button("Done") { showPreview = false }.keyboardShortcut(.defaultAction).frame(maxWidth: .infinity, alignment: .trailing)
            }.padding(24).frame(width: 740, height: 600)
        }
    }
    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "bubble.left.and.bubble.right.fill").font(.title2).foregroundStyle(forest)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Model Forum").font(.headline)
                    Text("A room for different minds").font(.caption2).foregroundStyle(.secondary)
                }
            }.padding(.horizontal, 20).padding(.top, 26).padding(.bottom, 24)
            Button { store.newConversation() } label: {
                Label("New conversation", systemImage: "plus").frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 5)
            }.buttonStyle(.bordered).padding(.horizontal, 16).disabled(store.busy)
            HStack {
                Text("CHANNELS").font(.system(size: 10, weight: .semibold)).tracking(1.2).foregroundStyle(.secondary)
                Spacer()
                Button { editingChannel = nil; showChannelEditor = true } label: { Image(systemName: "plus") }
                    .buttonStyle(.plain).help("Create channel").disabled(store.busy)
            }.padding(.horizontal, 20).padding(.top, 24).padding(.bottom, 10)
            TextField("Search this channel", text: $store.conversationSearch).textFieldStyle(.roundedBorder).padding(.horizontal, 14).padding(.bottom, 8)
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    Button { store.selectChannel(nil) } label: {
                        Label("Unfiled", systemImage: "tray").frame(maxWidth: .infinity, alignment: .leading).padding(10)
                            .background(store.selectedChannelID == nil ? forest.opacity(0.1) : .clear).cornerRadius(8)
                    }.buttonStyle(.plain).disabled(store.busy)
                    ForEach(store.activeChannels) { channel in
                        HStack {
                            Button { store.selectChannel(channel.id) } label: {
                                Label(channel.name, systemImage: "number").lineLimit(1).frame(maxWidth: .infinity, alignment: .leading)
                            }.buttonStyle(.plain)
                            Button { editingChannel = channel; showChannelEditor = true } label: { Image(systemName: "ellipsis") }
                                .buttonStyle(.plain).help("Rename or edit channel")
                        }.padding(10).background(store.selectedChannelID == channel.id ? forest.opacity(0.1) : .clear).cornerRadius(8)
                            .disabled(store.busy)
                            .contextMenu {
                                Button("Rename or edit channel…") { editingChannel = channel; showChannelEditor = true }.disabled(store.busy)
                                Button("Delete channel", role: .destructive) { store.deleteChannel(channel.id) }.disabled(store.busy)
                            }
                    }
                    Divider().padding(.vertical, 10)
                    Text(store.selectedChannel?.name ?? "Unfiled conversations").font(.caption.bold()).foregroundStyle(.secondary).padding(.horizontal, 10)
                    ForEach(store.visibleConversations) { conversation in
                        Button { store.select(conversation.id) } label: {
                            HStack(alignment: .top, spacing: 9) {
                                Image(systemName: "bubble.left").padding(.top, 2)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(conversation.title).font(.system(size: 12, weight: .medium)).lineLimit(2)
                                    Text("\(conversation.messages.count) messages").font(.caption2).foregroundStyle(.secondary)
                                }
                                Spacer(minLength: 0)
                            }.padding(12).frame(maxWidth: .infinity, alignment: .leading)
                                .background(store.selectedConversationID == conversation.id ? forest.opacity(0.11) : .clear)
                                .clipShape(RoundedRectangle(cornerRadius: 8))
                        }.buttonStyle(.plain).disabled(store.busy)
                            .contextMenu { moveMenu(conversation.id) }
                    }
                    if store.visibleConversations.isEmpty {
                        Text("Start a new conversation in this channel, or move one here using its menu.").font(.caption).foregroundStyle(.secondary).padding(10)
                    }
                }.padding(.horizontal, 10)
            }
            Spacer(minLength: 12)
            VStack(alignment: .leading, spacing: 12) {
                Button { showDeletedChannels = true } label: { Label("Recently deleted (\(store.deletedChannels.count))", systemImage: "trash") }.buttonStyle(.plain).disabled(store.busy)
                Label("History stays on this Mac", systemImage: "internaldrive").font(.caption).foregroundStyle(.secondary)
                Button { store.showSettings = true } label: {
                    HStack { Label("Settings", systemImage: "slider.horizontal.3"); Spacer(); Text("\(store.configuredCount)/4").foregroundStyle(.secondary) }.padding(.vertical, 3)
                }.buttonStyle(.plain).disabled(store.busy)
            }.padding(20)
        }.background(Color(nsColor: .controlBackgroundColor).opacity(0.55))
    }
    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text(store.conversation?.title ?? "Conversation").font(.system(size: 18, weight: .semibold)).lineLimit(1)
                Text(store.selectedChannel.map { "#" + $0.name + ($0.repository.map { " · " + $0 } ?? "") } ?? "Unfiled conversation").font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if let id = store.selectedConversationID {
                Menu { moveMenu(id) } label: { Label("Move", systemImage: "folder") }.disabled(store.busy)
            }
            Menu("More") {
                Button("Compare saved answers") { showComparison = true }.disabled((store.conversation?.messages.filter { $0.role == "assistant" }.count ?? 0) < 2)
                Button("Review or create GitHub PR…") { showGitHubReview = true }
                Button("Export conversation…") { store.exportConversation(asMarkdown: true) }
                Button("Workflows…") { store.settingsSection = "Workflows"; store.showSettings = true }
            }.disabled(store.busy)
            Button { showImageGenerator = true } label: { Label("Image", systemImage: "photo") }.disabled(store.busy)
            Button { showGitHub = true } label: { Label("Attach GitHub", systemImage: "link") }.disabled(store.busy)
        }.padding(.horizontal, 28).padding(.vertical, 20)
    }
    @ViewBuilder private func moveMenu(_ id: UUID) -> some View {
        Text("Move conversation to")
        Button("Unfiled") { store.moveConversation(id, to: nil) }.disabled(store.busy)
        ForEach(store.activeChannels) { channel in
            Button(channel.name) { store.moveConversation(id, to: channel.id) }.disabled(store.busy)
        }
    }
    private var messageArea: some View {
        ScrollViewReader { proxy in
            ScrollView {
                if store.conversation?.messages.isEmpty != false { welcome }
                else {
                    LazyVStack(alignment: .leading, spacing: 22) {
                        ForEach(store.conversation?.messages ?? []) { message in
                            VStack(alignment: .leading, spacing: 8) {
                                MessageCard(message: message, selected: store.critiqueID == message.id, busy: store.busy) { store.critique(message) }
                                ForEach(store.workspace.artifacts.filter { $0.messageID == message.id }) { record in
                                    ArtifactCard(record: record).environmentObject(store)
                                }
                            }.id(message.id)
                        }
                        if store.busy {
                            if !store.liveReply.isEmpty {
                                VStack(alignment: .leading, spacing: 8) {
                                    Text(store.liveAlias + " · responding…").font(.headline)
                                    Text(store.liveReply).font(.body).textSelection(.enabled)
                                    Text("Partial response — saved only after completion.").font(.caption).foregroundStyle(.secondary)
                                }.padding(18).frame(maxWidth: .infinity, alignment: .leading).background(Color.primary.opacity(0.035)).cornerRadius(12)
                            }
                            HStack(spacing: 10) { ProgressView().controlSize(.small); Text(store.activity).font(.callout).foregroundStyle(.secondary) }.padding(.vertical, 8)
                        }
                        Color.clear.frame(height: 1).id("bottom")
                    }.padding(28).frame(maxWidth: 960).frame(maxWidth: .infinity)
                }
            }.onChange(of: store.conversation?.messages.count) { _, _ in withAnimation { proxy.scrollTo("bottom", anchor: .bottom) } }
        }
    }
    private var welcome: some View {
        VStack(alignment: .leading, spacing: 22) {
            Image(systemName: "quote.bubble").font(.system(size: 38, weight: .light)).foregroundStyle(forest)
            Text("One conversation.\nMore than one perspective.").font(.system(size: 32, weight: .semibold, design: .serif))
            Text("Bring models into the conversation with @mentions. Ask one to propose an answer, another to challenge it, and decide what to keep.")
                .font(.system(size: 15)).foregroundStyle(.secondary).lineSpacing(5).fixedSize(horizontal: false, vertical: true)
            HStack(alignment: .top, spacing: 12) {
                starter("Ask a model", symbol: "at", text: "@gpt Explain the tradeoffs in my design.")
                starter("Compare perspectives", symbol: "rectangle.split.2x1", text: "@gpt @claude Independently propose an approach to this problem.")
            }
            Button("Set up your connections", systemImage: "key") { store.showSettings = true }.buttonStyle(.borderedProminent).controlSize(.large)
            Text("Save your API key in Connections, load the model list, and choose a model. Text conversations are sent when you press Send. Image prompts use Generate image; channel files upload automatically when enabled.").font(.caption).foregroundStyle(.secondary)
        }.padding(42).frame(maxWidth: 760, alignment: .leading).frame(maxWidth: .infinity, minHeight: 430)
    }
    private func starter(_ title: String, symbol: String, text: String) -> some View {
        Button { store.composer = text } label: {
            VStack(alignment: .leading, spacing: 9) {
                Label(title, systemImage: symbol).font(.system(size: 12, weight: .semibold))
                Text(text).font(.caption).foregroundStyle(.secondary).multilineTextAlignment(.leading)
            }.frame(maxWidth: .infinity, minHeight: 76, alignment: .topLeading).padding(16)
                .background(forest.opacity(0.05)).overlay(RoundedRectangle(cornerRadius: 12).stroke(forest.opacity(0.15))).clipShape(RoundedRectangle(cornerRadius: 12))
        }.buttonStyle(.plain)
    }
    private var composer: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let selected = store.selectedAnswer {
                HStack {
                    Label("Critiquing \(selected.author)", systemImage: "text.bubble").font(.caption.bold())
                    Text(String(selected.content.prefix(75))).font(.caption).lineLimit(1).foregroundStyle(.secondary)
                    Spacer()
                    Button { store.critiqueID = nil; store.contextScope = .conversation } label: { Image(systemName: "xmark.circle.fill") }.buttonStyle(.plain)
                }.padding(10).background(forest.opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 8))
            }
            HStack(spacing: 12) {
                Picker("To", selection: $store.selectedAlias) {
                    ForEach(store.workspace.participants) { Text("@\($0.alias)").tag($0.alias) }
                }.frame(width: 170)
                Toggle("Compare", isOn: $store.compare).toggleStyle(.checkbox)
                Menu("Workflow") {
                    ForEach(store.workspace.workflows) { workflow in Button(workflow.name) { store.runWorkflow(workflow) } }
                    Divider()
                    Button("Manage workflows…") { store.settingsSection = "Workflows"; store.showSettings = true }
                }
                if store.compare {
                    Picker("With", selection: $store.comparisonAlias) { ForEach(store.workspace.participants) { Text("@\($0.alias)").tag($0.alias) } }.frame(width: 185)
                }
                Spacer()
                if store.selectedAnswer != nil {
                    Picker("Context", selection: $store.contextScope) { ForEach(ContextScope.allCases) { Text($0.rawValue).tag($0) } }.labelsHidden().frame(width: 175)
                }
            }.font(.caption).disabled(store.busy)
            DisclosureGroup("Current model accounts") {
                VStack(alignment: .leading, spacing: 6) {
                    ForEach(store.workspace.participants) { participant in
                        Text("@\(participant.alias) · \(participant.provider.title): \(store.accountLabelSummary(for: participant.provider))")
                            .textSelection(.enabled)
                    }
                    Button("Manage accounts in Settings…") { store.showSettings = true }
                        .buttonStyle(.link).disabled(store.busy)
                }.frame(maxWidth: .infinity, alignment: .leading).padding(.top, 4)
            }.font(.caption).foregroundStyle(.secondary)
            VStack(alignment: .leading, spacing: 0) {
                ZStack(alignment: .topLeading) {
                    if store.composer.isEmpty { Text("Message a model… use @gpt or @claude to invite a perspective").foregroundStyle(.tertiary).padding(.horizontal, 12).padding(.top, 13).allowsHitTesting(false) }
                    TextEditor(text: $store.composer).font(.system(size: 14)).scrollContentBackground(.hidden).padding(7).frame(minHeight: 70, maxHeight: 120).disabled(store.busy)
                }
                HStack {
                    Button("Preview context", systemImage: "doc.text.magnifyingglass") {
                        do { let plan = try store.preparedTurn(); preview = "RECIPIENTS: \(plan.targets.map { "@\($0.alias) (\($0.provider.title), \($0.model))" }.joined(separator: ", "))\n\n\(plan.transcript)"; showPreview = true }
                        catch { store.error = error.localizedDescription }
                    }.buttonStyle(.plain).font(.caption).foregroundStyle(.secondary).disabled(store.busy)
                    Spacer()
                    if store.busy {
                        Button("Stop", systemImage: "stop.fill") { store.stop() }.buttonStyle(.bordered)
                    } else {
                        Button { store.send() } label: { Label("Send", systemImage: "arrow.up").padding(.horizontal, 8) }
                            .buttonStyle(.borderedProminent).keyboardShortcut(.return, modifiers: .command).disabled(store.composer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                }.padding(12)
            }.background(Color(nsColor: .textBackgroundColor)).clipShape(RoundedRectangle(cornerRadius: 12)).overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.primary.opacity(0.12)))
            Text(store.compare ? "Independent answers share conversation context; each uses its own saved agent instructions." : "\(store.contextScope.rawValue) is shared with the addressed models. ⌘ Return to send.")
                .font(.system(size: 10)).foregroundStyle(.secondary)
        }.padding(.horizontal, 28).padding(.top, 14).padding(.bottom, 20)
    }
}

struct MessageCard: View {
    let message: ChatMessage
    let selected: Bool
    let busy: Bool
    let critique: () -> Void
    @State private var expanded = false
    @State private var showProvenance = false
    @State private var showSource = false
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 9) {
                Image(systemName: icon).foregroundStyle(message.role == "user" ? Color.secondary : forest)
                    .frame(width: 28, height: 28).background(forest.opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 7))
                Text(message.author).font(.system(size: 13, weight: .semibold))
                if let provider = message.provider { Text(provider.title).font(.caption).foregroundStyle(.secondary) }
                Spacer()
                Text(message.date, style: .time).font(.caption2).foregroundStyle(.tertiary)
            }
            if message.role == "context" && !expanded {
                Text(String(message.content.prefix(240)) + (message.content.count > 240 ? "…" : "")).font(.callout).foregroundStyle(.secondary).textSelection(.enabled)
                Button("Show attached context") { expanded = true }.font(.caption)
            } else if message.role == "assistant" && !showSource {
                RichMessageView(text: message.content)
            } else {
                Text(message.content).font(.system(size: 14)).lineSpacing(5).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading)
            }
            if message.role == "assistant" {
                HStack(spacing: 14) {
                    Button("Critique", systemImage: "text.bubble") { critique() }.disabled(busy)
                    Button("Copy", systemImage: "doc.on.doc") { NSPasteboard.general.clearContents(); NSPasteboard.general.setString(message.content, forType: .string) }
                    Button(showSource ? "Formatted" : "Source", systemImage: showSource ? "textformat" : "chevron.left.forwardslash.chevron.right") { showSource.toggle() }
                    Button("Details", systemImage: "info.circle") { showProvenance.toggle() }
                    Spacer()
                    if let input = message.inputTokens, let output = message.outputTokens {
                        Text("\(input) in · \(output) out").foregroundStyle(.secondary)
                    }
                }.font(.caption).buttonStyle(.plain).foregroundStyle(forest)
                if showProvenance {
                    Text("Model: \(message.model ?? "unknown")\nContext references: \(message.contextMessageIDs.map(\.uuidString).joined(separator: ", "))\nUsage is provider-reported when available; no price estimate is shown.")
                        .font(.system(size: 10, design: .monospaced)).foregroundStyle(.secondary).textSelection(.enabled)
                    if let critiqueID = message.critiqueMessageID { Text("Critiqued answer: \(critiqueID.uuidString)").font(.caption2).textSelection(.enabled) }
                    if let context = message.requestContext {
                        DisclosureGroup("Exact context sent") { Text(context).font(.system(size: 11, design: .monospaced)).textSelection(.enabled) }.font(.caption)
                    }
                }
            }
        }.padding(18).background(message.role == "user" ? Color.primary.opacity(0.025) : Color(nsColor: .textBackgroundColor))
            .clipShape(RoundedRectangle(cornerRadius: 12)).overlay(RoundedRectangle(cornerRadius: 12).stroke(selected ? forest : Color.primary.opacity(0.06), lineWidth: selected ? 1.5 : 1))
    }
    private var icon: String {
        switch message.role { case "user": return "person"; case "context": return "link"; case "notice": return "info.circle"; default: return "sparkle" }
    }
}
