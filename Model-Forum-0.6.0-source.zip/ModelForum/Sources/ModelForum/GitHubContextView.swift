import SwiftUI
import ForumCore

struct GitHubContextView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    @State private var url = ""
    @State private var fetchedURL = ""
    @State private var context: String?
    @State private var error: String?
    @State private var loading = false
    @State private var task: Task<Void, Never>?
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Bring GitHub into the conversation").font(.title2.bold())
            Text("Load a repository, issue, or pull request using \(GitHubAccess.connectionLabel). Review the context before attaching it.").foregroundStyle(.secondary)
            HStack {
                TextField("https://github.com/owner/repo", text: $url).textFieldStyle(.roundedBorder).disabled(loading)
                Button("Load") { fetch() }.disabled(loading || url.isEmpty)
            }
            if loading { HStack { ProgressView().controlSize(.small); Text("Reading GitHub…").font(.callout) } }
            if let error { Text(error).foregroundStyle(.red).font(.callout).textSelection(.enabled) }
            ScrollView {
                Text(context ?? "Repository links load an overview, README, and top-level file listing from the default branch. Issue and pull-request links load their title and body. Source-file contents, code diffs, and comments are not included.")
                    .font(.system(.callout, design: .monospaced)).foregroundStyle(context == nil ? .secondary : .primary)
                    .textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding(16)
            }.frame(maxHeight: .infinity).background(Color(nsColor: .textBackgroundColor)).clipShape(RoundedRectangle(cornerRadius: 10))
            Label("Attached content is shared with models on your next Send when conversation context is selected.", systemImage: "info.circle").font(.caption).foregroundStyle(.secondary)
            HStack {
                Text("Read only · no GitHub changes").font(.caption).foregroundStyle(.secondary)
                Spacer()
                Button("Cancel") { task?.cancel(); dismiss() }.keyboardShortcut(.cancelAction)
                Button("Attach to conversation") {
                    if let context { store.attachGitHub(context); dismiss() }
                }.buttonStyle(.borderedProminent).disabled(context == nil || loading || fetchedURL != url)
            }
        }.padding(26).frame(width: 730, height: 570).onDisappear { task?.cancel() }
    }
    private func fetch() {
        task?.cancel(); context = nil; error = nil; loading = true
        let requestedURL = url
        task = Task {
            defer { loading = false }
            do {
                let result = try await GitHubAccess.context(url: requestedURL)
                try Task.checkCancellation()
                context = result; fetchedURL = requestedURL
            } catch { if !Task.isCancelled { self.error = error.localizedDescription } }
        }
    }
}
