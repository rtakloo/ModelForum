import SwiftUI
import ForumCore

struct PreferencesView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var section = "instructions"
    @State private var global = ""
    @State private var agentInstructions: [String: String] = [:]
    @State private var requireNoTraining = true
    @State private var confirmations: [String: Bool] = [:]
    @State private var selectedAlias = ""
    @State private var loaded = false
    @State private var privacyRevision = 0
    @State private var saveNotice: String?
    @State private var saveFailed = false

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Preferences").font(.system(size: 25, weight: .semibold, design: .serif))
                    Text("Set shared instructions, individual preferences, and privacy checks.")
                        .font(.callout).foregroundStyle(.secondary)
                }
                Spacer()
                Button("Done") { dismiss() }.keyboardShortcut(.cancelAction)
            }
            Picker("Preferences section", selection: $section) {
                Text("Instructions").tag("instructions")
                Text("Privacy").tag("privacy")
            }.pickerStyle(.segmented)
            ScrollView {
                if section == "instructions" { instructionSettings }
                else { privacySettings }
            }
            if let saveNotice {
                Text(saveNotice).font(.caption).foregroundStyle(saveFailed ? Color.red : Color.secondary)
            }
            HStack {
                Text("Changes apply to future requests after you save.").font(.caption).foregroundStyle(.secondary)
                Spacer()
                Button("Save settings") {
                    if store.savePreferences(global: global, agentInstructions: agentInstructions, requireNoTraining: requireNoTraining, confirmations: confirmations, expectedPrivacyRevision: privacyRevision) {
                        saveFailed = false; saveNotice = "Preferences saved."
                    } else {
                        saveFailed = true; saveNotice = store.error ?? "Could not save preferences."
                    }
                }.buttonStyle(.borderedProminent).disabled(store.busy || !loaded)
            }
        }.padding(26).frame(width: 650, height: 720)
            .onChange(of: store.privacyRevision) { _, revision in
                confirmations = store.workspace.privacyConfirmations
                privacyRevision = revision
                saveNotice = "An account changed. Review its privacy settings and confirm again."
            }
            .onAppear {
                if privacyRevision != store.privacyRevision {
                    confirmations = store.workspace.privacyConfirmations
                    privacyRevision = store.privacyRevision
                }
                guard !loaded else { return }
                global = store.workspace.globalInstructions
                agentInstructions = store.workspace.agentInstructions
                requireNoTraining = store.workspace.requireNoTraining
                confirmations = store.workspace.privacyConfirmations
                selectedAlias = store.workspace.participants.first?.alias ?? ""
                loaded = true
            }
    }

    private var instructionSettings: some View {
        VStack(alignment: .leading, spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Global instructions").font(.headline)
                Text("Preferences included with each addressed model’s request, such as writing style or how to explain uncertainty.")
                    .font(.caption).foregroundStyle(.secondary)
                instructionsEditor($global, label: "Global instructions")
                byteCount(global)
            }
            Divider()
            VStack(alignment: .leading, spacing: 8) {
                Text("Instructions for an individual agent").font(.headline)
                Picker("Agent", selection: $selectedAlias) {
                    ForEach(store.workspace.participants) { participant in
                        Text("@\(participant.alias) · \(participant.provider.title)").tag(participant.alias)
                    }
                }.pickerStyle(.menu)
                if !selectedAlias.isEmpty {
                    instructionsEditor(individualBinding, label: "Instructions for @\(selectedAlias)")
                    byteCount(agentInstructions[selectedAlias] ?? "")
                }
                Text("Only the addressed agent’s individual instructions are included with its request. Global instructions are shared. Instructions guide responses; they do not grant tools or enforce provider privacy settings.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Text("Instructions are saved locally with your workspace. Avoid putting passwords or API keys here. Each instruction field allows 20 KB; instructions and conversation context together allow 240 KB.")
                .font(.caption).foregroundStyle(.secondary)
        }.padding(.vertical, 6)
    }

    private var privacySettings: some View {
        VStack(alignment: .leading, spacing: 16) {
            Toggle("Require no-training account settings", isOn: $requireNoTraining)
                .font(.headline)
            Text("When enabled, requests are blocked until you confirm the selected provider’s account or server is configured to exclude your content from model training. Model Forum cannot verify or change those external settings. Review them first, then check the appropriate confirmation below and save.")
                .font(.callout).foregroundStyle(.secondary)
            Text("Turning this check off only removes the app’s confirmation requirement. It does not opt you into training or change your provider account. These confirmations are your declarations, not verified guarantees; review them again after changing accounts, servers, or provider settings.")
                .font(.caption).foregroundStyle(.secondary)
            ForEach(ProviderKind.allCases) { provider in
                privacyCard(provider)
            }
            VStack(alignment: .leading, spacing: 8) {
                Text("Retention and sharing are separate").font(.headline)
                Text("A no-training policy does not mean zero retention. Provider logging and retention rules still apply. OpenAI text responses use store: false, which does not remove all provider retention. Your local conversation history and files also remain on this Mac.")
                Text("GitHub exports follow your channel settings and repository visibility. Public exports can be read and reused by others; a provider privacy confirmation does not protect those copies or change requests already sent.")
            }.font(.caption).foregroundStyle(.secondary)
        }.padding(.vertical, 6)
    }

    private func privacyCard(_ provider: ProviderKind) -> some View {
        VStack(alignment: .leading, spacing: 9) {
            Text(provider.title).font(.headline)
            Text(privacyExplanation(provider)).font(.caption).foregroundStyle(.secondary)
            Toggle(confirmationLabel(provider), isOn: confirmationBinding(provider))
                .toggleStyle(.checkbox).font(.callout)
            HStack(spacing: 14) {
                Link("Official data policy", destination: policyURL(provider))
                if provider == .claudeCode {
                    Link("Claude privacy settings", destination: URL(string: "https://claude.ai/settings/data-privacy-controls")!)
                }
                if provider == .ollama {
                    Link("Local-only configuration", destination: URL(string: "https://docs.ollama.com/faq#how-do-i-disable-ollamas-cloud-features")!)
                }
            }.font(.caption)
        }.padding(14).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.primary.opacity(0.035)).clipShape(RoundedRectangle(cornerRadius: 10))
    }

    private func instructionsEditor(_ binding: Binding<String>, label: String) -> some View {
        TextEditor(text: binding).font(.body).frame(height: 130).padding(6)
            .background(Color(nsColor: .textBackgroundColor))
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.primary.opacity(0.15)))
            .accessibilityLabel(label)
    }

    private func byteCount(_ text: String) -> some View {
        Text("\(text.utf8.count.formatted()) / 20,000 bytes")
            .font(.caption).foregroundStyle(text.utf8.count > AgentPolicy.instructionByteLimit ? Color.red : Color.secondary)
    }

    private var individualBinding: Binding<String> {
        Binding(get: { agentInstructions[selectedAlias] ?? "" }, set: { agentInstructions[selectedAlias] = $0 })
    }

    private func confirmationBinding(_ provider: ProviderKind) -> Binding<Bool> {
        Binding(get: { confirmations[provider.rawValue] == true }, set: { confirmations[provider.rawValue] = $0 })
    }

    private func confirmationLabel(_ provider: ProviderKind) -> String {
        switch provider {
        case .openAI: return "I confirm this API account is not opted into sharing request content for training."
        case .anthropic: return "I confirm this API account has not opted into content use for training."
        case .ollama: return "I confirm this server runs locally, or its configured cloud route excludes content from training."
        case .claudeCode: return "I confirm training is disabled for the account and provider used by this CLI."
        }
    }

    private func privacyExplanation(_ provider: ProviderKind) -> String {
        switch provider {
        case .openAI:
            return "OpenAI excludes API inputs and outputs from training by default, but accounts can opt into sharing. Review the API organization’s data controls, including any administrator-enabled sharing. ChatGPT subscription settings do not establish the API account’s settings."
        case .anthropic:
            return "Anthropic excludes commercial API content from training by default. An organization can opt into improvement programs; voluntarily submitted feedback may also be used. Confirm the settings and agreements for the API account you use here."
        case .ollama:
            return "A local Ollama address can still route cloud models off this Mac. Ollama states that local prompts stay local and its cloud service does not train on content. Check the actual server and model routing; you can disable Ollama cloud features for local-only operation."
        case .claudeCode:
            return "Claude Code sends requests to a provider even though the CLI runs on your Mac. Consumer accounts can allow model improvement; commercial accounts normally exclude training unless opted in. Check the signed-in account and any configured gateway or third-party provider."
        }
    }

    private func policyURL(_ provider: ProviderKind) -> URL {
        switch provider {
        case .openAI: return URL(string: "https://developers.openai.com/api/docs/guides/your-data")!
        case .anthropic: return URL(string: "https://privacy.claude.com/en/articles/7996868-is-my-data-used-for-model-training")!
        case .ollama: return URL(string: "https://ollama.com/privacy")!
        case .claudeCode: return URL(string: "https://code.claude.com/docs/en/data-usage")!
        }
    }
}
