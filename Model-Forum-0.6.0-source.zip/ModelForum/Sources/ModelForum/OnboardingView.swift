import SwiftUI

struct OnboardingView: View {
    let openSettings: (String) -> Void
    let finish: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Welcome to Model Forum").font(.largeTitle.bold())
            Text("Bring different models into one conversation, then decide what each one sees.").foregroundStyle(.secondary)
            GroupBox("1 · Choose your connection") {
                VStack(alignment: .leading, spacing: 9) {
                    Text("Continue with ChatGPT for eligible plan usage, connect the official Claude tool, or save a separately billed API key in Keychain. Account eligibility and provider approval still apply.")
                    Button("Open Connections") { openSettings("Connections") }
                }.padding(8).frame(maxWidth: .infinity, alignment: .leading)
            }
            GroupBox("2 · Review instructions and privacy") {
                VStack(alignment: .leading, spacing: 9) {
                    Text("Set shared or individual instructions. Confirm each provider's account settings before enabling the no-training requirement. The app cannot change a provider's data policy.")
                    Button("Review Privacy") { openSettings("Instructions & Privacy") }
                }.padding(8).frame(maxWidth: .infinity, alignment: .leading)
            }
            GroupBox("3 · Start a conversation") {
                Text("Use @gpt or @claude to address a model. Choose Critique to review an answer, preview context before sending, and use channels to organize conversations. Linking GitHub and enabling automatic file saves are separate choices.").padding(8)
            }
            Text("Team hosting, billing, public distribution, and commercial provider approval require external setup. This preview runs locally.").font(.caption).foregroundStyle(.secondary)
            HStack { Spacer(); Button("Start using Model Forum", action: finish).keyboardShortcut(.defaultAction) }
        }.padding(30).frame(width: 660)
    }
}
