import SwiftUI
import AppKit
import ForumCore

struct CommercialSettingsView: View {
    @ObservedObject private var connection = TeamConnection.shared
    @State private var task: Task<Void, Never>?
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Team license and billing").font(.title2.bold())
            Text("The team server manages subscriptions. Provider API usage is billed separately by each model provider. This app has no embedded payment credentials.")
            if let team = connection.team {
                Text("Team: \(team.name) · \(team.role)")
                Button("Refresh license and billing setup") { run { try await connection.refreshLicense() } }
                if let license = connection.license {
                    Text(license.active ? "Active team license" : "No active team license")
                    Text("Server status: \(license.status)").font(.caption)
                    Text(license.licenseRequired ? "An active license is required to publish shared conversations. Reading and importing remain available." : "This server is running without a paid-license requirement.").font(.caption)
                    if license.status != "none" { Text("An existing subscription record must be managed in the portal. If it cannot be resumed there, ask the server operator to reconcile it before another purchase.").font(.caption) }
                    if !license.billingConfigured { Text("Checkout is unavailable: the server operator has not configured Stripe credentials, a price, an HTTPS return origin and a signed webhook endpoint.").font(.callout) }
                } else { Text("Refresh to check this server’s billing configuration. Checkout is disabled until configuration is confirmed.").font(.callout) }
                HStack {
                    Button("Open paid subscription checkout…") { openBilling("checkout") }
                        .disabled(!connection.isOwner || connection.license?.billingConfigured != true || connection.license?.status != "none")
                    Button("Manage subscription in Stripe…") { openBilling("portal") }
                        .disabled(!connection.isOwner || connection.license?.billingConfigured != true)
                }
                Text("Only team owners can open checkout or the customer portal. Review price, renewal terms and taxes on Stripe before confirming payment. Returning from checkout does not prove payment; refresh after the server processes Stripe’s signed event.").font(.caption).foregroundStyle(.secondary)
            } else { Text("Sign in and select a team in Team settings first.") }
            if let notice = connection.notice { Text(notice).textSelection(.enabled) }
            Spacer()
        }.padding(24).disabled(connection.busy)
            .onDisappear { task?.cancel() }
    }
    private func openBilling(_ resource: String) {
        run {
            let destination = try await connection.request("POST", resource, as: TeamBillingDestination.self)
            let url = try TeamEndpoint.billingURL(destination.url)
            guard NSWorkspace.shared.open(url) else { throw ForumError.message("Could not open the billing page.") }
        }
    }
    private func run(_ action: @escaping @MainActor () async throws -> Void) {
        guard !connection.busy else { return }
        connection.busy = true; connection.notice = nil
        task = Task { @MainActor in
            defer { connection.busy = false; task = nil }
            do { try await action() }
            catch is CancellationError { connection.notice = "Request canceled. Refresh status before retrying." }
            catch { connection.notice = error.localizedDescription }
        }
    }
}
