import SwiftUI
import AppKit

@main struct ModelForumApp: App {
    @StateObject private var store = AppStore()
    @AppStorage("ModelForum.onboardingCompleted") private var onboardingCompleted = false
    @State private var showOnboarding = false
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    var body: some Scene {
        WindowGroup("Model Forum") {
            WorkspaceView().environmentObject(store)
                .onAppear { appDelegate.store = store; showOnboarding = !onboardingCompleted }
                .sheet(isPresented: $showOnboarding) {
                    OnboardingView(openSettings: { section in
                        onboardingCompleted = true; showOnboarding = false; store.settingsSection = section
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { store.showSettings = true }
                    }, finish: { onboardingCompleted = true; showOnboarding = false })
                }
                .frame(minWidth: 980, minHeight: 680)
                .tint(Color(red: 0.18, green: 0.42, blue: 0.38))
                .sheet(isPresented: $store.showSettings) { SettingsView().environmentObject(store) }
        }
        .defaultSize(width: 1180, height: 820)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("New Conversation") { store.newConversation() }.keyboardShortcut("n").disabled(store.busy)
            }
            CommandGroup(replacing: .appSettings) {
                Button("Settings…") { store.showSettings = true }.keyboardShortcut(",").disabled(store.busy)
            }
        }
    }
}

@MainActor final class AppDelegate: NSObject, NSApplicationDelegate {
    weak var store: AppStore?
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApplication.shared.setActivationPolicy(.regular)
        NSApplication.shared.activate(ignoringOtherApps: true)
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        guard let store, store.hasActiveWork else { return .terminateNow }
        store.stopAll()
        Task { @MainActor in
            let deadline = Date().addingTimeInterval(5)
            while store.hasActiveWork && Date() < deadline { try? await Task.sleep(nanoseconds: 100_000_000) }
            sender.reply(toApplicationShouldTerminate: true)
        }
        return .terminateLater
    }
}
