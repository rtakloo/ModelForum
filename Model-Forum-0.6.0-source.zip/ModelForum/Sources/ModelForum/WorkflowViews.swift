import SwiftUI
import ForumCore

struct WorkflowListView: View {
    var definitions: [WorkflowDefinition]
    var busy: Bool
    var onRun: (WorkflowDefinition) -> Void
    var onEdit: (WorkflowDefinition) -> Void
    var onNew: () -> Void
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("Saved workflows").font(.headline); Spacer(); Button("New workflow", action: onNew).disabled(busy) }
            Text("Draft, critique, and revise the current conversation input in a bounded sequence. Completed steps retain their model and source context.")
                .font(.caption).foregroundStyle(.secondary)
            if definitions.isEmpty { Text("No saved workflows yet.").foregroundStyle(.secondary) }
            ForEach(definitions) { definition in
                HStack {
                    VStack(alignment: .leading) {
                        Text(definition.name).font(.headline)
                        Text("\(definition.draft.alias) → \(definition.critic.alias) → \(definition.reviser.alias) · up to \(definition.maximumSteps) steps")
                            .font(.caption).foregroundStyle(.secondary)
                        Text(definition.enforceOutputBudget ? "\(definition.perStepOutputTokens) tokens per step · \(definition.totalOutputTokenBudget) total output budget" : "Rounds only · provider plan limits apply; output total is not capped")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button("Edit") { onEdit(definition) }.disabled(busy)
                    Button("Run") { onRun(definition) }.disabled(busy)
                }.padding(10).background(.quaternary.opacity(0.3), in: RoundedRectangle(cornerRadius: 8))
            }
        }
    }
}

struct WorkflowEditorView: View {
    let participants: [Participant]
    let onSave: (WorkflowDefinition) -> Void
    let onCancel: () -> Void
    @State private var definition: WorkflowDefinition
    @State private var marker: String
    @State private var error: String?
    init(participants: [Participant], existing: WorkflowDefinition? = nil, onSave: @escaping (WorkflowDefinition) -> Void, onCancel: @escaping () -> Void) {
        self.participants = participants; self.onSave = onSave; self.onCancel = onCancel
        let first = participants.first ?? Participant(alias: "", provider: .openAI, model: "")
        let critic = participants.dropFirst().first ?? first
        let value = existing ?? WorkflowDefinition(draft: first, critic: critic, reviser: first)
        _definition = State(initialValue: value); _marker = State(initialValue: value.stopMarker ?? "")
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Draft → Critique → Revise").font(.title2.bold())
            Form {
                TextField("Workflow name", text: $definition.name)
                rolePicker("Draft", selection: $definition.draft)
                rolePicker("Critique", selection: $definition.critic)
                rolePicker("Revise", selection: $definition.reviser)
                Stepper("Critique/revision rounds: \(definition.rounds)", value: $definition.rounds, in: 1...5)
                TextField("Per-step output token cap", value: $definition.perStepOutputTokens, format: .number)
                Toggle("Enforce output-token budget (API routes only)", isOn: $definition.enforceOutputBudget)
                if definition.enforceOutputBudget {
                    TextField("Total output token budget", value: $definition.totalOutputTokenBudget, format: .number)
                } else {
                    Text("Rounds and the stop marker bound the number of requests. API per-step caps still apply, but a subscription route uses its provider plan limits and may produce more tokens. Total output is not capped.").font(.caption).foregroundStyle(.secondary)
                }
                TextField("Optional critic stop marker", text: $marker)
            }
            Text("One draft, then critique/revision rounds. When budget enforcement is on, each step reserves its full output cap from the total budget. The workflow stops on cancellation, failure, budget exhaustion, or an exact critic stop-marker answer. Model requests do not execute tools. Generated files follow this channel’s configured GitHub autosave setting.")
                .font(.caption).foregroundStyle(.secondary)
            if let error { Text(error).foregroundStyle(.red) }
            HStack { Spacer(); Button("Cancel", action: onCancel); Button("Save workflow") {
                do {
                    definition.stopMarker = marker.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : marker.trimmingCharacters(in: .whitespacesAndNewlines)
                    try definition.validate(); onSave(definition)
                } catch { self.error = error.localizedDescription }
            }.keyboardShortcut(.defaultAction).disabled(participants.isEmpty) }
        }.padding(24).frame(width: 640)
    }
    private func rolePicker(_ title: String, selection: Binding<Participant>) -> some View {
        VStack(alignment: .leading) {
            Picker(title, selection: Binding(get: { selection.wrappedValue.id }, set: { id in
                if let value = participants.first(where: { $0.id == id }) { selection.wrappedValue = value }
            })) {
                if !participants.contains(where: { $0.id == selection.wrappedValue.id }) {
                    Text("Saved: @\(selection.wrappedValue.alias)").tag(selection.wrappedValue.id)
                }
                ForEach(participants) { value in Text("@\(value.alias) · \(value.provider.title)").tag(value.id) }
            }
            TextField("\(title) model ID", text: selection.model)
        }
    }
}
