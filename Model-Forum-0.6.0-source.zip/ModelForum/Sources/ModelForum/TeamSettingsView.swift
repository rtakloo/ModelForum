import SwiftUI
import AppKit
import ForumCore

struct TeamSettingsView: View {
    let exportSelectedConversation: () throws -> Conversation
    let importSharedConversation: (Conversation) -> Void
    @ObservedObject private var connection = TeamConnection.shared
    @State private var email = ""
    @State private var password = ""
    @State private var joinToken = ""
    @State private var inviteEmail = ""
    @State private var inviteRole = "viewer"
    @State private var issuedToken = ""
    @State private var members: [TeamMember] = []
    @State private var invitations: [TeamInvitation] = []
    @State private var documents: [TeamDocumentSummary] = []
    @State private var audit: [TeamAuditEvent] = []
    @State private var documentID = ""
    @State private var pulled: TeamDocument?
    @State private var pending: TeamSharedConversation?
    @State private var confirmPublish = false
    @State private var task: Task<Void, Never>?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Team workspace").font(.title2.bold())
                Text("Connect to a separately operated Model Forum team server. Team passwords and sessions are separate from your model-provider API keys. This preview provides explicit sharing, not live collaborative editing.").font(.callout)
                TextField("Server origin", text: $connection.server).textFieldStyle(.roundedBorder).disabled(connection.identity != nil)
                if connection.identity == nil {
                    TextField("Team email", text: $email).textFieldStyle(.roundedBorder)
                    SecureField("Team password (12+ characters)", text: $password).textFieldStyle(.roundedBorder)
                    SecureField("Invitation token (only when joining)", text: $joinToken).textFieldStyle(.roundedBorder)
                    HStack {
                        Button("Sign in") { authenticate(join: false) }.disabled(email.isEmpty || password.isEmpty)
                        Button("Join with invitation") { authenticate(join: true) }.disabled(email.isEmpty || password.isEmpty || joinToken.isEmpty)
                        Button("Restore saved session") { run { try await connection.restore() } }
                    }
                    Text("First owner: bootstrap the server locally with its command-line setup. Invitations are copied and delivered by a team owner; this app sends no invitation emails.").font(.caption).foregroundStyle(.secondary)
                } else {
                    HStack {
                        Picker("Team", selection: $connection.selectedTeam) {
                            ForEach(connection.identity?.teams ?? []) { team in Text("\(team.name) · \(team.role)").tag(team.id) }
                        }
                        Button("Sign out") { run { try await connection.signOut() } }
                    }
                    sharing
                    if connection.isOwner { administration }
                }
                if let notice = connection.notice { Text(notice).font(.callout).textSelection(.enabled) }
            }.padding(24).disabled(connection.busy)
            if connection.busy {
                HStack { ProgressView().controlSize(.small); Button("Cancel request") { task?.cancel() } }.padding(.bottom)
            }
        }
        .onChange(of: connection.selectedTeam) { _, _ in resetTeamState() }
        .onDisappear { password = ""; joinToken = ""; issuedToken = ""; task?.cancel() }
        .sheet(isPresented: $confirmPublish) {
            VStack(alignment: .leading, spacing: 12) {
                Text("Publish this conversation?").font(.headline)
                Text("Every team member can read the visible text below. Check it for private information or pasted secrets. Provider keys, account labels, global instructions and exact request context are excluded.")
                ScrollView { Text(preview(pending)).font(.system(.body, design: .monospaced)).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading) }
                HStack {
                    Button("Cancel") { confirmPublish = false; pending = nil }
                    Spacer()
                    Button("Publish to team") { publish() }
                }
            }.padding(24).frame(width: 650, height: 500).disabled(connection.busy)
        }
    }
    private var sharing: some View {
        VStack(alignment: .leading, spacing: 10) {
            Divider()
            Text("Shared conversations").font(.headline)
            Text("Publish shares only the selected conversation’s visible messages and model names. Pull downloads one shared snapshot; Import makes a new local conversation. Conflicting revisions must be pulled before publishing again.").font(.caption)
            HStack {
                TextField("Shared conversation ID", text: $documentID).textFieldStyle(.roundedBorder)
                    .onChange(of: documentID) { _, _ in pulled = nil }
                Button("List") { run { documents = try await connection.request("GET", "documents", as: TeamDocuments.self).documents } }
                Button("Pull") { pull() }.disabled(documentID.isEmpty)
            }
            ForEach(documents) { document in
                Button("\(document.id) · revision \(document.revision)") { documentID = document.id; pulled = nil }.buttonStyle(.link)
            }
            if let pulled {
                Text("Downloaded revision \(pulled.revision): \(pulled.snapshot.title)").font(.caption)
                DisclosureGroup("Preview downloaded text") { ScrollView { Text(preview(pulled.snapshot)).textSelection(.enabled) }.frame(maxHeight: 200) }
                Button("Import as a new local conversation") {
                    do { importSharedConversation(try pulled.snapshot.localCopy()); connection.notice = "Imported a copy. The server conversation was not changed." }
                    catch { connection.notice = error.localizedDescription }
                }
            }
            Button("Preview selected local conversation for publishing…") {
                do {
                    _ = try TeamEndpoint.pathID(documentID)
                    pending = try TeamSharedConversation(exportSelectedConversation())
                    confirmPublish = true
                } catch { connection.notice = error.localizedDescription }
            }.disabled(!connection.isEditor || documentID.isEmpty)
            if !connection.isEditor { Text("Viewers may pull and import; publishing requires an editor or owner role.").font(.caption) }
        }
    }
    private var administration: some View {
        VStack(alignment: .leading, spacing: 10) {
            Divider()
            Text("Owner administration").font(.headline)
            HStack {
                TextField("Invite email", text: $inviteEmail).textFieldStyle(.roundedBorder)
                Picker("Role", selection: $inviteRole) { Text("Viewer").tag("viewer"); Text("Editor").tag("editor") }.frame(width: 130)
                Button("Create invitation") {
                    run {
                        let result = try await connection.request("POST", "invitations", body: TeamClient.body(["email": inviteEmail, "role": inviteRole]), as: TeamInviteToken.self)
                        issuedToken = result.token
                        connection.notice = "Invitation expires in 48 hours. Deliver the copied token privately; no email was sent."
                        try await refreshAdministration()
                    }
                }.disabled(inviteEmail.isEmpty)
            }
            if !issuedToken.isEmpty {
                HStack {
                    Text("New invitation token available (shown only this session)").font(.caption)
                    Button("Copy invitation token") { NSPasteboard.general.clearContents(); NSPasteboard.general.setString(issuedToken, forType: .string) }
                    Button("Hide token") { issuedToken = "" }
                }
            }
            Button("Refresh members and invitations") { run { try await refreshAdministration() } }
            ForEach(members) { member in
                HStack {
                    Text("\(member.email) · \(member.role)")
                    Spacer()
                    Menu("Change role") {
                        ForEach(["owner", "editor", "viewer"], id: \.self) { role in
                            Button(role.capitalized) { run {
                                _ = try await connection.request("PUT", "members/\(TeamEndpoint.pathID(member.id))", body: TeamClient.body(["role": role]), as: TeamOK.self)
                                try await refreshAdministration()
                            } }
                        }
                    }
                    Button("Revoke access", role: .destructive) { run {
                        _ = try await connection.request("DELETE", "members/\(TeamEndpoint.pathID(member.id))", as: TeamOK.self)
                        try await refreshAdministration()
                    } }
                }.font(.caption)
            }
            Text("Removing or changing a member invalidates their existing sessions. Removing access cannot erase copies they already downloaded. A team must retain an owner.").font(.caption).foregroundStyle(.secondary)
            ForEach(invitations) { invitation in
                HStack {
                    Text("Pending: \(invitation.email) · \(invitation.role)").font(.caption)
                    Button("Revoke invitation") { run {
                        _ = try await connection.request("DELETE", "invitations/\(TeamEndpoint.pathID(invitation.id))", as: TeamOK.self)
                        try await refreshAdministration()
                    } }
                }
            }
            DisclosureGroup("Recent audit metadata") {
                Button("Load last 100 events") { run { audit = try await connection.request("GET", "audit", as: TeamAudit.self).events } }
                ForEach(audit) { event in Text("\(Date(timeIntervalSince1970: event.created).formatted()) · \(event.action) · \(event.resource ?? "team")").font(.caption) }
            }
        }
    }
    private func authenticate(join: Bool) {
        let suppliedPassword = password, invitation = join ? joinToken : nil
        password = ""; joinToken = ""
        run { try await connection.authenticate(email: email, password: suppliedPassword, invitation: invitation) }
    }
    private func pull() {
        run {
            let id = try TeamEndpoint.pathID(documentID)
            let result = try await connection.request("GET", "documents/\(id)", as: TeamDocument.self)
            try result.snapshot.validate()
            pulled = result
        }
    }
    private func publish() {
        guard let pending else { return }
        confirmPublish = false
        run {
            let id = try TeamEndpoint.pathID(documentID)
            let value = try JSONSerialization.jsonObject(with: JSONEncoder().encode(pending))
            let result = try await connection.request("PUT", "documents/\(id)", body: TeamClient.body(["expectedRevision": pulled?.revision ?? 0, "snapshot": value]), as: TeamDocumentSummary.self)
            self.pending = nil
            // Pull separately after a successful publish to obtain a verified current revision for future edits.
            pulled = nil
            connection.notice = "Published revision \(result.revision). Pull before publishing another update."
        }
    }
    private func refreshAdministration() async throws {
        members = try await connection.request("GET", "members", as: TeamMembers.self).members
        invitations = try await connection.request("GET", "invitations", as: TeamInvitations.self).invitations
    }
    private func resetTeamState() {
        pulled = nil; pending = nil; members = []; invitations = []; documents = []; audit = []; issuedToken = ""; documentID = ""; connection.license = nil
    }
    private func preview(_ snapshot: TeamSharedConversation?) -> String {
        guard let snapshot else { return "" }
        return snapshot.title + "\n\n" + snapshot.messages.map { "[\($0.role) · \($0.author)]\n\($0.content)" }.joined(separator: "\n\n")
    }
    private func run(_ action: @escaping @MainActor () async throws -> Void) {
        guard !connection.busy else { return }
        connection.busy = true; connection.notice = nil
        task = Task { @MainActor in
            defer { connection.busy = false; task = nil }
            do { try await action() }
            catch is CancellationError { connection.notice = "Request canceled. A server-side change may already have completed; refresh before retrying." }
            catch { connection.notice = error.localizedDescription }
        }
    }
}
