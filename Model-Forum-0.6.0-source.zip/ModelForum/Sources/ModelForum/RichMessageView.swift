import AppKit
import SwiftUI
import WebKit

/// A local, display-only renderer. The source remains unchanged in conversation storage.
struct RichMessageView: View {
    let text: String
    static var rendererResourceURL: URL? {
        let codeBundle = Bundle(for: RendererBundleMarker.self)
        var roots = [Bundle.main.resourceURL, codeBundle.resourceURL, Bundle.main.bundleURL].compactMap { $0 }
        // SwiftPM's test runner keeps the resource bundle beside its .xctest bundle.
        for bundle in [Bundle.main, codeBundle] where bundle.bundleURL.pathExtension == "xctest" {
            roots.append(bundle.bundleURL.deletingLastPathComponent())
        }
        return rendererResourceURL(searchRoots: roots)
    }
    static func rendererResourceURL(searchRoots: [URL]) -> URL? {
        // Bundle.module traps when packaging omitted the bundle; an optional lookup preserves source fallback.
        for root in searchRoots where root.isFileURL {
            let candidate = root.appendingPathComponent("ModelForum_ModelForum.bundle", isDirectory: true)
            if let bundle = Bundle(url: candidate),
               let url = bundle.url(forResource: "index", withExtension: "html", subdirectory: "Renderer") {
                return url
            }
        }
        return nil
    }
    @State private var contentHeight: CGFloat = 32
    @State private var failure: String?

    var body: some View {
        Group {
            if let failure {
                VStack(alignment: .leading, spacing: 8) {
                    Label(failure + " Original source is shown below.", systemImage: "doc.text")
                        .font(.caption).foregroundStyle(.secondary)
                    Text(verbatim: text)
                        .font(.system(.body, design: .monospaced))
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            } else {
                MessageRendererWebView(text: text, height: $contentHeight, failure: $failure)
                    .frame(maxWidth: .infinity)
                    .frame(height: contentHeight)
                    .accessibilityLabel("Formatted message")
            }
        }
        .onChange(of: text) { _, _ in
            failure = nil
        }
        .transaction { $0.animation = nil }
    }
}

private final class RendererBundleMarker: NSObject {}

/// Kept separate from WebKit callbacks so protocol and sizing rules can be tested without a browser.
enum MessageRendererPolicy {
    static let maximumHeight: CGFloat = 10_000
    static let blockRemoteResources = #"[{"trigger":{"url-filter":"^https?://","url-filter-is-case-sensitive":false},"action":{"type":"block"}},{"trigger":{"url-filter":"^wss?://","url-filter-is-case-sensitive":false},"action":{"type":"block"}},{"trigger":{"url-filter":"^ftp://","url-filter-is-case-sensitive":false},"action":{"type":"block"}}]"#

    static func externalLink(_ url: URL) -> Bool {
        guard let parts = URLComponents(url: url, resolvingAgainstBaseURL: false),
              let scheme = parts.scheme?.lowercased(), ["https", "http"].contains(scheme),
              let host = parts.host, !host.isEmpty,
              parts.user == nil, parts.password == nil else { return false }
        return true
    }

    static func isRendererDocument(_ url: URL?, renderer: URL) -> Bool {
        guard let url, url.isFileURL, url.query == nil, url.fragment == nil else { return false }
        return url.standardizedFileURL == renderer.standardizedFileURL
    }

    static func height(_ value: Double) -> CGFloat? {
        guard value.isFinite, value > 0 else { return nil }
        return min(maximumHeight, max(24, CGFloat(value.rounded(.up))))
    }
}

/// CSS pixels reported by the trusted renderer; overscroll values are clamped to real content bounds.
struct MessageScrollMetrics: Equatable {
    let top: Double
    let maximumTop: Double
    init?(scrollTop: Double, scrollHeight: Double, clientHeight: Double) {
        guard scrollTop.isFinite, scrollHeight.isFinite, clientHeight.isFinite,
              scrollHeight >= 0, clientHeight > 0 else { return nil }
        maximumTop = max(0, scrollHeight - clientHeight)
        top = min(maximumTop, max(0, scrollTop))
    }
    func canScroll(nativeDeltaY: Double) -> Bool {
        // NSEvent already applies the user's natural-scroll preference: positive is up, negative down.
        if nativeDeltaY > 0 { return top > 1 }
        if nativeDeltaY < 0 { return maximumTop - top > 1 }
        return false
    }
}

enum MessageWheelRoute: Equatable { case renderer, conversation }
struct MessageWheelDispatch: Equatable {
    let toConversation: Bool
    let toRenderer: Bool
}

/// Route a single wheel event once. Only zero-delta termination events may finish both recipients.
struct MessageWheelSequence {
    private(set) var previousRoute: MessageWheelRoute?
    private var usedConversation = false
    private var usedRenderer = false

    mutating func reset() {
        previousRoute = nil; usedConversation = false; usedRenderer = false
    }

    mutating func dispatch(deltaX: Double, deltaY: Double, shift: Bool,
                           phase: NSEvent.Phase = [], momentumPhase: NSEvent.Phase = [],
                           metrics: MessageScrollMetrics?) -> MessageWheelDispatch {
        if phase.contains(.began) || phase.contains(.mayBegin) || momentumPhase.contains(.began) { reset() }
        let route: MessageWheelRoute
        if !deltaX.isFinite || !deltaY.isFinite || shift || abs(deltaX) > abs(deltaY) {
            route = .renderer
        } else if deltaY == 0 {
            route = previousRoute ?? ((metrics?.maximumTop ?? 0) <= 1 ? .conversation : .renderer)
        } else {
            route = metrics?.canScroll(nativeDeltaY: deltaY) == true ? .renderer : .conversation
        }
        let terminates = !phase.intersection([.ended, .cancelled]).isEmpty || !momentumPhase.intersection([.ended, .cancelled]).isEmpty
        let zeroDelta = deltaX == 0 && deltaY == 0
        let dispatch = MessageWheelDispatch(
            toConversation: route == .conversation || (zeroDelta && terminates && usedConversation),
            toRenderer: route == .renderer || (zeroDelta && terminates && usedRenderer)
        )
        usedConversation = usedConversation || dispatch.toConversation
        usedRenderer = usedRenderer || dispatch.toRenderer
        previousRoute = route
        if terminates { reset() }
        return dispatch
    }
}

@MainActor enum MessageScrollViewScope {
    static func topmostHit(in root: NSView, atSuperviewPoint point: NSPoint, belongsTo renderer: NSView) -> Bool {
        guard let hit = root.hitTest(point) else { return false }
        return hit === renderer || hit.isDescendant(of: renderer)
    }
    static func conversationScrollView(above renderer: NSView) -> NSScrollView? {
        var ancestor = renderer.superview
        while let view = ancestor {
            if let scroll = view as? NSScrollView { return scroll }
            ancestor = view.superview
        }
        return nil
    }
}

/// Share WebKit infrastructure across cards, but never a document, content controller, or source text.
@MainActor private enum MessageRendererRuntime {
    static let dataStore = WKWebsiteDataStore.nonPersistent()
    private static var ruleList: WKContentRuleList?
    private static var awaitingRule: [(WKContentRuleList?) -> Void] = []

    static func blocker(_ completion: @escaping (WKContentRuleList?) -> Void) {
        if let ruleList { completion(ruleList); return }
        awaitingRule.append(completion)
        guard awaitingRule.count == 1 else { return }
        WKContentRuleListStore.default().compileContentRuleList(
            forIdentifier: "ModelForumOfflineRenderer-v1",
            encodedContentRuleList: MessageRendererPolicy.blockRemoteResources
        ) { result, _ in
            DispatchQueue.main.async {
                ruleList = result
                let callbacks = awaitingRule
                awaitingRule.removeAll()
                callbacks.forEach { $0(result) }
            }
        }
    }
}

private struct MessageRendererWebView: NSViewRepresentable {
    let text: String
    @Binding var height: CGFloat
    @Binding var failure: String?

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeNSView(context: Context) -> NonDroppingWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = MessageRendererRuntime.dataStore
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
        configuration.defaultWebpagePreferences.allowsContentJavaScript = true
        configuration.userContentController.add(context.coordinator, name: "renderer")
        let webView = NonDroppingWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = false
        webView.allowsLinkPreview = false
        webView.isInspectable = false
        webView.underPageBackgroundColor = .clear
        webView.setContentHuggingPriority(.defaultLow, for: .horizontal)
        webView.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        context.coordinator.start(webView)
        return webView
    }

    func updateNSView(_ webView: NonDroppingWebView, context: Context) {
        context.coordinator.parent = self
        context.coordinator.update(text)
    }

    static func dismantleNSView(_ webView: NonDroppingWebView, coordinator: Coordinator) {
        coordinator.stop()
        webView.stopLoading()
        webView.configuration.userContentController.removeScriptMessageHandler(forName: "renderer")
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
    }

    @MainActor final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        var parent: MessageRendererWebView
        private weak var webView: WKWebView?
        private var rendererURL: URL?
        private var initialNavigation: WKNavigation?
        private var permitsInitialNavigation = false
        private var ready = false
        private var rendering = false
        private var stopped = false
        private var desiredText: String
        private var renderedText: String?
        private var revision = UUID()
        private var timeout: DispatchWorkItem?
        private var wheelMonitor: Any?
        private var scrollMetrics: MessageScrollMetrics?
        private var wheelSequence = MessageWheelSequence()
        private var forwardingWheel = false

        init(parent: MessageRendererWebView) {
            self.parent = parent
            desiredText = parent.text
        }

        func start(_ webView: WKWebView) {
            self.webView = webView
            installWheelMonitor()
            guard let url = RichMessageView.rendererResourceURL,
                  url.isFileURL else {
                fail("The offline formatting resources are unavailable.")
                return
            }
            rendererURL = url
            armTimeout()
            // Install the network blocker before loading even the trusted bundled document.
            MessageRendererRuntime.blocker { [weak self, weak webView] ruleList in
                guard let self, let webView, !self.stopped else { return }
                guard let ruleList else {
                    self.fail("Offline formatting could not be initialized safely.")
                    return
                }
                webView.configuration.userContentController.add(ruleList)
                self.permitsInitialNavigation = true
                self.initialNavigation = webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
                if self.initialNavigation == nil { self.fail("The offline formatter could not be opened.") }
            }
        }

        func update(_ text: String) {
            guard !stopped, desiredText != text else { return }
            desiredText = text
            scrollMetrics = nil
            wheelSequence.reset()
            revision = UUID()
            armTimeout()
            renderLatest()
        }

        private func renderLatest() {
            guard !stopped, ready, !rendering, renderedText != desiredText, let webView else { return }
            rendering = true
            let text = desiredText
            let requestedRevision = revision
            // Arguments are encoded by WebKit. Model output is never interpolated into JavaScript.
            webView.callAsyncJavaScript("return await window.renderMessage(text);", arguments: ["text": text], in: nil, in: .page) { [weak self] result in
                guard let self, !self.stopped else { return }
                self.rendering = false
                // A reply can change while the renderer is loading or while a prior render is in flight.
                guard requestedRevision == self.revision else {
                    // The stale call still changed the DOM. Force a refresh even if the desired text
                    // has returned to the last completed value (for example A → B → A).
                    self.renderedText = nil
                    self.renderLatest()
                    return
                }
                switch result {
                case .success:
                    self.renderedText = text
                    self.timeout?.cancel()
                case .failure:
                    self.fail("Rich formatting failed.")
                }
            }
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard !stopped, message.name == "renderer", message.webView === webView,
                  message.frameInfo.isMainFrame, let rendererURL,
                  MessageRendererPolicy.isRendererDocument(message.frameInfo.request.url, renderer: rendererURL),
                  let body = message.body as? [String: Any], let type = body["type"] as? String else { return }
            switch type {
            case "ready":
                guard !ready else { return }
                ready = true
                renderLatest()
            case "scrollState":
                guard ready, let top = body["scrollTop"] as? NSNumber,
                      let total = body["scrollHeight"] as? NSNumber,
                      let visible = body["clientHeight"] as? NSNumber else { return }
                scrollMetrics = MessageScrollMetrics(scrollTop: top.doubleValue, scrollHeight: total.doubleValue, clientHeight: visible.doubleValue)
            case "height":
                guard ready, let number = body["height"] as? NSNumber,
                      let height = MessageRendererPolicy.height(number.doubleValue) else { return }
                DispatchQueue.main.async { [weak self] in
                    guard let self, !self.stopped, abs(self.parent.height - height) >= 0.5 else { return }
                    self.parent.height = height
                }
            default: break
            }
        }

        private func installWheelMonitor() {
            guard wheelMonitor == nil else { return }
            // A local monitor sees events before WKContentView's handling. No global monitoring or
            // accessibility permission is used, and clicks/selection/keyboard events are untouched.
            wheelMonitor = NSEvent.addLocalMonitorForEvents(matching: .scrollWheel) { [weak self] event in
                guard let self, !self.stopped, !self.forwardingWheel,
                      let webView = self.webView, let window = webView.window,
                      event.window === window, let root = window.contentView,
                      let conversation = MessageScrollViewScope.conversationScrollView(above: webView) else { return event }
                // hitTest expects coordinates in the receiver's superview, not the receiver itself.
                let point = root.superview?.convert(event.locationInWindow, from: nil) ?? event.locationInWindow
                guard MessageScrollViewScope.topmostHit(in: root, atSuperviewPoint: point, belongsTo: webView) else { return event }
                let dispatch = self.wheelSequence.dispatch(
                    deltaX: Double(event.scrollingDeltaX), deltaY: Double(event.scrollingDeltaY),
                    shift: event.modifierFlags.contains(.shift), phase: event.phase,
                    momentumPhase: event.momentumPhase, metrics: self.scrollMetrics
                )
                if dispatch.toConversation {
                    self.forwardingWheel = true
                    // Direct dispatch preserves precision, natural direction and momentum phases.
                    // It does not repost the event through NSApplication's monitor chain.
                    conversation.scrollWheel(with: event)
                    self.forwardingWheel = false
                }
                return dispatch.toRenderer ? event : nil
            }
        }

        private func removeWheelMonitor() {
            if let wheelMonitor { NSEvent.removeMonitor(wheelMonitor) }
            wheelMonitor = nil
            wheelSequence.reset()
        }

        private func armTimeout() {
            timeout?.cancel()
            let expectedRevision = revision
            let item = DispatchWorkItem { [weak self] in
                guard let self, !self.stopped, self.revision == expectedRevision else { return }
                self.fail("The offline formatter did not respond.")
            }
            timeout = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 15, execute: item)
        }

        private func fail(_ message: String) {
            guard !stopped else { return }
            stopped = true
            removeWheelMonitor()
            timeout?.cancel()
            webView?.stopLoading()
            DispatchQueue.main.async { [weak self] in
                self?.parent.failure = message
            }
        }

        func stop() {
            stopped = true
            removeWheelMonitor()
            timeout?.cancel()
            timeout = nil
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard !stopped, let rendererURL else { decisionHandler(.cancel); return }
            let url = navigationAction.request.url
            if permitsInitialNavigation, navigationAction.navigationType == .other,
               navigationAction.targetFrame?.isMainFrame == true,
               MessageRendererPolicy.isRendererDocument(url, renderer: rendererURL) {
                permitsInitialNavigation = false
                decisionHandler(.allow)
                return
            }
            // No model-controlled navigation runs inside the renderer, including file URLs and popups.
            // Opening a normal web link requires a deliberate user click in the trusted main document.
            if navigationAction.navigationType == .linkActivated, navigationAction.sourceFrame.isMainFrame,
               MessageRendererPolicy.isRendererDocument(navigationAction.sourceFrame.request.url, renderer: rendererURL),
               let url, MessageRendererPolicy.externalLink(url) {
                NSWorkspace.shared.open(url)
            }
            decisionHandler(.cancel)
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
            guard !stopped, navigationResponse.isForMainFrame, navigationResponse.canShowMIMEType,
                  let rendererURL, MessageRendererPolicy.isRendererDocument(navigationResponse.response.url, renderer: rendererURL) else {
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            if navigation === initialNavigation { fail("The offline formatter could not finish loading.") }
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            if navigation === initialNavigation { fail("The offline formatter could not load.") }
        }

        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            fail("The offline formatter stopped.")
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? { nil }

        func webView(_ webView: WKWebView, runOpenPanelWith parameters: WKOpenPanelParameters, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping ([URL]?) -> Void) { completionHandler(nil) }

        func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) { completionHandler() }

        func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) { completionHandler(false) }

        func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (String?) -> Void) { completionHandler(nil) }
    }
}

/// WebKit's normal file/link dropping behavior must not replace a conversation message.
private final class NonDroppingWebView: WKWebView {
    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation { [] }
    override func draggingUpdated(_ sender: NSDraggingInfo) -> NSDragOperation { [] }
    override func prepareForDragOperation(_ sender: NSDraggingInfo) -> Bool { false }
    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool { false }
}
