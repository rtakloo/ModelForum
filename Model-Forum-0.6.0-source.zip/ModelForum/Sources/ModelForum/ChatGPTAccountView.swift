import SwiftUI
import ForumCore

struct ChatGPTAccountView: View {
    @EnvironmentObject private var store: AppStore
    @ObservedObject private var connection = ChatGPTConnection.shared
    @State private var localError: String?
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Picker("OpenAI connection", selection: Binding(get: { connection.useForOpenAI }, set: { enabled in
                change { connection.setUseForOpenAI(enabled) }
            })) {
                Text("API key · API billing").tag(false)
                Text("ChatGPT account · plan usage").tag(true)
            }.pickerStyle(.segmented).disabled(connection.busy)
            if connection.useForOpenAI {
                Picker("ChatGPT account", selection: Binding(get: { connection.activeProfileID }, set: { id in change { connection.selectProfile(id) } })) {
                    Text("Choose a saved account").tag(nil as UUID?)
                    ForEach(connection.profiles) { profile in Text(profile.label).tag(profile.id as UUID?) }
                }.disabled(connection.busy)
                if let profile = connection.activeProfile {
                    if let identity = profile.identity {
                        LabeledContent("Account ID", value: identity.subject)
                        LabeledContent("Email", value: identity.email ?? "Not supplied")
                        Text(identity.emailVerified ? "Identity and email verified by OpenAI." : "Identity verified by OpenAI. Email is an account claim; email ownership was not confirmed.")
                            .foregroundStyle(.secondary)
                    } else { Text("Registration saved; identity has not been verified yet.").foregroundStyle(.secondary) }
                    Text(profile.connected ? (profile.permitsInference ? "Connected · ChatGPT plan usage granted" : "Connected · plan usage not granted") : "Signed out").foregroundStyle(.secondary)
                }
                HStack {
                    Button("Continue with ChatGPT") {
                        change { connection.signIn(profileID: connection.activeProfileID, requestConsent: connection.activeProfile?.connected == true && connection.activeProfile?.permitsInference == false, beforeCommit: authorizeCommit) }
                    }.disabled(connection.busy)
                    Button("Add account") { change { connection.signIn(beforeCommit: authorizeCommit) } }.disabled(connection.busy)
                    if connection.activeProfile?.connected == true {
                        Button("Sign out") { change { connection.signOut() } }.disabled(connection.busy)
                    }
                    if connection.busy { ProgressView().controlSize(.small); Button("Cancel") { connection.cancelSignIn() } }
                }
                Text("Uses official browser sign-in. Passwords stay with OpenAI; this app stores its own OAuth session in macOS Keychain. It never imports Codex or ChatGPT browser credentials.").foregroundStyle(.secondary)
                Text("ChatGPT plan and app limits apply. This preview route cannot enforce the API output-token cap. Local limits stop responses above 200 KB text or 4 MB stream data; already-generated tokens can still count toward plan usage or credits.").foregroundStyle(.secondary)
                HStack {
                    Link("ChatGPT usage and app access", destination: URL(string: "https://chatgpt.com/settings/usage")!)
                    Link("Official connection guide", destination: URL(string: "https://developers.openai.com/siwc/token-sharing-open-source")!)
                }
                Text("Local preview connection. Commercial distribution requires OpenAI approval; account and workspace eligibility vary.").foregroundStyle(.secondary)
                if let status = connection.status { Text(status).foregroundStyle(connection.failed ? Color.red : Color.secondary) }
            }
            if let localError { Text(localError).foregroundStyle(.red) }
        }.font(.caption)
    }
    private func change(_ action: () -> Void) {
        guard store.credentialsWillChange(.openAI) else { localError = store.error ?? "Could not save the privacy reset. Resolve the workspace error first."; return }
        localError = nil; action()
    }
    private func authorizeCommit() -> Bool { !store.busy && store.credentialsWillChange(.openAI) }
}
