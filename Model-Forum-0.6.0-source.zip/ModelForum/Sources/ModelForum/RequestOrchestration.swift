import SwiftUI
import ForumCore

extension AppStore {
    var usesChatGPT: Bool { UserDefaults.standard.bool(forKey: "ChatGPT.useForOpenAI") }
    func performTextRequest(_ participant: Participant, transcript: String, tokenLimit: Int, sessionID: UUID) async throws -> ModelReply {
        try Task.checkCancellation()
        try AgentPolicy.validatePrivacy(provider: participant.provider, requireNoTraining: workspace.requireNoTraining, confirmations: workspace.privacyConfirmations)
        guard let _ = storage else { throw ForumError.message("Local storage is unavailable.") }
        let chatGPT = participant.provider == .openAI && usesChatGPT
        var billing: UsageBillingMode = participant.provider.needsKey ? .api : .localOrUnknown
        var key: String?
        if textRequestOverride == nil {
            if chatGPT {
                guard !ChatGPTConnection.shared.busy else { throw ForumError.message("Finish ChatGPT sign-in before sending.") }
                guard ChatGPTConnection.shared.activeProfile?.permitsInference == true else { throw ForumError.message("Continue with ChatGPT and grant plan usage before sending.") }
                billing = .subscription
            } else if participant.provider == .claudeCode {
                let status = try await ClaudeAccountConnection.shared.check(store: self)
                guard status.loggedIn else { throw ForumError.message("Sign in through the official Claude tool first.") }
                billing = status.authMethod == "claude.ai" ? .subscription : .localOrUnknown
            } else if participant.provider.needsKey {
                guard let saved = try KeychainStore.read(participant.provider), !saved.isEmpty else { throw ForumError.message("Save your \(participant.provider.title) API key in Connections first.") }
                key = saved
            }
        } else if chatGPT { billing = .subscription }
        // The official tool may have detected a new account above; confirm privacy after that check.
        try AgentPolicy.validatePrivacy(provider: participant.provider, requireNoTraining: workspace.requireNoTraining, confirmations: workspace.privacyConfirmations)
        let oldLedger = workspace.usageLedger
        let reservation = try workspace.usageLedger.reserve(participant: participant, transcript: transcript, maxOutputTokens: tokenLimit,
            sessionID: sessionID, billingMode: billing, policy: workspace.spendingPolicy)
        guard persist() else { workspace.usageLedger = oldLedger; throw ForumError.message("Could not save the usage reservation; no request was started.") }
        liveReply = ""; liveAlias = "@" + participant.alias
        let onDelta: @Sendable (String) async -> Void = { [weak self] delta in
            guard let store = self else { return }
            await MainActor.run {
                if store.liveReply.utf8.count < 256 * 1024 { store.liveReply += String(delta.prefix(8192)) }
            }
        }
        do {
            let reply: ModelReply
            if let override = textRequestOverride { reply = try await override(participant, transcript, tokenLimit) }
            else if chatGPT { reply = try await ChatGPTConnection.shared.reply(model: participant.model, transcript: transcript, onText: onDelta) }
            else if participant.provider == .claudeCode { reply = try await LocalTools.claudeReply(model: participant.model, transcript: transcript, maxOutputTokens: tokenLimit) }
            else { reply = try await ProviderClient().reply(participant: participant, transcript: transcript, apiKey: key, maxOutputTokens: tokenLimit, onDelta: onDelta) }
            workspace.usageLedger.settle(id: reservation.id, reply: reply)
            guard persist() else { throw ForumError.message("The provider completed, but its usage record could not be saved. Resolve storage before another request.") }
            return reply
        } catch {
            workspace.usageLedger.markUncertain(id: reservation.id); _ = persist()
            throw error
        }
    }
    func saveSpendingPolicy(_ policy: SpendingPolicy) {
        guard !busy else { return }
        do { try policy.validate(); let old = workspace.spendingPolicy; workspace.spendingPolicy = policy; if !persist() { workspace.spendingPolicy = old } }
        catch { self.error = error.localizedDescription }
    }
    @discardableResult func saveWorkflow(_ workflow: WorkflowDefinition) -> Bool {
        guard !busy else { return false }
        do {
            try workflow.validate(); let old = workspace.workflows
            if let i = workspace.workflows.firstIndex(where: { $0.id == workflow.id }) { workspace.workflows[i] = workflow }
            else { workspace.workflows.append(workflow) }
            guard persist() else { workspace.workflows = old; return false }; return true
        } catch { self.error = error.localizedDescription; return false }
    }
    func runWorkflow(_ definition: WorkflowDefinition) {
        guard !busy else { return }
        do {
            try definition.validate()
            guard let conversation, storage != nil else { throw ForumError.message("Select a conversation before running a workflow.") }
            guard conversation.channelID == nil || activeChannels.contains(where: { $0.id == conversation.channelID }) else { throw ForumError.message("Restore this channel first.") }
            let participants = [definition.draft, definition.critic, definition.reviser]
            if definition.enforceOutputBudget && usesChatGPT && participants.contains(where: { $0.provider == .openAI }) {
                throw ForumError.message("ChatGPT plan requests do not support output-token caps. Edit this workflow to turn off output-budget enforcement and use a fixed number of rounds, or explicitly choose the API connection.")
            }
            for p in participants { try AgentPolicy.validatePrivacy(provider: p.provider, requireNoTraining: workspace.requireNoTraining, confirmations: workspace.privacyConfirmations) }
            let question = composer.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !question.isEmpty else { throw ForumError.message("Write the workflow's task in the message box first.") }
            let context: [ChatMessage]
            if contextScope == .selected {
                guard let answer = selectedAnswer else { throw ForumError.message("Choose an answer before using selected-answer context.") }
                context = [answer]
            } else { context = conversation.messages }
            let input = try ConversationPolicy.transcript(messages: context, prompt: question, critique: selectedAnswer)
            let userMessage = ChatMessage(role: "user", author: "You", content: question)
            append(userMessage, to: conversation.id)
            guard persist() else { return }
            let contextIDs = context.map(\.id) + [userMessage.id]
            let channel = workspace.channels.first { $0.id == conversation.channelID }
            composer = ""; critiqueID = nil; contextScope = .conversation; busy = true; error = nil
            runningTask = Task {
                defer { busy = false; activity = ""; liveReply = ""; liveAlias = ""; runningTask = nil; persist() }
                do {
                    let run = try await WorkflowEngine.run(definition: definition, input: input, contextMessageIDs: contextIDs, request: { [weak self] request in
                        guard let self else { throw CancellationError() }
                        return try await self.requestWorkflowStep(request, sessionID: conversation.id)
                    }, onProgress: { [weak self] step in
                        guard let self else { throw CancellationError() }
                        try await self.saveWorkflowStep(step, conversationID: conversation.id, channel: channel)
                    })
                    workspace.workflowRuns.append(run)
                    append(ChatMessage(role: "notice", author: "Workflow", content: "\(definition.name): \(run.steps.count) steps; stopped: \(run.stopReason.rawValue)."), to: conversation.id)
                } catch {
                    let message = Task.isCancelled || error is CancellationError ? "Workflow stopped. Completed steps were kept; already-started requests may still be billed." : error.localizedDescription
                    self.error = message
                    append(ChatMessage(role: "notice", author: "Workflow", content: message), to: conversation.id)
                }
            }
        } catch { self.error = error.localizedDescription }
    }
    private func requestWorkflowStep(_ request: WorkflowRequest, sessionID: UUID) async throws -> ModelReply {
        activity = "Workflow \(request.stepIndex + 1): \(request.role.rawValue) by @\(request.participant.alias)…"
        let transcript = try AgentPolicy.compose(transcript: request.transcript, global: workspace.globalInstructions, individual: workspace.agentInstructions[request.participant.alias] ?? "")
        return try await performTextRequest(request.participant, transcript: transcript, tokenLimit: request.maxOutputTokens, sessionID: sessionID)
    }
    private func saveWorkflowStep(_ step: WorkflowStepResult, conversationID: UUID, channel: Channel?) throws {
        let transcript = try AgentPolicy.compose(transcript: step.transcript, global: workspace.globalInstructions, individual: workspace.agentInstructions[step.participant.alias] ?? "")
        let message = ChatMessage(id: step.id, role: "assistant", author: "@\(step.participant.alias) · \(step.role.rawValue)", content: step.text, model: step.model, inputTokens: step.inputTokens, outputTokens: step.outputTokens, contextMessageIDs: step.contextMessageIDs + step.previousStepIDs, provider: step.participant.provider, requestContext: transcript)
        append(message, to: conversationID)
        guard persist() else { throw ForumError.message("The completed workflow step could not be saved. No next request was started.") }
        try saveArtifacts(ArtifactFiles.extract(from: step.text), conversationID: conversationID, messageID: message.id, channel: channel)
    }
}

struct WorkflowSettingsView: View {
    @EnvironmentObject var store: AppStore
    @State private var editing: WorkflowDefinition?
    @State private var showingEditor = false
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("Model workflows").font(.title2.bold())
                Text("Write a task in the conversation, then run a saved workflow. Each completed answer is saved. Generated files follow the channel's automatic-save settings.").font(.caption)
                WorkflowListView(definitions: store.workspace.workflows, busy: store.busy, onRun: { store.runWorkflow($0); if store.busy { store.showSettings = false } }, onEdit: { editing = $0; showingEditor = true }, onNew: { editing = nil; showingEditor = true })
                if let error = store.error { Text(error).foregroundStyle(.red).font(.caption) }
            }.padding(26)
        }.frame(width: 650, height: 720)
        .sheet(isPresented: $showingEditor) {
            WorkflowEditorView(participants: store.workspace.participants, existing: editing, onSave: { if store.saveWorkflow($0) { showingEditor = false } }, onCancel: { showingEditor = false })
        }
    }
}

extension AppStore {
    func githubConnectionDidChange() {
        let revision = GitHubAppConnection.revision
        guard workspace.githubConnectionStamp != revision else { return }
        syncTask?.cancel()
        for i in workspace.channels.indices { workspace.channels[i].autoSave = false }
        workspace.githubConnectionStamp = revision
        if persist() { dataNotice = "GitHub connection changed. Automatic uploads are paused; review channel repositories and enable them again." }
    }
}
