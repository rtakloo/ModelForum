import SwiftUI
import AppKit
import ForumCore

@MainActor final class ClaudeAccountConnection: ObservableObject {
    static let shared = ClaudeAccountConnection()
    @Published private(set) var status: ClaudeAccountStatus?
    @Published var checking = false
    @Published var notice: String?
    private let defaults = UserDefaults.standard
    func check(store: AppStore) async throws -> ClaudeAccountStatus {
        let value = try await ClaudeAccountTools.status()
        let prior = defaults.string(forKey: "ClaudeAccount.identity")
        if prior != value.identityKey {
            guard store.credentialsWillChange(.claudeCode) else { throw ForumError.message("Could not record the changed Claude account. Resolve the workspace save error first.") }
            defaults.set(value.identityKey, forKey: "ClaudeAccount.identity")
        }
        status = value
        return value
    }
    func beginLogin(store: AppStore) throws {
        let executable = try ClaudeAccountTools.executable()
        guard store.credentialsWillChange(.claudeCode) else { throw ForumError.message("Could not save the account reset.") }
        status = nil
        // A private script launches the official interactive login; it contains no credential.
        func quote(_ s: String) -> String { "'" + s.replacingOccurrences(of: "'", with: "'\\''") + "'" }
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("ModelForum-login-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        let script = folder.appendingPathComponent("Connect-Claude.command")
        let text = "#!/bin/sh\nexec /usr/bin/env -i HOME=" + quote(FileManager.default.homeDirectoryForCurrentUser.path) + " PATH=/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin LANG=en_US.UTF-8 " + quote(executable.path) + " auth login\n"
        try Data(text.utf8).write(to: script, options: .withoutOverwriting)
        try FileManager.default.setAttributes([.posixPermissions: 0o700], ofItemAtPath: script.path)
        NSWorkspace.shared.open([script], withApplicationAt: URL(fileURLWithPath: "/System/Applications/Utilities/Terminal.app"), configuration: NSWorkspace.OpenConfiguration()) { _, error in
            Task { @MainActor in self.notice = error == nil ? "Complete sign-in in the official tool, then click Check account. Review privacy settings before sending." : "Could not open Terminal. Run claude auth login there, then check the account." }
        }
    }
}

struct ClaudeAccountView: View {
    @EnvironmentObject var store: AppStore
    @ObservedObject private var connection = ClaudeAccountConnection.shared
    @State private var confirmLogout = false
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Connect through the official Claude tool").font(.headline)
            Text(connection.status?.summary ?? "Account has not been checked.").textSelection(.enabled)
            if let plan = connection.status?.subscriptionType { Text("Tool-reported plan: \(plan)") }
            Text("Identity is reported by your installed tool. Account ID may be unavailable. This connection follows that tool's account and plan limits.").foregroundStyle(.secondary)
            HStack {
                Button("Sign in with Claude…") { do { try connection.beginLogin(store: store) } catch { connection.notice = error.localizedDescription } }
                Button(connection.checking ? "Checking…" : "Check account") {
                    connection.checking = true
                    Task { defer { connection.checking = false }; do { _ = try await connection.check(store: store); connection.notice = "Account status checked. Review its privacy settings before sending." } catch { connection.notice = error.localizedDescription } }
                }.disabled(connection.checking)
                Button("Sign out…") { confirmLogout = true }
            }
            if let notice = connection.notice { Text(notice).foregroundStyle(.secondary) }
            Link("Install the official Claude tool", destination: URL(string: "https://code.claude.com/docs/en/quickstart")!)
        }.font(.caption).confirmationDialog("Sign out of the Claude account used by the installed tool? Other apps using that tool will also be signed out.", isPresented: $confirmLogout) {
            Button("Sign out", role: .destructive) {
                guard store.credentialsWillChange(.claudeCode) else { return }
                Task { do { try await ClaudeAccountTools.logout(); _ = try await connection.check(store: store) } catch { connection.notice = error.localizedDescription } }
            }
        }
    }
}
