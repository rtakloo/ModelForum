import SwiftUI
import ForumCore

struct SettingsView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        HStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Settings").font(.title2.bold()).padding()
                ForEach(["Connections", "Instructions & Privacy", "GitHub", "Workflows", "Usage", "Team", "Billing", "Data", "PDF", "About & updates"], id: \.self) { section in
                    Button { store.settingsSection = section } label: {
                        Text(section).frame(maxWidth: .infinity, alignment: .leading).padding(9)
                            .background(store.settingsSection == section ? Color.accentColor.opacity(0.12) : Color.clear).cornerRadius(7)
                    }.buttonStyle(.plain)
                }
                Spacer()
                Button("Done") { dismiss() }.keyboardShortcut(.cancelAction).padding()
            }.padding(10).frame(width: 185)
            Divider()
            settingsContent.frame(width: 670, height: 750)
        }.frame(width: 875, height: 770)
    }
    @ViewBuilder private var settingsContent: some View {
        switch store.settingsSection {
        case "Instructions & Privacy": PreferencesView()
        case "GitHub": GitHubSettingsView()
        case "Workflows": WorkflowSettingsView()
        case "Usage": UsageSettingsView(policy: store.workspace.spendingPolicy, ledger: store.workspace.usageLedger, onSave: store.saveSpendingPolicy).disabled(store.busy)
        case "Team": TeamSettingsView(exportSelectedConversation: {
            guard let conversation = store.conversation else { throw ForumError.message("Select a conversation first.") }
            return conversation
        }, importSharedConversation: store.importTeamConversation)
        case "Billing": CommercialSettingsView()
        case "Data": DataSettingsView()
        case "About & updates": ReleaseSettingsView()
        case "PDF": PDFSettingsView()
        default: ConnectionsView()
        }
    }
}

struct PDFSettingsView: View {
    @State private var testing = false
    @State private var result: String?
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("LaTeX to PDF").font(.title2.bold())
            Label(LaTeXCompiler.status, systemImage: LaTeXCompiler.isAvailable ? "checkmark.circle" : "info.circle")
            Text("Compile PDF on a saved .tex file runs two local passes, saves a PDF in its conversation, and applies channel file autosave. MacTeX or BasicTeX must be installed.")
            Text("Only the selected source is supplied. External assets, bibliography tools and downloaded packages are unsupported. The compiler must successfully start its restrictive sandbox; there is no unsandboxed fallback.").font(.caption)
            Button(testing ? "Testing…" : "Test PDF compiler on this Mac") {
                testing = true; result = nil
                Task {
                    defer { testing = false }
                    do {
                        let source = "\\documentclass{article}\n\\begin{document}Model Forum compiler check: $a^2+b^2=c^2$.\\end{document}"
                        let pdf = try await LaTeXCompiler().compile(source: Data(source.utf8), filename: "check.tex")
                        result = "Compiler smoke test succeeded (\(pdf.data.count) bytes). This checks a benign document, not every containment boundary."
                    } catch { result = error.localizedDescription }
                }
            }.disabled(testing)
            if let result { Text(result).font(.caption).textSelection(.enabled) }
            Link("MacTeX and BasicTeX", destination: URL(string: "https://www.tug.org/mactex/")!)
            Spacer()
        }.padding(26)
    }
}

struct DeletedChannelsView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var deleting: Channel?
    @State private var confirmDelete = false
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Text("Recently deleted channels").font(.title2.bold())
                Spacer()
                Button("Done") { dismiss() }.keyboardShortcut(.cancelAction)
            }
            Text("Channels stay recoverable until you restore them. Their conversations and local files are kept. Existing GitHub files are unchanged. Restored channels have automatic uploads turned off.").font(.callout).foregroundStyle(.secondary)
            if let error = store.error { Text(error).foregroundStyle(.red).font(.caption).textSelection(.enabled) }
            if store.deletedChannels.isEmpty {
                ContentUnavailableView("No deleted channels", systemImage: "trash", description: Text("Deleted channels will appear here."))
            } else {
                List(store.deletedChannels) { channel in
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text(channel.name).font(.headline)
                            Text("\(store.workspace.conversations.filter { $0.channelID == channel.id }.count) conversations").font(.caption).foregroundStyle(.secondary)
                            if let date = channel.deletedAt { Text(date, style: .date).font(.caption2).foregroundStyle(.secondary) }
                        }
                        Spacer()
                        Button("Restore") { store.restoreChannel(channel.id) }.disabled(store.busy)
                        Button("Delete permanently…", role: .destructive) { deleting = channel; confirmDelete = true }.disabled(store.hasActiveWork)
                    }.padding(.vertical, 7)
                }
            }
        }.padding(24).frame(width: 680, height: 460)
        .confirmationDialog("Permanently delete this channel and its local conversations/files? Existing backups, team copies and GitHub files remain.", isPresented: $confirmDelete) {
            Button("Delete permanently", role: .destructive) { if let deleting { store.permanentlyDeleteChannels([deleting.id]) } }
        }
    }
}
