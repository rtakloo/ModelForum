import Foundation
import Network
import ForumCore

/// Binds IPv4 loopback only; callbacks and browser responses never appear in logs.
final class ChatGPTLoopback: @unchecked Sendable {
    private let queue = DispatchQueue(label: "com.modelforum.chatgpt.callback")
    private var listener: NWListener?
    private var startWaiter: CheckedContinuation<URL, Error>?
    private var callbackWaiter: CheckedContinuation<URL, Error>?
    private var result: Result<URL, Error>?
    private var connections: [NWConnection] = []
    private var port: UInt16?

    func start() async throws -> URL {
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                queue.async { [self] in
                    guard self.result == nil else { continuation.resume(throwing: CancellationError()); return }
                    self.startWaiter = continuation
                    do {
                        let parameters = NWParameters.tcp
                        parameters.requiredLocalEndpoint = .hostPort(host: .ipv4(.loopback), port: .any)
                        let listener = try NWListener(using: parameters)
                        self.listener = listener
                        listener.stateUpdateHandler = { [weak self, weak listener] state in
                            guard let self else { return }
                            if case .ready = state, let port = listener?.port?.rawValue {
                                self.port = port
                                self.startWaiter?.resume(returning: URL(string: "http://127.0.0.1:\(port)/auth/callback")!); self.startWaiter = nil
                            } else if case .failed = state { self.finish(.failure(ForumError.message("Could not start the local ChatGPT sign-in listener."))) }
                        }
                        listener.newConnectionHandler = { [weak self] connection in
                            guard let self, self.result == nil, self.connections.count < 16 else { connection.cancel(); return }
                            self.connections.append(connection)
                            connection.start(queue: self.queue)
                            self.queue.asyncAfter(deadline: .now() + 5) { connection.cancel() }
                            self.receive(connection, buffer: Data())
                        }
                        listener.start(queue: self.queue)
                        self.queue.asyncAfter(deadline: .now() + 600) { [weak self] in self?.finish(.failure(ForumError.message("ChatGPT sign-in timed out. Start again."))) }
                    } catch { self.finish(.failure(ForumError.message("Could not start the local ChatGPT sign-in listener."))) }
                }
            }
        } onCancel: { self.cancel() }
    }
    func callback() async throws -> URL {
        try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { continuation in
                queue.async {
                    if let result = self.result { continuation.resume(with: result) }
                    else { self.callbackWaiter = continuation }
                }
            }
        } onCancel: { self.cancel() }
    }
    func cancel() { queue.async { self.finish(.failure(CancellationError())) } }
    private func receive(_ connection: NWConnection, buffer: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 4096) { [weak self] data, _, complete, error in
            guard let self, self.result == nil else { connection.cancel(); return }
            var buffer = buffer
            if let data { buffer.append(data) }
            guard buffer.count <= 16_384, error == nil else { connection.cancel(); return }
            if buffer.range(of: Data("\r\n\r\n".utf8)) != nil {
                guard let text = String(data: buffer, encoding: .utf8), let first = text.components(separatedBy: "\r\n").first, let port = self.port else { connection.cancel(); return }
                let request = first.split(separator: " ")
                let headers = text.components(separatedBy: "\r\n").dropFirst().filter { $0.lowercased().hasPrefix("host:") }
                guard request.count == 3, request[0] == "GET", request[2] == "HTTP/1.1", request[1].hasPrefix("/auth/callback?"),
                      headers.count == 1, headers.first?.dropFirst(5).trimmingCharacters(in: .whitespaces) == "127.0.0.1:\(port)",
                      let url = URL(string: "http://127.0.0.1:\(port)" + request[1]) else { connection.cancel(); return }
                let body = "Sign-in callback received. You can return to Model Forum. The app will verify your account."
                let reply = "HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nCache-Control: no-store\r\nContent-Security-Policy: default-src 'none'\r\nConnection: close\r\nContent-Length: \(body.utf8.count)\r\n\r\n\(body)"
                connection.send(content: Data(reply.utf8), completion: .contentProcessed { _ in connection.cancel() })
                self.finish(.success(url), preserving: connection)
            } else if !complete { self.receive(connection, buffer: buffer) }
            else { connection.cancel() }
        }
    }
    private func finish(_ outcome: Result<URL, Error>, preserving: NWConnection? = nil) {
        guard result == nil else { return }
        result = outcome; listener?.cancel(); listener = nil
        for connection in connections where connection !== preserving { connection.cancel() }
        connections.removeAll()
        if let startWaiter { startWaiter.resume(throwing: CancellationError()); self.startWaiter = nil }
        callbackWaiter?.resume(with: outcome); callbackWaiter = nil
    }
}
