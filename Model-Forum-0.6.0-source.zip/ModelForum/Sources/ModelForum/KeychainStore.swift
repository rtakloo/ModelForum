import Foundation
import Security
import LocalAuthentication
import ForumCore

enum KeychainStore {
    private static let service = "com.modelforum.desktop.credentials"
    private static var chatGPTQuery: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service + ".oauth", kSecAttrAccount as String: "chatgpt-registrations"]
    }
    static func readChatGPTState() throws -> Data? {
        var query = chatGPTQuery
        query[kSecReturnData as String] = true; query[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data, data.count <= 1_048_576 else { throw ForumError.message("Keychain could not read ChatGPT accounts.") }
        return data
    }
    static func saveChatGPTState(_ data: Data) throws {
        guard data.count <= 1_048_576 else { throw ForumError.message("Too many saved ChatGPT accounts. Remove an account before adding another.") }
        let update = [kSecValueData as String: data]
        var status = SecItemUpdate(chatGPTQuery as CFDictionary, update as CFDictionary)
        if status == errSecItemNotFound {
            var query = chatGPTQuery
            query[kSecValueData as String] = data
            query[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            status = SecItemAdd(query as CFDictionary, nil)
        }
        guard status == errSecSuccess else { throw ForumError.message("Keychain could not save ChatGPT accounts.") }
    }
    private static func query(_ provider: ProviderKind) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: provider.rawValue]
    }
    static func read(_ provider: ProviderKind) throws -> String? {
        var request = query(provider)
        request[kSecReturnData as String] = true
        request[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(request as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data, let value = String(data: data, encoding: .utf8) else {
            throw ForumError.message("Keychain could not read this credential (status \(status)).")
        }
        return value
    }
    static func contains(_ provider: ProviderKind) -> Bool {
        var request = query(provider)
        request[kSecReturnAttributes as String] = true
        let context = LAContext()
        context.interactionNotAllowed = true
        request[kSecUseAuthenticationContext as String] = context
        return SecItemCopyMatching(request as CFDictionary, nil) == errSecSuccess
    }
    static func save(_ key: String, for provider: ProviderKind) throws {
        let key = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard provider.needsKey, !key.isEmpty, !key.contains(where: { $0.isWhitespace }), key.count < 4096 else {
            throw ForumError.message("Enter a valid API key without spaces.")
        }
        let update = [kSecValueData as String: Data(key.utf8)]
        var status = SecItemUpdate(query(provider) as CFDictionary, update as CFDictionary)
        if status == errSecItemNotFound {
            var request = query(provider)
            request[kSecValueData as String] = Data(key.utf8)
            request[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            status = SecItemAdd(request as CFDictionary, nil)
        }
        guard status == errSecSuccess else { throw ForumError.message("Keychain could not save the credential (status \(status)).") }
    }
    static func remove(_ provider: ProviderKind) throws {
        let status = SecItemDelete(query(provider) as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw ForumError.message("Keychain could not remove the credential (status \(status)).") }
    }
}
