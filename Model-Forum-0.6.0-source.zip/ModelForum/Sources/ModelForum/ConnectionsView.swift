import SwiftUI
import ForumCore

struct ConnectionsView: View {
    @EnvironmentObject var store: AppStore
    @Environment(\.dismiss) var dismiss
    @ObservedObject private var chatGPT = ChatGPTConnection.shared
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Your connections").font(.system(size: 25, weight: .semibold, design: .serif))
                    Text("Use your own accounts. Credentials stay in macOS Keychain.").font(.callout).foregroundStyle(.secondary)
                }
                Spacer()
                Button("Done") { store.persist(); dismiss() }.keyboardShortcut(.defaultAction)
            }
            ScrollView {
                VStack(spacing: 14) {
                    ForEach($store.workspace.participants) { $participant in
                        ConnectionRow(participant: $participant, persist: { store.persist() }, accountChanged: {
                            store.credentialsWillChange(participant.provider)
                        })
                    }
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Request limits").font(.headline)
                        Picker("Output token cap per request", selection: $store.workspace.maxOutputTokens) {
                            ForEach([1024, 2048, 4096, 8192, 16384, 32768], id: \.self) { limit in
                                Text(limit.formatted()).tag(limit)
                            }
                            if ![1024, 2048, 4096, 8192, 16384, 32768].contains(store.workspace.maxOutputTokens) {
                                Text("\(store.workspace.maxOutputTokens.formatted()) (current)").tag(store.workspace.maxOutputTokens)
                            }
                        }.onChange(of: store.workspace.maxOutputTokens) { _, _ in store.persist() }
                        if chatGPT.useForOpenAI {
                            Text("The ChatGPT account route does not support this cap. It applies only to compatible API/local connections. ChatGPT responses have a local size bound, which does not limit billable generation.").font(.caption).foregroundStyle(.secondary)
                        }
                        Text("This is a per-request output cap, not an account balance. OpenAI reasoning tokens count toward the cap, so a small cap can end a response before visible text. Higher caps may increase cost; model limits still apply.").font(.caption).foregroundStyle(.secondary)
                        Text("OpenAI API billing is separate: ChatGPT/Codex credits do not fund this API connection.").font(.caption).foregroundStyle(.secondary)
                        Link("Open OpenAI API billing", destination: URL(string: "https://platform.openai.com/settings/organization/billing/overview")!).font(.caption)
                        Text("One request per addressed participant. No automatic retries or autonomous loops.").font(.caption).foregroundStyle(.secondary)
                    }.padding(18).frame(maxWidth: .infinity, alignment: .leading).background(Color.primary.opacity(0.035)).clipShape(RoundedRectangle(cornerRadius: 12))
                    Text("Conversation history is stored locally as readable JSON. Cloud providers receive the context you send and apply their own data policies. Team sharing requires a configured team server and a separate team sign-in; provider credentials stay on this Mac.")
                        .font(.caption).foregroundStyle(.secondary).padding(.horizontal, 4)
                }
            }
        }.padding(26).frame(width: 650, height: 720).disabled(store.busy)
    }
}

private struct ConnectionRow: View {
    @Binding var participant: Participant
    let persist: () -> Void
    let accountChanged: () -> Bool
    @ObservedObject private var chatGPT = ChatGPTConnection.shared
    @State private var key = ""
    @State private var saved = false
    @State private var notice: String?
    @State private var failed = false
    @State private var confirmRemoval = false
    @State private var models: [ModelOption] = []
    @State private var customModel = false
    @State private var loadingModels = false
    @State private var catalogNotice: String?
    @State private var catalogFailed = false
    @State private var modelTask: Task<Void, Never>?
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(participant.provider.title).font(.headline)
                Text("@\(participant.alias)").font(.system(.caption, design: .monospaced)).foregroundStyle(.secondary)
                Spacer()
                if participant.provider.needsKey && !usesChatGPT {
                    Label(saved ? "Key saved" : "Needs key", systemImage: saved ? "checkmark.shield" : "key")
                        .font(.caption).foregroundStyle(saved ? Color.green : Color.secondary)
                }
            }
            Text(participant.provider.connectionDescription).font(.caption).foregroundStyle(.secondary)
            if participant.provider == .openAI { ChatGPTAccountView() }
            if participant.provider == .claudeCode { ClaudeAccountView() }
            if !usesChatGPT && participant.provider != .claudeCode { ProviderAccountEditor(provider: participant.provider) }
            HStack(spacing: 10) {
                Picker("Model", selection: modelChoice) {
                    Text(models.isEmpty ? "Load models to choose…" : "Choose a model…").tag("")
                    if !participant.model.isEmpty && !models.contains(where: { $0.id == participant.model }) {
                        Text("\(participant.model) (current)").tag(participant.model)
                    }
                    ForEach(models) { model in
                        Text(model.name == model.id ? model.id : "\(model.name) — \(model.id)").tag(model.id)
                    }
                    Divider()
                    Text("Enter a model ID…").tag("__custom_model__")
                }
                .pickerStyle(.menu).accessibilityLabel("\(participant.provider.title) model")
                .disabled(loadingModels || (usesChatGPT && chatGPT.busy))
                if loadingModels {
                    ProgressView().controlSize(.small)
                    Button("Cancel") { modelTask?.cancel() }
                } else if participant.provider != .claudeCode {
                    Button(models.isEmpty ? "Load models" : "Refresh", systemImage: "arrow.clockwise") { loadModels() }
                }
            }
            if customModel {
                TextField("Custom model ID", text: $participant.model)
                    .textFieldStyle(.roundedBorder).accessibilityLabel("\(participant.provider.title) custom model ID")
            }
            if let catalogNotice {
                Text(catalogNotice).font(.caption).foregroundStyle(catalogFailed ? Color.red : Color.secondary)
            }
            if participant.provider.needsKey && !usesChatGPT {
                HStack {
                    SecureField(saved ? "Replace saved API key" : "Paste your existing API key here", text: $key)
                        .textFieldStyle(.roundedBorder).accessibilityLabel("\(participant.provider.title) API key")
                    Button("Save to Keychain") {
                        do {
                            guard accountChanged() else { throw ForumError.message("Could not save the account reset. Resolve the workspace error before changing credentials.") }
                            try KeychainStore.save(key, for: participant.provider)
                            key = ""; saved = true; failed = false; notice = "Key saved on this Mac. Account labels and privacy confirmation were cleared. Click Load models to choose a model."
                            models = []; catalogNotice = nil
                        } catch { failed = true; notice = error.localizedDescription }
                    }.disabled(key.isEmpty || loadingModels)
                    if saved {
                        Button { confirmRemoval = true } label: { Image(systemName: "trash") }.accessibilityLabel("Remove saved \(participant.provider.title) key").disabled(loadingModels)
                    }
                }
            } else if usesChatGPT {
                Text("Load models from the selected ChatGPT account. No API key is used on this route, and failures never switch billing to the API key.").font(.caption).foregroundStyle(.secondary)
            } else if participant.provider == .ollama {
                Text("Start Ollama, then click Load models to choose an installed model. Connects to 127.0.0.1:11434; cloud-hosted Ollama models may still send data off this Mac.").font(.caption).foregroundStyle(.secondary)
            } else {
                Text("Uses your installed Claude Code CLI and its configured session. Runs in a temporary directory with ordinary tools, MCP, and user hooks disabled. Administrator policies still apply; this is not a security sandbox. Requires a recent CLI supporting safe mode.").font(.caption).foregroundStyle(.secondary)
            }
            if let notice { Text(notice).font(.caption).foregroundStyle(failed ? Color.red : Color.secondary) }
        }.padding(18).background(Color(nsColor: .textBackgroundColor)).clipShape(RoundedRectangle(cornerRadius: 12))
            .onAppear {
                saved = KeychainStore.contains(participant.provider)
                if participant.provider == .claudeCode { loadModels() }
            }
            .onDisappear { key = ""; modelTask?.cancel() }
            .onChange(of: participant.model) { _, _ in persist() }
            .onChange(of: chatGPT.useForOpenAI) { _, _ in resetOpenAIModels() }
            .onChange(of: chatGPT.activeProfileID) { _, _ in resetOpenAIModels() }
            .confirmationDialog("Remove this API key from Model Forum’s Keychain entry?", isPresented: $confirmRemoval) {
                Button("Remove key", role: .destructive) {
                    do { guard accountChanged() else { throw ForumError.message("Could not save the account reset. Resolve the workspace error before changing credentials.") }; try KeychainStore.remove(participant.provider); saved = false; notice = "Key removed. Account labels and privacy confirmation were cleared."; failed = false; models = []; catalogNotice = nil }
                    catch { failed = true; notice = error.localizedDescription }
                }
            }
    }
    private var usesChatGPT: Bool { participant.provider == .openAI && chatGPT.useForOpenAI }
    private func resetOpenAIModels() {
        guard participant.provider == .openAI else { return }
        modelTask?.cancel(); models = []; catalogNotice = nil; customModel = false
    }
    private var modelChoice: Binding<String> {
        Binding(get: { customModel ? "__custom_model__" : participant.model }, set: { value in
            if value == "__custom_model__" { customModel = true }
            else { customModel = false; participant.model = value }
        })
    }
    private func loadModels() {
        guard !loadingModels else { return }
        loadingModels = true; catalogNotice = nil
        let provider = participant.provider
        modelTask = Task { @MainActor in
            defer { loadingModels = false; modelTask = nil }
            do {
                let available: [ModelOption]
                if provider == .openAI && chatGPT.useForOpenAI {
                    available = try await chatGPT.loadModels()
                } else {
                    let apiKey = provider.needsKey ? try KeychainStore.read(provider) : nil
                    available = try await ModelCatalog().models(for: provider, apiKey: apiKey)
                }
                try Task.checkCancellation()
                models = available; catalogFailed = false
                catalogNotice = available.isEmpty ? "No matching models found. You can enter a model ID manually." : (provider == .claudeCode ? nil : "\(available.count) models loaded. Choose one from the dropdown.")
            } catch {
                if !Task.isCancelled { catalogFailed = true; catalogNotice = error.localizedDescription }
            }
        }
    }
}


private struct ProviderAccountEditor: View {
    @EnvironmentObject private var store: AppStore
    let provider: ProviderKind
    @State private var expanded = false
    @State private var email = ""
    @State private var accountID = ""
    @State private var organization = ""
    @State private var project = ""
    @State private var privacyRevision = 0
    @State private var loaded = false
    @State private var notice: String?
    @State private var failed = false

    private var label: ProviderAccountLabel { store.workspace.providerAccountLabels[provider.rawValue] ?? ProviderAccountLabel() }

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            LabeledContent("Email", value: label.email.map { $0 + " · unverified" } ?? "Not provided")
            LabeledContent("Account ID", value: label.accountID.map { $0 + " · unverified" } ?? "Not provided")
            Text(provider.manualIdentityStatus).foregroundStyle(.secondary)
            DisclosureGroup("Edit local account labels", isExpanded: $expanded) {
                VStack(alignment: .leading, spacing: 8) {
                    TextField("Email (optional, unverified)", text: $email)
                    TextField("Account ID (optional, unverified)", text: $accountID)
                    TextField("Organization (optional label)", text: $organization)
                    TextField("Project (optional label)", text: $project)
                    Text("Enter labels only, never API keys. These notes stay in your local workspace and do not select an organization/project or change billing.")
                        .foregroundStyle(.secondary)
                    HStack {
                        Button("Save account labels") { save() }
                        Button("Clear labels") {
                            email = ""; accountID = ""; organization = ""; project = ""
                            save()
                        }
                    }
                    if let notice { Text(notice).foregroundStyle(failed ? Color.red : Color.secondary) }
                }.textFieldStyle(.roundedBorder).padding(.top, 8)
            }
        }.font(.caption)
            .onAppear {
                if !loaded || privacyRevision != store.privacyRevision { load() }
            }
            .onChange(of: store.privacyRevision) { _, _ in
                load()
                notice = "A connection changed. Review the current labels before saving."
            }
    }
    private func load() {
        email = label.email ?? ""; accountID = label.accountID ?? ""
        organization = label.organization ?? ""; project = label.project ?? ""
        privacyRevision = store.privacyRevision
        loaded = true; failed = false; notice = nil
    }
    private func save() {
        let draft = ProviderAccountLabel(email: email, accountID: accountID, organization: organization, project: project)
        if store.saveAccountLabel(draft, for: provider, expectedPrivacyRevision: privacyRevision) {
            load()
            notice = label.isEmpty ? "Account labels cleared." : "Unverified account labels saved on this Mac."
        } else {
            failed = true
            notice = store.error ?? "Account labels could not be saved."
        }
    }
}
