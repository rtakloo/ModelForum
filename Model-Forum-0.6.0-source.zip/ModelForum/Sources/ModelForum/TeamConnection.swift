import SwiftUI
import Security
import ForumCore

@MainActor final class TeamConnection: ObservableObject {
    static let shared = TeamConnection()
    @Published var server = UserDefaults.standard.string(forKey: "team.server") ?? "http://127.0.0.1:8765"
    @Published private(set) var identity: TeamIdentity?
    @Published var selectedTeam = ""
    @Published var busy = false
    @Published var notice: String?
    @Published var license: TeamLicense?
    private var token: String?
    private var signedInServer: String?
    var team: TeamMembership? { identity?.teams.first { $0.id == selectedTeam } }
    var isOwner: Bool { team?.role == "owner" }
    var isEditor: Bool { ["owner", "editor"].contains(team?.role ?? "") }
    func client() throws -> TeamClient {
        let endpoint = try TeamEndpoint.normalized(server).absoluteString
        if let signedInServer, endpoint != signedInServer { throw ForumError.message("Sign out before changing the team server.") }
        return try TeamClient(endpoint: endpoint)
    }
    func request<T: Decodable & Sendable>(_ method: String, _ resource: String, body: Data? = nil, as type: T.Type) async throws -> T {
        guard let token, let team else { throw ForumError.message("Sign in and select a team first.") }
        let id = try TeamEndpoint.pathID(team.id)
        return try await client().request(method, path: "/v1/teams/\(id)/\(resource)", token: token, body: body, as: type)
    }
    func authenticate(email: String, password: String, invitation: String?) async throws {
        let client = try client()
        var fields = ["email": email, "password": password]
        if let invitation { fields["invitation"] = invitation }
        let session = try await client.request("POST", path: invitation == nil ? "/v1/auth/login" : "/v1/auth/join", body: TeamClient.body(fields), as: TeamSession.self)
        do {
            let me = try await client.request("GET", path: "/v1/me", token: session.token, as: TeamIdentity.self)
            try TeamSessionKeychain.save(session.token, endpoint: client.endpoint.absoluteString)
            token = session.token; signedInServer = client.endpoint.absoluteString
            identity = me; selectedTeam = me.teams.first?.id ?? ""; license = nil
            UserDefaults.standard.set(signedInServer, forKey: "team.server")
        } catch {
            _ = try? await client.request("POST", path: "/v1/auth/logout", token: session.token, as: TeamOK.self)
            throw error
        }
    }
    func restore() async throws {
        let client = try client()
        guard let saved = try TeamSessionKeychain.read(endpoint: client.endpoint.absoluteString) else { throw ForumError.message("No saved team session. Sign in first.") }
        let me = try await client.request("GET", path: "/v1/me", token: saved, as: TeamIdentity.self)
        token = saved; signedInServer = client.endpoint.absoluteString; identity = me; selectedTeam = me.teams.first?.id ?? ""; license = nil
    }
    func signOut() async throws {
        let client = try client()
        let prior = token
        try TeamSessionKeychain.remove(endpoint: client.endpoint.absoluteString)
        token = nil; identity = nil; selectedTeam = ""; signedInServer = nil; license = nil
        if let prior { _ = try await client.request("POST", path: "/v1/auth/logout", token: prior, as: TeamOK.self) }
    }
    func refreshLicense() async throws { license = try await request("GET", "entitlement", as: TeamLicense.self) }
}

private enum TeamSessionKeychain {
    static func query(_ endpoint: String) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "com.modelforum.team.sessions", kSecAttrAccount as String: endpoint]
    }
    static func save(_ token: String, endpoint: String) throws {
        var item = query(endpoint)
        let value = [kSecValueData as String: Data(token.utf8)]
        var status = SecItemUpdate(item as CFDictionary, value as CFDictionary)
        if status == errSecItemNotFound {
            item[kSecValueData as String] = Data(token.utf8)
            item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            status = SecItemAdd(item as CFDictionary, nil)
        }
        guard status == errSecSuccess else { throw ForumError.message("Could not save the team session in Keychain.") }
    }
    static func read(endpoint: String) throws -> String? {
        var item = query(endpoint); item[kSecReturnData as String] = true; item[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(item as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data, let value = String(data: data, encoding: .utf8) else { throw ForumError.message("Could not read the team session from Keychain.") }
        return value
    }
    static func remove(endpoint: String) throws {
        let status = SecItemDelete(query(endpoint) as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else { throw ForumError.message("Could not remove the team session from Keychain.") }
    }
}
