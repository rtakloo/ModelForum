import Foundation
import SwiftUI
import AppKit
import UniformTypeIdentifiers
import ForumCore

extension AppStore {
    func exportConversation(asMarkdown: Bool) {
        guard let conversation else { error = "Select a conversation first."; return }
        let panel = NSSavePanel()
        panel.nameFieldStringValue = "conversation." + (asMarkdown ? "md" : "json")
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            let data = asMarkdown ? Data(ConversationExport.markdown(conversation).utf8) : try JSONEncoder().encode(ConversationExport.portable(conversation))
            try data.write(to: url, options: .atomic)
            dataNotice = "Conversation exported. Attached file bytes are included only in a full backup."
        } catch { self.error = "Could not export the conversation." }
    }
    func createBackup() {
        guard !hasActiveWork, let storage else { error = "Wait for requests and uploads to finish before making a backup."; return }
        let panel = NSSavePanel(); panel.nameFieldStringValue = "Model-Forum-backup.json"
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do { try WorkspaceArchive(workspace: workspace, artifacts: storage.artifacts).encoded().write(to: url, options: .atomic); dataNotice = "Backup saved. It includes local conversations, instructions, and generated files; credentials are excluded." }
        catch { self.error = error.localizedDescription }
    }
    func restoreBackup(from url: URL) throws {
        guard !hasActiveWork, let storage else { throw ForumError.message("Wait for requests and uploads to finish before restoring.") }
        let values = try url.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey])
        guard values.isRegularFile == true, (values.fileSize ?? Int.max) <= WorkspaceArchive.maximumEncodedBytes else { throw ForumError.message("Choose a regular backup file of at most 128 MiB.") }
        let archive = try WorkspaceArchive.decode(Data(contentsOf: url))
        let folder = storage.file.deletingLastPathComponent()
        let parent = folder.deletingLastPathComponent()
        guard (try folder.resourceValues(forKeys: [.isSymbolicLinkKey])).isSymbolicLink != true else { throw ForumError.message("The workspace folder must not be a symbolic link.") }
        let stage = parent.appendingPathComponent("ModelForum-restore-" + UUID().uuidString)
        let previous = parent.appendingPathComponent("ModelForum-before-restore-" + UUID().uuidString)
        try FileManager.default.createDirectory(at: stage, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        var installed = false
        defer {
            if !installed && !FileManager.default.fileExists(atPath: WorkspaceStorage.restoreJournalURL(folder: folder).path) {
                try? FileManager.default.removeItem(at: stage)
            }
        }
        let restoredStorage = try WorkspaceStorage(folder: stage)
        for file in archive.files { _ = try restoredStorage.artifacts.store(draft: ArtifactDraft(filename: file.filename, mimeType: file.mimeType, data: file.data), id: file.id) }
        var restored = archive.workspace
        restored.schemaVersion = 5
        restored.privacyConfirmations = [:]; restored.providerAccountLabels = [:]
        restored.pendingFileDeletions = []
        restored.usageLedger.recoverInterruptedRequests()
        for i in restored.channels.indices { restored.channels[i].autoSave = false }
        for i in restored.artifacts.indices where restored.artifacts[i].syncState == .uploading { restored.artifacts[i].syncState = .pending }
        try restoredStorage.save(restored)
        try storage.installRestore(stage: stage, previous: previous)
        installed = true
        workspace = restored
        selectedChannelID = nil; selectedConversationID = restored.conversations.first(where: { $0.channelID == nil })?.id
        composer = ""; critiqueID = nil; error = nil
        // Invalidates open settings drafts without changing any external credential.
        _ = credentialsWillChange(.openAI)
        dataNotice = "Backup restored. Uploads are off and account confirmations need review. The prior workspace is preserved at \(previous.path)."
    }
    func permanentlyDeleteChannels(_ ids: Set<UUID>) {
        guard !hasActiveWork, let storage else { error = "Wait for requests and uploads to finish before deletion."; return }
        let eligible = Set(workspace.channels.filter { ids.contains($0.id) && $0.deletedAt != nil }.map(\.id))
        guard eligible == ids else { error = "Only deleted channels can be permanently removed."; return }
        let conversationIDs = Set(workspace.conversations.filter { $0.channelID.map(eligible.contains) == true }.map(\.id))
        let records = workspace.artifacts.filter { conversationIDs.contains($0.conversationID) }
        let old = workspace
        workspace.pendingFileDeletions += records.map(\.relativePath)
        workspace.artifacts.removeAll { conversationIDs.contains($0.conversationID) }
        workspace.conversations.removeAll { conversationIDs.contains($0.id) }
        workspace.channels.removeAll { eligible.contains($0.id) }
        workspace.workflowRuns.removeAll { run in run.contextMessageIDs.contains { id in old.conversations.filter { conversationIDs.contains($0.id) }.flatMap(\.messages).contains { $0.id == id } } }
        guard persist() else { workspace = old; return }
        completePendingFileDeletions(files: storage.artifacts)
        if selectedChannelID.map(eligible.contains) == true { selectChannel(nil) }
        dataNotice = "Deleted from this working copy. Existing backups, exports, remote team copies and GitHub files are retained."
    }
    func completePendingFileDeletions(files: ArtifactFiles? = nil) {
        guard !hasActiveWork, let files = files ?? storage?.artifacts else { return }
        var failed: [String] = []
        for path in Set(workspace.pendingFileDeletions) {
            do { try files.remove(relativePath: path) } catch { failed.append(path) }
        }
        workspace.pendingFileDeletions = failed; _ = persist()
        if !failed.isEmpty { error = "\(failed.count) local files could not be removed. Resolve file permissions and retry cleanup in Data settings." }
    }
    var retentionCandidates: [Channel] {
        guard workspace.deletedChannelRetentionDays > 0 else { return [] }
        let cutoff = Date().addingTimeInterval(-Double(workspace.deletedChannelRetentionDays) * 86400)
        return deletedChannels.filter { ($0.deletedAt ?? .distantFuture) < cutoff }
    }
    func importTeamConversation(_ shared: Conversation) {
        guard !busy else { return }
        let copy = Conversation(title: shared.title, messages: shared.messages.map { ChatMessage(role: $0.role, author: $0.author, content: $0.content, date: $0.date, model: $0.model, provider: $0.provider) })
        let old = workspace
        workspace.conversations.insert(copy, at: 0)
        guard persist() else { workspace = old; return }
        select(copy.id)
        dataNotice = "Shared conversation copied to Unfiled. No remote files or credentials were imported."
    }
}

struct DataSettingsView: View {
    @EnvironmentObject var store: AppStore
    @State private var confirmRetention = false
    @State private var restoreURL: URL?
    @State private var confirmRestore = false
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                Text("History & data").font(.title2.bold())
                Text("History stays on this Mac unless you explicitly share a conversation, export it, or enable channel file uploads.")
                HStack { Button("Export current conversation (.md)") { store.exportConversation(asMarkdown: true) }; Button("Export JSON") { store.exportConversation(asMarkdown: false) } }
                Divider()
                Text("Backup and recovery").font(.headline)
                Text("A full backup includes history, instructions, usage records and generated files. It is readable JSON and contains no API keys or sign-in tokens. Keep it in a private location. Maximum 128 MiB.").font(.caption)
                HStack {
                    Button("Save full backup…") { store.createBackup() }
                    Button("Restore backup…") {
                        let panel = NSOpenPanel(); panel.canChooseDirectories = false; panel.allowsMultipleSelection = false
                        if panel.runModal() == .OK { restoreURL = panel.url; confirmRestore = true }
                    }
                }
                Divider()
                Text("Deleted-channel retention").font(.headline)
                Picker("Eligible for cleanup after", selection: $store.workspace.deletedChannelRetentionDays) {
                    Text("Keep indefinitely").tag(0); Text("30 days").tag(30); Text("90 days").tag(90); Text("365 days").tag(365)
                }.onChange(of: store.workspace.deletedChannelRetentionDays) { _, _ in store.persist() }
                Text("Cleanup is explicit. Review recently deleted channels before removing eligible ones. Removing a channel deletes its local conversations/files; existing backups, exports, team copies and GitHub files are unaffected.").font(.caption)
                Button("Delete \(store.retentionCandidates.count) eligible channels permanently…", role: .destructive) { confirmRetention = true }.disabled(store.retentionCandidates.isEmpty)
                if !store.workspace.pendingFileDeletions.isEmpty { Button("Retry pending local file cleanup") { store.completePendingFileDeletions() } }
                if let notice = store.dataNotice { Text(notice).font(.caption).textSelection(.enabled) }
                if let error = store.error { Text(error).font(.caption).foregroundStyle(.red).textSelection(.enabled) }
            }.padding(26)
        }.frame(width: 650, height: 720).disabled(store.hasActiveWork)
        .confirmationDialog("Replace this workspace with the selected backup? The current workspace is preserved in a separate recovery folder. Automatic uploads will be disabled.", isPresented: $confirmRestore) {
            Button("Restore backup") { if let url = restoreURL { do { try store.restoreBackup(from: url) } catch { store.error = error.localizedDescription } } }
        }
        .confirmationDialog("Permanently delete eligible channels and their local conversations/files? This cannot be undone in the app.", isPresented: $confirmRetention) {
            Button("Delete permanently", role: .destructive) { store.permanentlyDeleteChannels(Set(store.retentionCandidates.map(\.id))) }
        }
    }
}
