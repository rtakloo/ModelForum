import Foundation
import Darwin
import ForumCore

/// Held across a refresh and its atomic Keychain replacement, including across app processes.
final class ChatGPTCredentialLock {
    private let descriptor: Int32
    static func defaultDirectory(applicationSupport: URL) -> URL {
        // Workspace restore replaces ModelForum. Keep the coordination inode in a stable sibling.
        applicationSupport.appendingPathComponent("ModelForum-SessionLocks", isDirectory: true)
    }
    init(directory: URL? = nil) throws {
        let root = try directory ?? Self.defaultDirectory(applicationSupport: FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true))
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        var directoryInfo = stat()
        guard lstat(root.path, &directoryInfo) == 0, directoryInfo.st_uid == geteuid(),
              directoryInfo.st_mode & S_IFMT == S_IFDIR, directoryInfo.st_mode & 0o077 == 0 else {
            throw ForumError.message("The ChatGPT account lock directory must be private and owned by this user.")
        }
        let path = root.appendingPathComponent("chatgpt-session.lock").path
        let opened = Darwin.open(path, O_CREAT | O_RDWR | O_NOFOLLOW | O_CLOEXEC, mode_t(0o600))
        guard opened >= 0 else { throw ForumError.message("Could not protect the ChatGPT account update with a local lock.") }
        var info = stat()
        guard fstat(opened, &info) == 0, info.st_uid == geteuid(), info.st_mode & S_IFMT == S_IFREG, info.st_mode & 0o077 == 0,
              flock(opened, LOCK_EX | LOCK_NB) == 0 else {
            Darwin.close(opened)
            throw ForumError.message("Another Model Forum process is updating ChatGPT accounts. Wait for it to finish and retry.")
        }
        descriptor = opened
    }
    deinit { flock(descriptor, LOCK_UN); Darwin.close(descriptor) }
}
