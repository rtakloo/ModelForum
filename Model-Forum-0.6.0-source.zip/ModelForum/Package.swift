// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "ModelForum",
    platforms: [.macOS(.v14)],
    products: [.executable(name: "ModelForum", targets: ["ModelForum"])],
    targets: [
        .target(name: "ForumCore"),
        .executableTarget(name: "ModelForum", dependencies: ["ForumCore"], resources: [.copy("Resources/Renderer")]),
        .testTarget(name: "ForumCoreTests", dependencies: ["ForumCore"]),
        .testTarget(name: "ModelForumTests", dependencies: ["ModelForum", "ForumCore"])
    ]
)
