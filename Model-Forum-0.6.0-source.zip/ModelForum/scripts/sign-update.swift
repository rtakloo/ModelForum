#!/usr/bin/env swift
// Publisher tool: private signing key is read from a protected file, never printed.
import Foundation
import CryptoKit
import Darwin
struct Release: Codable { let version: String; let build: Int; let minimumMacOSMajor: Int; let downloadURL: URL; let sha256: String; let byteCount: Int; let expiresAt: Date; let notes: String }
struct Envelope: Codable { let payload: Data; let signature: Data }
guard CommandLine.arguments.count == 8 else { fatalError("Usage: sign-update.swift key-file app.zip version build https-url notes-file output.json") }
let a = CommandLine.arguments
let keyURL = URL(fileURLWithPath: a[1])
let descriptor = open(keyURL.path, O_RDONLY | O_NOFOLLOW | O_CLOEXEC)
guard descriptor >= 0 else { fatalError("Could not open a regular private key file.") }
defer { close(descriptor) }
var info = stat()
guard fstat(descriptor, &info) == 0, (info.st_mode & S_IFMT) == S_IFREG,
      info.st_uid == getuid(), info.st_nlink == 1, info.st_mode & 0o077 == 0, info.st_size == 32 else {
    fatalError("Private key must be a 32-byte owner-only regular file owned by this user.")
}
var bytes = [UInt8](repeating: 0, count: 32)
guard read(descriptor, &bytes, 32) == 32 else { fatalError("Could not read the private key.") }
let key = try Curve25519.Signing.PrivateKey(rawRepresentation: Data(bytes))
let zip = try Data(contentsOf: URL(fileURLWithPath: a[2]))
guard let build = Int(a[4]), let url = URL(string:a[5]), url.scheme == "https" else { fatalError("Invalid release metadata.") }
let release = Release(version:a[3], build:build, minimumMacOSMajor:14, downloadURL:url, sha256:SHA256.hash(data:zip).map{String(format:"%02x",$0)}.joined(), byteCount:zip.count, expiresAt:Date().addingTimeInterval(30*86400), notes:try String(contentsOfFile:a[6],encoding:.utf8))
let payload = try JSONEncoder().encode(release)
try JSONEncoder().encode(Envelope(payload:payload,signature:try key.signature(for:payload))).write(to:URL(fileURLWithPath:a[7]),options:.atomic)
print("Signed update manifest written. Public verification key: " + key.publicKey.rawRepresentation.base64EncodedString())
