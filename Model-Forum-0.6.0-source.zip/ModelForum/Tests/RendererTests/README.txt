Offline renderer verification

Run using Node.js with jsdom available in NODE_PATH:
  NODE_PATH=/absolute/work/renderer-deps/node_modules node --test Tests/RendererTests/renderer.test.cjs

The implementation dependencies are bundled under Sources/ModelForum/Resources/Renderer/vendor.
Their exact versions, registry integrity strings, source repositories, licenses, and SHA-256
checksums are recorded in vendor/manifest.json. Tests load those bundled files, not npm copies.
Test-only jsdom version used during development: 30.1.3. No model APIs are used.

fixture.html provides a deterministic visual inspection page with Heron and Pythagorean
formulas, fractions, roots, tables, Markdown structure, and literal code. Open it through
a local file-capable browser or a local static HTTP server. security-fixtures.json contains
the malicious-markup regression inputs also exercised by the Node tests.

Contract: window.renderMessage(text) accepts a string and returns mode, characters, truncated.
Native message channel renderer receives {type:"ready"} and {type:"height",height:number}.
It also receives {type:"scrollState",scrollTop,scrollHeight,clientHeight}; metrics refresh
on every replacement message and after scroll/layout changes for native wheel routing.
Links remain ordinary HTTP(S) anchors; the native navigation delegate owns opening them.
Messages longer than 200,000 JavaScript string code units show complete plaintext source
with a visible limit notice. Formulas have a 10,000-code-unit parsing/rendering limit and a
500-formula budget per render. Code is never reparsed as math. Only explicit math fences
opt into typesetting; latex and tex fences remain source. Raw HTML displays as literal text.
The viewport caps at 10,000 CSS pixels and scrolls internally for longer content.

Copying any selected typeset formula writes plain-text LaTeX only, using canonical
\(...\) or \[...\] delimiters. A partial visual selection copies the whole formula
without changing the visible selection. Mixed selections preserve prose, code whitespace,
block breaks, list markers, and table separators. No-math selections keep native behavior.

These DOM tests are not a WKWebView layout or browser sandbox test. The app's native
resource rules and navigation handling must also be verified in the integrated application.

Primary implementation documentation:
  https://marked.js.org/using_pro
  https://github.com/cure53/DOMPurify
  https://katex.org/docs/options
  https://katex.org/docs/browser
