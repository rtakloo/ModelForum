/* Deterministic offline visual fixture; no provider requests. */
document.addEventListener("DOMContentLoaded", () => {
  window.renderMessage(String.raw`# Geometry, rendered clearly

For a right triangle, **Pythagoras’ theorem** gives \(a^2+b^2=c^2\).
With legs $a=3$ and $b=4$, the hypotenuse is $c=5$.

## Heron’s formula

For side lengths \(a,b,c\), define the semiperimeter \(s=(a+b+c)/2\). Then

\[
A=\sqrt{s(s-a)(s-b)(s-c)}.
\]

For the 3–4–5 triangle:

$$
s=6,\qquad A=\sqrt{6\cdot3\cdot2\cdot1}=6.
$$

> The square-root bar should cover the entire product; subscripts and fractions should be typeset, not shown as source.

| Quantity | Formula | Value |
|---|---|---|
| Hypotenuse | $\sqrt{a^2+b^2}$ | 5 |
| Semiperimeter | $\frac{a+b+c}{2}$ | 6 |
| Area | $\frac{ab}{2}$ | 6 |

1. Check that the sides satisfy the triangle inequality.
2. Compute the semiperimeter.
3. Substitute into Heron’s formula.

### Source code remains source code

Inline code: ` + '`sqrt(s*(s-a)*(s-b)*(s-c))`' + String.raw`.

` + '```python\narea = sqrt(s * (s-a) * (s-b) * (s-c))\n# $x^2$ and \\(a+b\\) remain literal here\n```' + String.raw`

An explicitly marked formula:

` + '```math\n\\sum_{k=1}^{n} k = \\frac{n(n+1)}{2}\n```' + String.raw`

A LaTeX deliverable remains source:

` + '```latex filename=triangle.tex\n\\documentclass{article}\n\\begin{document}\n$A=6$\n\\end{document}\n```' + String.raw`

Read [the reference link](https://example.com/geometry) if you choose. An external image is represented as text: ![A triangle diagram](https://example.com/triangle.png).
`);
});
