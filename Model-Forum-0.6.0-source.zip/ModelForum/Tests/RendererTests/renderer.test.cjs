const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { JSDOM } = require(process.env.RENDERER_JSDOM || 'jsdom');
const renderer = path.resolve(__dirname, '../../Sources/ModelForum/Resources/Renderer');

function environment() {
  const dom = new JSDOM('<!doctype html><html><body><main id="message"></main></body></html>', {
    runScripts: 'outside-only', pretendToBeVisual: true, url: 'file://' + renderer + '/index.html'
  });
  const messages = [];
  dom.window.webkit = { messageHandlers: { renderer: { postMessage: message => messages.push(message) } } };
  dom.window.ResizeObserver = class { observe() {} };
  for (const file of ['vendor/marked/marked.umd.js', 'vendor/dompurify/purify.min.js', 'vendor/katex/katex.min.js', 'renderer.js']) {
    dom.window.eval(fs.readFileSync(path.join(renderer, file), 'utf8'));
  }
  return { dom, window: dom.window, root: dom.window.document.getElementById('message'), messages };
}

function copyRange(window, range) {
  const selection = window.getSelection();
  selection.removeAllRanges();
  selection.addRange(range);
  const values = new Map([['text/html', 'stale-rich-clipboard']]);
  let clears = 0;
  const event = new window.Event('copy', { bubbles: true, cancelable: true });
  Object.defineProperty(event, 'clipboardData', { value: {
    clearData() { clears++; values.clear(); },
    setData(type, value) { values.set(type, value); }
  } });
  window.document.dispatchEvent(event);
  return { text: values.get('text/plain'), values, clears, prevented: event.defaultPrevented };
}

function firstVisualText(window, formula) {
  const walker = window.document.createTreeWalker(formula.querySelector('.katex-html'), window.NodeFilter.SHOW_TEXT);
  let node;
  while ((node = walker.nextNode())) if (node.nodeValue.trim()) return node;
  throw new Error('No visual text in formula');
}

test('Markdown headings, lists, quotes, tables, links and code render', () => {
  const { dom, window, root } = environment();
  window.renderMessage('# Title\n\n**Bold** and *italic*.\n\n- one\n- two\n\n> quote\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n[reference](https://example.com/a)\n\n```js\nconst value = 1;\n```');
  assert.equal(root.querySelector('h1').textContent, 'Title');
  assert.equal(root.querySelectorAll('li').length, 2);
  assert.equal(root.querySelector('strong').textContent, 'Bold');
  assert.ok(root.querySelector('blockquote'));
  assert.ok(root.querySelector('table'));
  assert.equal(root.querySelector('a').href, 'https://example.com/a');
  assert.ok(root.querySelector('pre code').textContent.includes('const value'));
  dom.window.close();
});

test('All four math delimiter forms typeset with accessible MathML', () => {
  const { dom, window, root } = environment();
  const source = String.raw`Inline \(a^2+b^2=c^2\) and $\frac{x}{2}$.

\[
A=\sqrt{s(s-a)(s-b)(s-c)}
\]

$$
\sum_{k=1}^{n}k=\frac{n(n+1)}{2}
$$`;
  assert.equal(window.renderMessage(source).mode, 'rich');
  assert.equal(root.querySelectorAll('.katex').length, 4);
  assert.equal(root.querySelectorAll('.katex-display').length, 2);
  assert.equal(root.querySelectorAll('math').length, 4);
  assert.equal(root.querySelector('annotation[encoding="application/x-tex"]').textContent, 'a^2+b^2=c^2');
  assert.equal(root.querySelectorAll('.katex-error').length, 0);
  dom.window.close();
});

test('Math in headings, table cells and list items renders', () => {
  const { dom, window, root } = environment();
  window.renderMessage('# Result $x^2$\n\n- \\(a+b\\)\n\n| Expression |\n|---|\n| $\\sqrt{4}$ |');
  assert.equal(root.querySelectorAll('.katex').length, 3);
  dom.window.close();
});

test('Inline and fenced code are preserved; plain sqrt prose is not guessed', () => {
  const { dom, window, root } = environment();
  const source = 'Literal `$x^2$` and `\\(x\\)` plus sqrt(x).\n\n```python\n$y$ \\[z\\]\n```\n\n```latex\n\\frac{a}{b}\n```\n\n```latex filename=paper.tex\n\\documentclass{article}\n\\begin{document}\n$x$\n\\end{document}\n```';
  window.renderMessage(source);
  assert.equal(root.querySelectorAll('.katex').length, 0);
  assert.equal(root.querySelectorAll('code').length, 5);
  assert.ok(root.textContent.includes('sqrt(x)'));
  assert.ok(root.textContent.includes('\\documentclass{article}'));
  dom.window.close();
});

test('Only explicit math fences typeset; a full document stays code even there', () => {
  const { dom, window, root } = environment();
  window.renderMessage('```math\na^2+b^2=c^2\n```\n\n```math\n\\documentclass{article}\n\\begin{document}\nx\n\\end{document}\n```');
  assert.equal(root.querySelectorAll('.katex').length, 1);
  assert.ok(root.querySelector('pre code').textContent.includes('\\documentclass'));
  dom.window.close();
});

test('Escaped dollars and common currency prose remain text', () => {
  const { dom, window, root } = environment();
  window.renderMessage(String.raw`Cost is \$5, or $5 and $10. Unclosed $price stays plain.`);
  assert.equal(root.querySelectorAll('.katex').length, 0);
  assert.ok(root.textContent.includes('$5'));
  dom.window.close();
});

for (const fixture of JSON.parse(fs.readFileSync(path.join(__dirname, 'security-fixtures.json')))) {
  test('Security: ' + fixture.name, () => {
    const { dom, window, root } = environment();
    assert.equal(window.renderMessage(fixture.text).mode, 'rich');
    assert.equal(window.compromised, undefined);
    assert.equal(root.querySelectorAll('script,iframe,frame,style,img,object,embed,form,input,video,audio').length, 0);
    for (const element of root.querySelectorAll('*')) {
      for (const attribute of element.attributes) {
        assert.ok(!/^on/i.test(attribute.name), attribute.name);
        assert.ok(!['src', 'srcset', 'xlink:href'].includes(attribute.name));
        if (attribute.name === 'href') assert.match(attribute.value, /^https?:\/\//);
        if (attribute.name === 'style') assert.ok(!/url\s*\(/i.test(attribute.value));
      }
    }
    dom.window.close();
  });
}

test('Remote images preserve alt text without resource elements', () => {
  const { dom, window, root } = environment();
  window.renderMessage('![Triangle diagram](https://example.com/track.png)');
  assert.equal(root.querySelector('img'), null);
  assert.equal(root.querySelector('.image-placeholder').textContent, 'Image: Triangle diagram');
  dom.window.close();
});

test('Long messages use complete source fallback instead of truncation', () => {
  const { dom, window, root } = environment();
  const source = '# ' + 'x'.repeat(200001) + '\nFINAL SENTINEL';
  const result = window.renderMessage(source);
  assert.equal(result.mode, 'source');
  assert.equal(result.truncated, false);
  assert.equal(root.querySelector('pre').textContent, source);
  assert.ok(root.querySelector('.render-notice'));
  dom.window.close();
});

test('Malformed TeX is visible without crashing and macro state does not leak between renders', () => {
  const { dom, window, root } = environment();
  window.renderMessage('$\\notACommand{x}$');
  assert.ok(root.textContent.includes('\\notACommand'));
  window.renderMessage('$\\gdef\\secret{PRIVATE}\\secret$');
  window.renderMessage('$\\secret$');
  assert.ok(!root.textContent.includes('PRIVATE'));
  dom.window.close();
});

test('Math count limit leaves remaining formulas visible', () => {
  const { dom, window, root } = environment();
  window.renderMessage(Array.from({length: 502}, () => '$x$').join(' '));
  assert.equal(root.querySelectorAll('.katex').length, 500);
  assert.equal(root.querySelectorAll('.math-limit').length, 2);
  dom.window.close();
});

test('Native bridge emits ready and bounded height without repeated identical updates', async () => {
  const { dom, window, root, messages } = environment();
  root.getBoundingClientRect = () => ({ height: 12000 });
  window.renderMessage('hello');
  await new Promise(resolve => setTimeout(resolve, 40));
  assert.ok(messages.some(message => message.type === 'ready'));
  assert.ok(messages.some(message => message.type === 'height' && message.height === 10000));
  const heightMessages = messages.filter(message => message.type === 'height').length;
  window.renderMessage('same height');
  await new Promise(resolve => setTimeout(resolve, 40));
  assert.equal(messages.filter(message => message.type === 'height').length, heightMessages);
  dom.window.close();
});

test('Bundled assets match pinned manifest and font URLs resolve locally', () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(renderer, 'vendor/manifest.json')));
  assert.equal(manifest.packages.length, 3);
  for (const file of manifest.files) {
    const bytes = fs.readFileSync(path.join(renderer, 'vendor', file.path));
    assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), file.sha256, file.path);
  }
  const css = fs.readFileSync(path.join(renderer, 'vendor/katex/katex.min.css'), 'utf8');
  for (const match of css.matchAll(/url\(([^)]+)\)/g)) {
    assert.ok(!/^https?:/.test(match[1]));
    assert.ok(fs.existsSync(path.join(renderer, 'vendor/katex', match[1])));
  }
  const html = fs.readFileSync(path.join(renderer, 'index.html'), 'utf8');
  assert.ok(html.includes("connect-src 'none'"));
  assert.ok(html.includes("img-src 'none'"));
  assert.ok(html.includes("frame-src 'none'"));
  assert.ok(!/<(?:script|link)[^>]+(?:src|href)="https?:/i.test(html));
});

test('Copy formula-only selection emits LaTeX once and removes rich clipboard data', () => {
  const { dom, window, root } = environment();
  window.renderMessage(String.raw`\(a^2+b^2=c^2\)`);
  const range = window.document.createRange();
  range.selectNode(root.querySelector('.katex'));
  const result = copyRange(window, range);
  assert.equal(result.text, String.raw`\(a^2+b^2=c^2\)`);
  assert.equal(result.prevented, true);
  assert.equal(result.clears, 1);
  assert.deepEqual([...result.values.keys()], ['text/plain']);
  dom.window.close();
});

test('Copy a partial visual formula expands only the clipboard, not visible selection', () => {
  const { dom, window, root } = environment();
  window.renderMessage(String.raw`Before \(a^2+b^2=c^2\) after.`);
  const text = firstVisualText(window, root.querySelector('.katex'));
  const range = window.document.createRange();
  range.setStart(text, 0); range.setEnd(text, 1);
  const result = copyRange(window, range);
  assert.equal(result.text, String.raw`\(a^2+b^2=c^2\)`);
  const retained = window.getSelection().getRangeAt(0);
  assert.equal(retained.startContainer, text);
  assert.equal(retained.startOffset, 0);
  assert.equal(retained.endContainer, text);
  assert.equal(retained.endOffset, 1);
  dom.window.close();
});

test('Copy a partial display formula uses display delimiters', () => {
  const { dom, window, root } = environment();
  window.renderMessage(String.raw`\[\sqrt{s(s-a)(s-b)(s-c)}\]`);
  const text = firstVisualText(window, root.querySelector('.katex'));
  const range = window.document.createRange();
  range.setStart(text, 0); range.setEnd(text, 1);
  const result = copyRange(window, range);
  assert.equal(result.text, String.raw`\[\sqrt{s(s-a)(s-b)(s-c)}\]`);
  dom.window.close();
});

test('Copy mixed prose, multiple and adjacent formulas, and literal inline code', () => {
  const { dom, window, root } = environment();
  window.renderMessage('Given $a$ and $b$, use $a+b$. Adjacent: \\(x\\)\\(y\\). Code: `\\(literal\\)`.');
  const range = window.document.createRange();
  range.selectNodeContents(root);
  const result = copyRange(window, range);
  assert.equal(result.text, String.raw`Given \(a\) and \(b\), use \(a+b\). Adjacent: \(x\)\(y\). Code: \(literal\).`);
  assert.equal(result.values.has('text/html'), false);
  dom.window.close();
});

test('Copy mixed partial endpoints keeps selected prose and complete endpoint formulas', () => {
  const { dom, window, root } = environment();
  window.renderMessage(String.raw`Start \(a+b\), middle, \(c+d\) end.`);
  const maths = root.querySelectorAll('.katex');
  const start = firstVisualText(window, maths[0]);
  const end = firstVisualText(window, maths[1]);
  const range = window.document.createRange();
  range.setStart(start, 0); range.setEnd(end, 1);
  assert.equal(copyRange(window, range).text, String.raw`\(a+b\), middle, \(c+d\)`);
  dom.window.close();
});

test('Copy preserves paragraph, list, table breaks and exact fenced-code whitespace', () => {
  const { dom, window, root } = environment();
  window.renderMessage('First $x$.\n\nSecond paragraph.\n\n- one $a$\n- two\n\n| A | B |\n|---|---|\n| $b$ | c |\n\n```js\n  const x = 1;\n\n    // \\(literal\\)\n```');
  const range = window.document.createRange(); range.selectNodeContents(root);
  const text = copyRange(window, range).text;
  assert.ok(text.includes('First \\(x\\).\n\nSecond paragraph.'));
  assert.ok(text.includes('- one \\(a\\)\n- two'));
  assert.ok(text.includes('A\tB\n\\(b\\)\tc'), JSON.stringify(text));
  assert.ok(text.includes('  const x = 1;\n\n    // \\(literal\\)\n'));
  dom.window.close();
});

test('Copy preserves ordered-list numbering in mixed formula selections', () => {
  const { dom, window, root } = environment();
  window.renderMessage('4. Compute $s$.\n5. Evaluate $A$.');
  const range = window.document.createRange(); range.selectNodeContents(root);
  assert.equal(copyRange(window, range).text, '4. Compute \\(s\\).\n5. Evaluate \\(A\\).');
  dom.window.close();
});

test('Partial ordered-list copy keeps live numbering when earlier siblings are omitted', () => {
  const { dom, window, root } = environment();
  window.renderMessage('3. First\n4. Second $x$\n5. Third\n\nEnd.');
  const items = root.querySelectorAll('li');
  const range = window.document.createRange();
  range.setStart(items[1].firstChild, 0);
  range.setEndAfter(root.querySelector('p'));
  assert.equal(copyRange(window, range).text, '4. Second \\(x\\)\n5. Third\n\nEnd.');
  dom.window.close();
});

test('Selected list items preserve markers when the enclosing list is outside the clone', () => {
  const { dom, window, root } = environment();
  window.renderMessage('3. First\n4. Second $x$\n5. Third');
  const list = root.querySelector('ol');
  const items = list.querySelectorAll('li');
  const range = window.document.createRange();
  range.setStartBefore(items[1]); range.setEndAfter(items[2]);
  assert.equal(copyRange(window, range).text, '4. Second \\(x\\)\n5. Third');
  dom.window.close();
});

test('Copy multiple display and inline formulas preserves annotation source', () => {
  const { dom, window, root } = environment();
  window.renderMessage('Inline $x$.\n\n$$\na^2+b^2=c^2\n$$\n\nThen \\(y\\).\n\n```math\n\\frac{a}{b}\n```');
  const range = window.document.createRange(); range.selectNodeContents(root);
  const text = copyRange(window, range).text;
  assert.equal(text, 'Inline \\(x\\).\n\n\\[\na^2+b^2=c^2\n\\]\n\nThen \\(y\\).\n\n\\[\\frac{a}{b}\\]');
  dom.window.close();
});

test('Copy without math or with an empty selection leaves native behavior untouched', () => {
  const { dom, window, root } = environment();
  window.renderMessage('Plain **text** and `\\(code\\)` before $x$.');
  const range = window.document.createRange(); range.selectNodeContents(root.querySelector('strong'));
  let result = copyRange(window, range);
  assert.equal(result.prevented, false); assert.equal(result.clears, 0); assert.equal(result.text, undefined);
  range.selectNodeContents(root.querySelector('code'));
  result = copyRange(window, range);
  assert.equal(result.prevented, false); assert.equal(result.clears, 0);
  range.collapse(true);
  result = copyRange(window, range);
  assert.equal(result.prevented, false); assert.equal(result.clears, 0);
  dom.window.close();
});

test('Scroll bridge reports clamped finite metrics after render and scroll', async () => {
  const { dom, window, root, messages } = environment();
  Object.defineProperty(root, 'scrollHeight', { configurable: true, value: 20000 });
  Object.defineProperty(root, 'clientHeight', { configurable: true, value: 10000 });
  window.renderMessage('message');
  await new Promise(resolve => setTimeout(resolve, 35));
  let state = messages.filter(message => message.type === 'scrollState').at(-1);
  assert.equal(state.scrollTop, 0); assert.equal(state.scrollHeight, 20000); assert.equal(state.clientHeight, 10000);
  root.scrollTop = 15000;
  root.dispatchEvent(new window.Event('scroll'));
  await new Promise(resolve => setTimeout(resolve, 35));
  state = messages.filter(message => message.type === 'scrollState').at(-1);
  assert.equal(state.scrollTop, 10000);
  root.scrollTop = -12;
  root.dispatchEvent(new window.Event('scroll'));
  await new Promise(resolve => setTimeout(resolve, 35));
  state = messages.filter(message => message.type === 'scrollState').at(-1);
  assert.equal(state.scrollTop, 0);
  dom.window.close();
});

test('Every replacement message refreshes scroll metrics even when dimensions are unchanged', async () => {
  const { dom, window, root, messages } = environment();
  root.getBoundingClientRect = () => ({ height: 10000 });
  Object.defineProperty(root, 'scrollHeight', { configurable: true, value: 20000 });
  Object.defineProperty(root, 'clientHeight', { configurable: true, value: 10000 });
  window.renderMessage('first');
  await new Promise(resolve => setTimeout(resolve, 35));
  const scrollCount = messages.filter(message => message.type === 'scrollState').length;
  const heightCount = messages.filter(message => message.type === 'height').length;
  window.renderMessage('second');
  await new Promise(resolve => setTimeout(resolve, 35));
  assert.equal(messages.filter(message => message.type === 'scrollState').length, scrollCount + 1);
  assert.equal(messages.filter(message => message.type === 'height').length, heightCount);
  dom.window.close();
});
