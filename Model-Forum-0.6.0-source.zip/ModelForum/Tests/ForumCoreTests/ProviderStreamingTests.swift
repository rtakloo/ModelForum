import Foundation
import XCTest
@testable import ForumCore

private actor DeltaProbe {
    var values: [String] = []
    func append(_ value: String) { values.append(value) }
}
final class ProviderStreamingTests: XCTestCase {
    private var session: URLSession!
    private var client: ProviderClient!
    override func setUp() {
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [StreamingStubProtocol.self]
        session = URLSession(configuration: config)
        client = ProviderClient(session: session)
    }
    override func tearDown() {
        session.invalidateAndCancel(); client = nil; session = nil
        StreamingStubProtocol.handler = nil
    }
    private var participant: Participant { Participant(alias: "test", provider: .openAI, model: "test-model") }
    private let completed = #"{"type":"response.completed","response":{"status":"completed","model":"actual-model","output":[{"type":"message","role":"assistant","status":"completed","content":[{"type":"output_text","text":"Hello 🌍"}]}],"usage":{"input_tokens":17,"output_tokens":9}}}"#
    private func event(_ json: String) -> String { "data: " + json + "\n\n" }
    func testRealStreamRequestYieldsDeltasAndAcceptsOnlyFinalUsageAndText() async throws {
        let probe = DeltaProbe()
        let fixture = ": keepalive\r\n\r\n" + event(#"{"type":"response.reasoning_text.delta","delta":"private reasoning"}"#) + event(#"{"type":"response.output_text.delta","delta":"Hello "}"#) + event(#"{"type":"response.function_call_arguments.delta","delta":"private tool args"}"#) + event(#"{"type":"response.output_text.delta","delta":"🌍"}"#) + event(completed)
        StreamingStubProtocol.handler = { request in
            XCTAssertEqual(request.value(forHTTPHeaderField: "Accept"), "text/event-stream")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-secret")
            let body = try Self.body(request)
            XCTAssertEqual(body["stream"] as? Bool, true)
            XCTAssertEqual(body["store"] as? Bool, false)
            XCTAssertNil(body["tools"])
            return (200, "text/event-stream; charset=utf-8", Data(fixture.utf8))
        }
        let reply = try await client.reply(participant: participant, transcript: "private prompt", apiKey: "test-secret", maxOutputTokens: 100, onDelta: { await probe.append($0) })
        let deltas = await probe.values
        XCTAssertEqual(deltas, ["Hello ", "🌍"])
        XCTAssertEqual(reply.text, "Hello 🌍")
        XCTAssertEqual(reply.model, "actual-model")
        XCTAssertEqual(reply.inputTokens, 17)
        XCTAssertEqual(reply.outputTokens, 9)
    }
    func testEOFAndFailureNeverPromotePartialOutputOrEchoProviderErrors() async {
        let fixtures = [
            event(#"{"type":"response.output_text.delta","delta":"partial"}"#),
            event(#"{"type":"response.output_text.delta","delta":"partial"}"#) + event(#"{"type":"error","message":"test-secret private prompt"}"#),
            event(#"{"type":"response.failed","response":{"error":{"message":"test-secret private prompt"}}}"#),
            "event: response.completed\ndata: {\"type\":\"response.output_text.delta\",\"delta\":\"test-secret private prompt\"}\n\n"
        ]
        for fixture in fixtures {
            StreamingStubProtocol.handler = { _ in (200, "text/event-stream", Data(fixture.utf8)) }
            do {
                _ = try await client.reply(participant: participant, transcript: "private prompt", apiKey: "test-secret", maxOutputTokens: 100, onDelta: { _ in })
                XCTFail("Expected stream failure")
            } catch {
                XCTAssertTrue(error is ForumError)
                XCTAssertFalse(error.localizedDescription.contains("test-secret"))
                XCTAssertFalse(error.localizedDescription.contains("private prompt"))
            }
        }
    }
    func testIncompleteStreamPreservesOutputLimitExplanation() async {
        let fixture = event(#"{"type":"response.incomplete","response":{"status":"incomplete","incomplete_details":{"reason":"max_output_tokens"}}}"#)
        StreamingStubProtocol.handler = { _ in (200, "text/event-stream", Data(fixture.utf8)) }
        do {
            _ = try await client.reply(participant: participant, transcript: "prompt", apiKey: "test-secret", maxOutputTokens: 2048, onDelta: { _ in })
            XCTFail("Expected incomplete response")
        } catch {
            XCTAssertTrue(error.localizedDescription.contains("2048 output tokens"))
            XCTAssertTrue(error.localizedDescription.contains("No completed answer was accepted"))
        }
    }
    func testHTTPQuotaIsSanitizedAndWrongContentTypeRejected() async {
        StreamingStubProtocol.handler = { _ in (429, "application/json", Data(#"{"error":{"code":"insufficient_quota","message":"test-secret private prompt"}}"#.utf8)) }
        do {
            _ = try await client.reply(participant: participant, transcript: "prompt", apiKey: "test-secret", maxOutputTokens: 100, onDelta: { _ in })
            XCTFail("Expected quota failure")
        } catch { XCTAssertTrue(error.localizedDescription.contains("insufficient account quota")); XCTAssertFalse(error.localizedDescription.contains("test-secret")) }
        StreamingStubProtocol.handler = { _ in (200, "application/json", Data("test-secret".utf8)) }
        do {
            _ = try await client.reply(participant: participant, transcript: "prompt", apiKey: "test-secret", maxOutputTokens: 100, onDelta: { _ in })
            XCTFail("Expected content type failure")
        } catch { XCTAssertTrue(error.localizedDescription.contains("did not return an event stream")) }
    }
    func testCancellationDuringDeltaPreventsCompletedReply() async {
        let fixture = event(#"{"type":"response.output_text.delta","delta":"partial"}"#) + event(completed)
        StreamingStubProtocol.handler = { _ in (200, "text/event-stream", Data(fixture.utf8)) }
        let client = self.client!
        let participant = self.participant
        let task = Task {
            try await client.reply(participant: participant, transcript: "prompt", apiKey: "test-secret", maxOutputTokens: 100, onDelta: { _ in
                withUnsafeCurrentTask { $0?.cancel() }
            })
        }
        do { _ = try await task.value; XCTFail("Expected cancellation") }
        catch { XCTAssertTrue(error is CancellationError) }
    }
    func testFramingHandlesCRLFSplitUnicodeAndMultilineData() throws {
        var parser = ProviderSSEParser()
        let source = ": ping\r\n\r\nevent: example\r\ndata: {\"text\":\r\ndata: \"🌍\"}\r\n\r\n"
        var events: [ProviderSSEEvent] = []
        for byte in source.utf8 { if let event = try parser.append(byte) { events.append(event) } }
        XCTAssertEqual(events.count, 1)
        XCTAssertEqual(events[0].name, "example")
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: events[0].data) as? [String: String])
        XCTAssertEqual(object["text"], "🌍")
    }
    func testMalformedUTF8AndBoundedLineEventTotalRejectWithoutUnboundedAllocation() throws {
        var parser = ProviderSSEParser(lineLimit: 20, eventLimit: 30, totalLimit: 100)
        XCTAssertThrowsError(try Array(repeating: UInt8(65), count: 21).forEach { _ = try parser.append($0) })
        parser = ProviderSSEParser(lineLimit: 30, eventLimit: 10, totalLimit: 100)
        XCTAssertThrowsError(try "data: 123456\ndata: 123456\n".utf8.forEach { _ = try parser.append($0) })
        parser = ProviderSSEParser(lineLimit: 30, eventLimit: 30, totalLimit: 10)
        XCTAssertThrowsError(try ":a\n:a\n:a\n:a\n".utf8.forEach { _ = try parser.append($0) })
        parser = ProviderSSEParser()
        _ = try parser.append(0xFF)
        XCTAssertThrowsError(try parser.append(10))
    }
    private static func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while stream.hasBytesAvailable {
                let count = stream.read(&buffer, maxLength: buffer.count)
                if count <= 0 { break }
                data.append(buffer, count: count)
            }
        }
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
    }
}

private final class StreamingStubProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, String, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            guard let handler = Self.handler else { throw URLError(.unknown) }
            let (status, contentType, body) = try handler(request)
            let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: "HTTP/1.1", headerFields: ["Content-Type": contentType])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            // Deliberately split UTF-8 and SSE records at arbitrary byte boundaries.
            var offset = 0
            while offset < body.count {
                let end = min(offset + 7, body.count)
                client?.urlProtocol(self, didLoad: body.subdata(in: offset..<end))
                offset = end
            }
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}
