import XCTest
@testable import ForumCore

private actor GitHubReviewFixture {
    struct Call { let path: String; let method: String; let body: Data; let accept: String }
    var replies: [Data]
    var calls: [Call] = []
    init(_ values: [String]) { replies = values.map { Data($0.utf8) } }
    func send(_ path: String, _ method: String, _ body: Data, _ accept: String) throws -> Data {
        calls.append(.init(path: path, method: method, body: body, accept: accept))
        guard !replies.isEmpty else { throw GitHubAppError.invalidResponse }
        return replies.removeFirst()
    }
}
final class GitHubReviewClientTests: XCTestCase {
    private let first = String(repeating: "a", count: 40)
    private let second = String(repeating: "b", count: 40)
    private func reference(_ sha: String) -> String { "{\"object\":{\"type\":\"commit\",\"sha\":\"\(sha)\"}}" }
    private func client(_ fixture: GitHubReviewFixture) -> GitHubReviewClient {
        .init { path, method, body, accept in try await fixture.send(path, method, body, accept) }
    }
    func testPinnedDiffThenExplicitCreateWithJSONBodyAndExistingCheck() async throws {
        let fixture = GitHubReviewFixture([reference(first), reference(second), "diff --git a/a b/a\n+hello", reference(first), reference(second), "[]", "{\"number\":7}"])
        let client = client(fixture)
        let review = try await client.preview(repository: "owner/repo", base: "main", head: "feature/topic")
        var calls = await fixture.calls
        XCTAssertEqual(calls.count, 3)
        XCTAssertTrue(calls.allSatisfy { $0.method == "GET" })
        XCTAssertEqual(calls[1].path, "repos/owner/repo/git/ref/heads/feature%2Ftopic")
        XCTAssertEqual(calls[2].path, "repos/owner/repo/compare/\(first)...\(second)")
        let result = try await client.create(review: review, title: "A title", body: "Body\ntext")
        XCTAssertEqual(result.url.absoluteString, "https://github.com/owner/repo/pull/7")
        calls = await fixture.calls
        XCTAssertEqual(calls.last?.method, "POST")
        XCTAssertTrue(calls[5].path.contains("head=owner%3Afeature%2Ftopic"))
        let body = try XCTUnwrap(try JSONSerialization.jsonObject(with: calls.last!.body) as? [String: Any])
        XCTAssertEqual(body["head"] as? String, "feature/topic")
        XCTAssertEqual(body["draft"] as? Bool, true)
        XCTAssertEqual(body["body"] as? String, "Body\ntext")
    }
    func testChangedBranchRequiresReviewAgainNoWrite() async throws {
        let fixture = GitHubReviewFixture([reference(first), reference(second), "diff", reference(first), reference(String(repeating: "c", count: 40))])
        let client = client(fixture)
        let review = try await client.preview(repository: "owner/repo", base: "main", head: "feature")
        do { _ = try await client.create(review: review, title: "Title", body: ""); XCTFail() }
        catch { XCTAssertTrue(error.localizedDescription.contains("changed since")) }
        let calls = await fixture.calls
        XCTAssertTrue(calls.allSatisfy { $0.method == "GET" })
    }
    func testExistingPullRequestReturnsWithoutDuplicateWrite() async throws {
        let fixture = GitHubReviewFixture([reference(first), reference(second), "diff", reference(first), reference(second), "[{\"number\":4}]"])
        let client = client(fixture)
        let review = try await client.preview(repository: "owner/repo", base: "main", head: "feature")
        let result = try await client.create(review: review, title: "Title", body: "")
        XCTAssertTrue(result.alreadyExists)
        let calls = await fixture.calls
        XCTAssertTrue(calls.allSatisfy { $0.method == "GET" })
    }
    func testPRDiffBoundAndHostValidation() async throws {
        let fixture = GitHubReviewFixture([String(repeating: "x", count: 524_289)])
        do { _ = try await client(fixture).pullRequestDiff(url: "https://github.com/owner/repo/pull/1"); XCTFail() }
        catch { XCTAssertEqual(error as? GitHubAppError, .tooLarge) }
        let other = GitHubReviewFixture([])
        for url in ["https://attacker.invalid/owner/repo/pull/1", "https://github.com/owner/repo", "https://github.com/owner/repo/issues/1"] {
            do { _ = try await client(other).pullRequestDiff(url: url); XCTFail() } catch {}
        }
        let calls = await other.calls
        XCTAssertTrue(calls.isEmpty)
    }
    func testUnsafeBranchesFailBeforeNetworkAndMalformedSHARejected() async throws {
        let other = GitHubReviewFixture([])
        for head in ["--danger", "a..b", "a/../b", "a?ref=x", "a\nb", "a.lock", "a//b"] {
            do { _ = try await client(other).preview(repository: "owner/repo", base: "main", head: head); XCTFail(head) } catch {}
        }
        let calls = await other.calls
        XCTAssertTrue(calls.isEmpty)
        let malformed = GitHubReviewFixture([reference("not-a-sha")])
        do { _ = try await client(malformed).preview(repository: "owner/repo", base: "main", head: "feature"); XCTFail() }
        catch { XCTAssertEqual(error as? GitHubAppError, .invalidResponse) }
    }
}
