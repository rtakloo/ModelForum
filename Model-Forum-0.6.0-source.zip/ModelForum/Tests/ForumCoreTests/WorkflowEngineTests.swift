import XCTest
@testable import ForumCore

private actor WorkflowProbe {
    var requests: [WorkflowRequest] = []
    var results: [WorkflowStepResult] = []
    func request(_ value: WorkflowRequest, answer: String? = nil) -> ModelReply {
        requests.append(value)
        return ModelReply(text: answer ?? "answer-\(value.stepIndex)", model: value.participant.model, inputTokens: 20, outputTokens: 5)
    }
    func progress(_ value: WorkflowStepResult) { results.append(value) }
}
final class WorkflowEngineTests: XCTestCase {
    private func definition(rounds: Int = 1, budget: Int = 300, marker: String? = nil) -> WorkflowDefinition {
        WorkflowDefinition(draft: Participant(alias: "writer", provider: .openAI, model: "writer-model"), critic: Participant(alias: "critic", provider: .anthropic, model: "critic-model"), reviser: Participant(alias: "editor", provider: .openAI, model: "editor-model"), rounds: rounds, perStepOutputTokens: 100, totalOutputTokenBudget: budget, stopMarker: marker)
    }
    func testOrderedRolesPreserveOriginalContextAndCompletedStepProvenance() async throws {
        let probe = WorkflowProbe(); let context = [UUID(), UUID()]
        let run = try await WorkflowEngine.run(definition: definition(), input: "Original request", contextMessageIDs: context, request: { await probe.request($0) }, onProgress: { await probe.progress($0) })
        let requests = await probe.requests
        XCTAssertEqual(requests.map(\.role), [.draft, .critique, .revise])
        XCTAssertEqual(requests.map { $0.participant.model }, ["writer-model", "critic-model", "editor-model"])
        XCTAssertTrue(requests.allSatisfy { $0.originalInput == "Original request" && $0.contextMessageIDs == context })
        XCTAssertTrue(requests[1].transcript.contains("answer-0"))
        XCTAssertTrue(requests[2].transcript.contains("answer-0"))
        XCTAssertTrue(requests[2].transcript.contains("answer-1"))
        XCTAssertEqual(requests[2].previousStepIDs, Array(run.steps.prefix(2)).map(\.id))
        XCTAssertEqual(run.steps.map(\.maxOutputTokens).reduce(0, +), 300)
        XCTAssertEqual(run.stopReason, .completed)
        let restored = try JSONDecoder().decode(WorkflowRun.self, from: JSONEncoder().encode(run))
        XCTAssertEqual(restored.steps.map(\.transcript), run.steps.map(\.transcript))
        XCTAssertEqual(restored.originalInput, run.originalInput)
    }
    func testBudgetBoundsCallsEvenWithoutUsageAndLimitsLastStep() async throws {
        let probe = WorkflowProbe()
        let run = try await WorkflowEngine.run(definition: definition(rounds: 5, budget: 250), input: "Question", contextMessageIDs: [], request: { request in
            _ = await probe.request(request)
            return ModelReply(text: "answer", model: request.participant.model)
        })
        XCTAssertEqual(run.steps.map(\.maxOutputTokens), [100, 100, 50])
        XCTAssertEqual(run.stopReason, .outputBudget)
        let requests = await probe.requests
        XCTAssertEqual(requests.count, 3)
    }
    func testRoundsOnlyWorkflowDoesNotPretendToCapSubscriptionOutput() async throws {
        var definition = definition(rounds: 2, budget: 100)
        definition.enforceOutputBudget = false
        let run = try await WorkflowEngine.run(definition: definition, input: "Question", contextMessageIDs: [], request: { value in
            ModelReply(text: "answer", model: value.participant.model, outputTokens: 1000)
        })
        XCTAssertEqual(run.steps.count, 5)
        XCTAssertTrue(run.steps.allSatisfy { $0.maxOutputTokens == 100 })
        XCTAssertEqual(run.stopReason, .completed)
    }
    func testOnlyExactCriticMarkerStopsBeforeRevision() async throws {
        let probe = WorkflowProbe()
        let run = try await WorkflowEngine.run(definition: definition(marker: "APPROVED"), input: "Question", contextMessageIDs: [], request: { value in await probe.request(value, answer: value.role == .critique ? " APPROVED\n" : "Draft") })
        XCTAssertEqual(run.stopReason, .stopMarker)
        XCTAssertEqual(run.steps.count, 2)
        let continues = try await WorkflowEngine.run(definition: definition(marker: "APPROVED"), input: "Question", contextMessageIDs: [], request: { value in ModelReply(text: "The text contains APPROVED but needs revision", model: value.participant.model) })
        XCTAssertEqual(continues.steps.count, 3)
        XCTAssertEqual(continues.stopReason, .completed)
    }
    func testProgressPersistenceFailureStopsBeforeNextRequest() async {
        let probe = WorkflowProbe()
        do {
            _ = try await WorkflowEngine.run(definition: definition(), input: "Question", contextMessageIDs: [], request: { await probe.request($0) }, onProgress: { _ in throw ForumError.message("Mock persistence failed") })
            XCTFail("Expected persistence failure")
        } catch { XCTAssertTrue(error.localizedDescription.contains("Mock persistence")) }
        let requests = await probe.requests
        XCTAssertEqual(requests.count, 1)
    }
    func testInvalidDefinitionFailsWithoutRequestAndCancellationPropagates() async {
        var invalid = definition(); invalid.rounds = 100
        do {
            _ = try await WorkflowEngine.run(definition: invalid, input: "Question", contextMessageIDs: [], request: { _ in XCTFail("Invalid workflow made a request"); throw CancellationError() })
            XCTFail("Expected validation failure")
        } catch { XCTAssertTrue(error is ForumError) }
        let valid = definition()
        let task = Task {
            try await WorkflowEngine.run(definition: valid, input: "Question", contextMessageIDs: [], request: { _ in throw CancellationError() })
        }
        do { _ = try await task.value; XCTFail("Expected cancellation") }
        catch { XCTAssertTrue(error is CancellationError) }
    }
    func testProviderFailureDoesNotInventCompletedStepOrContinue() async {
        let probe = WorkflowProbe()
        do {
            _ = try await WorkflowEngine.run(definition: definition(), input: "Question", contextMessageIDs: [], request: { value in
                if value.role == .critique { throw ForumError.message("Incomplete provider output") }
                return await probe.request(value)
            }, onProgress: { await probe.progress($0) })
            XCTFail("Expected provider failure")
        } catch { XCTAssertTrue(error is ForumError) }
        let results = await probe.results
        XCTAssertEqual(results.map(\.role), [.draft])
    }
}
