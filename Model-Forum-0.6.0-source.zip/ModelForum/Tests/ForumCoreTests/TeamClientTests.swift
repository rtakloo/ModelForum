import XCTest
@testable import ForumCore

final class TeamClientTests: XCTestCase {
    func testSharingWhitelistsVisibleConversationAndExcludesProvenanceAndWorkspaceFields() throws {
        let message = ChatMessage(role: "assistant", author: "@gpt", content: "Visible answer", model: "test-model", inputTokens: 100,
                                  contextMessageIDs: [UUID()], provider: .openAI, requestContext: "PRIVATE GLOBAL INSTRUCTION", critiqueMessageID: UUID())
        let conversation = Conversation(title: "Chosen conversation", messages: [message], channelID: UUID())
        let shared = try TeamSharedConversation(conversation)
        let data = try JSONEncoder().encode(shared)
        let raw = try XCTUnwrap(String(data: data, encoding: .utf8))
        XCTAssertTrue(raw.contains("Visible answer"))
        for excluded in ["PRIVATE GLOBAL INSTRUCTION", "requestContext", "channelID", "contextMessageIDs", "critiqueMessageID", "providerAccountLabels", "apiKey", "globalInstructions", "inputTokens"] {
            XCTAssertFalse(raw.contains(excluded), excluded)
        }
        let object = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
        XCTAssertEqual(Set(object.keys), ["title", "messages"])
        let copy = try shared.localCopy()
        XCTAssertNotEqual(copy.id, conversation.id)
        XCTAssertNotEqual(copy.messages[0].id, message.id)
        XCTAssertNil(copy.channelID); XCTAssertNil(copy.messages[0].requestContext)
        XCTAssertEqual(copy.messages[0].content, message.content)
    }
    func testTeamOriginsNeverAcceptInsecureRemoteOrEmbeddedCredentialsOrPaths() throws {
        for good in ["https://team.example.test", "https://team.example.test/", "http://127.0.0.1:8765", "http://localhost:8765"] {
            XCTAssertNoThrow(try TeamEndpoint.normalized(good))
        }
        for bad in ["http://team.example.test", "https://u:p@team.example.test", "https://team.example.test/private", "https://team.example.test?secret=x", "https://team.example.test#fragment", "file:///tmp/test", "http://127.0.0.1.attacker.test"] {
            XCTAssertThrowsError(try TeamEndpoint.normalized(bad), bad)
        }
    }
    func testSharedPathIDsCannotChangeDestinationAndBillingOnlyOpensStripeHTTPS() throws {
        XCTAssertEqual(try TeamEndpoint.pathID("topic_1-v2"), "topic_1-v2")
        for bad in ["../secrets", "a/b", "a?x", "a%2Fb", "", String(repeating: "x", count: 81)] { XCTAssertThrowsError(try TeamEndpoint.pathID(bad)) }
        XCTAssertNoThrow(try TeamEndpoint.billingURL("https://checkout.stripe.com/c/pay/example"))
        XCTAssertNoThrow(try TeamEndpoint.billingURL("https://billing.stripe.com/p/session/example"))
        for bad in ["http://checkout.stripe.com/a", "https://checkout.stripe.com.attacker.test/a", "https://u:p@checkout.stripe.com/a", "https://checkout.stripe.com:444/a", "javascript:alert(1)"] { XCTAssertThrowsError(try TeamEndpoint.billingURL(bad)) }
    }
    func testOversizedOrUnsupportedConversationCannotBePublished() throws {
        XCTAssertThrowsError(try TeamSharedConversation(Conversation(title: String(repeating: "x", count: 161))))
        let invalid = ChatMessage(role: "tool", author: "Tool", content: "Unsupported tool result")
        XCTAssertThrowsError(try TeamSharedConversation(Conversation(messages: [invalid])))
        let tooMany = (0..<501).map { _ in ChatMessage(role: "user", author: "You", content: "x") }
        XCTAssertThrowsError(try TeamSharedConversation(Conversation(messages: tooMany)))
        let huge = (0..<3).map { _ in ChatMessage(role: "user", author: "You", content: String(repeating: "x", count: 180_000)) }
        XCTAssertThrowsError(try TeamSharedConversation(Conversation(messages: huge)))
    }
}
