import XCTest
@testable import ForumCore

private actor LaTeXRunnerFixture {
    enum Mode: Sendable { case success, fail, sandboxFailure, cancelled, timeout, malformed, oversized, symlink }
    private let mode: Mode
    private(set) var invocations = [LaTeXCompiler.Invocation]()
    init(_ mode: Mode) { self.mode = mode }
    func run(_ invocation: LaTeXCompiler.Invocation) throws -> SubprocessResult {
        invocations.append(invocation)
        let output = invocation.directory.appendingPathComponent("document.pdf")
        switch mode {
        case .cancelled: throw CancellationError()
        case .timeout: throw SubprocessError.timedOut
        case .fail: return SubprocessResult(stdout: Data("user text that should not enter error messages".utf8), stderr: Data(), status: 1)
        case .sandboxFailure: return SubprocessResult(stdout: Data(), stderr: Data("sandbox-exec: sandbox_init: Operation not permitted".utf8), status: 1)
        case .malformed: try Data("not a PDF document".utf8).write(to: output)
        case .oversized: try Data(repeating: 0, count: 8 * 1_024 * 1_024 + 1).write(to: output)
        case .symlink:
            if !FileManager.default.fileExists(atPath: output.path) {
                try FileManager.default.createSymbolicLink(at: output, withDestinationURL: invocation.directory.appendingPathComponent("document.tex"))
            }
        case .success: try Data("%PDF-1.4\nfixture output\n%%EOF\n".utf8).write(to: output)
        }
        return SubprocessResult(stdout: Data(), stderr: Data(), status: 0)
    }
}

final class LaTeXCompilerTests: XCTestCase {
    private var configuration: LaTeXCompiler.Configuration {
        .init(engine: URL(fileURLWithPath: "/usr/local/texlive/2021/bin/universal-darwin/pdftex"),
              texRoot: URL(fileURLWithPath: "/usr/local/texlive/2021"), sandbox: URL(fileURLWithPath: "/usr/bin/sandbox-exec"))
    }
    private let source = Data(#"\documentclass{article}\begin{document}Hello\end{document}"#.utf8)
    private func compiler(_ fixture: LaTeXRunnerFixture) -> LaTeXCompiler {
        LaTeXCompiler(configuration: configuration) { invocation in try await fixture.run(invocation) }
    }

    func testInstalledCompilerBenignSmokeWhenExplicitlyEnabled() async throws {
        guard ProcessInfo.processInfo.environment["MODEL_FORUM_TEST_LATEX"] == "1" else {
            throw XCTSkip("Set MODEL_FORUM_TEST_LATEX=1 to run the installed sandboxed engine smoke test.")
        }
        guard LaTeXCompiler.isAvailable else { throw XCTSkip(LaTeXCompiler.status) }
        let pdf = try await LaTeXCompiler().compile(source: source, filename: "smoke.tex")
        XCTAssertTrue(pdf.data.starts(with: Data("%PDF-".utf8)))
        XCTAssertEqual(pdf.filename, "smoke.pdf")
    }

    func testTwoPassCompilationAndJobCleanup() async throws {
        let fixture = LaTeXRunnerFixture(.success)
        let result = try await compiler(fixture).compile(source: source, filename: "my paper.tex")
        XCTAssertEqual(result.filename, "my paper.pdf")
        XCTAssertEqual(result.mimeType, "application/pdf")
        XCTAssertTrue(result.data.starts(with: Data("%PDF-".utf8)))
        let invocations = await fixture.invocations
        XCTAssertEqual(invocations.count, 2)
        XCTAssertTrue(invocations[0].directory.path.hasPrefix("/private/tmp/ModelForum-TeX-"))
        XCTAssertEqual(invocations[0].directory, invocations[1].directory)
        XCTAssertFalse(FileManager.default.fileExists(atPath: invocations[0].directory.path))
    }

    func testEngineAlwaysRunsThroughSandboxWithShellEscapeDisabled() {
        let directory = URL(fileURLWithPath: "/private/tmp/latex-fixture")
        let invocation = LaTeXCompiler.invocation(configuration: configuration, directory: directory)
        XCTAssertEqual(invocation.executable.path, "/bin/sh")
        XCTAssertEqual(invocation.arguments[1], "ulimit -f 16384 && ulimit -t 30 && exec \"$@\"")
        XCTAssertEqual(invocation.arguments[3], "/usr/bin/sandbox-exec")
        XCTAssertEqual(invocation.arguments[4], "-p")
        XCTAssertEqual(invocation.arguments[6], configuration.engine.path)
        for flag in ["-no-shell-escape", "-no-parse-first-line", "-halt-on-error", "-no-mktex=tex", "-no-mktex=tfm", "-no-mktex=pk"] {
            XCTAssertTrue(invocation.arguments.contains(flag))
        }
        XCTAssertEqual(invocation.arguments.last, "document.tex")
        XCTAssertNil(invocation.environment["HOME"])
        XCTAssertEqual(invocation.environment["TMPDIR"], directory.path)
        XCTAssertEqual(invocation.environment["shell_escape"], "f")
        XCTAssertEqual(invocation.environment["openout_any"], "p")
        XCTAssertEqual(invocation.environment["MKTEXFMT"], "0")
        XCTAssertNil(invocation.environment["OPENAI_API_KEY"])
        XCTAssertNil(invocation.environment["ENV"])
        XCTAssertEqual(invocation.timeout, 40)
        XCTAssertEqual(invocation.outputLimit, 1_048_576)
    }

    func testProfileDeniesNetworkHomeReadsAndArbitraryWritesOrChildren() {
        let profile = LaTeXCompiler.sandboxProfile(configuration: configuration, directory: URL(fileURLWithPath: "/private/tmp/job"))
        XCTAssertTrue(profile.contains("(deny default)"))
        XCTAssertTrue(profile.contains("(deny network*)"))
        XCTAssertTrue(profile.contains("(deny process-fork)"))
        XCTAssertTrue(profile.contains("(allow process-exec (literal \"\(configuration.engine.path)\"))"))
        XCTAssertTrue(profile.contains("(subpath \"/usr/local/texlive/2021\")"))
        XCTAssertFalse(profile.contains("/Users/"))
        XCTAssertFalse(profile.contains("(allow network"))
        XCTAssertFalse(profile.contains("(allow file-read*)"))
        XCTAssertFalse(profile.contains("(allow file-write* (subpath"))
        let mappings = profile.split(separator: "\n").first { $0.contains("(allow file-map-executable") }!
        XCTAssertTrue(mappings.contains("(literal \"\(configuration.engine.path)\")"))
        for root in ["/usr/lib", "/System/Library", "/System/Volumes/Preboot/Cryptexes/App/System",
                     "/System/Volumes/Preboot/Cryptexes/Incoming/OS", "/System/Volumes/Preboot/Cryptexes/OS",
                     "/System/Cryptexes/App", "/System/Cryptexes/OS"] {
            XCTAssertTrue(mappings.contains("(subpath \"\(root)\")"))
        }
        XCTAssertFalse(mappings.contains("/private/tmp/job"))
        XCTAssertFalse(mappings.contains("(subpath \"\(configuration.texRoot.path)\")"))
        XCTAssertFalse(profile.contains("(import"))
        let writes = profile.split(separator: "\n").first { $0.contains("(allow file-write*") }!
        XCTAssertTrue(writes.contains("/private/tmp/job/document.pdf"))
        XCTAssertFalse(writes.contains("document.tex"))
        XCTAssertFalse(writes.contains("/dev/null"))
        XCTAssertFalse(profile.contains("(allow process-exec (literal \"/bin/sh\"))"))
    }

    func testUnavailableFailsClosedWithoutRunner() async throws {
        let fixture = LaTeXRunnerFixture(.success)
        let unavailable = LaTeXCompiler(configuration: nil) { invocation in try await fixture.run(invocation) }
        do { _ = try await unavailable.compile(source: source, filename: "paper.tex"); XCTFail("Expected unavailable") }
        catch { XCTAssertEqual(error as? LaTeXCompilationError, .unavailable) }
        let invocations = await fixture.invocations
        XCTAssertTrue(invocations.isEmpty)
    }

    func testCompilerAndSandboxFailuresStopBeforeSecondPassAndCleanup() async throws {
        for (mode, expected) in [(LaTeXRunnerFixture.Mode.fail, LaTeXCompilationError.failed), (.sandboxFailure, .sandboxUnavailable), (.timeout, .timedOut)] {
            let fixture = LaTeXRunnerFixture(mode)
            do { _ = try await compiler(fixture).compile(source: source, filename: "paper.tex"); XCTFail("Expected failure") }
            catch {
                XCTAssertEqual(error as? LaTeXCompilationError, expected)
                XCTAssertFalse(error.localizedDescription.contains("user text"))
            }
            let invocations = await fixture.invocations
            XCTAssertEqual(invocations.count, 1)
            XCTAssertFalse(FileManager.default.fileExists(atPath: invocations[0].directory.path))
        }
    }

    func testCancellationCleansJobAndDoesNotRetry() async throws {
        let fixture = LaTeXRunnerFixture(.cancelled)
        do { _ = try await compiler(fixture).compile(source: source, filename: "paper.tex"); XCTFail("Expected cancellation") }
        catch { XCTAssertTrue(error is CancellationError) }
        let invocations = await fixture.invocations
        XCTAssertEqual(invocations.count, 1)
        XCTAssertFalse(FileManager.default.fileExists(atPath: invocations[0].directory.path))
    }

    func testRejectsMalformedOversizedOrSymlinkPDF() async throws {
        for (mode, expected) in [(LaTeXRunnerFixture.Mode.malformed, LaTeXCompilationError.invalidPDF), (.oversized, .tooLarge), (.symlink, .invalidPDF)] {
            let fixture = LaTeXRunnerFixture(mode)
            do { _ = try await compiler(fixture).compile(source: source, filename: "paper.tex"); XCTFail("Expected rejected PDF") }
            catch { XCTAssertEqual(error as? LaTeXCompilationError, expected) }
            let invocations = await fixture.invocations
            XCTAssertFalse(FileManager.default.fileExists(atPath: invocations[0].directory.path))
        }
    }

    func testInvalidSourceAndFilenameFailBeforeRunner() async throws {
        let fixture = LaTeXRunnerFixture(.success)
        let compiler = compiler(fixture)
        for filename in ["../paper.tex", "--shell-escape.tex", "paper.tex\n", "paper.pdf", "paper..tex"] {
            do { _ = try await compiler.compile(source: source, filename: filename); XCTFail("Unsafe filename") }
            catch { XCTAssertEqual(error as? LaTeXCompilationError, .invalidSource) }
        }
        for data in [Data(), Data([0xff, 0xfe]), Data(repeating: 120, count: 2_097_153)] {
            do { _ = try await compiler.compile(source: data, filename: "paper.tex"); XCTFail("Invalid source") }
            catch { XCTAssertEqual(error as? LaTeXCompilationError, .invalidSource) }
        }
        let invocations = await fixture.invocations
        XCTAssertTrue(invocations.isEmpty)
    }

    func testInstalledCompilerDeniesOutsideJobReadsAndWritesWhenExplicitlyEnabled() async throws {
        guard ProcessInfo.processInfo.environment["MODEL_FORUM_TEST_LATEX"] == "1" else {
            throw XCTSkip("Set MODEL_FORUM_TEST_LATEX=1 to run real containment probes.")
        }
        guard LaTeXCompiler.isAvailable else { throw XCTSkip(LaTeXCompiler.status) }
        let compiler = LaTeXCompiler()
        // Require a successful baseline: sandbox startup failure must not masquerade as a passed denial probe.
        _ = try await compiler.compile(source: source, filename: "baseline.tex")
        let fixture = URL(fileURLWithPath: "/private/tmp", isDirectory: true)
            .appendingPathComponent("ModelForum-TeX-probe-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: fixture, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        defer { try? FileManager.default.removeItem(at: fixture) }
        let input = fixture.appendingPathComponent("outside.tex")
        let output = fixture.appendingPathComponent("outside.txt")
        let marker = Data("Benign test fixture; no user information.".utf8)
        try marker.write(to: input, options: .withoutOverwriting)
        let probes = [
            "\\documentclass{article}\\begin{document}\\input{\(input.path)}\\end{document}",
            "\\documentclass{article}\\begin{document}\\newwrite\\outside\\immediate\\openout\\outside=\(output.path) \\immediate\\write\\outside{Benign marker}\\immediate\\closeout\\outside Hello\\end{document}"
        ]
        for probe in probes {
            do {
                _ = try await compiler.compile(source: Data(probe.utf8), filename: "containment.tex")
                XCTFail("Compiler unexpectedly allowed access outside its job directory")
            } catch { XCTAssertEqual(error as? LaTeXCompilationError, .failed) }
        }
        XCTAssertFalse(FileManager.default.fileExists(atPath: output.path))
        XCTAssertEqual(try Data(contentsOf: input), marker)
    }
}
