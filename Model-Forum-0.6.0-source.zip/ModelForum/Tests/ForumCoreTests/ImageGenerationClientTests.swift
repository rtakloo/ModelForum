import Foundation
import XCTest
@testable import ForumCore

final class ImageGenerationClientTests: XCTestCase {
    private var session: URLSession!
    private var client: ImageGenerationClient!
    private static let pngBase64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aZWkAAAAASUVORK5CYII="

    override func setUp() {
        super.setUp()
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [ImageStubProtocol.self]
        session = URLSession(configuration: config)
        client = ImageGenerationClient(session: session)
    }
    override func tearDown() {
        session.invalidateAndCancel()
        ImageStubProtocol.handler = nil
        client = nil; session = nil
        super.tearDown()
    }

    func testRequestAndExactPNGBytes() async throws {
        ImageStubProtocol.handler = { request in
            XCTAssertEqual(request.url?.absoluteString, "https://api.openai.com/v1/images/generations")
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-secret")
            XCTAssertNil(request.value(forHTTPHeaderField: "x-api-key"))
            XCTAssertEqual(request.value(forHTTPHeaderField: "Content-Type"), "application/json")
            XCTAssertFalse(request.httpShouldHandleCookies)
            let body = try Self.body(request)
            XCTAssertEqual(body["prompt"] as? String, "A small green bird")
            XCTAssertEqual(body["model"] as? String, "gpt-image-1")
            XCTAssertEqual(body["n"] as? Int, 1)
            XCTAssertEqual(body["size"] as? String, "1024x1024")
            XCTAssertEqual(body["output_format"] as? String, "png")
            XCTAssertEqual(body["quality"] as? String, "medium")
            XCTAssertEqual(body["stream"] as? Bool, false)
            XCTAssertNil(body["response_format"])
            return (200, Self.response(Self.pngBase64), [:])
        }
        let result = try await client.generate(prompt: "A small green bird", model: "gpt-image-1", apiKey: "test-secret")
        XCTAssertEqual(result.filename, "image.png")
        XCTAssertEqual(result.mimeType, "image/png")
        XCTAssertEqual(result.data, Data(base64Encoded: Self.pngBase64))
    }

    func testInvalidModelKeyOrPromptNeverSendsRequest() async {
        ImageStubProtocol.handler = { _ in XCTFail("Invalid input must not send a request"); return (500, Data(), [:]) }
        let cases = [("prompt", "gpt-4.1", "test-secret"), ("prompt", "dall-e-3", "test-secret"), ("prompt", "gpt-image-", "test-secret"), ("prompt", "gpt-image-1\nmalformed", "test-secret"), ("prompt", "gpt-image-1", ""), ("prompt", "gpt-image-1", "bad\u{0000}key"), (" ", "gpt-image-1", "test-secret")]
        for (prompt, model, key) in cases {
            do {
                _ = try await client.generate(prompt: prompt, model: model, apiKey: key)
                XCTFail("Expected validation error")
            } catch { XCTAssertTrue(error is ForumError) }
        }
    }

    func testNoArbitraryURLDownloadFallback() async {
        var requests = 0
        ImageStubProtocol.handler = { _ in
            requests += 1
            return (200, Data(#"{"data":[{"url":"https://private.example/collect"}]}"#.utf8), [:])
        }
        do {
            _ = try await client.generate(prompt: "prompt", model: "gpt-image-1", apiKey: "test-secret")
            XCTFail("Expected unsupported image data error")
        } catch { XCTAssertTrue(error.localizedDescription.contains("URL downloads")) }
        XCTAssertEqual(requests, 1)
    }

    func testHTTPFailuresDoNotExposeResponseBody() async {
        for status in [401, 403, 429, 500, 307] {
            ImageStubProtocol.handler = { _ in (status, Data("test-secret private prompt".utf8), [:]) }
            do {
                _ = try await client.generate(prompt: "private prompt", model: "gpt-image-1", apiKey: "test-secret")
                XCTFail("Expected HTTP error")
            } catch {
                XCTAssertTrue(error.localizedDescription.contains("\(status)"))
                XCTAssertFalse(error.localizedDescription.contains("test-secret"))
                XCTAssertFalse(error.localizedDescription.contains("private prompt"))
            }
        }
    }

    func testMalformedBase64AndNonPNGResponsesAreRejected() {
        let invalidResponses = [
            Data("secret malformed body".utf8),
            Data(#"{"data":[]}"#.utf8),
            Self.response("not-base64!"),
            Self.response(Data("not a PNG".utf8).base64EncodedString()),
            Self.response(Data([137, 80, 78, 71, 13, 10, 26, 10]).base64EncodedString()),
            Data("{\"data\":[{\"b64_json\":\"\(Self.pngBase64)\"},{\"b64_json\":\"\(Self.pngBase64)\"}]}".utf8)
        ]
        for response in invalidResponses {
            XCTAssertThrowsError(try ImageGenerationClient.decodeResponse(response)) { error in
                XCTAssertFalse(error.localizedDescription.contains("secret malformed body"))
            }
        }
    }

    func testOversizeDecodedFileIsRejected() {
        var image = Data([137, 80, 78, 71, 13, 10, 26, 10])
        image.append(Data(repeating: 0, count: 8 * 1024 * 1024 - 7))
        XCTAssertThrowsError(try ImageGenerationClient.decodeResponse(Self.response(image.base64EncodedString()))) { error in
            XCTAssertTrue(error.localizedDescription.contains("8 MiB"))
        }
    }

    func testOversizeHTTPResponseIsRejectedBeforeReadingBody() async {
        ImageStubProtocol.handler = { _ in (200, Data(), ["Content-Length": "16777217"]) }
        do {
            _ = try await client.generate(prompt: "prompt", model: "gpt-image-1", apiKey: "test-secret")
            XCTFail("Expected response size limit error")
        } catch { XCTAssertTrue(error.localizedDescription.contains("16 MiB")) }
    }

    func testTimeoutAndCancellationAreSanitized() async {
        for code in [URLError.timedOut, URLError.cancelled] {
            ImageStubProtocol.handler = { _ in throw URLError(code, userInfo: [NSLocalizedDescriptionKey: "test-secret"]) }
            do {
                _ = try await client.generate(prompt: "prompt", model: "gpt-image-1", apiKey: "test-secret")
                XCTFail("Expected network error")
            } catch {
                XCTAssertFalse(error.localizedDescription.contains("test-secret"))
                if code == .cancelled { XCTAssertTrue(error is CancellationError) }
                else { XCTAssertTrue(error.localizedDescription.contains("timed out")) }
            }
        }
    }

    private static func response(_ base64: String) -> Data {
        // Base64 does not require JSON escaping.
        Data("{\"data\":[{\"b64_json\":\"\(base64)\"}]}".utf8)
    }

    private static func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while stream.hasBytesAvailable {
                let read = stream.read(&buffer, maxLength: buffer.count)
                if read <= 0 { break }
                data.append(buffer, count: read)
            }
        }
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
    }
}

private final class ImageStubProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, Data, [String: String]))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            guard let handler = Self.handler else { throw URLError(.unknown) }
            let (status, body, headers) = try handler(request)
            let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: "HTTP/1.1", headerFields: headers)!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: body)
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}
