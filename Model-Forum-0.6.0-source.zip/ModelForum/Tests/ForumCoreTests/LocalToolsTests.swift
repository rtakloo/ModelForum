import XCTest
@testable import ForumCore

final class LocalToolsTests: XCTestCase {
    func testGitHubReadOnlyArguments() throws {
        let issue = try GitHubRequest("https://github.com/apple/swift/issues/123/")
        XCTAssertEqual(issue.arguments, ["issue", "view", "https://github.com/apple/swift/issues/123", "--json", "title,body,url"])
        let pr = try GitHubRequest("https://github.com/apple/swift/pull/42")
        XCTAssertEqual(pr.arguments.first, "pr")
        XCTAssertEqual(pr.arguments.last, "title,body,url,headRefOid,baseRefName")
    }

    func testGitHubRejectsAmbiguousAndInjectedURLs() {
        let invalid = ["http://github.com/a/b/issues/1", "https://github.com.evil/a/b/issues/1",
            "https://evil@github.com/a/b/issues/1", "https://github.com/a/b/issues/1?x=2",
            "https://github.com/a/b/pull/1#discussion", "https://github.com/a/b/pull/0",
            "https://github.com/a/b/pull/-1", "https://github.com/a/b/pull/1;touch x",
            "https://github.com/a/b%2fc/pull/1", "https://github.com/a/../pull/1",
            "https://github.com/a/b/pull/1\n", "https://github.com/a/b/actions/1",
            "https://github.com/a/b/issues/123/extra", "https://github.com:443/a/b/issues/1"]
        for url in invalid { XCTAssertThrowsError(try GitHubRequest(url), url) }
    }

    func testClaudeSecurityArgumentsAndResponse() throws {
        let arguments = LocalTools.claudeArguments(model: "sonnet")
        for flag in ["--safe-mode", "--restricted", "--strict-mcp-config", "--disable-slash-commands", "--no-session-persistence"] {
            XCTAssertTrue(arguments.contains(flag))
        }
        XCTAssertEqual(arguments[arguments.firstIndex(of: "--tools")! + 1], "")
        XCTAssertEqual(arguments[arguments.firstIndex(of: "--setting-sources")! + 1], "")
        XCTAssertEqual(arguments[arguments.firstIndex(of: "--settings")! + 1], "{\"disableAllHooks\":true}")
        let reply = try LocalTools.decodeClaude(Data(#"{"result":"Answer","is_error":false,"usage":{"input_tokens":10,"output_tokens":3}}"#.utf8), model: "sonnet")
        XCTAssertEqual(reply.text, "Answer"); XCTAssertEqual(reply.outputTokens, 3)
        XCTAssertThrowsError(try LocalTools.decodeClaude(Data(#"{"is_error":true,"result":"failure"}"#.utf8), model: "sonnet"))
    }

    func testPromptIsStdinAndSpecialCharactersStayLiteral() async throws {
        let content = Data("$(touch /tmp/never-run) `echo secret` ; \"quotes\"\n".utf8)
        let result = try await Subprocess.run(executable: URL(fileURLWithPath: "/bin/cat"), arguments: [], input: content)
        XCTAssertEqual(result.stdout, content); XCTAssertEqual(result.status, 0)
    }

    func testClaudeUsesReportedModelInsteadOfRequestedAlias() throws {
        let data = Data(#"{"subtype":"success","is_error":false,"result":"Answer","model":"claude-sonnet-resolved","modelUsage":{"claude-other":{"inputTokens":2}}}"#.utf8)
        let reply = try LocalTools.decodeClaude(data, model: "sonnet")
        XCTAssertEqual(reply.model, "claude-sonnet-resolved")
    }

    func testClaudeShowsCompletedRefusal() throws {
        let data = Data(#"{"subtype":"success","is_error":false,"stop_reason":"refusal","result":"I cannot help with that request."}"#.utf8)
        XCTAssertEqual(try LocalTools.decodeClaude(data, model: "sonnet").text, "I cannot help with that request.")
    }

    func testClaudeUsesUnambiguousModelUsage() throws {
        let data = Data(#"{"subtype":"success","result":"Answer","modelUsage":{"claude-sonnet-resolved":{"inputTokens":12,"outputTokens":3}}}"#.utf8)
        XCTAssertEqual(try LocalTools.decodeClaude(data, model: "sonnet").model, "claude-sonnet-resolved")
    }

    func testClaudeMarksMissingAndAmbiguousModelMetadataUnresolved() throws {
        for json in [#"{"result":"Answer"}"#, #"{"result":"Answer","modelUsage":{"model-a":{},"model-b":{}}}"#] {
            let reply = try LocalTools.decodeClaude(Data(json.utf8), model: "sonnet")
            XCTAssertEqual(reply.model, "sonnet (requested; actual model unresolved)")
        }
    }

    func testClaudeRejectsIncompleteResultEvenWithText() {
        for subtype in ["error_max_turns", "error_during_execution", "error_max_budget_usd", "truncated"] {
            let json = "{\"subtype\":\"\(subtype)\",\"is_error\":false,\"result\":\"Partial answer\"}"
            XCTAssertThrowsError(try LocalTools.decodeClaude(Data(json.utf8), model: "sonnet"), subtype)
        }
        let truncated = Data(#"{"subtype":"success","is_error":false,"stop_reason":"max_tokens","result":"Partial"}"#.utf8)
        XCTAssertThrowsError(try LocalTools.decodeClaude(truncated, model: "sonnet"))
    }

    func testConcurrentInputAndBothOutputStreams() async throws {
        // Fixed test-only program; production public APIs never accept shell commands.
        let input = Data(repeating: 120, count: 200_000)
        let script = "dd bs=1024 count=100 if=/dev/zero >&2 2>/dev/null; cat"
        let result = try await Subprocess.run(executable: URL(fileURLWithPath: "/bin/sh"), arguments: ["-c", script], input: input)
        XCTAssertEqual(result.stdout, input)
        XCTAssertEqual(result.stderr.count, 102_400)
    }

    func testOutputLimitStopsProcess() async {
        do {
            _ = try await Subprocess.run(executable: URL(fileURLWithPath: "/usr/bin/yes"), arguments: [], timeout: 3, outputLimit: 1024)
            XCTFail("Expected output cap")
        } catch { XCTAssertEqual(error as? SubprocessError, .outputTooLarge) }
    }

    func testTimeoutStopsProcess() async {
        let start = Date()
        do {
            _ = try await Subprocess.run(executable: URL(fileURLWithPath: "/bin/sleep"), arguments: ["10"], timeout: 0.05)
            XCTFail("Expected timeout")
        } catch { XCTAssertEqual(error as? SubprocessError, .timedOut) }
        XCTAssertLessThan(Date().timeIntervalSince(start), 2)
    }

    func testCancellationStopsProcess() async throws {
        let task = Task { try await Subprocess.run(executable: URL(fileURLWithPath: "/bin/sleep"), arguments: ["10"]) }
        try await Task.sleep(nanoseconds: 30_000_000)
        let start = Date(); task.cancel()
        do { _ = try await task.value; XCTFail("Expected cancellation") }
        catch { XCTAssertTrue(error is CancellationError) }
        XCTAssertLessThan(Date().timeIntervalSince(start), 2)
    }

    func testInputCapAndExitStatus() async throws {
        do {
            _ = try await Subprocess.run(executable: URL(fileURLWithPath: "/bin/cat"), arguments: [], input: Data(repeating: 0, count: 2_097_153))
            XCTFail("Expected input cap")
        } catch { XCTAssertEqual(error as? SubprocessError, .inputTooLarge) }
        let result = try await Subprocess.run(executable: URL(fileURLWithPath: "/usr/bin/false"), arguments: [])
        XCTAssertNotEqual(result.status, 0)
    }
}
