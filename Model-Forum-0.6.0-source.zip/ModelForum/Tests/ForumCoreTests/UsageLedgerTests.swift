import XCTest
@testable import ForumCore

final class UsageLedgerTests: XCTestCase {
    private let participant = Participant(alias: "test", provider: .openAI, model: "test-model")
    private var price: ModelPrice { ModelPrice(provider: .openAI, model: "test-model", inputPerMillionUSD: 1, outputPerMillionUSD: 2) }
    func testFullOutputReservationPrecedesSettlementAndKeepsPriceSnapshot() throws {
        var ledger = UsageLedger(); let session = UUID()
        var policy = SpendingPolicy(prices: [price])
        let record = try ledger.reserve(participant: participant, transcript: "hello", maxOutputTokens: 100, sessionID: session, billingMode: .api, policy: policy)
        XCTAssertEqual(record.status, .reserved)
        XCTAssertEqual(record.estimatedInputTokens, 1029)
        XCTAssertEqual(try XCTUnwrap(record.reservedUSD), 0.001229, accuracy: 0.0000001)
        policy.prices[0].outputPerMillionUSD = 100
        ledger.settle(id: record.id, reply: ModelReply(text: "done", model: "test-model", inputTokens: 10, outputTokens: 20))
        XCTAssertEqual(try XCTUnwrap(ledger.records[0].estimatedCostUSD), 0.00005, accuracy: 0.0000001)
        XCTAssertEqual(ledger.records[0].status, .completed)
        let restored = try JSONDecoder().decode(UsageLedger.self, from: JSONEncoder().encode(ledger))
        XCTAssertEqual(restored.records[0].id, record.id)
        XCTAssertEqual(restored.records[0].price, price)
    }
    func testUnknownPricesAreNeverZeroAndCapsFailClosed() throws {
        var ledger = UsageLedger(); let session = UUID()
        let unknown = try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: session, billingMode: .api, policy: SpendingPolicy())
        XCTAssertNil(unknown.reservedUSD)
        ledger.settle(id: unknown.id, reply: ModelReply(text: "done", model: "test-model", inputTokens: 10, outputTokens: 10))
        XCTAssertNil(ledger.records[0].accountedUSD)
        XCTAssertThrowsError(try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: session, billingMode: .api, policy: SpendingPolicy(monthlyCapUSD: 10)))
        XCTAssertThrowsError(try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: session, billingMode: .api, policy: SpendingPolicy(prices: [price], sessionCapUSD: 10)))
        XCTAssertEqual(ledger.records.count, 1)
    }
    func testUncertainAndInterruptedRequestsKeepReservationsAndBlockOverspend() throws {
        var ledger = UsageLedger(); let session = UUID()
        let policy = SpendingPolicy(prices: [price], sessionCapUSD: 0.002)
        let first = try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: session, billingMode: .api, policy: policy)
        ledger.markUncertain(id: first.id)
        XCTAssertEqual(ledger.records[0].accountedUSD, first.reservedUSD)
        XCTAssertThrowsError(try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: session, billingMode: .api, policy: policy))
        let second = try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: UUID(), billingMode: .api, policy: policy)
        ledger.recoverInterruptedRequests()
        XCTAssertEqual(ledger.records.first { $0.id == second.id }?.status, .uncertain)
        XCTAssertEqual(ledger.records.first { $0.id == second.id }?.accountedUSD, second.reservedUSD)
    }
    func testSubscriptionNeverUsesAPIRateAndUnknownExternalRouteCannotBypassCaps() throws {
        var ledger = UsageLedger(); let policy = SpendingPolicy(prices: [price], requestCapUSD: 0)
        let subscription = try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: UUID(), billingMode: .subscription, policy: policy)
        ledger.settle(id: subscription.id, reply: ModelReply(text: "done", model: "test-model", inputTokens: 10, outputTokens: 10))
        XCTAssertNil(ledger.records[0].price)
        XCTAssertNil(ledger.records[0].estimatedCostUSD)
        XCTAssertThrowsError(try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: UUID(), billingMode: .localOrUnknown, policy: policy))
    }
    func testAliasResolutionFailsClosedWhileMissingUsageRetainsReservation() throws {
        var ledger = UsageLedger()
        let first = try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: UUID(), billingMode: .api, policy: SpendingPolicy(prices: [price]))
        ledger.settle(id: first.id, reply: ModelReply(text: "done", model: "resolved-different-model", inputTokens: 10, outputTokens: 10))
        XCTAssertNil(ledger.records[0].estimatedCostUSD)
        XCTAssertNil(ledger.records[0].accountedUSD)
        XCTAssertThrowsError(try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: first.sessionID, billingMode: .api, policy: SpendingPolicy(prices: [price], sessionCapUSD: 10)))
        let second = try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: UUID(), billingMode: .api, policy: SpendingPolicy(prices: [price]))
        ledger.settle(id: second.id, reply: ModelReply(text: "done", model: "test-model"))
        XCTAssertNil(ledger.records[1].estimatedCostUSD)
        XCTAssertEqual(ledger.records[1].accountedUSD, second.reservedUSD)
    }
    func testInvalidPersistedAmountsAndTokensCannotReduceCapTotals() throws {
        var valid = UsageLedger(); let session = UUID()
        let record = try valid.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: session, billingMode: .api, policy: SpendingPolicy(prices: [price]))
        let mutations: [(inout UsageRecord) -> Void] = [
            { $0.reservedUSD = -100 }, { $0.reservedUSD = .nan }, { $0.reservedUSD = .infinity },
            { $0.estimatedCostUSD = -100 }, { $0.estimatedCostUSD = .nan }, { $0.estimatedCostUSD = .infinity },
            { $0.estimatedInputTokens = -1 }, { $0.maxOutputTokens = -1 },
            { $0.inputTokens = -1 }, { $0.outputTokens = -1 },
            { $0.reservedUSD = 0 }, { $0.price?.inputPerMillionUSD = -1 },
            { $0.date = Date(timeIntervalSinceReferenceDate: .nan) }
        ]
        for mutate in mutations {
            var ledger = valid; mutate(&ledger.records[0])
            XCTAssertThrowsError(try ledger.validate())
            XCTAssertThrowsError(try JSONEncoder().encode(ledger))
            XCTAssertThrowsError(try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: session, billingMode: .api, policy: SpendingPolicy(prices: [price], sessionCapUSD: 0.002)))
            XCTAssertEqual(ledger.records.count, 1)
        }
        var duplicate = valid; duplicate.records.append(record)
        XCTAssertThrowsError(try duplicate.validate())
    }
    func testBackupDecodeRejectsNegativeAccountingAndMismatchedCostSnapshots() throws {
        var ledger = UsageLedger()
        let record = try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: UUID(), billingMode: .api, policy: SpendingPolicy(prices: [price]))
        ledger.settle(id: record.id, reply: ModelReply(text: "answer", model: participant.model, inputTokens: 20, outputTokens: 20))
        let data = try JSONEncoder().encode(ledger)
        for field in ["reservedUSD", "estimatedCostUSD", "estimatedInputTokens", "inputTokens", "outputTokens", "maxOutputTokens"] {
            var object = try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
            var records = try XCTUnwrap(object["records"] as? [[String: Any]])
            records[0][field] = -100
            object["records"] = records
            XCTAssertThrowsError(try JSONDecoder().decode(UsageLedger.self, from: JSONSerialization.data(withJSONObject: object)))
        }
        var forged = ledger
        forged.records[0].estimatedCostUSD = 0
        XCTAssertThrowsError(try forged.validate())
        XCTAssertNoThrow(try JSONDecoder().decode(UsageLedger.self, from: data).validate())
    }
    func testMonthlyCapUsesUTCAndRejectsInvalidPolicies() throws {
        var ledger = UsageLedger(); let policy = SpendingPolicy(prices: [price], monthlyCapUSD: 0.002)
        let formatter = ISO8601DateFormatter()
        let january = try XCTUnwrap(formatter.date(from: "2026-01-31T23:59:59Z"))
        let february = try XCTUnwrap(formatter.date(from: "2026-02-01T00:00:00Z"))
        _ = try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: UUID(), billingMode: .api, policy: policy, date: january)
        XCTAssertThrowsError(try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: UUID(), billingMode: .api, policy: policy, date: january))
        _ = try ledger.reserve(participant: participant, transcript: "x", maxOutputTokens: 100, sessionID: UUID(), billingMode: .api, policy: policy, date: february)
        XCTAssertThrowsError(try SpendingPolicy(prices: [price, price]).validate())
        XCTAssertThrowsError(try SpendingPolicy(requestCapUSD: -.infinity).validate())
        XCTAssertThrowsError(try SpendingPolicy(prices: [ModelPrice(provider: .openAI, model: "test", inputPerMillionUSD: .nan, outputPerMillionUSD: 1)]).validate())
    }
}
