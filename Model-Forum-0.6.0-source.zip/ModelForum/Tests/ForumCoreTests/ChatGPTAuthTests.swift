import XCTest
import Foundation
import CryptoKit
import Security
@testable import ForumCore

final class ChatGPTAuthTests: XCTestCase {
    func testAuthorizationUsesPKCEFreshStateExactLoopbackAndStableHost() throws {
        let uri = URL(string: "http://127.0.0.1:54321/auth/callback")!
        let pending = try ChatGPTAuthorization(redirectURI: uri)
        let second = try ChatGPTAuthorization(redirectURI: uri)
        let items = URLComponents(url: pending.browserURL(hostID: "urn:uuid:stable"), resolvingAgainstBaseURL: false)!.queryItems!
        let values = Dictionary(uniqueKeysWithValues: items.map { ($0.name, $0.value!) })
        XCTAssertEqual(values["client_id"], "dynamic_agent_client")
        XCTAssertEqual(values["agent_name_hint"], "Model Forum")
        XCTAssertEqual(values["ext_agent_host_id"], "urn:uuid:stable")
        XCTAssertEqual(values["redirect_uri"], uri.absoluteString)
        XCTAssertEqual(values["code_challenge"], Data(SHA256.hash(data: Data(pending.verifier.utf8))).base64URL)
        XCTAssertEqual(values["code_challenge_method"], "S256")
        XCTAssertTrue(values["scope"]!.contains("chatgpt.tokens.use.direct"))
        XCTAssertNotEqual(pending.state, second.state); XCTAssertNotEqual(pending.nonce, second.nonce)
        let result = try pending.validateCallback(callback(pending, extra: ["client_id": "oaiapp_test", "code": "code"]))
        XCTAssertEqual(result.clientID, "oaiapp_test"); XCTAssertEqual(result.code, "code")
        XCTAssertThrowsError(try ChatGPTAuthorization(redirectURI: URL(string: "http://localhost:54321/auth/callback")!))
    }
    func testCallbackRejectsStateExpiryWrongPortDuplicateParameterAndMissingIssuedClient() throws {
        let pending = try ChatGPTAuthorization(redirectURI: URL(string: "http://127.0.0.1:54321/auth/callback")!)
        let valid = callback(pending, extra: ["client_id": "oaiapp_test", "code": "code"])
        XCTAssertThrowsError(try pending.validateCallback(valid, now: pending.createdAt.addingTimeInterval(601)))
        for url in [callback(pending, extra: ["state": "wrong", "code": "code", "client_id": "oaiapp_test"]),
                    callback(pending, extra: ["code": "code"]),
                    callback(pending, extra: ["code": "code", "client_id": "dynamic_agent_client"]),
                    URL(string: valid.absoluteString.replacingOccurrences(of: ":54321", with: ":54322"))!,
                    URL(string: valid.absoluteString + "&state=" + pending.state)!] {
            XCTAssertThrowsError(try pending.validateCallback(url))
        }
        XCTAssertThrowsError(try pending.validateCallback(callback(pending, extra: ["error": "private-secret"]))) { XCTAssertFalse($0.localizedDescription.contains("private-secret")) }
    }
    func testReturningRegistrationNeverChangesClientAndOmitsDynamicName() throws {
        let pending = try ChatGPTAuthorization(redirectURI: URL(string: "http://127.0.0.1:12345/auth/callback")!, clientID: "oaiapp_saved")
        XCTAssertEqual(try pending.validateCallback(callback(pending, extra: ["code": "code"])).clientID, "oaiapp_saved")
        XCTAssertThrowsError(try pending.validateCallback(callback(pending, extra: ["code": "code", "client_id": "oaiapp_other"])))
        let url = pending.browserURL(hostID: "host", idTokenHint: "retained-token", emailHint: "person@example.test")
        let values = URLComponents(url: url, resolvingAgainstBaseURL: false)!.queryItems!
        XCTAssertFalse(values.contains { $0.name == "agent_name_hint" })
        XCTAssertEqual(values.first { $0.name == "id_token_hint" }?.value, "retained-token")
    }
    func testRSASignatureAndIdentityClaimsAreActuallyVerified() throws {
        let fixture = try ChatGPTJWTFixture()
        let identity = try ChatGPTTokenValidation.identity(idToken: fixture.token(), jwks: fixture.jwks, clientID: "oaiapp_test", nonce: "nonce")
        XCTAssertEqual(identity.subject, "subject-test")
        XCTAssertEqual(identity.email, "person@example.test")
        XCTAssertTrue(identity.emailVerified)
        for change: [String: Any] in [["iss": "https://evil.example"], ["aud": "other-client"], ["nonce": "wrong"], ["exp": 1], ["iat": Date().timeIntervalSince1970 + 1000], ["nbf": Date().timeIntervalSince1970 + 1000], ["sub": ""], ["aud": ["oaiapp_test", "second"]]] {
            XCTAssertThrowsError(try ChatGPTTokenValidation.identity(idToken: fixture.token(changes: change), jwks: fixture.jwks, clientID: "oaiapp_test", nonce: "nonce"))
        }
        let wrongKey = try ChatGPTJWTFixture(alternate: true)
        XCTAssertThrowsError(try ChatGPTTokenValidation.identity(idToken: wrongKey.token(), jwks: fixture.jwks, clientID: "oaiapp_test", nonce: "nonce"))
        XCTAssertThrowsError(try ChatGPTTokenValidation.identity(idToken: fixture.token(header: ["alg": "none", "kid": "test-key"]), jwks: fixture.jwks, clientID: "oaiapp_test", nonce: "nonce"))
        XCTAssertThrowsError(try ChatGPTTokenValidation.identity(idToken: fixture.token(header: ["alg": "HS256", "kid": "test-key"]), jwks: fixture.jwks, clientID: "oaiapp_test", nonce: "nonce"))
    }
    func testAudienceArrayRequiresAuthorizedPartyAndUnknownSigningKeyFailsClosed() throws {
        let fixture = try ChatGPTJWTFixture()
        let token = try fixture.token(changes: ["aud": ["oaiapp_test", "other"], "azp": "oaiapp_test"])
        XCTAssertNoThrow(try ChatGPTTokenValidation.identity(idToken: token, jwks: fixture.jwks, clientID: "oaiapp_test", nonce: "nonce"))
        XCTAssertThrowsError(try ChatGPTTokenValidation.identity(idToken: fixture.token(header: ["alg": "RS256", "kid": "unknown"]), jwks: fixture.jwks, clientID: "oaiapp_test", nonce: "nonce"))
        let bad = "private-secret.invalid.signature"
        XCTAssertThrowsError(try ChatGPTTokenValidation.identity(idToken: bad, jwks: fixture.jwks, clientID: "oaiapp_test", nonce: "nonce")) { XCTAssertFalse($0.localizedDescription.contains("private-secret")) }
    }
    private func callback(_ pending: ChatGPTAuthorization, extra: [String: String]) -> URL {
        var values = ["state": pending.state]; values.merge(extra) { _, new in new }
        var url = URLComponents(url: pending.redirectURI, resolvingAgainstBaseURL: false)!
        url.queryItems = values.map { URLQueryItem(name: $0.key, value: $0.value) }
        return url.url!
    }
}

struct ChatGPTJWTFixture {
    let key: SecKey
    let jwks: Data
    init(alternate: Bool = false) throws {
        // Import deterministic synthetic material: SecKeyCreateRandomKey returns errSecParam
        // in this test environment, even with explicitly nonpersistent key attributes.
        // Signature creation and verification still execute using Security's RSA implementation.
        let encoded = alternate ? ChatGPTSyntheticRSAKeys.alternate : ChatGPTSyntheticRSAKeys.primary
        let privateDER = try XCTUnwrap(Data(base64Encoded: encoded, options: .ignoreUnknownCharacters))
        key = try XCTUnwrap(SecKeyCreateWithData(privateDER as CFData, [kSecAttrKeyType: kSecAttrKeyTypeRSA, kSecAttrKeyClass: kSecAttrKeyClassPrivate] as CFDictionary, nil))
        let publicKey = try XCTUnwrap(SecKeyCopyPublicKey(key))
        let bytes = [UInt8](try XCTUnwrap(SecKeyCopyExternalRepresentation(publicKey, nil)) as Data)
        var offset = 0
        func readLength() -> Int {
            let value = Int(bytes[offset]); offset += 1
            if value < 128 { return value }
            var length = 0
            for _ in 0..<(value & 127) { length = length * 256 + Int(bytes[offset]); offset += 1 }
            return length
        }
        XCTAssertEqual(bytes[offset], 0x30); offset += 1; _ = readLength()
        func integer() -> Data {
            XCTAssertEqual(bytes[offset], 2); offset += 1
            let length = readLength(); var result = Data(bytes[offset..<(offset + length)]); offset += length
            while result.count > 1 && result.first == 0 { result.removeFirst() }
            return result
        }
        let n = integer(); let e = integer()
        jwks = try JSONSerialization.data(withJSONObject: ["keys": [["kid": "test-key", "kty": "RSA", "alg": "RS256", "use": "sig", "n": n.base64URL, "e": e.base64URL]]])
    }
    func token(changes: [String: Any] = [:], header: [String: String] = ["alg": "RS256", "kid": "test-key"]) throws -> String {
        var claims: [String: Any] = ["iss": "https://auth.openai.com", "sub": "subject-test", "aud": "oaiapp_test", "nonce": "nonce", "iat": Date().timeIntervalSince1970 - 10, "exp": Date().timeIntervalSince1970 + 3600, "email": "person@example.test", "email_verified": true]
        claims.merge(changes) { _, new in new }
        let encoded = try JSONSerialization.data(withJSONObject: header).base64URL + "." + JSONSerialization.data(withJSONObject: claims).base64URL
        let signature = try XCTUnwrap(SecKeyCreateSignature(key, .rsaSignatureMessagePKCS1v15SHA256, Data(encoded.utf8) as CFData, nil)) as Data
        return encoded + "." + signature.base64URL
    }
}
