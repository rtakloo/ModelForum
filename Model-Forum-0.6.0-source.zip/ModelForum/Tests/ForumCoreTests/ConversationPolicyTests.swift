import XCTest
@testable import ForumCore

final class ConversationPolicyTests: XCTestCase {
    func testOnlyLeadingMentionsDispatch() throws {
        let result = try ConversationPolicy.route("@gpt Review what @claude wrote", knownAliases: ["gpt", "claude"], fallback: "claude")
        XCTAssertEqual(result.aliases, ["gpt"])
        XCTAssertEqual(result.body, "Review what @claude wrote")
    }
    func testMultipleMentionsDeduplicate() throws {
        let result = try ConversationPolicy.route(" @gpt @claude @gpt Solve it ", knownAliases: ["gpt", "claude"], fallback: "gpt")
        XCTAssertEqual(result.aliases, ["gpt", "claude"])
        XCTAssertEqual(result.body, "Solve it")
    }
    func testRejectUnknownMentionsAndEmptyQuestions() {
        XCTAssertThrowsError(try ConversationPolicy.route("@unknown question", knownAliases: ["gpt"], fallback: "gpt"))
        XCTAssertThrowsError(try ConversationPolicy.route("@gpt", knownAliases: ["gpt"], fallback: "gpt"))
    }
    func testContextKeepsAuthorshipAndBounds() throws {
        let message = ChatMessage(role: "assistant", author: "@claude", content: "My claim")
        let transcript = try ConversationPolicy.transcript(messages: [message], prompt: "Check it")
        XCTAssertTrue(transcript.contains(message.id.uuidString))
        XCTAssertTrue(transcript.contains("@claude"))
        XCTAssertTrue(transcript.contains("CURRENT USER REQUEST:\nCheck it"))
        let huge = ChatMessage(role: "context", author: "GitHub", content: String(repeating: "a", count: 250_000))
        XCTAssertThrowsError(try ConversationPolicy.transcript(messages: [huge], prompt: "Check it"))
    }
    func testRoundTripRetainsProvenance() throws {
        let contextID = UUID()
        let message = ChatMessage(role: "assistant", author: "@gpt", content: "Result", model: "model-id", inputTokens: 10, outputTokens: 4, contextMessageIDs: [contextID], provider: .openAI, requestContext: "Exact original input", critiqueMessageID: contextID)
        let data = try JSONEncoder().encode(Conversation(messages: [message]))
        let restored = try JSONDecoder().decode(Conversation.self, from: data)
        XCTAssertEqual(restored.messages.first?.contextMessageIDs, [contextID])
        XCTAssertEqual(restored.messages.first?.provider, .openAI)
        XCTAssertEqual(restored.messages.first?.inputTokens, 10)
        XCTAssertEqual(restored.messages.first?.requestContext, "Exact original input")
        XCTAssertEqual(restored.messages.first?.critiqueMessageID, contextID)
    }
}
