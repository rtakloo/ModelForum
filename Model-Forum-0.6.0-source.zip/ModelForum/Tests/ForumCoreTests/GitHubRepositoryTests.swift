import XCTest
@testable import ForumCore

final class GitHubRepositoryTests: XCTestCase {
    private let url = "https://github.com/rtakloo/Chatgpt"
    private let sha = String(repeating: "a", count: 40)
    private func json(_ object: Any) throws -> Data { try JSONSerialization.data(withJSONObject: object) }
    private func overview(empty: Bool = false, branch: String = "main") throws -> Data {
        try json(["description": "A discussion workspace", "isPrivate": false, "isEmpty": empty,
                  "defaultBranchRef": empty ? NSNull() : ["name": branch]])
    }
    private func reference() throws -> Data { try json(["object": ["sha": sha, "type": "commit"]]) }
    private func readme(_ text: String = "# Chatgpt\nRepository information") throws -> Data {
        try json(["path": "README.md", "size": text.utf8.count, "encoding": "base64", "content": Data(text.utf8).base64EncodedString()])
    }
    private func listing() throws -> Data { try json([["name": "Sources", "type": "dir"], ["name": "README.md", "type": "file"]]) }

    func testScreenshotURLAndOptionalTrailingSlash() throws {
        for raw in [url, url + "/"] {
            let request = try GitHubRequest(raw)
            XCTAssertTrue(request.isRepository)
            XCTAssertEqual(request.canonicalURL, url)
            XCTAssertEqual(request.repository, "rtakloo/Chatgpt")
            XCTAssertEqual(request.arguments, ["repo", "view", url, "--json", "nameWithOwner,description,isPrivate,isEmpty,defaultBranchRef"])
        }
    }

    func testRootRejectsHostileURLs() {
        for raw in [url + "?token=x", url + "#readme", url + "/tree/main", url + "\n", url + "//",
                    "https://github.com/a/..", "https://github.com/a/.", "https://github.com/a/b%2fc",
                    "https://github.com/a/b;rm", "https://github.com/a/b$(id)",
                    "https://github.com.evil/a/b", "https://evil@github.com/a/b", "https://github.com:443/a/b"] {
            XCTAssertThrowsError(try GitHubRequest(raw), raw)
        }
    }

    func testRepositorySectionsPinREADMEAndListingToSameCommit() async throws {
        var calls = [[String]]()
        var responses = try [overview(branch: "release/v1"), reference(), readme(), listing()]
        let result = try await LocalTools.githubContext(url: url) { arguments in
            calls.append(arguments)
            return responses.removeFirst()
        }
        XCTAssertTrue(result.contains("GitHub repository: \(url)"))
        XCTAssertTrue(result.contains("Default branch: \"release/v1\""))
        XCTAssertTrue(result.contains("Resolved commit: \(sha)"))
        XCTAssertTrue(result.contains("# Chatgpt"))
        XCTAssertTrue(result.contains("\"Sources\" [dir]"))
        XCTAssertTrue(result.contains("1,000 entries"))
        XCTAssertEqual(calls.count, 4)
        XCTAssertEqual(calls[1][1], "repos/rtakloo/Chatgpt/git/ref/heads/release%2Fv1")
        XCTAssertEqual(calls[2][1], "repos/rtakloo/Chatgpt/readme")
        XCTAssertEqual(calls[3][1], "repos/rtakloo/Chatgpt/contents")
        for call in calls.dropFirst() {
            XCTAssertEqual(call[call.firstIndex(of: "--method")! + 1], "GET")
            XCTAssertEqual(call[call.firstIndex(of: "--hostname")! + 1], "github.com")
        }
        for call in calls.suffix(2) { XCTAssertEqual(Array(call.suffix(2)), ["--raw-field", "ref=\(sha)"]) }
    }

    func testMissingReadmeStillImportsListing() async throws {
        var count = 0
        let result = try await LocalTools.githubContext(url: url) { _ in
            count += 1
            switch count {
            case 1: return try self.overview()
            case 2: return try self.reference()
            case 3: throw GitHubFetchError.http(404)
            default: return try self.listing()
            }
        }
        XCTAssertTrue(result.contains("No README found at this commit"))
        XCTAssertTrue(result.contains("\"Sources\" [dir]"))
    }

    func testEmptyRepositoryDoesNotFetchCommitOrContents() async throws {
        var calls = 0
        let result = try await LocalTools.githubContext(url: url) { _ in calls += 1; return try self.overview(empty: true) }
        XCTAssertEqual(calls, 1)
        XCTAssertTrue(result.contains("Empty repository: no commits"))
        XCTAssertTrue(result.contains("Resolved commit: none"))
    }

    func testMetadataAndCommitFailuresDoNotBecomeMissingReadme() async throws {
        for failingCall in [1, 2] {
            var calls = 0
            do {
                _ = try await LocalTools.githubContext(url: url) { _ in
                    calls += 1
                    if calls == failingCall { throw GitHubFetchError.http(403) }
                    return try self.overview()
                }
                XCTFail("Expected initial lookup failure")
            } catch { XCTAssertEqual(error as? GitHubFetchError, .http(403)) }
            XCTAssertEqual(calls, failingCall)
        }
    }

    func testPartialSectionFailureIsVisibleAndDoesNotLeakDetails() async throws {
        var calls = 0
        let result = try await LocalTools.githubContext(url: url) { _ in
            calls += 1
            if calls == 1 { return try self.overview() }
            if calls == 2 { return try self.reference() }
            throw ForumError.message("secret-token-should-never-appear")
        }
        XCTAssertTrue(result.contains("README request failed; this snapshot is partial"))
        XCTAssertTrue(result.contains("directory request failed; this snapshot is partial"))
        XCTAssertFalse(result.contains("secret-token"))
        XCTAssertFalse(result.contains("No README found"))
    }

    func testReadmeAndListingExcerptsStayUnder80KB() async throws {
        let huge = String(repeating: "🙂", count: 60_000)
        let entries = (0..<500).map { ["name": String(repeating: "x", count: 150) + String($0), "type": "file"] }
        var responses = try [overview(), reference(), readme(huge), json(entries)]
        let result = try await LocalTools.githubContext(url: url) { _ in responses.removeFirst() }
        XCTAssertLessThan(result.utf8.count, 80_000)
        XCTAssertTrue(result.contains("Excerpt truncated at 56000 UTF-8 bytes"))
        XCTAssertTrue(result.contains("first 200 of 500 returned entries"))
        XCTAssertFalse(result.contains("�"))
    }

    func testOversizedReadmeAndDownloadCapAreExplicit() async throws {
        for downloadCap in [false, true] {
            var calls = 0
            let result = try await LocalTools.githubContext(url: url) { _ in
                calls += 1
                switch calls {
                case 1: return try self.overview()
                case 2: return try self.reference()
                case 3:
                    if downloadCap { throw SubprocessError.outputTooLarge }
                    return try self.json(["size": 2_000_000, "encoding": "none"])
                default: return try self.listing()
                }
            }
            XCTAssertTrue(result.contains(downloadCap ? "bounded download limit" : "1 MiB retrieval limit"))
            XCTAssertTrue(result.contains("\"Sources\" [dir]"))
        }
    }

    func testCancellationIsNotSwallowedAsPartialSuccess() async throws {
        var calls = 0
        do {
            _ = try await LocalTools.githubContext(url: url) { _ in
                calls += 1
                if calls == 1 { return try self.overview() }
                if calls == 2 { return try self.reference() }
                throw CancellationError()
            }
            XCTFail("Expected cancellation")
        } catch { XCTAssertTrue(error is CancellationError) }
        XCTAssertEqual(calls, 3)
    }

    func testIssueAndPRImportRegression() async throws {
        for kind in ["issues", "pull"] {
            var calls = [[String]]()
            let result = try await LocalTools.githubContext(url: url + "/\(kind)/7") { arguments in
                calls.append(arguments)
                return try self.json(["title": "Existing item", "body": "Its contents", "headRefOid": self.sha])
            }
            XCTAssertEqual(calls.count, 1)
            XCTAssertEqual(calls[0].first, kind == "pull" ? "pr" : "issue")
            XCTAssertTrue(result.contains("Title: Existing item"))
            XCTAssertTrue(result.contains("Its contents"))
        }
    }

    func testHTTPStatusUsesHeadersAndNeverRawFailureBody() throws {
        let ok = SubprocessResult(stdout: Data("HTTP/2.0 200 OK\r\nContent-Type: application/json\r\n\r\n{\"value\":1}".utf8), stderr: Data(), status: 0)
        XCTAssertEqual(try GitHubRepository.responseBody(ok, includesHeaders: true), Data(#"{"value":1}"#.utf8))
        let missing = SubprocessResult(stdout: Data("HTTP/2.0 404 Not Found\n\nsecret-token".utf8), stderr: Data("secret".utf8), status: 1)
        XCTAssertThrowsError(try GitHubRepository.responseBody(missing, includesHeaders: true)) { error in
            XCTAssertEqual(error as? GitHubFetchError, .http(404))
            XCTAssertFalse(error.localizedDescription.contains("secret"))
        }
    }
}
