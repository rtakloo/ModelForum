import XCTest
@testable import ForumCore

final class ProviderAccountTests: XCTestCase {
    func testLabelsNormalizeAndRoundTripWithoutVerificationClaims() throws {
        let label = try ProviderAccountLabel(email: " desk-team@example.test ", accountID: " account-123 ", organization: " Research ", project: " project-456 ").validated()
        XCTAssertEqual(label.email, "desk-team@example.test")
        XCTAssertEqual(label.accountID, "account-123")
        XCTAssertEqual(label.organization, "Research")
        XCTAssertEqual(label.project, "project-456")
        XCTAssertTrue(label.summary?.contains("desk-team@example.test") == true)
        XCTAssertTrue(label.summary?.contains("account-123") == true)
        XCTAssertTrue(label.summary?.contains("unverified") == true)
        XCTAssertEqual(try JSONDecoder().decode(ProviderAccountLabel.self, from: JSONEncoder().encode(label)), label)
        let empty = try ProviderAccountLabel(email: "  ", accountID: "").validated()
        XCTAssertTrue(empty.isEmpty); XCTAssertNil(empty.summary)
    }

    func testAccountFieldsRejectCredentialsControlsAndOversizedValuesWithoutEchoingThem() {
        let unsafe = ["sk-proj-synthetic-test-credential", "sk-ant-synthetic-test-credential", "Bearer synthetic-private-token",
                      "ghp_syntheticsecret", "first\nsecond", "tab\tvalue", "hidden\u{202E}value", String(repeating: "x", count: 255)]
        for text in unsafe {
            for label in [ProviderAccountLabel(email: text), ProviderAccountLabel(accountID: text), ProviderAccountLabel(organization: text), ProviderAccountLabel(project: text)] {
                XCTAssertThrowsError(try label.validated()) { error in
                    XCTAssertEqual(error.localizedDescription, "Account labels must be at most 254 characters and cannot contain credentials, newlines, or control characters.")
                    XCTAssertFalse(error.localizedDescription.contains(text))
                }
                XCTAssertThrowsError(try JSONEncoder().encode(label))
            }
        }
    }

    func testDecodingUnsafeStoredLabelFailsWithoutDisplayingCredential() throws {
        let data = try JSONSerialization.data(withJSONObject: ["email": "sk-proj-synthetic-test-credential"])
        XCTAssertThrowsError(try JSONDecoder().decode(ProviderAccountLabel.self, from: data)) { error in
            XCTAssertFalse(error.localizedDescription.contains("synthetic-test-credential"))
        }
    }

    func testLegacyWorkspaceHasNoLabelsAndKeepsExistingTokenCap() throws {
        var state = SavedWorkspace.initial
        state.schemaVersion = 3
        state.maxOutputTokens = 8192
        let message = ChatMessage(role: "user", author: "You", content: "Keep this history")
        state.conversations[0].messages = [message]
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(state)) as? [String: Any])
        object.removeValue(forKey: "providerAccountLabels")
        let decoded = try JSONDecoder().decode(SavedWorkspace.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(decoded.schemaVersion, 3)
        XCTAssertTrue(decoded.providerAccountLabels.isEmpty)
        XCTAssertEqual(decoded.maxOutputTokens, 8192)
        XCTAssertEqual(decoded.conversations[0].messages[0].id, message.id)
        XCTAssertEqual(SavedWorkspace.initial.maxOutputTokens, 2048)
        XCTAssertEqual(SavedWorkspace.initial.schemaVersion, 5)
    }

    func testProviderLabelsRemainSeparateAndConnectionsDescribeIdentityLimits() throws {
        var state = SavedWorkspace.initial
        state.providerAccountLabels = [ProviderKind.openAI.rawValue: ProviderAccountLabel(email: "api@example.test", accountID: "openai-id"),
                                       ProviderKind.claudeCode.rawValue: ProviderAccountLabel(email: "cli@example.test", accountID: "cli-id")]
        let decoded = try JSONDecoder().decode(SavedWorkspace.self, from: JSONEncoder().encode(state))
        XCTAssertEqual(decoded.providerAccountLabels, state.providerAccountLabels)
        XCTAssertNil(decoded.providerAccountLabels[ProviderKind.anthropic.rawValue])
        XCTAssertEqual(ProviderKind.openAI.connectionDescription, "OpenAI API")
        XCTAssertEqual(ProviderKind.claudeCode.connectionDescription, "Claude Code session")
        XCTAssertTrue(ProviderKind.ollama.manualIdentityStatus.contains("Local models need no account"))
        XCTAssertTrue(ProviderKind.ollama.connectionDescription.contains("not verified"))
        XCTAssertTrue(ProviderKind.openAI.manualIdentityStatus.contains("not retrieved"))
    }
}
