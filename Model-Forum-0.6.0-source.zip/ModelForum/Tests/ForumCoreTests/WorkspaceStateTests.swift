import XCTest
@testable import ForumCore

final class WorkspaceStateTests: XCTestCase {
    func testOldWorkspaceMigrationPreservesMessagesAndSettings() throws {
        let message = ChatMessage(role: "user", author: "You", content: "Preserve this")
        let old = SavedWorkspace(conversations: [Conversation(title: "Existing", messages: [message])], participants: [Participant(alias: "gpt", provider: .openAI, model: "chosen-model")], maxOutputTokens: 4000)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(old)) as? [String: Any])
        object.removeValue(forKey: "channels"); object.removeValue(forKey: "artifacts"); object.removeValue(forKey: "schemaVersion")
        for key in ["globalInstructions", "agentInstructions", "requireNoTraining", "privacyConfirmations", "providerAccountLabels"] { object.removeValue(forKey: key) }
        var conversations = try XCTUnwrap(object["conversations"] as? [[String: Any]])
        conversations[0].removeValue(forKey: "channelID"); object["conversations"] = conversations
        let result = try JSONDecoder().decode(SavedWorkspace.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(result.schemaVersion, 1)
        XCTAssertTrue(result.channels.isEmpty); XCTAssertTrue(result.artifacts.isEmpty)
        XCTAssertEqual(result.conversations[0].messages[0].id, message.id)
        XCTAssertEqual(result.conversations[0].messages[0].content, "Preserve this")
        XCTAssertNil(result.conversations[0].channelID)
        XCTAssertEqual(result.participants[0].model, "chosen-model")
        XCTAssertEqual(result.maxOutputTokens, 4000)
        XCTAssertEqual(result.globalInstructions, "")
        XCTAssertTrue(result.agentInstructions.isEmpty)
        XCTAssertTrue(result.requireNoTraining)
        XCTAssertTrue(result.privacyConfirmations.isEmpty)
    }
    func testRenameMoveAndRelinkPreserveMessagesAndArtifactDestination() throws {
        var state = SavedWorkspace.initial
        let originalMessage = ChatMessage(role: "assistant", author: "gpt", content: "A document")
        state.conversations[0].messages = [originalMessage]
        let conversationID = state.conversations[0].id
        let first = try state.createChannel(name: "Research", repository: "https://github.com/owner/repo/", autoSave: true)
        let second = try state.createChannel(name: "Other", repository: nil, autoSave: false)
        try state.moveConversation(id: conversationID, channelID: first.id)
        let destination = try ArtifactFiles.destination(channel: first, conversationID: conversationID, artifactID: UUID(), filename: "paper.tex")
        state.artifacts = [ArtifactRecord(conversationID: conversationID, messageID: originalMessage.id, filename: "paper.tex", mimeType: "application/x-tex", relativePath: "existing", byteCount: 12, destination: destination)]
        try state.updateChannel(id: first.id, name: "Renamed", repository: "owner/different", autoSave: true)
        try state.renameConversation(id: conversationID, title: "Saved discussion")
        try state.moveConversation(id: conversationID, channelID: second.id)
        XCTAssertEqual(state.channels[0].folder, first.folder)
        XCTAssertEqual(state.channels[0].repository, "owner/different")
        XCTAssertEqual(state.artifacts[0].destination, destination)
        XCTAssertEqual(state.conversations[0].messages[0].id, originalMessage.id)
        XCTAssertEqual(state.conversations[0].channelID, second.id)
        try state.moveConversation(id: conversationID, channelID: nil)
        XCTAssertNil(state.conversations[0].channelID)
        let restored = try JSONDecoder().decode(SavedWorkspace.self, from: JSONEncoder().encode(state))
        XCTAssertEqual(restored.artifacts[0].destination, destination)
        XCTAssertEqual(restored.channels[0].folder, first.folder)
    }
    func testChannelValidationIsAtomic() throws {
        var state = SavedWorkspace.initial
        let channel = try state.createChannel(name: " Research ", repository: nil, autoSave: false)
        XCTAssertEqual(channel.name, "Research")
        for name in ["RESEARCH", "", "  ", String(repeating: "a", count: 81), "bad\u{0}name"] {
            XCTAssertThrowsError(try state.createChannel(name: name, repository: nil, autoSave: false))
        }
        XCTAssertThrowsError(try state.updateChannel(id: channel.id, name: "Changed", repository: nil, autoSave: true))
        XCTAssertEqual(state.channels[0].name, "Research")
        XCTAssertThrowsError(try state.moveConversation(id: state.conversations[0].id, channelID: UUID()))
        XCTAssertNil(state.conversations[0].channelID)
        XCTAssertThrowsError(try state.renameConversation(id: UUID(), title: "Unknown"))
    }
    func testRepositoryNormalizationRejectsUnsafeInputs() throws {
        XCTAssertEqual(try SavedWorkspace.normalizedRepository("https://github.com/owner/repo/"), "owner/repo")
        XCTAssertEqual(try SavedWorkspace.normalizedRepository(" owner/repo "), "owner/repo")
        XCTAssertNil(try SavedWorkspace.normalizedRepository(""))
        for value in ["https://evil.com/a/b", "http://github.com/a/b", "https://github.com/a/b/issues/1", "https://user@github.com/a/b", "https://github.com:443/a/b", "https://github.com/a/b?x=1", "https://github.com/a/b#main", "https://github.com/a/b%2Fc", "a/../b", "a/..", "a/b;echo", "a/b\nc", "-a/b", "a/b/", "a//b"] {
            XCTAssertThrowsError(try SavedWorkspace.normalizedRepository(value), value)
        }
    }
    func testVersionTwoWorkspaceAndLegacyChannelDecodeWithSafeDefaults() throws {
        var state = SavedWorkspace.initial
        let channel = try state.createChannel(name: "Existing research", repository: "owner/repo", autoSave: true)
        state.conversations[0].channelID = channel.id
        state.schemaVersion = 2
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(state)) as? [String: Any])
        for key in ["globalInstructions", "agentInstructions", "requireNoTraining", "privacyConfirmations", "providerAccountLabels"] { object.removeValue(forKey: key) }
        var channels = try XCTUnwrap(object["channels"] as? [[String: Any]])
        channels[0].removeValue(forKey: "deletedAt")
        object["channels"] = channels
        let restored = try JSONDecoder().decode(SavedWorkspace.self, from: JSONSerialization.data(withJSONObject: object))
        XCTAssertEqual(restored.schemaVersion, 2)
        XCTAssertEqual(restored.channels[0].id, channel.id)
        XCTAssertEqual(restored.channels[0].folder, channel.folder)
        XCTAssertTrue(restored.channels[0].autoSave)
        XCTAssertNil(restored.channels[0].deletedAt)
        XCTAssertEqual(restored.conversations[0].channelID, channel.id)
        XCTAssertEqual(restored.globalInstructions, "")
        XCTAssertTrue(restored.agentInstructions.isEmpty)
        XCTAssertTrue(restored.requireNoTraining)
        XCTAssertTrue(restored.privacyConfirmations.isEmpty)
        XCTAssertEqual(SavedWorkspace.initial.schemaVersion, 5)
    }

    func testDeleteAndRestorePreserveConversationAndArtifactHistory() throws {
        var state = SavedWorkspace.initial
        let channel = try state.createChannel(name: "Research", repository: "owner/repo", autoSave: true)
        let message = ChatMessage(role: "assistant", author: "@gpt", content: "Existing answer")
        let conversationID = state.conversations[0].id
        state.conversations[0].messages = [message]
        try state.moveConversation(id: conversationID, channelID: channel.id)
        let artifactID = UUID()
        let destination = try ArtifactFiles.destination(channel: channel, conversationID: conversationID, artifactID: artifactID, filename: "paper.tex")
        var artifact = ArtifactRecord(id: artifactID, conversationID: conversationID, messageID: message.id, filename: "paper.tex", mimeType: "application/x-tex", relativePath: artifactID.uuidString.lowercased() + "/paper.tex", byteCount: 17, destination: destination)
        artifact.syncState = .uploaded
        artifact.remoteURL = "https://github.com/owner/repo"
        artifact.commitSHA = String(repeating: "a", count: 40)
        state.artifacts = [artifact]
        try state.deleteChannel(id: channel.id)
        let deletionDate = try XCTUnwrap(state.channels[0].deletedAt)
        XCTAssertFalse(state.channels[0].autoSave)
        XCTAssertEqual(state.channels[0].name, channel.name)
        XCTAssertEqual(state.channels[0].folder, channel.folder)
        XCTAssertEqual(state.channels[0].repository, channel.repository)
        XCTAssertEqual(state.conversations[0].channelID, channel.id)
        XCTAssertEqual(state.conversations[0].messages[0].id, message.id)
        try state.deleteChannel(id: channel.id)
        XCTAssertEqual(state.channels[0].deletedAt, deletionDate)
        state = try JSONDecoder().decode(SavedWorkspace.self, from: JSONEncoder().encode(state))
        XCTAssertEqual(state.channels[0].deletedAt, deletionDate)
        try state.restoreChannel(id: channel.id)
        XCTAssertNil(state.channels[0].deletedAt)
        XCTAssertFalse(state.channels[0].autoSave)
        XCTAssertEqual(state.channels[0].id, channel.id)
        XCTAssertEqual(state.channels[0].folder, channel.folder)
        XCTAssertEqual(state.conversations[0].messages[0].content, message.content)
        XCTAssertEqual(state.artifacts[0].id, artifact.id)
        XCTAssertEqual(state.artifacts[0].relativePath, artifact.relativePath)
        XCTAssertEqual(state.artifacts[0].destination, artifact.destination)
        XCTAssertEqual(state.artifacts[0].syncState, artifact.syncState)
        XCTAssertEqual(state.artifacts[0].remoteURL, artifact.remoteURL)
        XCTAssertEqual(state.artifacts[0].commitSHA, artifact.commitSHA)
        XCTAssertEqual(state.schemaVersion, 5)
    }

    func testDeletedChannelRejectsEditsMovesAndDuplicateNamesUntilRestored() throws {
        var state = SavedWorkspace.initial
        let channel = try state.createChannel(name: "Research", repository: "owner/repo", autoSave: true)
        try state.deleteChannel(id: channel.id)
        XCTAssertThrowsError(try state.moveConversation(id: state.conversations[0].id, channelID: channel.id))
        XCTAssertNil(state.conversations[0].channelID)
        XCTAssertThrowsError(try state.updateChannel(id: channel.id, name: "Changed", repository: "owner/changed", autoSave: true))
        XCTAssertEqual(state.channels[0].name, channel.name)
        XCTAssertEqual(state.channels[0].repository, channel.repository)
        XCTAssertFalse(state.channels[0].autoSave)
        XCTAssertThrowsError(try state.createChannel(name: "RESEARCH", repository: nil, autoSave: false)) { error in
            XCTAssertTrue(error.localizedDescription.contains("deleted channel"))
        }
        XCTAssertThrowsError(try state.deleteChannel(id: UUID()))
        XCTAssertThrowsError(try state.restoreChannel(id: UUID()))
        try state.restoreChannel(id: channel.id)
        try state.moveConversation(id: state.conversations[0].id, channelID: channel.id)
        try state.updateChannel(id: channel.id, name: "Restored research", repository: channel.repository, autoSave: true)
        XCTAssertTrue(state.channels[0].autoSave)
        XCTAssertEqual(state.conversations[0].channelID, channel.id)
    }

    func testInstructionAndPrivacySettingsRoundTrip() throws {
        var state = SavedWorkspace.initial
        state.globalInstructions = "Verify important claims.\nKeep the user's notation."
        state.agentInstructions = ["gpt": "Draft a solution.", "claude": "Review independently.", "custom-alias": "Preserve my settings."]
        state.requireNoTraining = false
        state.privacyConfirmations = [ProviderKind.openAI.rawValue: true, ProviderKind.anthropic.rawValue: false]
        let restored = try JSONDecoder().decode(SavedWorkspace.self, from: JSONEncoder().encode(state))
        XCTAssertEqual(restored.schemaVersion, 5)
        XCTAssertEqual(restored.globalInstructions, state.globalInstructions)
        XCTAssertEqual(restored.agentInstructions, state.agentInstructions)
        XCTAssertFalse(restored.requireNoTraining)
        XCTAssertEqual(restored.privacyConfirmations, state.privacyConfirmations)
        XCTAssertNil(restored.privacyConfirmations[ProviderKind.claudeCode.rawValue])
    }

}
