import Foundation
import XCTest
import CryptoKit
@testable import ForumCore

final class SignedUpdateTests: XCTestCase {
    private let now = Date(timeIntervalSince1970: 1_800_000_000)
    private let zip = Data("test archive bytes".utf8)
    private var release: UpdateRelease {
        UpdateRelease(version: "0.6.1", build: 9, minimumMacOSMajor: 14, downloadURL: URL(string: "https://updates.example.test/app.zip")!, sha256: SHA256.hash(data: zip).map { String(format: "%02x", $0) }.joined(), byteCount: zip.count, expiresAt: now.addingTimeInterval(3600), notes: "Release notes")
    }
    private func envelope(_ release: UpdateRelease, key: Curve25519.Signing.PrivateKey) throws -> Data {
        let payload = try JSONEncoder().encode(release)
        return try JSONEncoder().encode(SignedUpdateEnvelope(payload: payload, signature: key.signature(for: payload)))
    }
    private func verify(_ data: Data, key: Curve25519.Signing.PrivateKey, build: Int = 8, date: Date? = nil) throws -> UpdateRelease {
        try SignedUpdate.verify(data, publicKey: key.publicKey.rawRepresentation, currentBuild: build, allowedHost: "updates.example.test", now: date ?? now, macOSMajor: 14)
    }
    func testSignedNewerReleaseAndExactDownloadAreAccepted() throws {
        let key = Curve25519.Signing.PrivateKey()
        let verified = try verify(envelope(release, key: key), key: key)
        XCTAssertEqual(verified.build, 9); XCTAssertEqual(verified.version, "0.6.1")
        XCTAssertNoThrow(try SignedUpdate.verifyDownload(zip, release: verified))
    }
    func testTamperedPayloadSignatureAndWrongPublicKeyAreRejected() throws {
        let key = Curve25519.Signing.PrivateKey()
        let data = try envelope(release, key: key)
        var altered = try JSONDecoder().decode(SignedUpdateEnvelope.self, from: data)
        altered.payload.append(32)
        XCTAssertThrowsError(try verify(JSONEncoder().encode(altered), key: key))
        altered = try JSONDecoder().decode(SignedUpdateEnvelope.self, from: data)
        altered.signature[0] ^= 1
        XCTAssertThrowsError(try verify(JSONEncoder().encode(altered), key: key))
        XCTAssertThrowsError(try verify(data, key: Curve25519.Signing.PrivateKey()))
    }
    func testRollbackSameBuildExpiredAndIncompatibleOSAreRejected() throws {
        let key = Curve25519.Signing.PrivateKey()
        let data = try envelope(release, key: key)
        XCTAssertThrowsError(try verify(data, key: key, build: 9))
        XCTAssertThrowsError(try verify(data, key: key, build: 10))
        XCTAssertThrowsError(try verify(data, key: key, date: release.expiresAt))
        XCTAssertThrowsError(try verify(data, key: key, date: release.expiresAt.addingTimeInterval(1)))
        var incompatible = release; incompatible.minimumMacOSMajor = 15
        XCTAssertThrowsError(try verify(envelope(incompatible, key: key), key: key))
    }
    func testDownloadURLsMustUsePinnedHTTPSHostWithoutCredentialsOrCustomPort() throws {
        let key = Curve25519.Signing.PrivateKey()
        for address in ["http://updates.example.test/app.zip", "https://evil.example/app.zip", "https://updates.example.test.evil.example/app.zip", "https://user:secret@updates.example.test/app.zip", "https://updates.example.test:8443/app.zip", "https://updates.example.test/app.dmg"] {
            var invalid = release; invalid.downloadURL = URL(string: address)!
            XCTAssertThrowsError(try verify(envelope(invalid, key: key), key: key)) { error in XCTAssertFalse(error.localizedDescription.contains("secret")) }
        }
    }
    func testSignedMetadataStillMustMeetBoundedSizeAndHashSchema() throws {
        let key = Curve25519.Signing.PrivateKey()
        for size in [0, -1, 536_870_913] {
            var invalid = release; invalid.byteCount = size
            XCTAssertThrowsError(try verify(envelope(invalid, key: key), key: key))
        }
        for digest in ["bad", String(repeating: "g", count: 64), String(repeating: "A", count: 64)] {
            var invalid = release; invalid.sha256 = digest
            XCTAssertThrowsError(try verify(envelope(invalid, key: key), key: key))
        }
        var invalid = release; invalid.version = String(repeating: "v", count: 65)
        XCTAssertThrowsError(try verify(envelope(invalid, key: key), key: key))
        invalid = release; invalid.notes = String(repeating: "n", count: 16_385)
        XCTAssertThrowsError(try verify(envelope(invalid, key: key), key: key))
    }
    func testMalformedOversizeEnvelopeAndInvalidVerificationKeyFailClosed() throws {
        let key = Curve25519.Signing.PrivateKey()
        XCTAssertThrowsError(try verify(Data("private malformed body".utf8), key: key)) { XCTAssertFalse($0.localizedDescription.contains("private malformed body")) }
        XCTAssertThrowsError(try verify(Data(repeating: 0, count: 256 * 1024 + 1), key: key))
        XCTAssertThrowsError(try SignedUpdate.verify(envelope(release, key: key), publicKey: Data([1]), currentBuild: 8, allowedHost: "updates.example.test", now: now))
    }
    func testDownloadRejectsSameLengthTamperingAndTruncation() throws {
        var tampered = zip; tampered[0] ^= 1
        XCTAssertThrowsError(try SignedUpdate.verifyDownload(tampered, release: release))
        XCTAssertThrowsError(try SignedUpdate.verifyDownload(zip.dropLast(), release: release))
        XCTAssertThrowsError(try SignedUpdate.verifyDownload(zip + Data([0]), release: release))
    }
}
