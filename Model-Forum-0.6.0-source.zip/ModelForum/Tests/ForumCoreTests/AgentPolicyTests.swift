import XCTest
@testable import ForumCore

final class AgentPolicyTests: XCTestCase {
    func testInstructionsPrecedeContextAndOnlySuppliedIndividualInstructionsAppear() throws {
        let result = try AgentPolicy.compose(transcript: "USER QUESTION", global: "GLOBAL PREFERENCE", individual: "AGENT ONE PREFERENCE")
        let global = try XCTUnwrap(result.range(of: "GLOBAL USER INSTRUCTIONS:\nGLOBAL PREFERENCE"))
        let individual = try XCTUnwrap(result.range(of: "INSTRUCTIONS FOR THIS AGENT:\nAGENT ONE PREFERENCE"))
        let context = try XCTUnwrap(result.range(of: "CONVERSATION CONTEXT AND CURRENT REQUEST:\nUSER QUESTION"))
        XCTAssertLessThan(global.lowerBound, individual.lowerBound)
        XCTAssertLessThan(individual.lowerBound, context.lowerBound)
        XCTAssertFalse(result.contains("AGENT TWO PREFERENCE"))
        let other = try AgentPolicy.compose(transcript: "USER QUESTION", global: "GLOBAL PREFERENCE", individual: "AGENT TWO PREFERENCE")
        XCTAssertFalse(other.contains("AGENT ONE PREFERENCE"))
    }

    func testEmptyPreferencesPreserveExactTranscript() throws {
        let transcript = "  original context\n"
        XCTAssertEqual(try AgentPolicy.compose(transcript: transcript, global: "", individual: ""), transcript)
        XCTAssertEqual(try AgentPolicy.compose(transcript: transcript, global: " \n", individual: "\t"), transcript)
    }

    func testInstructionLimitsCountUTF8Bytes() throws {
        let atLimit = String(repeating: "é", count: 10_000)
        XCTAssertNoThrow(try AgentPolicy.compose(transcript: "", global: atLimit, individual: atLimit))
        XCTAssertThrowsError(try AgentPolicy.compose(transcript: "", global: atLimit + "a", individual: ""))
        XCTAssertThrowsError(try AgentPolicy.compose(transcript: "", global: "", individual: atLimit + "a"))
    }

    func testTotalBudgetIncludesInstructionLabelsAndPreferences() throws {
        let context = String(repeating: "a", count: 240_000)
        XCTAssertEqual(try AgentPolicy.compose(transcript: context, global: "", individual: "").utf8.count, 240_000)
        XCTAssertThrowsError(try AgentPolicy.compose(transcript: context + "a", global: "", individual: ""))
        XCTAssertThrowsError(try AgentPolicy.compose(transcript: context, global: "Short preference", individual: ""))
    }

    func testInstructionsAreNotSilentlyTruncated() throws {
        let global = "  Keep this exact whitespace.\n"
        let individual = "Prefer evidence.\nEND"
        let result = try AgentPolicy.compose(transcript: "context", global: global, individual: individual)
        XCTAssertTrue(result.contains(global))
        XCTAssertTrue(result.contains(individual))
        XCTAssertTrue(result.hasSuffix("context"))
    }

    func testImageCompositionAndSeparateImageLimit() throws {
        XCTAssertEqual(try AgentPolicy.imagePrompt(prompt: "a bird", global: "", individual: ""), "a bird")
        let result = try AgentPolicy.imagePrompt(prompt: "a bird", global: "Use muted colors", individual: "Prefer watercolor")
        XCTAssertTrue(result.contains("GLOBAL USER INSTRUCTIONS:\nUse muted colors"))
        XCTAssertTrue(result.hasSuffix("IMAGE DESCRIPTION:\na bird"))
        XCTAssertNoThrow(try AgentPolicy.imagePrompt(prompt: String(repeating: "x", count: 32_000), global: "", individual: ""))
        XCTAssertThrowsError(try AgentPolicy.imagePrompt(prompt: String(repeating: "x", count: 32_000), global: "extra", individual: ""))
        XCTAssertThrowsError(try AgentPolicy.imagePrompt(prompt: " \n", global: "extra", individual: ""))
    }

    func testEveryProviderNeedsItsOwnExplicitConfirmation() throws {
        for provider in ProviderKind.allCases {
            XCTAssertThrowsError(try AgentPolicy.validatePrivacy(provider: provider, requireNoTraining: true, confirmations: [:]))
            XCTAssertThrowsError(try AgentPolicy.validatePrivacy(provider: provider, requireNoTraining: true, confirmations: [provider.rawValue: false]))
            XCTAssertNoThrow(try AgentPolicy.validatePrivacy(provider: provider, requireNoTraining: true, confirmations: [provider.rawValue: true]))
            let others = Dictionary(uniqueKeysWithValues: ProviderKind.allCases.filter { $0 != provider }.map { ($0.rawValue, true) })
            XCTAssertThrowsError(try AgentPolicy.validatePrivacy(provider: provider, requireNoTraining: true, confirmations: others))
        }
    }

    func testDisabledGuardDoesNotRequireConfirmationOrMutateSettings() throws {
        let confirmations = [ProviderKind.openAI.rawValue: false]
        for provider in ProviderKind.allCases {
            XCTAssertNoThrow(try AgentPolicy.validatePrivacy(provider: provider, requireNoTraining: false, confirmations: confirmations))
        }
        XCTAssertEqual(confirmations, [ProviderKind.openAI.rawValue: false])
    }

    func testErrorsContainNoUserInstructionsOrContext() {
        let privateText = "PRIVATE-SENTINEL" + String(repeating: "x", count: 20_000)
        XCTAssertThrowsError(try AgentPolicy.compose(transcript: "SENSITIVE CONTEXT", global: privateText, individual: "")) { error in
            XCTAssertFalse(error.localizedDescription.contains("PRIVATE-SENTINEL"))
            XCTAssertFalse(error.localizedDescription.contains("SENSITIVE CONTEXT"))
        }
    }
}
