import XCTest
@testable import ForumCore

private actor GitHubHTTPFixture {
    var replies: [GitHubHTTPResponse]
    var requests: [URLRequest] = []
    var limits: [Int] = []
    init(_ json: [String], statuses: [Int]? = nil) {
        replies = json.enumerated().map { .init(status: statuses?[$0.offset] ?? 200, data: Data($0.element.utf8)) }
    }
    func send(_ request: URLRequest, limit: Int) throws -> GitHubHTTPResponse {
        requests.append(request); limits.append(limit)
        guard !replies.isEmpty else { throw GitHubAppError.invalidResponse }
        return replies.removeFirst()
    }
}
final class GitHubAppClientTests: XCTestCase {
    private func client(_ fixture: GitHubHTTPFixture, token: String? = nil) -> GitHubAppClient {
        .init(token: token) { request, limit in try await fixture.send(request, limit: limit) }
    }
    func testDeviceAuthorizationUsesPublicClientIDAndFixedHost() async throws {
        let fixture = GitHubHTTPFixture([#"{"device_code":"fixture-device","user_code":"ABCD-EFGH","verification_uri":"https://github.com/login/device","expires_in":900,"interval":5}"#])
        let authorization = try await client(fixture).begin(clientID: "Iv1.fixture123")
        XCTAssertEqual(authorization.userCode, "ABCD-EFGH")
        let requests = await fixture.requests
        let request = try XCTUnwrap(requests.first)
        XCTAssertEqual(request.url?.absoluteString, "https://github.com/login/device/code")
        XCTAssertNil(request.value(forHTTPHeaderField: "Authorization"))
        let body = try XCTUnwrap(try JSONSerialization.jsonObject(with: request.httpBody!) as? [String: String])
        XCTAssertEqual(body, ["client_id": "Iv1.fixture123"])
    }
    func testPendingAndSlowDownThenAuthenticatedIdentity() async throws {
        let fixture = GitHubHTTPFixture([
            #"{"error":"authorization_pending"}"#, #"{"error":"slow_down"}"#,
            #"{"access_token":"ghu_fixture_only","token_type":"bearer","expires_in":28800}"#,
            #"{"id":42,"login":"fixture-user"}"#
        ])
        let authorization = GitHubDeviceAuthorization(userCode: "ABCD-EFGH", expiresAt: Date().addingTimeInterval(900), deviceCode: "test", interval: 1, clientID: "Iv1.fixture123")
        let credential = try await client(fixture).finish(authorization, sleep: { _ in })
        XCTAssertEqual(credential.account, .init(id: 42, login: "fixture-user"))
        XCTAssertNotNil(credential.expiresAt)
        let requests = await fixture.requests
        XCTAssertEqual(requests.count, 4)
        XCTAssertEqual(requests.last?.url?.absoluteString, "https://api.github.com/user")
        XCTAssertEqual(requests.last?.value(forHTTPHeaderField: "Authorization"), "Bearer ghu_fixture_only")
        XCTAssertFalse(String(data: requests[0].httpBody!, encoding: .utf8)!.contains("client_secret"))
    }
    func testDeviceDenialAndCancellationDoNotFetchUser() async throws {
        let authorization = GitHubDeviceAuthorization(userCode: "ABCD-EFGH", expiresAt: Date().addingTimeInterval(900), deviceCode: "test", interval: 1, clientID: "Iv1.fixture123")
        let fixture = GitHubHTTPFixture([#"{"error":"access_denied"}"#])
        do { _ = try await client(fixture).finish(authorization, sleep: { _ in }); XCTFail() }
        catch { XCTAssertEqual(error as? GitHubAppError, .denied) }
        let cancelFixture = GitHubHTTPFixture([])
        do { _ = try await client(cancelFixture).finish(authorization, sleep: { _ in throw CancellationError() }); XCTFail() }
        catch { XCTAssertTrue(error is CancellationError) }
        let requests = await cancelFixture.requests
        XCTAssertTrue(requests.isEmpty)
    }
    func testHostileDeviceURIAndInvalidClientRejected() async throws {
        let fixture = GitHubHTTPFixture([#"{"device_code":"fixture","user_code":"ABCD-EFGH","verification_uri":"https://attacker.invalid/login/device","expires_in":900,"interval":5}"#])
        do { _ = try await client(fixture).begin(clientID: "Iv1.fixture123"); XCTFail() }
        catch { XCTAssertEqual(error as? GitHubAppError, .invalidResponse) }
        let other = GitHubHTTPFixture([])
        do { _ = try await client(other).begin(clientID: "secret\nvalue"); XCTFail() }
        catch { XCTAssertEqual(error as? GitHubAppError, .configuration) }
        let requests = await other.requests
        XCTAssertTrue(requests.isEmpty)
    }
    func testSelectedRepositoriesAndPermissions() async throws {
        let fixture = GitHubHTTPFixture([
            #"{"installations":[{"id":8,"permissions":{"contents":"write","pull_requests":"read","issues":"read"}}]}"#,
            #"{"repositories":[{"id":9,"full_name":"owner/repo","permissions":{"push":true}}]}"#
        ])
        let repositories = try await client(fixture, token: "ghu_fixture_only").repositories()
        XCTAssertEqual(repositories.count, 1)
        XCTAssertEqual(repositories[0].contents, "write")
        XCTAssertEqual(repositories[0].pullRequests, "read")
        XCTAssertTrue(repositories[0].userCanPush)
        let requests = await fixture.requests
        XCTAssertEqual(requests[1].url?.path, "/user/installations/8/repositories")
    }
    func testPermissionDeniedBeforeMutationAndHTTPFailuresAreSanitized() async throws {
        let fixture = GitHubHTTPFixture([
            #"{"installations":[{"id":8,"permissions":{"contents":"read"}}]}"#,
            #"{"repositories":[{"id":9,"full_name":"owner/repo","permissions":{"push":true}}]}"#
        ])
        do { try await client(fixture, token: "ghu_fixture_only").require(repository: "owner/repo", permission: "contents", write: true); XCTFail() }
        catch { XCTAssertEqual(error as? GitHubAppError, .permissions) }
        let auth = GitHubHTTPFixture([#"{"message":"secret sentinel"}"#], statuses: [401])
        do { _ = try await client(auth, token: "ghu_fixture_only").api("user"); XCTFail() }
        catch { XCTAssertEqual(error as? GitHubAppError, .expired); XCTAssertFalse(error.localizedDescription.contains("sentinel")) }
    }
    func testTransportLimitsAndFixedAPIOrigin() async throws {
        let fixture = GitHubHTTPFixture([String(repeating: "x", count: 100)])
        do { _ = try await client(fixture, token: "ghu_fixture_only").api("user", limit: 50); XCTFail() }
        catch { XCTAssertEqual(error as? GitHubAppError, .tooLarge) }
        let other = GitHubHTTPFixture([])
        do { _ = try await client(other, token: "ghu_fixture_only").api("https://attacker.invalid/user"); XCTFail() }
        catch { XCTAssertEqual(error as? GitHubAppError, .invalidResponse) }
        let requests = await other.requests
        XCTAssertTrue(requests.isEmpty)
    }
}

extension GitHubAppClientTests {
    func testBuiltInIssueAndPRImportsTranslateRESTWithoutCLI() async throws {
        let fixture = GitHubHTTPFixture([
            #"{"title":"Issue title","body":"Issue body"}"#,
            #"{"title":"PR title","body":"PR body","head":{"sha":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"}}"#
        ])
        let session = GitHubAccessSession(client: client(fixture, token: "ghu_fixture_only"), generation: GitHubAppConnection.generation)
        let issue = try GitHubRequest("https://github.com/owner/repo/issues/3")
        let pr = try GitHubRequest("https://github.com/owner/repo/pull/4")
        let issueData = try await session.arguments(issue.arguments)
        let prData = try await session.arguments(pr.arguments)
        let issueObject = try XCTUnwrap(try JSONSerialization.jsonObject(with: issueData) as? [String: String])
        let prObject = try XCTUnwrap(try JSONSerialization.jsonObject(with: prData) as? [String: String])
        XCTAssertEqual(issueObject["title"], "Issue title")
        XCTAssertEqual(prObject["headRefOid"], String(repeating: "a", count: 40))
        let requests = await fixture.requests
        XCTAssertEqual(requests.map { $0.url!.path }, ["/repos/owner/repo/issues/3", "/repos/owner/repo/pulls/4"])
    }
    func testBuiltInEmptyRepositoryAndPinnedContentArguments() async throws {
        let fixture = GitHubHTTPFixture([
            #"{"description":"Empty repo","private":true,"default_branch":"main","size":0}"#,
            #"{"message":"empty"}"#, #"{"type":"file","sha":"fixture"}"#
        ], statuses: [200, 409, 200])
        let session = GitHubAccessSession(client: client(fixture, token: "ghu_fixture_only"), generation: GitHubAppConnection.generation)
        let request = try GitHubRequest("https://github.com/rtakloo/Chatgpt")
        let data = try await session.arguments(request.arguments)
        let object = try XCTUnwrap(try JSONSerialization.jsonObject(with: data) as? [String: Any])
        XCTAssertEqual(object["isEmpty"] as? Bool, true)
        _ = try await session.arguments(GitHubRepository.api("repos/rtakloo/Chatgpt/contents", sha: String(repeating: "a", count: 40)))
        let requests = await fixture.requests
        XCTAssertEqual(requests.last?.url?.query, "ref=" + String(repeating: "a", count: 40))
    }
    func testBuiltInAuthenticationFailureNeverFallsBackToCLI() async throws {
        let fixture = GitHubHTTPFixture([#"{"message":"bad credential"}"#], statuses: [401])
        let session = GitHubAccessSession(client: client(fixture, token: "ghu_fixture_only"), generation: GitHubAppConnection.generation)
        do { _ = try await session.api("user"); XCTFail() }
        catch { XCTAssertEqual(error as? GitHubAppError, .expired) }
        let requests = await fixture.requests
        XCTAssertEqual(requests.count, 1)
    }
}
