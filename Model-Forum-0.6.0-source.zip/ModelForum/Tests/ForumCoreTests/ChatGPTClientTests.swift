import Foundation
import XCTest
@testable import ForumCore

final class ChatGPTClientTests: XCTestCase {
    private var session: URLSession!
    private var client: ChatGPTClient!
    private var credentials: ChatGPTCredentials {
        ChatGPTCredentials(accessToken: "test-oauth-secret", refreshToken: "test-refresh-secret", idToken: nil, expiresAt: Date().addingTimeInterval(3600), scopes: ["resource.invoke", "chatgpt.tokens.use.direct"])
    }
    override func setUp() {
        super.setUp()
        let config = URLSessionConfiguration.ephemeral; config.protocolClasses = [ChatGPTStub.self]
        session = URLSession(configuration: config); client = ChatGPTClient(session: session)
    }
    override func tearDown() { session.invalidateAndCancel(); ChatGPTStub.handler = nil; client = nil; session = nil; super.tearDown() }

    func testCatalogUsesSelectedOAuthAccountPreservesOrderingAndFiltersVisibility() async throws {
        ChatGPTStub.handler = { request in
            XCTAssertEqual(request.url?.absoluteString, "https://api.openai.com/v1/models")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-oauth-secret")
            return (200, "application/json", #"{"models":[{"slug":"second","display_name":"Second","visibility":"list"},{"slug":"hidden","visibility":"hide"},{"slug":"first","display_name":"First","visibility":"list"}]}"#)
        }
        let models = try await client.models(credentials: credentials)
        XCTAssertEqual(models.map(\.id), ["second", "first"])
        XCTAssertEqual(models.map(\.name), ["Second", "First"])
    }
    func testMissingPlanScopePreventsAnyNetworkRequest() async {
        ChatGPTStub.handler = { _ in XCTFail("No request without plan scope"); return (500, "application/json", "") }
        let identityOnly = ChatGPTCredentials(accessToken: "test", refreshToken: nil, idToken: nil, expiresAt: Date(), scopes: ["openid"])
        do { _ = try await client.models(credentials: identityOnly); XCTFail("Expected scope error") }
        catch { XCTAssertTrue(error.localizedDescription.contains("has not granted")) }
        do { _ = try await client.reply(model: "model", transcript: "prompt", credentials: identityOnly); XCTFail("Expected scope error") }
        catch { XCTAssertTrue(error.localizedDescription.contains("has not granted")) }
    }
    func testStreamingRequestHasRequiredFieldsAndWaitsForCompletedEvent() async throws {
        let deltas = ChatGPTDeltaCollector()
        ChatGPTStub.handler = { request in
            XCTAssertEqual(request.url?.absoluteString, "https://api.openai.com/v1/responses")
            let body = try Self.body(request)
            XCTAssertEqual(body["stream"] as? Bool, true); XCTAssertEqual(body["store"] as? Bool, false)
            XCTAssertEqual((body["input"] as? [[String: String]])?.first?["content"], "private prompt")
            XCTAssertNil(body["max_output_tokens"]); XCTAssertNil(body["tools"]); XCTAssertNil(body["previous_response_id"])
            return (200, "text/event-stream", Self.event(["type": "response.output_text.delta", "delta": "Answer"]) + Self.completed())
        }
        let result = try await client.reply(model: "chosen", transcript: "private prompt", credentials: credentials) { delta in await deltas.add(delta) }
        XCTAssertEqual(result.text, "Answer"); XCTAssertEqual(result.model, "actual-model"); XCTAssertEqual(result.outputTokens, 7)
        let captured = await deltas.values; XCTAssertEqual(captured, ["Answer"])
    }
    func testPartialInterruptedIncompleteOrFailedStreamsNeverReturnSuccessfulAnswer() async {
        let fixtures = [
            Self.event(["type": "response.output_text.delta", "delta": "partial"]),
            Self.event(["type": "response.incomplete", "response": ["status": "incomplete"]]),
            Self.event(["type": "response.failed", "response": ["error": ["code": "subscription_sharing_usage_limit_exceeded", "message": "test-oauth-secret private prompt"]]]),
            "data: not-json\n\n",
            "data: [DONE]\n\n"
        ]
        for fixture in fixtures {
            ChatGPTStub.handler = { _ in (200, "text/event-stream", fixture) }
            do { _ = try await client.reply(model: "model", transcript: "private prompt", credentials: credentials); XCTFail("Partial stream accepted") }
            catch { XCTAssertFalse(error.localizedDescription.contains("test-oauth-secret")); XCTAssertFalse(error.localizedDescription.contains("private prompt")) }
        }
    }
    func testUsageFailureAfterDeltasIsActionableAndSanitized() async {
        ChatGPTStub.handler = { _ in (200, "text/event-stream", Self.event(["type": "response.output_text.delta", "delta": "partial"]) + Self.event(["type": "response.failed", "response": ["error": ["code": "subscription_sharing_usage_limit_exceeded", "message": "test-oauth-secret"]]])) }
        do { _ = try await client.reply(model: "model", transcript: "prompt", credentials: credentials); XCTFail("Expected usage failure") }
        catch { XCTAssertTrue(error.localizedDescription.contains("whole plan may still")); XCTAssertFalse(error.localizedDescription.contains("test-oauth-secret")) }
    }
    func testHTTPAdmissionAndTransportErrorsNeverEchoSecrets() async {
        for status in [401, 403, 429, 503, 302] {
            ChatGPTStub.handler = { _ in (status, "application/json", #"{"detail":"test-oauth-secret private prompt"}"#) }
            do { _ = try await client.models(credentials: credentials); XCTFail("Expected HTTP failure") }
            catch { XCTAssertTrue(error.localizedDescription.contains("HTTP \(status)")); XCTAssertFalse(error.localizedDescription.contains("test-oauth-secret")); XCTAssertFalse(error.localizedDescription.contains("private prompt")) }
        }
        ChatGPTStub.handler = { _ in throw URLError(.timedOut, userInfo: [NSLocalizedDescriptionKey: "test-oauth-secret"]) }
        do { _ = try await client.models(credentials: credentials); XCTFail("Expected timeout") }
        catch { XCTAssertTrue(error.localizedDescription.contains("timed out")); XCTAssertFalse(error.localizedDescription.contains("test-oauth-secret")) }
    }
    func testAuthorizationCodeExchangeVerifiesSignedIdentityAndUsesExactCallback() async throws {
        let fixture = try ChatGPTJWTFixture()
        let pending = try ChatGPTAuthorization(redirectURI: URL(string: "http://127.0.0.1:12345/auth/callback")!)
        let token = try fixture.token(changes: ["nonce": pending.nonce])
        ChatGPTStub.handler = { request in
            XCTAssertNil(request.value(forHTTPHeaderField: "Authorization"))
            switch request.url!.path {
            case "/api/accounts/oauth/token":
                let form = try Self.data(request)
                let values = URLComponents(string: "https://example.test/?" + String(data: form, encoding: .utf8)!)!.queryItems!
                XCTAssertEqual(values.first { $0.name == "redirect_uri" }?.value, pending.redirectURI.absoluteString)
                XCTAssertEqual(values.first { $0.name == "code_verifier" }?.value, pending.verifier)
                XCTAssertEqual(values.first { $0.name == "client_id" }?.value, "oaiapp_test")
                XCTAssertFalse(values.contains { $0.name == "client_secret" })
                let data = try JSONSerialization.data(withJSONObject: ["access_token": "test-oauth-secret", "refresh_token": "test-refresh-secret", "id_token": token, "token_type": "Bearer", "expires_in": 3600, "scope": "resource.invoke chatgpt.tokens.use.direct"])
                return (200, "application/json", String(data: data, encoding: .utf8)!)
            case "/.well-known/openid-configuration": return (200, "application/json", Self.discovery)
            case "/.well-known/jwks.json": return (200, "application/json", String(data: fixture.jwks, encoding: .utf8)!)
            default: XCTFail("Unexpected endpoint"); throw URLError(.badURL)
            }
        }
        let (saved, identity) = try await client.exchange(code: "one-time-code", clientID: "oaiapp_test", authorization: pending)
        XCTAssertTrue(saved.permitsInference); XCTAssertEqual(identity.subject, "subject-test")
        XCTAssertEqual(saved.refreshToken, "test-refresh-secret")
    }
    func testRefreshReplacesRotatingTokenAndPreservesOmittedScope() async throws {
        ChatGPTStub.handler = { request in
            let data = try Self.data(request)
            let body = String(data: data, encoding: .utf8)!
            XCTAssertTrue(body.contains("grant_type=refresh_token")); XCTAssertTrue(body.contains("client_id=oaiapp_saved"))
            XCTAssertFalse(body.contains("scope=")); XCTAssertFalse(body.contains("dynamic_agent_client"))
            return (200, "application/json", #"{"access_token":"new-access","refresh_token":"new-refresh","token_type":"Bearer","expires_in":3600}"#)
        }
        let result = try await client.refresh(credentials, clientID: "oaiapp_saved", expectedIdentity: ChatGPTIdentity(subject: "subject", email: nil, emailVerified: false))
        XCTAssertEqual(result.refreshToken, "new-refresh"); XCTAssertEqual(result.accessToken, "new-access"); XCTAssertTrue(result.permitsInference)
    }
    func testInvalidRefreshTokenIsTerminalButNetworkFailureIsNot() async {
        ChatGPTStub.handler = { _ in (400, "application/json", #"{"error":"invalid_grant","error_description":"test-refresh-secret"}"#) }
        do { _ = try await client.refresh(credentials, clientID: "client", expectedIdentity: ChatGPTIdentity(subject: "subject", email: nil, emailVerified: false)); XCTFail("Expected terminal error") }
        catch { XCTAssertTrue(error is ChatGPTSessionError); XCTAssertFalse(error.localizedDescription.contains("test-refresh-secret")) }
        ChatGPTStub.handler = { _ in throw URLError(.notConnectedToInternet) }
        do { _ = try await client.refresh(credentials, clientID: "client", expectedIdentity: ChatGPTIdentity(subject: "subject", email: nil, emailVerified: false)); XCTFail("Expected connection error") }
        catch { XCTAssertFalse(error is ChatGPTSessionError) }
    }
    func testRefreshRejectsAValidlySignedDifferentAccount() async throws {
        let fixture = try ChatGPTJWTFixture()
        let token = try fixture.token(changes: ["sub": "different-account", "aud": "oaiapp_saved"])
        ChatGPTStub.handler = { request in
            if request.url!.path == "/.well-known/openid-configuration" { return (200, "application/json", Self.discovery) }
            if request.url!.path == "/.well-known/jwks.json" { return (200, "application/json", String(data: fixture.jwks, encoding: .utf8)!) }
            let data = try JSONSerialization.data(withJSONObject: ["access_token": "new-access", "refresh_token": "new-refresh", "id_token": token, "token_type": "Bearer", "expires_in": 3600])
            return (200, "application/json", String(data: data, encoding: .utf8)!)
        }
        do {
            _ = try await client.refresh(credentials, clientID: "oaiapp_saved", expectedIdentity: ChatGPTIdentity(subject: "original-account", email: nil, emailVerified: false))
            XCTFail("Account changed during refresh")
        } catch { XCTAssertTrue(error.localizedDescription.contains("did not match the saved account")) }
    }
    func testSSEHandlesCommentsCRLFAndMultipleDataLines() throws {
        var decoder = ChatGPTEventDecoder(); var result: Data?
        for byte in Data(":keepalive\r\nevent: message\r\ndata: {\"type\":\r\ndata: \"test\"}\r\n\r\n".utf8) { if let event = try decoder.append(byte) { result = event } }
        XCTAssertEqual(String(data: try XCTUnwrap(result), encoding: .utf8), "{\"type\":\n\"test\"}")
    }
    private static let discovery = #"{"issuer":"https://auth.openai.com","authorization_endpoint":"https://auth.openai.com/api/accounts/authorize","token_endpoint":"https://auth.openai.com/api/accounts/oauth/token","jwks_uri":"https://auth.openai.com/.well-known/jwks.json","revocation_endpoint":"https://auth.openai.com/api/accounts/oauth/revoke"}"#
    private static func event(_ object: [String: Any]) -> String { "data: " + String(data: try! JSONSerialization.data(withJSONObject: object), encoding: .utf8)! + "\n\n" }
    private static func completed() -> String {
        event(["type": "response.completed", "response": ["status": "completed", "model": "actual-model", "output": [["type": "message", "role": "assistant", "status": "completed", "content": [["type": "output_text", "text": "Answer"]]]], "usage": ["input_tokens": 4, "output_tokens": 7]]])
    }
    private static func body(_ request: URLRequest) throws -> [String: Any] { try XCTUnwrap(JSONSerialization.jsonObject(with: data(request)) as? [String: Any]) }
    private static func data(_ request: URLRequest) throws -> Data {
        if let data = request.httpBody { return data }
        let stream = try XCTUnwrap(request.httpBodyStream); stream.open(); defer { stream.close() }
        var data = Data(); var buffer = [UInt8](repeating: 0, count: 4096)
        while stream.hasBytesAvailable { let count = stream.read(&buffer, maxLength: buffer.count); if count <= 0 { break }; data.append(buffer, count: count) }
        return data
    }
}

private actor ChatGPTDeltaCollector { var values: [String] = []; func add(_ value: String) { values.append(value) } }
private final class ChatGPTStub: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, String, String))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            let (status, mime, body) = try XCTUnwrap(Self.handler)(request)
            let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: nil, headerFields: ["Content-Type": mime])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: Data(body.utf8)); client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}
