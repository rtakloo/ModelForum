import XCTest
@testable import ForumCore

private actor ArtifactTransportFixture {
    enum Step: @unchecked Sendable { case response(Data), failure(Error) }
    struct Call: Sendable { let arguments: [String]; let input: Data }
    private var steps: [Step]
    private(set) var calls = [Call]()
    init(_ steps: [Step]) { self.steps = steps }
    func send(_ arguments: [String], _ input: Data) throws -> Data {
        calls.append(Call(arguments: arguments, input: input))
        guard !steps.isEmpty else { throw GitHubFetchError.invalidResponse }
        switch steps.removeFirst() { case .response(let data): return data; case .failure(let error): throw error }
    }
}

final class GitHubArtifactClientTests: XCTestCase {
    private let branch = "model-forum-artifacts"
    private let startingSHA = String(repeating: "a", count: 40)
    private let savedSHA = String(repeating: "b", count: 40)
    private let bytes = Data("Private artifact; $(never execute)\n".utf8)
    private var destination: ArtifactDestination {
        ArtifactDestination(repository: "rtakloo/Chatgpt", path: "model-forum/channels/11111111-1111-1111-1111-111111111111/conversations/22222222-2222-2222-2222-222222222222/33333333-3333-3333-3333-333333333333/report.md")
    }
    private func encoded(_ value: Any) throws -> Data { try JSONSerialization.data(withJSONObject: value) }
    private func response(_ value: Any) throws -> ArtifactTransportFixture.Step { .response(try encoded(value)) }
    private func reference(_ branchName: String? = nil, sha: String? = nil) throws -> ArtifactTransportFixture.Step {
        try response(["ref": "refs/heads/\(branchName ?? branch)", "object": ["type": "commit", "sha": sha ?? startingSHA]])
    }
    private func content(_ data: Data? = nil) -> [String: Any] {
        let data = data ?? bytes
        return ["type": "file", "path": destination.path, "sha": GitHubArtifactClient.gitBlobSHA(data), "size": data.count,
                "html_url": "https://evil.invalid/untrusted-link"]
    }
    private func written() throws -> ArtifactTransportFixture.Step {
        try response(["content": content(), "commit": ["sha": savedSHA]])
    }
    private func client(_ fixture: ArtifactTransportFixture) -> GitHubArtifactClient {
        GitHubArtifactClient { arguments, input in try await fixture.send(arguments, input) }
    }
    private func methods(_ calls: [ArtifactTransportFixture.Call]) -> [String] {
        calls.map { $0.arguments[$0.arguments.firstIndex(of: "--method")! + 1] }
    }

    func testExistingBranchGetsDestinationBeforeStdinPut() async throws {
        let fixture = ArtifactTransportFixture(try [reference(), .failure(GitHubFetchError.http(404)), written()])
        let result = try await client(fixture).upload(data: bytes, destination: destination)
        let calls = await fixture.calls
        XCTAssertEqual(methods(calls), ["GET", "GET", "PUT"])
        XCTAssertTrue(calls[1].arguments.contains("ref=\(startingSHA)"))
        XCTAssertTrue(calls[1].arguments.contains("Accept: application/vnd.github.object+json"))
        XCTAssertEqual(Array(calls[1].arguments.suffix(2)), ["--jq", "{type,path,sha,size}"])
        let payload = try XCTUnwrap(JSONSerialization.jsonObject(with: calls[2].input) as? [String: Any])
        XCTAssertEqual(payload["branch"] as? String, branch)
        XCTAssertEqual(payload["content"] as? String, bytes.base64EncodedString())
        XCTAssertNil(payload["sha"], "Never provide an update SHA that would allow overwriting")
        XCTAssertEqual(Array(calls[2].arguments.suffix(2)), ["--input", "-"])
        XCTAssertFalse(calls[2].arguments.joined().contains(bytes.base64EncodedString()))
        XCTAssertEqual(result.commitSHA, savedSHA)
        XCTAssertEqual(result.url, "https://github.com/rtakloo/Chatgpt/blob/\(savedSHA)/\(destination.path)")
        XCTAssertFalse(result.url.contains("evil"))
        for call in calls { XCTAssertEqual(call.arguments[call.arguments.firstIndex(of: "--hostname")! + 1], "github.com") }
    }

    func testCreatesOnlyDedicatedBranchFromDefaultCommit() async throws {
        let fixture = ArtifactTransportFixture(try [
            .failure(GitHubFetchError.http(404)), response(["default_branch": "release/v1"]), reference("release/v1"),
            reference(), .failure(GitHubFetchError.http(404)), written()
        ])
        _ = try await client(fixture).upload(data: bytes, destination: destination)
        let calls = await fixture.calls
        XCTAssertEqual(methods(calls), ["GET", "GET", "GET", "POST", "GET", "PUT"])
        XCTAssertEqual(calls[2].arguments[1], "repos/rtakloo/Chatgpt/git/ref/heads/release%2Fv1")
        XCTAssertEqual(calls[3].arguments[1], "repos/rtakloo/Chatgpt/git/refs")
        let payload = try XCTUnwrap(JSONSerialization.jsonObject(with: calls[3].input) as? [String: String])
        XCTAssertEqual(payload, ["ref": "refs/heads/model-forum-artifacts", "sha": startingSHA])
        XCTAssertEqual(Array(calls[3].arguments.suffix(2)), ["--input", "-"])
    }

    func testIdenticalExistingArtifactIsIdempotentWithoutMutation() async throws {
        let fixture = ArtifactTransportFixture(try [reference(), response(content())])
        let result = try await client(fixture).upload(data: bytes, destination: destination)
        let calls = await fixture.calls
        XCTAssertEqual(methods(calls), ["GET", "GET"])
        XCTAssertEqual(result.commitSHA, startingSHA)
    }

    func testDifferentExistingBytesNeverOverwritten() async throws {
        let fixture = ArtifactTransportFixture(try [reference(), response(content(Data("different".utf8)))])
        do { _ = try await client(fixture).upload(data: bytes, destination: destination); XCTFail("Expected conflict") }
        catch { XCTAssertEqual(error as? ArtifactUploadError, .conflict) }
        let calls = await fixture.calls
        XCTAssertEqual(methods(calls), ["GET", "GET"])
    }

    func testAmbiguousPutRetryReadsExistingAndDoesNotWriteTwice() async throws {
        let fixture = ArtifactTransportFixture(try [
            reference(), .failure(GitHubFetchError.http(404)), .failure(SubprocessError.timedOut),
            reference(sha: savedSHA), response(content())
        ])
        let uploader = client(fixture)
        do { _ = try await uploader.upload(data: bytes, destination: destination); XCTFail("Expected unconfirmed result") }
        catch { XCTAssertEqual(error as? ArtifactUploadError, .unavailable) }
        let result = try await uploader.upload(data: bytes, destination: destination)
        let calls = await fixture.calls
        XCTAssertEqual(methods(calls), ["GET", "GET", "PUT", "GET", "GET"])
        XCTAssertEqual(result.commitSHA, savedSHA)
    }

    func testBranchCreationRaceOnlyRecoversMatchingCommit() async throws {
        for matching in [true, false] {
            var steps: [ArtifactTransportFixture.Step] = try [
                .failure(GitHubFetchError.http(404)), response(["default_branch": "main"]), reference("main"),
                .failure(GitHubFetchError.http(422)), reference(sha: matching ? startingSHA : savedSHA)
            ]
            if matching { steps.append(try response(content())) }
            let fixture = ArtifactTransportFixture(steps)
            do {
                _ = try await client(fixture).upload(data: bytes, destination: destination)
                XCTAssertTrue(matching)
            } catch { XCTAssertFalse(matching); XCTAssertEqual(error as? ArtifactUploadError, .branchRace) }
            let calls = await fixture.calls
            XCTAssertEqual(methods(calls).filter { $0 == "POST" }.count, 1)
            XCTAssertFalse(methods(calls).contains("PUT"))
        }
    }

    func testAuthenticationAndProtectedBranchErrorsAreActionable() async throws {
        for status in [401, 403, 409, 422] {
            let fixture = ArtifactTransportFixture(try [reference(), .failure(GitHubFetchError.http(404)), .failure(GitHubFetchError.http(status))])
            do { _ = try await client(fixture).upload(data: bytes, destination: destination); XCTFail("Expected write failure") }
            catch { XCTAssertEqual(error as? ArtifactUploadError, status == 401 || status == 403 ? .accessDenied : .protectedBranch) }
        }
        let fixture = ArtifactTransportFixture([.failure(GitHubFetchError.http(403))])
        do { _ = try await client(fixture).upload(data: bytes, destination: destination); XCTFail("Expected read denial") }
        catch { XCTAssertEqual(error as? ArtifactUploadError, .accessDenied) }
        let calls = await fixture.calls
        XCTAssertEqual(methods(calls), ["GET"])
    }

    func testUnsafeDestinationsFailBeforeTransport() async throws {
        var invalid = [ArtifactDestination]()
        var changed = destination; changed.branch = "main"; invalid.append(changed)
        changed = destination; changed.repository = "owner/repo?secret=x"; invalid.append(changed)
        for path in [".github/workflows/test.yml", destination.path + "/../x", destination.path.replacingOccurrences(of: "report.md", with: "%2Ffile"),
                     destination.path.replacingOccurrences(of: "report.md", with: "../file"), destination.path.replacingOccurrences(of: "report.md", with: "report.md\n"),
                     destination.path.replacingOccurrences(of: "11111111-1111-1111-1111-111111111111", with: "not-a-uuid")] {
            changed = destination; changed.path = path; invalid.append(changed)
        }
        let fixture = ArtifactTransportFixture([])
        let uploader = client(fixture)
        for target in invalid {
            do { _ = try await uploader.upload(data: bytes, destination: target); XCTFail("Unsafe destination accepted") }
            catch { XCTAssertEqual(error as? ArtifactUploadError, .invalidDestination) }
        }
        let calls = await fixture.calls
        XCTAssertTrue(calls.isEmpty)
    }

    func testEmptyRepositoryDoesNotCreateInitialCommit() async throws {
        let fixture = ArtifactTransportFixture(try [.failure(GitHubFetchError.http(404)), response(["default_branch": "main"]), .failure(GitHubFetchError.http(409))])
        do { _ = try await client(fixture).upload(data: bytes, destination: destination); XCTFail("Expected empty repository") }
        catch { XCTAssertEqual(error as? ArtifactUploadError, .emptyRepository) }
        let calls = await fixture.calls
        XCTAssertTrue(methods(calls).allSatisfy { $0 == "GET" })
    }

    func testMalformedResponseStopsWithoutWriteAndDoesNotLeak() async throws {
        for data in [Data("secret-access-token".utf8), try encoded(["ref": "refs/heads/\(branch)", "object": ["sha": "invalid", "type": "commit"]])] {
            let fixture = ArtifactTransportFixture([.response(data)])
            do { _ = try await client(fixture).upload(data: bytes, destination: destination); XCTFail("Expected invalid response") }
            catch {
                XCTAssertEqual(error as? ArtifactUploadError, .invalidResponse)
                XCTAssertFalse(error.localizedDescription.contains("secret-access-token"))
            }
            let calls = await fixture.calls
            XCTAssertEqual(methods(calls), ["GET"])
        }
    }

    func testSizeBoundaryAndGitBlobHash() throws {
        XCTAssertEqual(GitHubArtifactClient.gitBlobSHA(Data()), "e69de29bb2d1d6434b8b29ae775ad8c2e48c5391")
        try GitHubArtifactClient.validate(data: Data(repeating: 0, count: 8 * 1_024 * 1_024), destination: destination)
        XCTAssertThrowsError(try GitHubArtifactClient.validate(data: Data(repeating: 0, count: 8 * 1_024 * 1_024 + 1), destination: destination)) { error in
            XCTAssertEqual(error as? ArtifactUploadError, .tooLarge)
        }
    }

    func testMaximumBinaryPayloadFitsTransportWithoutSlashExpansion() async throws {
        let data = Data(repeating: 255, count: 8 * 1_024 * 1_024)
        let fixture = ArtifactTransportFixture(try [reference(), .failure(GitHubFetchError.http(404)),
            response(["content": content(data), "commit": ["sha": savedSHA]])])
        _ = try await client(fixture).upload(data: data, destination: destination)
        let calls = await fixture.calls
        XCTAssertLessThan(calls[2].input.count, 12 * 1_024 * 1_024)
        let payload = try XCTUnwrap(JSONSerialization.jsonObject(with: calls[2].input) as? [String: Any])
        XCTAssertEqual(Data(base64Encoded: try XCTUnwrap(payload["content"] as? String)), data)
    }

    func testFilenameWithSpacesEncodesEndpointAndResultURL() async throws {
        var target = destination
        target.path = target.path.replacingOccurrences(of: "report.md", with: "my paper.tex")
        var file = content()
        file["path"] = target.path
        let fixture = ArtifactTransportFixture(try [reference(), .failure(GitHubFetchError.http(404)),
            response(["content": file, "commit": ["sha": savedSHA]])])
        let result = try await client(fixture).upload(data: bytes, destination: target)
        let calls = await fixture.calls
        for call in calls.suffix(2) {
            XCTAssertTrue(call.arguments[1].hasSuffix("/my%20paper.tex"))
            XCTAssertFalse(call.arguments[1].contains(" "))
        }
        XCTAssertTrue(result.url.hasSuffix("/my%20paper.tex"))
        XCTAssertFalse(result.url.contains(" "))
        for name in ["my paper.tex ", "my..paper.tex", "_paper.tex", "my%20paper.tex", "my/paper.tex"] {
            target.path = destination.path.replacingOccurrences(of: "report.md", with: name)
            XCTAssertThrowsError(try GitHubArtifactClient.validate(data: bytes, destination: target), name)
        }
    }
}
