import XCTest
@testable import ForumCore

final class ArtifactFilesTests: XCTestCase {
    private func withStore(_ body: (ArtifactFiles) throws -> Void) throws {
        let root = URL(fileURLWithPath: "/private/tmp", isDirectory: true).appendingPathComponent("artifact-tests-" + UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        try body(ArtifactFiles(root: root))
    }
    private func draft(_ filename: String = "paper.tex", _ text: String = "sample") -> ArtifactDraft {
        ArtifactDraft(filename: filename, mimeType: "text/plain", data: Data(text.utf8))
    }
    func testStoreReadPermissionsAndImmutableContents() throws {
        try withStore { store in
            let id = UUID()
            let path = try store.store(draft: draft(), id: id)
            XCTAssertEqual(path, id.uuidString.lowercased() + "/paper.tex")
            XCTAssertEqual(try store.read(relativePath: path), Data("sample".utf8))
            XCTAssertEqual(try store.store(draft: draft(), id: id), path)
            XCTAssertThrowsError(try store.store(draft: draft("paper.tex", "changed"), id: id))
            XCTAssertEqual(try store.read(relativePath: path), Data("sample".utf8))
            let url = try store.url(relativePath: path)
            let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
            XCTAssertEqual((attributes[.posixPermissions] as? NSNumber)?.intValue, 0o600)
            let rootAttributes = try FileManager.default.attributesOfItem(atPath: store.root.path)
            XCTAssertEqual((rootAttributes[.posixPermissions] as? NSNumber)?.intValue, 0o700)
        }
    }
    func testTraversalAndUnsupportedExtensionsRejected() throws {
        try withStore { store in
            for name in ["../secret.tex", "/tmp/secret.tex", "sub/file.tex", "sub\\file.tex", ".secret.tex", "a..tex", "evil.exe", "x%2F.tex", "a\n.tex"] {
                XCTAssertThrowsError(try store.store(draft: draft(name), id: UUID()), name)
            }
            for path in ["../secret.tex", "/tmp/secret.tex", "notuuid/paper.tex", UUID().uuidString.lowercased() + "/../x.tex"] {
                XCTAssertThrowsError(try store.read(relativePath: path), path)
            }
        }
    }
    func testSymlinkFileAndDirectoryRejectedWithoutWritingTarget() throws {
        try withStore { store in
            let id = UUID(), another = UUID()
            let path = try store.store(draft: draft(), id: id)
            let target = try store.url(relativePath: path)
            let linkedFile = target.deletingLastPathComponent().appendingPathComponent("linked.tex")
            try FileManager.default.createSymbolicLink(at: linkedFile, withDestinationURL: target)
            XCTAssertThrowsError(try store.read(relativePath: id.uuidString.lowercased() + "/linked.tex"))
            XCTAssertThrowsError(try store.store(draft: draft("linked.tex", "overwrite"), id: id))
            let linkedDirectory = store.root.appendingPathComponent(another.uuidString.lowercased())
            try FileManager.default.createSymbolicLink(at: linkedDirectory, withDestinationURL: target.deletingLastPathComponent())
            XCTAssertThrowsError(try store.store(draft: draft("other.tex"), id: another))
            let linkedRoot = store.root.appendingPathComponent("linked-root")
            try FileManager.default.createSymbolicLink(at: linkedRoot, withDestinationURL: store.root)
            XCTAssertThrowsError(try ArtifactFiles(root: linkedRoot).store(draft: draft(), id: UUID()))
            XCTAssertEqual(try store.read(relativePath: path), Data("sample".utf8))
        }
    }
    func testOversizedFileRejected() throws {
        try withStore { store in
            let oversized = ArtifactDraft(filename: "big.txt", mimeType: "text/plain", data: Data(repeating: 65, count: ArtifactFiles.maximumBytes + 1))
            XCTAssertThrowsError(try store.store(draft: oversized, id: UUID()))
        }
    }
    func testDestinationIsStableAndRequiresOptIn() throws {
        var channel = Channel(name: "Research", repository: "owner/repo", autoSave: true)
        let conversation = UUID(), artifact = UUID()
        let original = try ArtifactFiles.destination(channel: channel, conversationID: conversation, artifactID: artifact, filename: "paper.tex")
        XCTAssertEqual(original?.branch, "model-forum-artifacts")
        XCTAssertEqual(original?.path, channel.folder + "/conversations/" + conversation.uuidString.lowercased() + "/" + artifact.uuidString.lowercased() + "/paper.tex")
        channel.name = "New name"
        XCTAssertEqual(try ArtifactFiles.destination(channel: channel, conversationID: conversation, artifactID: artifact, filename: "paper.tex"), original)
        channel.autoSave = false
        XCTAssertNil(try ArtifactFiles.destination(channel: channel, conversationID: conversation, artifactID: artifact, filename: "paper.tex"))
        channel.autoSave = true; channel.folder = "../../bad"
        XCTAssertThrowsError(try ArtifactFiles.destination(channel: channel, conversationID: conversation, artifactID: artifact, filename: "paper.tex"))
    }
    func testExplicitFilesAndStandaloneLatexExtractedButSnippetsIgnored() throws {
        let text = "Here is the file.\n```markdown filename=notes.md\n# Notes\n```\n```python\nprint('ordinary snippet')\n```"
        let files = try ArtifactFiles.extract(from: text)
        XCTAssertEqual(files.count, 1); XCTAssertEqual(files[0].filename, "notes.md")
        XCTAssertEqual(String(data: files[0].data, encoding: .utf8), "# Notes\n")
        let latex = "\\documentclass{article}\n\\begin{document}\nHello\n\\end{document}"
        XCTAssertEqual(try ArtifactFiles.extract(from: "```latex\n" + latex + "\n```").first?.filename, "document.tex")
        XCTAssertEqual(try ArtifactFiles.extract(from: latex).first?.filename, "document.tex")
        XCTAssertTrue(try ArtifactFiles.extract(from: "```latex\nx^2+y^2\n```").isEmpty)
        XCTAssertTrue(try ArtifactFiles.extract(from: "![photo](https://example.com/photo.png)").isEmpty)
        XCTAssertEqual(try ArtifactFiles.extract(from: "```text filename=\"My notes.txt\"\nHello\n```").first?.filename, "My notes.txt")
    }
    func testMalformedDuplicateAndTooManyFilesFailVisibly() throws {
        for text in ["```tex filename=../paper.tex\nx\n```", "```text filename=image.png\nbase64content\n```", "```text filename=note.txt\nunclosed", "```text filename=note.txt\nx\n```\n```text filename=NOTE.txt\ny\n```", (0..<9).map { "```text filename=file\($0).txt\nx\n```" }.joined(separator: "\n")] {
            XCTAssertThrowsError(try ArtifactFiles.extract(from: text))
        }
    }
}
