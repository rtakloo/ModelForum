import XCTest
@testable import ForumCore

final class ClaudeAccountTests: XCTestCase {
    private func decode(_ object: [String: Any]) throws -> ClaudeAccountStatus {
        try ClaudeAccountStatus.decode(JSONSerialization.data(withJSONObject: object))
    }
    func testOfficialStatusFieldsAndMissingAccountIDRemainExplicit() throws {
        let status = try decode(["loggedIn": true, "authMethod": "claude.ai", "email": "fixture@example.invalid", "orgId": "org-fixture", "subscriptionType": "max"])
        XCTAssertTrue(status.loggedIn)
        XCTAssertEqual(status.email, "fixture@example.invalid")
        XCTAssertEqual(status.organizationID, "org-fixture")
        XCTAssertEqual(status.subscriptionType, "max")
        XCTAssertNil(status.accountID)
        XCTAssertTrue(status.summary.contains("ID not supplied"))
        let loggedOut = try decode(["loggedIn": false, "authMethod": "none"])
        XCTAssertEqual(loggedOut.summary, "Not signed in")
    }
    func testAccountOrOrganizationChangesInvalidateIdentityButPlanChangeDoesNot() throws {
        let baseline: [String: Any] = ["loggedIn": true, "authMethod": "claude.ai", "email": "a@example.invalid", "accountId": "account-a", "orgId": "org-a", "subscriptionType": "pro"]
        let original = try decode(baseline)
        for field in ["email", "accountId", "orgId", "authMethod"] {
            var changed = baseline; changed[field] = field == "authMethod" ? "api_key" : "different"
            XCTAssertNotEqual(try decode(changed).identityKey, original.identityKey)
        }
        var plan = baseline; plan["subscriptionType"] = "max"
        XCTAssertEqual(try decode(plan).identityKey, original.identityKey)
    }
    func testUnknownMethodsMalformedStatusAndOversizedResponsesFailClosed() throws {
        for object: [String: Any] in [["loggedIn": true, "authMethod": "unknown"], ["loggedIn": "yes"], ["authMethod": "none"]] {
            XCTAssertThrowsError(try decode(object))
        }
        XCTAssertThrowsError(try ClaudeAccountStatus.decode(Data("broken JSON".utf8)))
        XCTAssertThrowsError(try ClaudeAccountStatus.decode(Data(repeating: 32, count: 65_537)))
    }
    func testUntrustedIdentityFieldsCannotDisplayControlCharactersOrTokenLikeValues() throws {
        for value in ["sk-fixture-not-a-real-key", "Bearer fixture", "line\nbreak", "bidi\u{202e}marker", String(repeating: "x", count: 513)] {
            let status = try decode(["loggedIn": true, "authMethod": "api_key", "email": value, "accountId": value, "orgId": value, "subscriptionType": value])
            XCTAssertNil(status.email); XCTAssertNil(status.accountID); XCTAssertNil(status.organizationID); XCTAssertNil(status.subscriptionType)
            XCTAssertFalse(status.summary.contains(value))
        }
    }
    func testUnexpectedSecretFieldsAreNotDecodedOrReencoded() throws {
        let status = try decode(["loggedIn": true, "authMethod": "claude.ai", "email": "fixture@example.invalid", "accessToken": "fixture-secret-sentinel"])
        let encoded = String(data: try JSONEncoder().encode(status), encoding: .utf8)!
        XCTAssertFalse(encoded.contains("fixture-secret-sentinel"))
        XCTAssertFalse(status.summary.contains("fixture-secret-sentinel"))
    }
}
