import Foundation
import XCTest
@testable import ForumCore

final class ModelCatalogTests: XCTestCase {
    private var session: URLSession!
    private var catalog: ModelCatalog!
    override func setUp() {
        super.setUp()
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [CatalogStubProtocol.self]
        session = URLSession(configuration: config)
        catalog = ModelCatalog(session: session)
    }
    override func tearDown() {
        session.invalidateAndCancel()
        CatalogStubProtocol.handler = nil
        catalog = nil; session = nil
        super.tearDown()
    }

    func testOpenAIListsFiltersAndDeduplicatesWithoutInference() async throws {
        CatalogStubProtocol.handler = { request in
            XCTAssertEqual(request.url?.absoluteString, "https://api.openai.com/v1/models")
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertNil(request.httpBody)
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-secret")
            XCTAssertNil(request.value(forHTTPHeaderField: "x-api-key"))
            XCTAssertFalse(request.httpShouldHandleCookies)
            return (200, #"{"data":[{"id":"gpt-4o-mini"},{"id":"gpt-4.1"},{"id":"gpt-4o-mini"},{"id":"o3"},{"id":"gpt-4o-audio-preview"},{"id":"gpt-4o-realtime-preview"},{"id":"gpt-4o-mini-transcribe"},{"id":"gpt-4o-mini-tts"},{"id":"gpt-image-1"},{"id":"gpt-4o-search-preview"},{"id":"text-embedding-3-small"},{"id":"unrecognized-model"}]}"#)
        }
        let result = try await catalog.models(for: .openAI, apiKey: "test-secret")
        XCTAssertEqual(result.map(\.id), ["gpt-4.1", "gpt-4o-mini", "o3"])
        XCTAssertEqual(result.map(\.name), result.map(\.id))
    }

    func testAnthropicPaginationUsesCursorAndDisplayNames() async throws {
        var calls = 0
        CatalogStubProtocol.handler = { request in
            calls += 1
            XCTAssertEqual(request.url?.host, "api.anthropic.com")
            XCTAssertEqual(request.value(forHTTPHeaderField: "x-api-key"), "test-secret")
            XCTAssertEqual(request.value(forHTTPHeaderField: "anthropic-version"), "2023-06-01")
            XCTAssertNil(request.value(forHTTPHeaderField: "Authorization"))
            let query = URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems ?? []
            XCTAssertEqual(query.first { $0.name == "limit" }?.value, "100")
            if calls == 1 {
                XCTAssertNil(query.first { $0.name == "after_id" })
                return (200, #"{"data":[{"id":"model-b","display_name":"Beta"}],"has_more":true,"last_id":"cursor+/?&"}"#)
            }
            XCTAssertEqual(query.first { $0.name == "after_id" }?.value, "cursor+/?&")
            return (200, #"{"data":[{"id":"model-a","display_name":"Alpha"},{"id":"model-b","display_name":"Beta"}],"has_more":false,"last_id":"model-a"}"#)
        }
        let result = try await catalog.models(for: .anthropic, apiKey: "test-secret")
        XCTAssertEqual(calls, 2)
        XCTAssertEqual(result, [ModelOption(id: "model-a", name: "Alpha"), ModelOption(id: "model-b", name: "Beta")])
    }

    func testOllamaDoesNotReceiveCloudCredentials() async throws {
        CatalogStubProtocol.handler = { request in
            XCTAssertEqual(request.url?.absoluteString, "http://127.0.0.1:11434/api/tags")
            XCTAssertNil(request.value(forHTTPHeaderField: "Authorization"))
            XCTAssertNil(request.value(forHTTPHeaderField: "x-api-key"))
            XCTAssertNil(request.value(forHTTPHeaderField: "anthropic-version"))
            return (200, #"{"models":[{"name":"local-model:latest","model":"different-metadata"}]}"#)
        }
        let result = try await catalog.models(for: .ollama, apiKey: "cloud-secret")
        XCTAssertEqual(result, [ModelOption(id: "local-model:latest", name: "local-model:latest")])
    }

    func testCLIAliasesNeedNeitherNetworkNorKey() async throws {
        CatalogStubProtocol.handler = { _ in XCTFail("CLI aliases should not load remotely"); return (500, "") }
        let result = try await catalog.models(for: .claudeCode, apiKey: nil)
        XCTAssertEqual(result.map(\.id), ["sonnet", "opus", "haiku"])
    }

    func testImageCatalogOnlyReturnsActualImageIDs() async throws {
        CatalogStubProtocol.handler = { request in
            XCTAssertEqual(request.url?.absoluteString, "https://api.openai.com/v1/models")
            XCTAssertEqual(request.httpMethod, "GET")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-secret")
            XCTAssertNil(request.value(forHTTPHeaderField: "x-api-key"))
            return (200, #"{"data":[{"id":"gpt-4.1"},{"id":"gpt-image-1"},{"id":"gpt-image-1-mini"},{"id":"gpt-image-1"},{"id":"dall-e-3"},{"id":"unknown-image-model"}]}"#)
        }
        let result = try await catalog.imageModels(apiKey: "test-secret")
        XCTAssertEqual(result, [ModelOption(id: "gpt-image-1", name: "gpt-image-1"), ModelOption(id: "gpt-image-1-mini", name: "gpt-image-1-mini")])
    }

    func testImageCatalogRequiresKeyBeforeNetwork() async {
        CatalogStubProtocol.handler = { _ in XCTFail("Missing key must not reach the network"); return (500, "") }
        do {
            _ = try await catalog.imageModels(apiKey: nil)
            XCTFail("Expected key validation failure")
        } catch { XCTAssertTrue(error is ForumError) }
    }

    func testImageCatalogDoesNotInventFallbackModels() async throws {
        CatalogStubProtocol.handler = { _ in (200, #"{"data":[{"id":"gpt-4.1"}]}"#) }
        let result = try await catalog.imageModels(apiKey: "test-secret")
        XCTAssertTrue(result.isEmpty)
    }

    func testMissingAndInvalidKeysNeverSendRequests() async {
        CatalogStubProtocol.handler = { _ in XCTFail("Invalid keys must not be sent"); return (500, "") }
        for provider in [ProviderKind.openAI, .anthropic] {
            for key in [nil, "", "a\nb", "abc\u{0000}def"] as [String?] {
                do {
                    _ = try await catalog.models(for: provider, apiKey: key)
                    XCTFail("Expected key validation error")
                } catch { XCTAssertTrue(error is ForumError) }
            }
        }
    }

    func testHTTPAndMalformedErrorsNeverEchoSensitiveBodies() async {
        for (status, body) in [(401, "private-secret"), (429, "private-secret"), (302, "private-secret"), (200, "private-secret"), (200, #"{"wrong":[]}"#)] {
            CatalogStubProtocol.handler = { _ in (status, body) }
            do {
                _ = try await catalog.models(for: .openAI, apiKey: "test-secret")
                XCTFail("Expected listing error")
            } catch {
                XCTAssertFalse(error.localizedDescription.contains("private-secret"))
                XCTAssertFalse(error.localizedDescription.contains("test-secret"))
                XCTAssertTrue(error is ForumError)
            }
        }
    }

    func testRepeatedCursorFailsInsteadOfLooping() async {
        var calls = 0
        CatalogStubProtocol.handler = { _ in
            calls += 1
            return (200, #"{"data":[{"id":"model-a"}],"has_more":true,"last_id":"model-a"}"#)
        }
        do {
            _ = try await catalog.models(for: .anthropic, apiKey: "test-secret")
            XCTFail("Expected pagination error")
        } catch { XCTAssertTrue(error.localizedDescription.contains("pagination")) }
        XCTAssertEqual(calls, 2)
    }

    func testPaginationStopsAtTenPages() async {
        var calls = 0
        CatalogStubProtocol.handler = { _ in
            calls += 1
            return (200, "{\"data\":[{\"id\":\"model-\(calls)\"}],\"has_more\":true,\"last_id\":\"model-\(calls)\"}")
        }
        do {
            _ = try await catalog.models(for: .anthropic, apiKey: "test-secret")
            XCTFail("Expected page limit error")
        } catch { XCTAssertTrue(error.localizedDescription.contains("10-page")) }
        XCTAssertEqual(calls, 10)
    }

    func testResponseByteLimit() async {
        CatalogStubProtocol.handler = { _ in (200, String(repeating: " ", count: 2 * 1024 * 1024 + 1)) }
        do {
            _ = try await catalog.models(for: .ollama, apiKey: nil)
            XCTFail("Expected size limit error")
        } catch { XCTAssertTrue(error.localizedDescription.contains("size limit")) }
    }

    func testTimeoutAndCancellation() async {
        for code in [URLError.timedOut, URLError.cancelled] {
            CatalogStubProtocol.handler = { _ in throw URLError(code, userInfo: [NSLocalizedDescriptionKey: "private-secret"]) }
            do {
                _ = try await catalog.models(for: .openAI, apiKey: "test-secret")
                XCTFail("Expected network error")
            } catch {
                XCTAssertFalse(error.localizedDescription.contains("private-secret"))
                if code == .cancelled { XCTAssertTrue(error is CancellationError) }
                else { XCTAssertTrue(error.localizedDescription.contains("timed out")) }
            }
        }
    }
}

private final class CatalogStubProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, String))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            guard let handler = Self.handler else { throw URLError(.unknown) }
            let (status, body) = try handler(request)
            let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: "HTTP/1.1", headerFields: ["Content-Type": "application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: Data(body.utf8))
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}
