// Synthetic RSA test keys generated solely for offline JWT fixtures.
// Publicly distributed test material: never use for a service, account, or real credential.
enum ChatGPTSyntheticRSAKeys {
    static let primary = """
    MIIEpAIBAAKCAQEAzcEQ1dyrlPBgcSPG7j44EGneWu0PhEiJPXr+gow82k1wdOQf
    0mU+dqbgFb861lOyAKeqQL9hVdhAkR/7G9Y0i1wmwU5G1ELg6/jBsRCrIBGCEiKt
    xtg3zW8cXTRKHzMa7xPFhv8FNpxopsUdXSKl3W3W6rLAfYKdAIG1iZKwQfolU6KF
    SYNz8POd6MS6kr0dBvshDCwcWVu8oTvXad07jW+M59ZT/UpZQUEZTvp/IH07oXUa
    ggnZaJr3PM/bx8msbjz9PIZx1Q6J25929Q55H0H548U/DW+GeIW6I9k1dYcvwd+J
    t+kbzyWRXIVuPxnFe+/AajomqnY8RIBjqcpBSwIDAQABAoIBAAy6hzvDwAr3Epr3
    4fmhIxTDh+b2HWyglCTtM/Yy43IvMj14/g2lB8fiq6A3dACzAs25kaBvISq6CxyE
    maNE4tFFl9GDnIF1ywuuGEVySN6IrBRKeEJXOUnd4tJSnCHxURbokTgNv257ye7v
    PibMhZhSOuZ1Z8/GlxyN6a4jbgCsHXavuWyfAxQ6Ug8XIiVhLdquUXe4gmJluxWf
    BxyXlcQWNohRFMqAu130DPpfWvVqHGWCse5AWJcUGwgdDwfsyGq5jy6QTbBv7SUo
    OuCS764uovlve/CaQDpHuOT7hBg/CRh81ZS+AQHVMhNkFUuSeg4wRpqSkravRWeb
    jrPUk/kCgYEA+CfNfBEYkXJQThkwsKt4C1dvvXR3Cg3W+dbscnq9LZ1UVntS8ZAm
    SCadMC5acayWHL79+AH1jOHReAvHAGTLN0GvHbPwl9e5/g4TdpIMpfUOj9DPtFBB
    TvtzHJ70vBZO+zVmMtOwaSVh3dC4jRxmQPLuwPD+sRY0qZOvlnx4IW8CgYEA1EIh
    bmUIFgDwPjs5ScrFp3fXkkX7R3IXXjQRAWdYpkIGNdJ4aXYdvWBNTgXv4rhNdxjo
    yLyCk5Ov9ZcxcsguRuaYEOcvGl53qJctv7hoipX2+i5rDBHtMN3/1Hi44UbxkcxF
    7+7ga3LsTsFFldQae/gM4b48U0FqFWyKReFyt+UCgYEA7ZGFWhIv2AZ9NNdO0sPF
    L+5sLg7Sa5CmTxbf1BUHCSVGeWilFlevHoHBGEA4G/1i1HBQSN7vSglh9LApuonE
    NskuMZxzZ5qCF+M35NqbO0Hox+va/L+cVlXJdQwENhCRWlNb3KrmhzLfh3BrTcRz
    bBhmU9YjrjsY/YNCpSnSBAcCgYEAypI6ebMuXmGS5rF64TQGIue68rybLfpy1tL2
    D9LjxfhpGOC/TlcN1vibjoUYBdZDCBDbyQgvzkw6uDYNWTA3Ci90nV0llRLnPBzb
    6odCLlElHmtCeoh5SBP23n5AY69jSPQdIvllcOaDJD5L/MwqYnm/QYpe5E4fwkaO
    SFb7NwkCgYAqdy7UfK3zVRCTZImkMHsk0vJwwklbbnJTHudoiHFceUbNqd/b3UcQ
    atI//L+QbwAuj6TSPemuOBMs9QJ85VpnCKeRmqlIq69oMNEQDjUg6BjQWmH4BReK
    nptUG1tDLANMHkNKnkMZk4Z4I17mIhpUcKmuB7MdvtBzRTy4uZ6yXg==
    """
    static let alternate = """
    MIIEpAIBAAKCAQEAwmDFQSKkkAqzRltYpWwmM7i6GUXUORISSFqoWihfLFUkqxGM
    JLBllzHLsZbEg2QC6fgV6ff9nJn7xJorFh3WToiYfTwBnIi0rkeRvHNZMO8JD/Xs
    +VyTN9iYJgkR18Hr/GzrWWYeImXabXKDxHUDjGkxEblUbN0m+Trkn/VddahSB9ps
    u8I0exhk9XGU+gTGatxStXHZI9of6ysymo/Hh5ShfrvYnzHxohpNg+7Dyv2GZOOw
    L/M/kJ6cupCLJA9NLsD3YOWwqqzf9r1uRz/TQl4a8LYgyYrTQRL247MlLCoeZrrO
    S8Qt1jfvHSCTsJd6lqSbSdVOFidHSVYwK9vSfQIDAQABAoIBABvzDTn98Lqzhy6t
    MNRsdhvGyp+arlbcdduIiZ+ZIYI+5exhNA0Mfjcc1mS9QJmB9ndNEF2ZppJvg8ez
    wVFHTgrx0jdjuvmWoKBUsyxtS5xhKqTsYDxE5vhHQS1q7XFgNX4Q7VBoAhpBGgTV
    zAOiLbXxZDhftTeIHzQEF162yc8CekJpb97Lq4Ra0ojfhkzS3MiAHY7dCP0ltTJW
    5gUNMFow2imapITC9CPQkzxD4rwMIrWN5ExWGa3+imj78l+dMrKV+ycvHNRL5Mj+
    jVpFsVt70e/14UnQ3/DlgorEHtt9b2UmXpPqA6nKdqMyertJWyyptwkUIL1Nkfil
    3/I0RQECgYEA579gAVfe5f5Qhd3+6qF4wV1OTzQEVSdzqrtuaRxlqGe+r439R6d6
    eiCr3xwPtQDMqqbYo1rpitUWxi3/Jv8wEuLvbgj32DRTEzSfvqc2gmfqN7hzAu5n
    DMbGDt5cFKQ2Q1HHl87qxVMAGo4QdKt9T1DCsIIKGlFduTh4kiUS8oECgYEA1rg/
    dhnU+0bjNB3DLl0iNGu6l3rkTbCBnVK5juId29LT6V7lDq52xfsynC9cy9O+RzvK
    3E6p1hcIoqJKiD8EdsmUSLJ66zyP94VSlSgRzT4DADm/aJI1NX+SbRYtvdWZV2RI
    EtoDUs/nlWEwli1KyKxJyApjF82UqysgPVqLqf0CgYBqy3U5iT3NrSF8Xy4O//Q+
    33mr5COu/iw+XHtn8s8iCRUFn6A9ef9l8lJh0XOnjMPETHj+5nFDKimBkEbJuMV1
    nqCJi5ZzSsGR0yleWX40ICD+JoDRs/1HFP7GcU/rrzTWVwRsf80Ou84LbrZEnZZ0
    i5n8byCquh4/sbdWWcFegQKBgQCNg4dH1gSZy4GI4qi10OnvNKUYmwUG8vKp9lCX
    jA1zyMKjh0hd4bwkBce4SjrVl2tL1WuAwVOL50hor5+Bpk7R308cjo0WpqaX0sW3
    yl3ZMCqYJncxe1MYPEkMHlbtS26xu0UJL6iLFr0hpZl5EMa99Vb3QWlH0dVO7rBj
    3143HQKBgQDOxGJ2kgVpla/SRtroUnYLsur8U36uAJPhgguhdS2H7WUfFWLSrrXr
    QXmdOmu7U4E0d3ryN9hbjPPUQYOdgb5AB2jxIYqUolIKyohhyEG80261tMxLF15U
    qHDuEQNqn0ZLTVJ5yXzUsAbj4zikPUOdM7g61QB/6sI3Zbx0ntHXqw==
    """
}
