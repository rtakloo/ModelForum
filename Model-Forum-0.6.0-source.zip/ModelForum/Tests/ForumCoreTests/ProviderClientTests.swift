import Foundation
import XCTest
@testable import ForumCore

final class ProviderClientTests: XCTestCase {
    private var session: URLSession!
    private var client: ProviderClient!
    override func setUp() {
        super.setUp()
        let config = URLSessionConfiguration.ephemeral
        config.protocolClasses = [ProviderStubProtocol.self]
        session = URLSession(configuration: config)
        client = ProviderClient(session: session)
    }
    override func tearDown() {
        session.invalidateAndCancel()
        ProviderStubProtocol.handler = nil
        client = nil; session = nil
        super.tearDown()
    }

    private func participant(_ provider: ProviderKind = .openAI, model: String = "configured-model") -> Participant {
        Participant(alias: "test", provider: provider, model: model)
    }

    func testOpenAIRequestAndOutputIgnoresReasoningAndUsesActualModel() async throws {
        ProviderStubProtocol.handler = { request in
            XCTAssertEqual(request.url?.absoluteString, "https://api.openai.com/v1/responses")
            XCTAssertEqual(request.httpMethod, "POST")
            XCTAssertEqual(request.value(forHTTPHeaderField: "Authorization"), "Bearer test-secret")
            let body = try Self.body(request)
            XCTAssertEqual(body["model"] as? String, "configured-model")
            XCTAssertEqual(body["input"] as? String, "private context")
            XCTAssertEqual(body["store"] as? Bool, false)
            XCTAssertEqual(body["max_output_tokens"] as? Int, 256)
            XCTAssertNil(body["tools"])
            return (200, #"{"status":"completed","model":"actual-model","output":[{"type":"reasoning","summary":[]},{"type":"message","role":"assistant","status":"completed","content":[{"type":"output_text","text":"Answer"},{"type":"output_text","text":"Evidence"}]}],"usage":{"input_tokens":42,"output_tokens":15}}"#)
        }
        let reply = try await client.reply(participant: participant(), transcript: "private context", apiKey: "test-secret", maxOutputTokens: 256)
        XCTAssertEqual(reply.text, "Answer\n\nEvidence")
        XCTAssertEqual(reply.model, "actual-model")
        XCTAssertEqual(reply.inputTokens, 42)
        XCTAssertEqual(reply.outputTokens, 15)
    }

    func testAnthropicRequestAndTextBlocks() async throws {
        ProviderStubProtocol.handler = { request in
            XCTAssertEqual(request.url?.host, "api.anthropic.com")
            XCTAssertEqual(request.value(forHTTPHeaderField: "x-api-key"), "test-secret")
            XCTAssertEqual(request.value(forHTTPHeaderField: "anthropic-version"), "2023-06-01")
            XCTAssertNil(request.value(forHTTPHeaderField: "Authorization"))
            let body = try Self.body(request)
            XCTAssertEqual(body["max_tokens"] as? Int, 256)
            XCTAssertEqual((body["messages"] as? [[String: String]])?.first?["content"], "prompt")
            return (200, #"{"type":"message","role":"assistant","stop_reason":"end_turn","content":[{"type":"thinking","thinking":"internal"},{"type":"text","text":"Visible"}],"usage":{"input_tokens":5,"output_tokens":8}}"#)
        }
        let reply = try await client.reply(participant: participant(.anthropic), transcript: "prompt", apiKey: "test-secret", maxOutputTokens: 256)
        XCTAssertEqual(reply.text, "Visible")
        XCTAssertEqual(reply.outputTokens, 8)
    }

    func testOllamaNeverReceivesCloudKey() async throws {
        ProviderStubProtocol.handler = { request in
            XCTAssertEqual(request.url?.absoluteString, "http://127.0.0.1:11434/api/chat")
            XCTAssertNil(request.value(forHTTPHeaderField: "Authorization"))
            XCTAssertNil(request.value(forHTTPHeaderField: "x-api-key"))
            let body = try Self.body(request)
            XCTAssertEqual(body["stream"] as? Bool, false)
            XCTAssertEqual((body["options"] as? [String: Int])?["num_predict"], 256)
            return (200, #"{"done":true,"done_reason":"stop","model":"local-model","message":{"role":"assistant","content":"Local answer"},"prompt_eval_count":9,"eval_count":3}"#)
        }
        let reply = try await client.reply(participant: participant(.ollama), transcript: "prompt", apiKey: "cloud-secret", maxOutputTokens: 256)
        XCTAssertEqual(reply.text, "Local answer")
        XCTAssertEqual(reply.inputTokens, 9)
    }

    func testHTTPErrorNeverEchoesResponseBody() async {
        ProviderStubProtocol.handler = { _ in (401, #"{"error":{"message":"test-secret private context"}}"#) }
        do {
            _ = try await client.reply(participant: participant(), transcript: "private context", apiKey: "test-secret", maxOutputTokens: 256)
            XCTFail("Expected HTTP error")
        } catch {
            XCTAssertTrue(error.localizedDescription.contains("401"))
            XCTAssertFalse(error.localizedDescription.contains("test-secret"))
            XCTAssertFalse(error.localizedDescription.contains("private context"))
        }
    }

    func testTruncatedResponsesAreNotPassedToNextModelAsCompleted() async {
        let cases: [(ProviderKind, String)] = [
            (.openAI, #"{"status":"incomplete","output":[{"type":"message","role":"assistant","status":"incomplete","content":[{"type":"output_text","text":"partial"}]}]}"#),
            (.anthropic, #"{"stop_reason":"max_tokens","content":[{"type":"text","text":"partial"}]}"#),
            (.ollama, #"{"done":true,"done_reason":"length","message":{"role":"assistant","content":"partial"}}"#)
        ]
        for (provider, body) in cases {
            ProviderStubProtocol.handler = { _ in (200, body) }
            do {
                _ = try await client.reply(participant: participant(provider), transcript: "prompt", apiKey: "test-secret", maxOutputTokens: 256)
                XCTFail("Expected incomplete response error for \(provider)")
            } catch { XCTAssertFalse(error.localizedDescription.contains("partial")) }
        }
    }

    func testOpenAIOutputBudgetIncludesActualRequestLimitAndReasoningWithoutVisibleText() async {
        let body = #"{"status":"incomplete","max_output_tokens":999999,"incomplete_details":{"reason":"max_output_tokens"},"output":[{"type":"reasoning","summary":[]}],"usage":{"output_tokens":32768}}"#
        let message = await failureMessage(status: 200, body: body, maxOutputTokens: 32768)
        XCTAssertTrue(message.contains("32768 output tokens"))
        XCTAssertTrue(message.contains("including reasoning tokens"))
        XCTAssertTrue(message.contains("before any visible answer"))
        XCTAssertTrue(message.contains("context-window"))
        XCTAssertTrue(message.contains("Increase the output token limit"))
        XCTAssertTrue(message.contains("not an account billing quota"))
        XCTAssertFalse(message.contains("999999"), "Do not trust the response's echoed request limit")
    }

    func testOpenAIContentFilterIsDistinctFromOutputLimit() async {
        let body = #"{"status":"incomplete","incomplete_details":{"reason":"content_filter","message":"test-secret private context"},"output":[{"type":"message","role":"assistant","status":"incomplete","content":[{"type":"output_text","text":"private partial answer"}]}]}"#
        let message = await failureMessage(status: 200, body: body)
        XCTAssertTrue(message.contains("content filter"))
        XCTAssertTrue(message.contains("revise the request"))
        XCTAssertFalse(message.contains("output token"))
        XCTAssertFalse(message.contains("billing"))
        XCTAssertFalse(message.contains("private partial answer"))
    }

    func testOpenAIUnknownIncompleteAndUnfinishedStatusesDoNotInventTokenLimit() async {
        let bodies = [
            #"{"status":"incomplete","incomplete_details":{"reason":"test-secret private context"}}"#,
            #"{"status":"incomplete"}"#,
            #"{"status":"incomplete","incomplete_details":{"reason":42}}"#,
            #"{"status":"failed","incomplete_details":{"reason":"max_output_tokens"},"error":{"message":"test-secret private context"}}"#,
            #"{"status":"cancelled"}"#,
            #"{}"#
        ]
        for body in bodies {
            let message = await failureMessage(status: 200, body: body)
            XCTAssertFalse(message.contains("output token"))
            XCTAssertFalse(message.contains("context-window"))
            XCTAssertFalse(message.contains("billing"))
            XCTAssertTrue(message.contains("No completed answer was accepted"))
        }
    }

    func testCompletedResponseStillRejectsIncompleteAssistantMessage() async {
        let body = #"{"status":"completed","output":[{"type":"message","role":"assistant","status":"incomplete","content":[{"type":"output_text","text":"private partial answer"}]}]}"#
        let message = await failureMessage(status: 200, body: body)
        XCTAssertTrue(message.contains("incomplete message"))
        XCTAssertFalse(message.contains("private partial answer"))
    }

    func testOpenAIQuota429RecognizesOnlyCodeOrTypeAndDoesNotEchoProviderText() async {
        let bodies = [
            #"{"error":{"code":"insufficient_quota","message":"test-secret private context"}}"#,
            #"{"error":{"type":"insufficient_quota","message":"test-secret private context"}}"#,
            #"{"error":{"code":"unknown_future_code","type":"insufficient_quota","message":"test-secret private context"}}"#
        ]
        for body in bodies {
            let message = await failureMessage(status: 429, body: body)
            XCTAssertTrue(message.contains("HTTP 429"))
            XCTAssertTrue(message.contains("insufficient account quota"))
            XCTAssertTrue(message.contains("API credits, billing"))
            XCTAssertTrue(message.contains("Retrying will not restore access"))
            XCTAssertTrue(message.contains("separate from this app's per-request output token limit"))
            XCTAssertFalse(message.contains("unknown_future_code"))
        }
    }

    func testSpecificOpenAIBillingCodesTakePrecedenceOverBroadQuotaType() async {
        let cases = [
            ("credit_balance_exhausted", "exhausted API credits", "add credits"),
            ("organization_spend_limit_exceeded", "organization spending limit", "organization's API billing limit"),
            ("project_spend_limit_exceeded", "project spending limit", "API project's billing limit"),
            ("organization_usage_limit_exceeded", "organization usage limit", "available limit increases")
        ]
        for (code, explanation, action) in cases {
            let body = "{\"error\":{\"code\":\"\(code)\",\"type\":\"insufficient_quota\",\"message\":\"test-secret private context\"}}"
            let message = await failureMessage(status: 429, body: body)
            XCTAssertTrue(message.contains(explanation))
            XCTAssertTrue(message.contains(action))
            XCTAssertTrue(message.contains("separate from this app's per-request output token limit"))
            XCTAssertFalse(message.contains("insufficient account quota"))
            if code != "credit_balance_exhausted" { XCTAssertFalse(message.contains("add credits")) }
            XCTAssertFalse(message.contains(code))
        }
    }

    func testSlowDownCodeAndBroadRateLimitTypeHaveTrafficAdvice() async {
        let slowdown = await failureMessage(status: 429, body: #"{"error":{"code":"slow_down","type":"rate_limit_error","message":"test-secret private context"}}"#)
        XCTAssertTrue(slowdown.contains("increase traffic gradually"))
        XCTAssertFalse(slowdown.contains("billing"))
        let broad = await failureMessage(status: 429, body: #"{"error":{"type":"rate_limit_error","message":"test-secret private context"}}"#)
        XCTAssertTrue(broad.contains("request or token rate limit"))
        XCTAssertFalse(broad.contains("credits"))
    }

    func testOpenAIRateLimit429HasTrafficAdviceInsteadOfQuotaAdvice() async {
        for field in ["code", "type"] {
            let body = "{\"error\":{\"\(field)\":\"rate_limit_exceeded\",\"message\":\"test-secret private context\"}}"
            let message = await failureMessage(status: 429, body: body)
            XCTAssertTrue(message.contains("request or token rate limit"))
            XCTAssertTrue(message.contains("reduce request frequency"))
            XCTAssertTrue(message.contains("retry manually"))
            XCTAssertFalse(message.contains("credits"))
            XCTAssertFalse(message.contains("Increase the output"))
        }
    }

    func testUnknownMalformedOversizeOrOtherProvider429DoesNotGuessCause() async {
        let cases: [(ProviderKind, String)] = [
            (.openAI, #"{"error":{"code":"test-secret","type":"private context","message":"insufficient_quota"}}"#),
            (.openAI, #"{"error":{"code":"max_output_tokens","message":"test-secret private context"}}"#),
            (.openAI, #"{"error":{"code":42,"type":false}}"#),
            (.openAI, "test-secret private context"),
            (.openAI, #"{"error":{"code":"insufficient_quota","message":""# + String(repeating: "x", count: 65_536) + #""}}"#),
            (.anthropic, #"{"error":{"code":"insufficient_quota","message":"test-secret private context"}}"#)
        ]
        for (provider, body) in cases {
            let message = await failureMessage(status: 429, body: body, provider: provider)
            XCTAssertTrue(message.contains("dashboard for the cause"))
            XCTAssertFalse(message.contains("OpenAI reported"))
            XCTAssertFalse(message.contains("max_output_tokens"))
            XCTAssertFalse(message.contains("Increase the output"))
        }
    }

    private func failureMessage(status: Int, body: String, provider: ProviderKind = .openAI, maxOutputTokens: Int = 256, file: StaticString = #filePath, line: UInt = #line) async -> String {
        ProviderStubProtocol.handler = { _ in (status, body) }
        do {
            _ = try await client.reply(participant: participant(provider), transcript: "private context", apiKey: "test-secret", maxOutputTokens: maxOutputTokens)
            XCTFail("Expected sanitized provider error", file: file, line: line)
            return ""
        } catch {
            XCTAssertTrue(error is ForumError, file: file, line: line)
            XCTAssertFalse(error.localizedDescription.contains("test-secret"), file: file, line: line)
            XCTAssertFalse(error.localizedDescription.contains("private context"), file: file, line: line)
            return error.localizedDescription
        }
    }

    func testMalformedAndEmptyResponsesAreRejected() async {
        for body in ["invalid secret body", #"{"status":"completed","output":[]}"#] {
            ProviderStubProtocol.handler = { _ in (200, body) }
            do {
                _ = try await client.reply(participant: participant(), transcript: "prompt", apiKey: "test-secret", maxOutputTokens: 256)
                XCTFail("Expected response error")
            } catch { XCTAssertFalse(error.localizedDescription.contains("secret body")) }
        }
    }

    func testMissingModelAndMissingKeyFailBeforeNetwork() async {
        ProviderStubProtocol.handler = { _ in XCTFail("Should not send request"); return (500, "") }
        for (model, key) in [(" ", "test-secret"), ("configured", "")] {
            do {
                _ = try await client.reply(participant: participant(model: model), transcript: "prompt", apiKey: key, maxOutputTokens: 256)
                XCTFail("Expected validation error")
            } catch { XCTAssertTrue(error is ForumError) }
        }
    }

    func testTimeoutIsSanitizedAndCancellationIsPreserved() async {
        for code in [URLError.timedOut, URLError.cancelled] {
            ProviderStubProtocol.handler = { _ in throw URLError(code, userInfo: [NSLocalizedDescriptionKey: "private-secret"]) }
            do {
                _ = try await client.reply(participant: participant(), transcript: "prompt", apiKey: "test-secret", maxOutputTokens: 256)
                XCTFail("Expected network error")
            } catch {
                XCTAssertFalse(error.localizedDescription.contains("private-secret"))
                if code == .cancelled { XCTAssertTrue(error is CancellationError) }
                else { XCTAssertTrue(error.localizedDescription.contains("timed out")) }
            }
        }
    }

    func testRedirectGuardRefusesCredentialForwarding() {
        let guardDelegate = ProviderRedirectGuard()
        let source = URL(string: "https://api.openai.com/v1/responses")!
        let response = HTTPURLResponse(url: source, statusCode: 307, httpVersion: nil, headerFields: nil)!
        let task = session.dataTask(with: source)
        let redirected = URLRequest(url: URL(string: "https://other.example/collect")!)
        var invoked = false
        guardDelegate.urlSession(session, task: task, willPerformHTTPRedirection: response, newRequest: redirected) { request in
            invoked = true
            XCTAssertNil(request)
        }
        XCTAssertTrue(invoked)
        task.cancel()
    }

    private static func body(_ request: URLRequest) throws -> [String: Any] {
        var data = request.httpBody ?? Data()
        if data.isEmpty, let stream = request.httpBodyStream {
            stream.open(); defer { stream.close() }
            var buffer = [UInt8](repeating: 0, count: 4096)
            while stream.hasBytesAvailable {
                let read = stream.read(&buffer, maxLength: buffer.count)
                if read <= 0 { break }
                data.append(buffer, count: read)
            }
        }
        return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
    }
}

private final class ProviderStubProtocol: URLProtocol {
    static var handler: ((URLRequest) throws -> (Int, String))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        do {
            guard let handler = Self.handler else { throw URLError(.unknown) }
            let (status, body) = try handler(request)
            let response = HTTPURLResponse(url: request.url!, statusCode: status, httpVersion: "HTTP/1.1", headerFields: ["Content-Type": "application/json"])!
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: Data(body.utf8))
            client?.urlProtocolDidFinishLoading(self)
        } catch { client?.urlProtocol(self, didFailWithError: error) }
    }
    override func stopLoading() {}
}
