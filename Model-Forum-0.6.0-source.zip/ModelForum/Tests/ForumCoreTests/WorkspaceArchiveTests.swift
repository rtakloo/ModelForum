import XCTest
@testable import ForumCore

final class WorkspaceArchiveTests: XCTestCase {
    private func withFixture(_ body: (SavedWorkspace, ArtifactFiles) throws -> Void) throws {
        let root = URL(fileURLWithPath: "/private/tmp").appendingPathComponent("ModelForum-archive-test-" + UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: root) }
        let store = ArtifactFiles(root: root)
        let channel = Channel(name: "Research", repository: "owner/repo", autoSave: true)
        let message = ChatMessage(role: "assistant", author: "claude", content: "Visible answer", model: "fixture-model",
                                  requestContext: "Private request context")
        let conversation = Conversation(title: "Fixture conversation", messages: [message], channelID: channel.id)
        let artifactID = UUID(), bytes = Data("# Research notes\n".utf8)
        let path = try store.store(draft: .init(filename: "notes.md", mimeType: "text/markdown", data: bytes), id: artifactID)
        let record = ArtifactRecord(id: artifactID, conversationID: conversation.id, messageID: message.id,
                                    filename: "notes.md", mimeType: "text/markdown", relativePath: path, byteCount: bytes.count)
        let workspace = SavedWorkspace(conversations: [conversation], participants: [], maxOutputTokens: 2048,
                                       channels: [channel], artifacts: [record], globalInstructions: "Shared instructions")
        try body(workspace, store)
    }
    func testRoundTripPreservesIDsOwnershipAndExactFileBytes() throws {
        try withFixture { workspace, store in
            let archive = try WorkspaceArchive(workspace: workspace, artifacts: store)
            let restored = try WorkspaceArchive.decode(archive.encoded())
            XCTAssertEqual(restored.workspace.conversations[0].id, workspace.conversations[0].id)
            XCTAssertEqual(restored.workspace.channels[0].folder, workspace.channels[0].folder)
            XCTAssertEqual(restored.workspace.artifacts[0].messageID, workspace.conversations[0].messages[0].id)
            XCTAssertEqual(restored.files[0].data, try store.read(relativePath: workspace.artifacts[0].relativePath))
            XCTAssertEqual(restored.files[0].sha256, WorkspaceArchive.hash(restored.files[0].data))
        }
    }
    func testTamperedBytesAndOwnershipFailDecode() throws {
        try withFixture { workspace, store in
            let original = try WorkspaceArchive(workspace: workspace, artifacts: store)
            var tampered = original
            tampered.files[0].data = Data("Tampered bytes".utf8)
            XCTAssertThrowsError(try WorkspaceArchive.decode(JSONEncoder().encode(tampered)))
            tampered = original; tampered.workspace.artifacts[0].messageID = UUID()
            XCTAssertThrowsError(try WorkspaceArchive.decode(JSONEncoder().encode(tampered)))
            tampered = original; tampered.workspace.artifacts[0].conversationID = UUID()
            XCTAssertThrowsError(try tampered.validate())
            tampered = original; tampered.workspace.conversations[0].channelID = UUID()
            XCTAssertThrowsError(try tampered.validate())
        }
    }
    func testPathTraversalAndInvalidChannelFoldersRejected() throws {
        try withFixture { workspace, store in
            let original = try WorkspaceArchive(workspace: workspace, artifacts: store)
            for name in ["../escape.md", "/tmp/escape.md", "nested/file.md", "bad%2Fname.md", ".hidden.md"] {
                var tampered = original
                tampered.files[0].filename = name
                tampered.workspace.artifacts[0].filename = name
                tampered.workspace.artifacts[0].relativePath = tampered.files[0].id.uuidString.lowercased() + "/" + name
                XCTAssertThrowsError(try WorkspaceArchive.decode(JSONEncoder().encode(tampered)), name)
            }
            var tampered = original
            tampered.workspace.channels[0].folder = "../../outside"
            XCTAssertThrowsError(try tampered.validate())
        }
    }
    func testDuplicateRecordsAndUnknownFormatsRejected() throws {
        try withFixture { workspace, store in
            let original = try WorkspaceArchive(workspace: workspace, artifacts: store)
            var tampered = original
            tampered.files.append(tampered.files[0]); tampered.workspace.artifacts.append(tampered.workspace.artifacts[0])
            XCTAssertThrowsError(try tampered.validate())
            tampered = original; tampered.workspace.conversations.append(tampered.workspace.conversations[0])
            XCTAssertThrowsError(try tampered.validate())
            tampered = original; tampered.format = 999
            XCTAssertThrowsError(try tampered.validate())
            XCTAssertThrowsError(try WorkspaceArchive.decode(Data("not JSON".utf8)))
        }
    }
    func testAggregateDeclaredSizeRejectedBeforeAnyFileRead() throws {
        // The directory deliberately does not exist: the content-limit error must precede file IO.
        let missing = ArtifactFiles(root: URL(fileURLWithPath: "/private/tmp/ModelForum-missing-" + UUID().uuidString))
        let conversation = Conversation()
        let records = (0..<9).map { _ in
            ArtifactRecord(conversationID: conversation.id, messageID: UUID(), filename: "large.txt", mimeType: "text/plain",
                           relativePath: "missing/large.txt", byteCount: ArtifactFiles.maximumBytes)
        }
        let workspace = SavedWorkspace(conversations: [conversation], participants: [], maxOutputTokens: 2048, artifacts: records)
        XCTAssertThrowsError(try WorkspaceArchive(workspace: workspace, artifacts: missing)) { error in
            XCTAssertTrue(error.localizedDescription.contains("64 MiB"))
        }
        var negative = workspace; negative.artifacts = [records[0]]; negative.artifacts[0].byteCount = -1
        XCTAssertThrowsError(try WorkspaceArchive(workspace: negative, artifacts: missing)) { error in
            XCTAssertTrue(error.localizedDescription.contains("64 MiB"))
        }
        XCTAssertFalse(FileManager.default.fileExists(atPath: missing.root.path))
    }
    func testConversationTextBoundIncludesHiddenRequestContext() throws {
        try withFixture { workspace, store in
            var archive = try WorkspaceArchive(workspace: workspace, artifacts: store)
            archive.workspace.conversations[0].messages[0].requestContext = String(repeating: "x", count: 32 * 1024 * 1024)
            XCTAssertThrowsError(try archive.encoded()) { error in
                XCTAssertTrue(error.localizedDescription.contains("Conversation text"))
            }
        }
    }
    func testPortableExportDropsHiddenContextAndChannelMembership() throws {
        try withFixture { workspace, _ in
            let original = workspace.conversations[0]
            let portable = ConversationExport.portable(original)
            XCTAssertNil(portable.channelID)
            XCTAssertNil(portable.messages[0].requestContext)
            XCTAssertEqual(portable.messages[0].content, original.messages[0].content)
            XCTAssertEqual(portable.messages[0].model, original.messages[0].model)
            XCTAssertFalse(ConversationExport.markdown(original).contains("Private request context"))
            XCTAssertTrue(ConversationExport.markdown(original).contains("Visible answer"))
        }
    }
}
