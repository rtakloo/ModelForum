import XCTest
import AppKit
@testable import ModelForum

final class RichMessageViewTests: XCTestCase {
    func testMissingResourceBundleReturnsNilInsteadOfTrapping() {
        XCTAssertNil(RichMessageView.rendererResourceURL(searchRoots: []))
        let missing = URL(fileURLWithPath: "/private/tmp/ModelForumMissingResources-" + UUID().uuidString, isDirectory: true)
        XCTAssertNil(RichMessageView.rendererResourceURL(searchRoots: [missing]))
    }
    func testOnlyWebLinksMayBeOpenedOutsideTheRenderer() throws {
        for raw in ["https://example.com/paper?q=math#proof", "http://localhost:8080/", "https://github.com/owner/repo"] {
            XCTAssertTrue(MessageRendererPolicy.externalLink(try XCTUnwrap(URL(string: raw))), raw)
        }
        for raw in ["file:///etc/passwd", "javascript:alert(1)", "data:text/html,hello", "mailto:person@example.com", "https://user:password@example.com/", "ftp://example.com/file", "model-forum://preferences", "https:/missing-host"] {
            XCTAssertFalse(MessageRendererPolicy.externalLink(try XCTUnwrap(URL(string: raw))), raw)
        }
    }

    func testOnlyExactBundledDocumentCanNavigateOrSendMessages() throws {
        let renderer = URL(fileURLWithPath: "/private/tmp/Renderer/index.html")
        XCTAssertTrue(MessageRendererPolicy.isRendererDocument(renderer, renderer: renderer))
        for raw in ["file:///private/tmp/Renderer/other.html", "file:///private/tmp/secret.txt", "file:///private/tmp/Renderer/index.html?payload=x", "file:///private/tmp/Renderer/index.html#fragment", "https://example.com/index.html", "about:blank"] {
            XCTAssertFalse(MessageRendererPolicy.isRendererDocument(try XCTUnwrap(URL(string: raw)), renderer: renderer), raw)
        }
        XCTAssertFalse(MessageRendererPolicy.isRendererDocument(nil, renderer: renderer))
    }

    func testMessageHeightRejectsInvalidValuesAndCapsScrollableCards() {
        XCTAssertNil(MessageRendererPolicy.height(.nan))
        XCTAssertNil(MessageRendererPolicy.height(.infinity))
        XCTAssertNil(MessageRendererPolicy.height(-1))
        XCTAssertNil(MessageRendererPolicy.height(0))
        XCTAssertEqual(MessageRendererPolicy.height(1), 24)
        XCTAssertEqual(MessageRendererPolicy.height(129.3), 130)
        XCTAssertEqual(MessageRendererPolicy.height(80_000), 10_000)
    }

    func testRemoteBlockerRulesAreValidAndCoverNetworkProtocols() throws {
        let rules = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(MessageRendererPolicy.blockRemoteResources.utf8)) as? [[String: Any]])
        XCTAssertEqual(rules.count, 3)
        let regexes = try rules.map { rule -> NSRegularExpression in
            let trigger = try XCTUnwrap(rule["trigger"] as? [String: Any])
            let expression = try XCTUnwrap(trigger["url-filter"] as? String)
            let action = try XCTUnwrap(rule["action"] as? [String: Any])
            XCTAssertEqual(action["type"] as? String, "block")
            XCTAssertEqual(trigger["url-filter-is-case-sensitive"] as? Bool, false)
            // WebKit's content-blocking regex subset does not support alternation.
            XCTAssertFalse(expression.contains("|"))
            return try NSRegularExpression(pattern: expression, options: [.caseInsensitive])
        }
        for url in ["http://example.com/a", "https://example.com/a", "wss://example.com/a", "ws://example.com/a", "ftp://example.com/a", "HTTPS://example.com/a"] {
            XCTAssertTrue(regexes.contains { $0.firstMatch(in: url, range: NSRange(url.startIndex..., in: url)) != nil }, url)
        }
        let local = "file:///private/tmp/Renderer/index.html"
        XCTAssertFalse(regexes.contains { $0.firstMatch(in: local, range: NSRange(local.startIndex..., in: local)) != nil })
    }
    func testVerticalWheelRoutesShortMessagesAndLongMessageBoundaries() throws {
        let short = try XCTUnwrap(MessageScrollMetrics(scrollTop: 0, scrollHeight: 200, clientHeight: 200))
        let top = try XCTUnwrap(MessageScrollMetrics(scrollTop: 0, scrollHeight: 16_000, clientHeight: 10_000))
        let middle = try XCTUnwrap(MessageScrollMetrics(scrollTop: 3000, scrollHeight: 16_000, clientHeight: 10_000))
        let bottom = try XCTUnwrap(MessageScrollMetrics(scrollTop: 6000, scrollHeight: 16_000, clientHeight: 10_000))
        for (metrics, delta, parent) in [(short, 8.0, true), (short, -8.0, true),
                                        (top, 8.0, true), (top, -8.0, false),
                                        (middle, 8.0, false), (middle, -8.0, false),
                                        (bottom, 8.0, false), (bottom, -8.0, true)] {
            var sequence = MessageWheelSequence()
            let dispatch = sequence.dispatch(deltaX: 0, deltaY: delta, shift: false, metrics: metrics)
            XCTAssertEqual(dispatch.toConversation, parent)
            XCTAssertEqual(dispatch.toRenderer, !parent)
        }
    }

    func testScrollMetricsClampBounceAndRejectInvalidLayout() throws {
        XCTAssertNil(MessageScrollMetrics(scrollTop: .nan, scrollHeight: 100, clientHeight: 50))
        XCTAssertNil(MessageScrollMetrics(scrollTop: 0, scrollHeight: .infinity, clientHeight: 50))
        XCTAssertNil(MessageScrollMetrics(scrollTop: 0, scrollHeight: 100, clientHeight: 0))
        XCTAssertNil(MessageScrollMetrics(scrollTop: 0, scrollHeight: -1, clientHeight: 50))
        let topBounce = try XCTUnwrap(MessageScrollMetrics(scrollTop: -20, scrollHeight: 1000, clientHeight: 500))
        let bottomBounce = try XCTUnwrap(MessageScrollMetrics(scrollTop: 540, scrollHeight: 1000, clientHeight: 500))
        XCTAssertEqual(topBounce.top, 0); XCTAssertFalse(topBounce.canScroll(nativeDeltaY: 2))
        XCTAssertEqual(bottomBounce.top, 500); XCTAssertFalse(bottomBounce.canScroll(nativeDeltaY: -2))
        let fractionalEnd = try XCTUnwrap(MessageScrollMetrics(scrollTop: 499.5, scrollHeight: 1000, clientHeight: 500))
        XCTAssertFalse(fractionalEnd.canScroll(nativeDeltaY: -2))
        var sequence = MessageWheelSequence()
        XCTAssertEqual(sequence.dispatch(deltaX: 0, deltaY: -5, shift: false, metrics: nil), MessageWheelDispatch(toConversation: true, toRenderer: false))
        XCTAssertEqual(sequence.dispatch(deltaX: 0, deltaY: .nan, shift: false, metrics: nil), MessageWheelDispatch(toConversation: false, toRenderer: true))
    }

    func testHorizontalAndShiftWheelRemainInRenderer() {
        for (x, y, shift) in [(20.0, 0.0, false), (-20.0, 2.0, false), (0.0, -20.0, true)] {
            var sequence = MessageWheelSequence()
            _ = sequence.dispatch(deltaX: 0, deltaY: -4, shift: false, phase: .began, metrics: nil)
            let dispatch = sequence.dispatch(deltaX: x, deltaY: y, shift: shift, phase: .changed, metrics: nil)
            XCTAssertFalse(dispatch.toConversation)
            XCTAssertTrue(dispatch.toRenderer)
        }
    }

    func testGestureBoundaryHandoffDoesNotDuplicateMovementAndFinishesBothRecipients() throws {
        let middle = try XCTUnwrap(MessageScrollMetrics(scrollTop: 100, scrollHeight: 1000, clientHeight: 500))
        let bottom = try XCTUnwrap(MessageScrollMetrics(scrollTop: 500, scrollHeight: 1000, clientHeight: 500))
        var sequence = MessageWheelSequence()
        let internalScroll = sequence.dispatch(deltaX: 0, deltaY: -12, shift: false, phase: .began, metrics: middle)
        let parentScroll = sequence.dispatch(deltaX: 0, deltaY: -8, shift: false, phase: .changed, metrics: bottom)
        XCTAssertEqual(internalScroll, MessageWheelDispatch(toConversation: false, toRenderer: true))
        XCTAssertEqual(parentScroll, MessageWheelDispatch(toConversation: true, toRenderer: false))
        let ended = sequence.dispatch(deltaX: 0, deltaY: 0, shift: false, phase: .ended, metrics: bottom)
        XCTAssertEqual(ended, MessageWheelDispatch(toConversation: true, toRenderer: true))
        XCTAssertNil(sequence.previousRoute)
        let momentum = sequence.dispatch(deltaX: 0, deltaY: -2, shift: false, momentumPhase: .began, metrics: bottom)
        XCTAssertEqual(momentum, MessageWheelDispatch(toConversation: true, toRenderer: false))
        let momentumEnd = sequence.dispatch(deltaX: 0, deltaY: 0, shift: false, momentumPhase: .ended, metrics: bottom)
        XCTAssertEqual(momentumEnd, MessageWheelDispatch(toConversation: true, toRenderer: false))
        XCTAssertNil(sequence.previousRoute)
        _ = sequence.dispatch(deltaX: 0, deltaY: 3, shift: false, phase: .began, metrics: middle)
        let cancelled = sequence.dispatch(deltaX: 0, deltaY: 0, shift: false, phase: .cancelled, metrics: middle)
        XCTAssertEqual(cancelled, MessageWheelDispatch(toConversation: false, toRenderer: true))
        XCTAssertNil(sequence.previousRoute)
    }

    @MainActor func testWheelScopeUsesTopmostHitAndSuperviewCoordinates() {
        let root = NSView(frame: NSRect(x: 40, y: 30, width: 400, height: 300))
        let renderer = NSView(frame: NSRect(x: 20, y: 20, width: 200, height: 100))
        let webContent = NSView(frame: renderer.bounds)
        renderer.addSubview(webContent)
        root.addSubview(renderer)
        // These are the root's superview coordinates; root-local (30,30) would be wrong.
        let point = NSPoint(x: 70, y: 60)
        XCTAssertTrue(MessageScrollViewScope.topmostHit(in: root, atSuperviewPoint: point, belongsTo: renderer))
        XCTAssertFalse(MessageScrollViewScope.topmostHit(in: root, atSuperviewPoint: NSPoint(x: 30, y: 30), belongsTo: renderer))
        let overlay = NSView(frame: renderer.frame)
        root.addSubview(overlay)
        XCTAssertFalse(MessageScrollViewScope.topmostHit(in: root, atSuperviewPoint: point, belongsTo: renderer))
        overlay.isHidden = true
        XCTAssertTrue(MessageScrollViewScope.topmostHit(in: root, atSuperviewPoint: point, belongsTo: renderer))
    }

    @MainActor func testConversationScrollLookupSkipsRendererDescendants() {
        let conversation = NSScrollView(frame: NSRect(x: 0, y: 0, width: 400, height: 300))
        let document = NSView(frame: NSRect(x: 0, y: 0, width: 400, height: 1000))
        conversation.documentView = document
        let renderer = NSView(frame: NSRect(x: 0, y: 0, width: 300, height: 200))
        document.addSubview(renderer)
        renderer.addSubview(NSScrollView(frame: renderer.bounds))
        XCTAssertTrue(MessageScrollViewScope.conversationScrollView(above: renderer) === conversation)
        renderer.removeFromSuperview()
        XCTAssertNil(MessageScrollViewScope.conversationScrollView(above: renderer))
    }

}
