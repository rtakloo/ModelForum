import AppKit
import WebKit
import XCTest
@testable import ModelForum

/// Opt in on a Mac with working WebKit child processes. This creates no window and uses no network.
@MainActor final class RendererIntegrationTests: XCTestCase {
    func testBundledFileRendererTypesetsMathPreservesCodeAndLoadsLocalFonts() async throws {
        guard ProcessInfo.processInfo.environment["MODEL_FORUM_TEST_WEBKIT"] == "1" else {
            throw XCTSkip("Set MODEL_FORUM_TEST_WEBKIT=1 to exercise the bundled renderer in native WebKit.")
        }
        _ = NSApplication.shared
        let renderer = try XCTUnwrap(RichMessageView.rendererResourceURL)
        XCTAssertTrue(renderer.isFileURL)
        let blockerDirectory = URL(fileURLWithPath: "/private/tmp", isDirectory: true)
            .appendingPathComponent("ModelForumRendererRules-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: blockerDirectory, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        defer { try? FileManager.default.removeItem(at: blockerDirectory) }
        let blockerStore = try XCTUnwrap(WKContentRuleListStore(url: blockerDirectory))
        let blockerReady = expectation(description: "offline resource blocker compiles")
        var compiledBlocker: WKContentRuleList?
        var blockerError: Error?
        blockerStore.compileContentRuleList(forIdentifier: "ModelForumRendererIntegrationTest-v1", encodedContentRuleList: MessageRendererPolicy.blockRemoteResources) { rule, error in
            compiledBlocker = rule
            blockerError = error
            blockerReady.fulfill()
        }
        await fulfillment(of: [blockerReady], timeout: 10)
        if let blockerError { throw blockerError }
        let blocker = try XCTUnwrap(compiledBlocker)
        let ready = expectation(description: "bundled renderer sends ready")
        let probe = RendererProbe(renderer: renderer, ready: ready)
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
        configuration.userContentController.add(blocker)
        configuration.userContentController.add(probe, name: "renderer")
        let webView = WKWebView(frame: NSRect(x: 0, y: 0, width: 720, height: 420), configuration: configuration)
        webView.navigationDelegate = probe
        webView.isInspectable = false
        defer {
            webView.stopLoading()
            webView.navigationDelegate = nil
            webView.configuration.userContentController.removeScriptMessageHandler(forName: "renderer")
        }
        XCTAssertNotNil(webView.loadFileURL(renderer, allowingReadAccessTo: renderer.deletingLastPathComponent()))
        await fulfillment(of: [ready], timeout: 15)
        if let error = probe.loadError { throw error }
        guard probe.receivedReady else {
            XCTFail("The native renderer did not send its ready signal.")
            return
        }
        let measured = expectation(description: "rendered content sends a positive height")
        probe.measured = measured
        let source = #"""
        **Heron's formula**

        For sides a, b, and c, let s be the semiperimeter.

        \[
        A = \sqrt{s(s-a)(s-b)(s-c)}
        \]

        ```latex
        \[ \alpha + \beta \]
        ```
        """#
        let rendered = expectation(description: "render and local font loading complete")
        var renderResult: Result<Any, Error>?
        probe.expectsRenderedHeight = true
        webView.callAsyncJavaScript("""
            const render = await window.renderMessage(text);
            const mainFonts = await document.fonts.load('16px KaTeX_Main');
            const mathFonts = await document.fonts.load('italic 16px KaTeX_Math');
            await document.fonts.ready;
            const root = document.getElementById('message');
            const code = root.querySelector('pre code');
            return {
                mode: render.mode,
                mathCount: root.querySelectorAll('.katex').length,
                mathML: root.querySelectorAll('math').length,
                annotation: root.querySelector('annotation')?.textContent || '',
                bold: root.querySelector('strong')?.textContent || '',
                code: code?.textContent || '',
                codeContainsMath: !!code?.querySelector('.katex'),
                mainFontCount: mainFonts.length,
                mathFontCount: mathFonts.length,
                fontsLoaded: mainFonts.concat(mathFonts).every(face => face.status === 'loaded'),
                renderedHeight: root.getBoundingClientRect().height,
                csp: document.querySelector('meta[http-equiv="Content-Security-Policy"]')?.content || ''
            };
            """, arguments: ["text": source], in: nil, in: .page) { result in
                renderResult = result
                rendered.fulfill()
            }
        await fulfillment(of: [rendered, measured], timeout: 15)
        let result = try XCTUnwrap(renderResult).get()
        let dom = try XCTUnwrap(result as? [String: Any])
        XCTAssertEqual(dom["mode"] as? String, "rich")
        XCTAssertEqual(dom["bold"] as? String, "Heron's formula")
        XCTAssertEqual((dom["mathCount"] as? NSNumber)?.intValue, 1)
        XCTAssertEqual((dom["mathML"] as? NSNumber)?.intValue, 1)
        XCTAssertEqual((dom["annotation"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines), #"A = \sqrt{s(s-a)(s-b)(s-c)}"#)
        XCTAssertEqual((dom["code"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines), #"\[ \alpha + \beta \]"#)
        XCTAssertEqual(dom["codeContainsMath"] as? Bool, false)
        XCTAssertGreaterThan((dom["mainFontCount"] as? NSNumber)?.intValue ?? 0, 0)
        XCTAssertGreaterThan((dom["mathFontCount"] as? NSNumber)?.intValue ?? 0, 0)
        XCTAssertEqual(dom["fontsLoaded"] as? Bool, true)
        XCTAssertGreaterThan((dom["renderedHeight"] as? NSNumber)?.doubleValue ?? 0, 24)
        XCTAssertTrue((dom["csp"] as? String)?.contains("connect-src 'none'") == true)
        XCTAssertTrue(probe.heights.contains { $0 > 24 && $0 <= Double(MessageRendererPolicy.maximumHeight) })
        XCTAssertTrue(probe.rejectedNavigationURLs.isEmpty)
    }
}

@MainActor private final class RendererProbe: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
    let renderer: URL
    let ready: XCTestExpectation
    var measured: XCTestExpectation?
    var receivedReady = false
    var expectsRenderedHeight = false
    var heights: [Double] = []
    var loadError: Error?
    var rejectedNavigationURLs: [URL] = []
    private var fulfilledReady = false
    private var fulfilledHeight = false

    init(renderer: URL, ready: XCTestExpectation) {
        self.renderer = renderer; self.ready = ready
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "renderer", message.frameInfo.isMainFrame,
              MessageRendererPolicy.isRendererDocument(message.frameInfo.request.url, renderer: renderer),
              let body = message.body as? [String: Any], let type = body["type"] as? String else { return }
        if type == "ready" {
            receivedReady = true
            if !fulfilledReady { fulfilledReady = true; ready.fulfill() }
        } else if type == "height", let value = body["height"] as? NSNumber {
            heights.append(value.doubleValue)
            if expectsRenderedHeight, value.doubleValue > 24, !fulfilledHeight, let measured {
                fulfilledHeight = true
                measured.fulfill()
            }
        }
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.targetFrame?.isMainFrame == true,
           MessageRendererPolicy.isRendererDocument(navigationAction.request.url, renderer: renderer) {
            decisionHandler(.allow)
        } else {
            if let url = navigationAction.request.url { rejectedNavigationURLs.append(url) }
            decisionHandler(.cancel)
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { failed(error) }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { failed(error) }
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) { failed(NSError(domain: "RendererIntegrationTest", code: 1, userInfo: [NSLocalizedDescriptionKey: "The native WebKit content process terminated."])) }
    private func failed(_ error: Error) {
        loadError = error
        if !fulfilledReady { fulfilledReady = true; ready.fulfill() }
        if !fulfilledHeight, let measured { fulfilledHeight = true; measured.fulfill() }
    }
}
