import XCTest
import ForumCore
@testable import ModelForum

@MainActor final class ProviderAccountStoreTests: XCTestCase {
    private func storage() throws -> WorkspaceStorage {
        let root = URL(fileURLWithPath: "/private/tmp", isDirectory: true).appendingPathComponent("ModelForumAccountTests-" + UUID().uuidString, isDirectory: true)
        return try WorkspaceStorage(folder: root)
    }
    private func store(_ storage: WorkspaceStorage) -> AppStore {
        AppStore(storage: storage, upload: { _, _ in
            XCTFail("Account-label tests must not upload artifacts")
            throw ForumError.message("Unexpected upload")
        })
    }
    private func clean(_ storage: WorkspaceStorage) { try? FileManager.default.removeItem(at: storage.file.deletingLastPathComponent()) }

    func testCredentialResetDurablyClearsOnlyRelevantLabelsAndRejectsStaleDraft() throws {
        let storage = try storage(); defer { clean(storage) }
        let store = store(storage); defer { store.stopAll() }
        let old = ProviderAccountLabel(email: "old@example.test", accountID: "old-id", organization: "org-id", project: "project-id")
        let other = ProviderAccountLabel(email: "other@example.test", accountID: "other-id")
        let revision = store.privacyRevision
        XCTAssertTrue(store.saveAccountLabel(old, for: .openAI, expectedPrivacyRevision: revision))
        XCTAssertTrue(store.saveAccountLabel(other, for: .anthropic, expectedPrivacyRevision: revision))
        store.workspace.privacyConfirmations[ProviderKind.openAI.rawValue] = true
        XCTAssertTrue(store.persist())
        var mockCredentialWrites = 0
        if store.credentialsWillChange(.openAI) {
            let durable = try storage.load()
            XCTAssertNil(durable.providerAccountLabels[ProviderKind.openAI.rawValue])
            XCTAssertEqual(durable.privacyConfirmations[ProviderKind.openAI.rawValue], false)
            mockCredentialWrites += 1
        }
        XCTAssertEqual(mockCredentialWrites, 1)
        XCTAssertEqual(store.workspace.providerAccountLabels[ProviderKind.anthropic.rawValue], other)
        XCTAssertFalse(store.saveAccountLabel(old, for: .openAI, expectedPrivacyRevision: revision))
        XCTAssertNil(try storage.load().providerAccountLabels[ProviderKind.openAI.rawValue])
        let updated = ProviderAccountLabel(email: "new@example.test", accountID: "new-id")
        XCTAssertTrue(store.saveAccountLabel(updated, for: .openAI, expectedPrivacyRevision: store.privacyRevision))
        XCTAssertEqual(try storage.load().providerAccountLabels[ProviderKind.openAI.rawValue], updated)
        XCTAssertTrue(store.accountLabelSummary(for: .openAI).contains("new@example.test"))
        XCTAssertTrue(store.accountLabelSummary(for: .openAI).contains("new-id"))
        XCTAssertTrue(store.accountLabelSummary(for: .openAI).contains("unverified"))
        XCTAssertTrue(store.saveAccountLabel(ProviderAccountLabel(), for: .openAI, expectedPrivacyRevision: store.privacyRevision))
        XCTAssertEqual(store.accountLabelSummary(for: .openAI), "Account label not provided")
    }

    func testAccountResetWriteFailurePreventsCredentialMutation() throws {
        let storage = try storage(); defer { clean(storage) }
        let store = store(storage); defer { store.stopAll() }
        XCTAssertTrue(store.saveAccountLabel(ProviderAccountLabel(email: "original@example.test"), for: .openAI, expectedPrivacyRevision: 0))
        try FileManager.default.removeItem(at: storage.file)
        try FileManager.default.createDirectory(at: storage.file, withIntermediateDirectories: false)
        var mockCredentialWrites = 0
        if store.credentialsWillChange(.openAI) { mockCredentialWrites += 1 }
        XCTAssertEqual(mockCredentialWrites, 0)
        XCTAssertNil(store.workspace.providerAccountLabels[ProviderKind.openAI.rawValue])
        XCTAssertEqual(store.workspace.privacyConfirmations[ProviderKind.openAI.rawValue], false)
        XCTAssertNotNil(store.error)
    }

    func testFailedOrInvalidLabelSavePreservesPriorLabel() throws {
        let storage = try storage(); defer { clean(storage) }
        let store = store(storage); defer { store.stopAll() }
        let original = ProviderAccountLabel(email: "original@example.test")
        XCTAssertTrue(store.saveAccountLabel(original, for: .openAI, expectedPrivacyRevision: 0))
        XCTAssertFalse(store.saveAccountLabel(ProviderAccountLabel(accountID: "sk-proj-synthetic-test-credential"), for: .openAI, expectedPrivacyRevision: 0))
        XCTAssertEqual(store.workspace.providerAccountLabels[ProviderKind.openAI.rawValue], original)
        XCTAssertEqual(try storage.load().providerAccountLabels[ProviderKind.openAI.rawValue], original)
        XCTAssertFalse(store.error?.contains("synthetic-test-credential") == true)
        try FileManager.default.removeItem(at: storage.file)
        try FileManager.default.createDirectory(at: storage.file, withIntermediateDirectories: false)
        XCTAssertFalse(store.saveAccountLabel(ProviderAccountLabel(email: "unsaved@example.test"), for: .openAI, expectedPrivacyRevision: 0))
        XCTAssertEqual(store.workspace.providerAccountLabels[ProviderKind.openAI.rawValue], original)
    }

    func testAccountLabelsNeverEnterPreparedPrompts() throws {
        let storage = try storage(); defer { clean(storage) }
        let store = store(storage); defer { store.stopAll() }
        let label = ProviderAccountLabel(email: "private-label@example.test", accountID: "private-account-marker", organization: "private-org-marker", project: "private-project-marker")
        XCTAssertTrue(store.saveAccountLabel(label, for: .openAI, expectedPrivacyRevision: 0))
        store.workspace.participants[0].model = "test-model"
        store.workspace.participants[1].model = "test-model"
        store.composer = "@gpt @claude Explain the same mathematical claim."
        let plan = try store.preparedTurn()
        for text in [plan.transcript, plan.body] + Array(plan.agentTranscripts.values) {
            for secretLabel in [label.email, label.accountID, label.organization, label.project].compactMap({ $0 }) {
                XCTAssertFalse(text.contains(secretLabel))
            }
        }
        XCTAssertTrue(store.workspace.conversations[0].messages.isEmpty)
        XCTAssertTrue(store.accountLabelSummary(for: .ollama).contains("Local account not required"))
    }

    func testSchemaThreeMigrationBacksUpOriginalBytesAndPreservesInstructionsHistoryAndCap() throws {
        let storage = try storage(); defer { clean(storage) }
        var old = SavedWorkspace.initial
        old.schemaVersion = 3
        old.maxOutputTokens = 4096
        old.globalInstructions = "Retain notation"
        old.agentInstructions = ["gpt": "Explain assumptions"]
        old.privacyConfirmations = [ProviderKind.openAI.rawValue: true]
        let message = ChatMessage(role: "user", author: "You", content: "Existing question")
        old.conversations[0].messages = [message]
        let channel = try old.createChannel(name: "Existing", repository: nil, autoSave: false)
        old.conversations[0].channelID = channel.id
        old.schemaVersion = 3
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(old)) as? [String: Any])
        object.removeValue(forKey: "providerAccountLabels")
        let original = try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
        try original.write(to: storage.file)
        let root = storage.file.deletingLastPathComponent()
        let settingsBackup = root.appendingPathComponent("workspace-before-settings.json")
        let olderBytes = Data("Preserve previous backup".utf8)
        try olderBytes.write(to: settingsBackup)
        let migrated = try storage.load()
        let accountBackup = root.appendingPathComponent("workspace-before-account-labels.json")
        XCTAssertEqual(try Data(contentsOf: accountBackup), original)
        XCTAssertEqual(try Data(contentsOf: storage.file), original)
        XCTAssertEqual(try Data(contentsOf: settingsBackup), olderBytes)
        XCTAssertEqual(migrated.schemaVersion, 5)
        XCTAssertTrue(migrated.providerAccountLabels.isEmpty)
        XCTAssertEqual(migrated.maxOutputTokens, 4096)
        XCTAssertEqual(migrated.globalInstructions, old.globalInstructions)
        XCTAssertEqual(migrated.agentInstructions, old.agentInstructions)
        XCTAssertEqual(migrated.privacyConfirmations, old.privacyConfirmations)
        XCTAssertEqual(migrated.channels[0], channel)
        XCTAssertEqual(migrated.conversations[0].messages[0].id, message.id)
        try storage.save(migrated)
        _ = try storage.load()
        XCTAssertEqual(try Data(contentsOf: accountBackup), original)
        XCTAssertEqual(try Data(contentsOf: settingsBackup), olderBytes)
        let permissions = try FileManager.default.attributesOfItem(atPath: accountBackup.path)[.posixPermissions] as? NSNumber
        XCTAssertEqual(permissions?.intValue, 0o600)
    }
}
