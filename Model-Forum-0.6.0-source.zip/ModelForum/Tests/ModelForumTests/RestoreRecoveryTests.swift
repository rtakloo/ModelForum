import XCTest
import Darwin
import ForumCore
@testable import ModelForum

final class RestoreRecoveryTests: XCTestCase {
    private func fixture() throws -> (root: URL, live: URL, stage: URL, previous: URL) {
        let root = URL(fileURLWithPath: "/private/tmp", isDirectory: true).appendingPathComponent("ModelForumRestoreTests-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: false, attributes: [.posixPermissions: 0o700])
        let live = root.appendingPathComponent("ModelForum", isDirectory: true)
        let stage = root.appendingPathComponent("ModelForum-restore-" + UUID().uuidString, isDirectory: true)
        let previous = root.appendingPathComponent("ModelForum-before-restore-" + UUID().uuidString, isDirectory: true)
        var old = SavedWorkspace.initial; old.conversations[0].title = "Original workspace"
        var new = SavedWorkspace.initial; new.conversations[0].title = "Restored workspace"
        try WorkspaceStorage(folder: live).save(old)
        try WorkspaceStorage(folder: stage).save(new)
        return (root, live, stage, previous)
    }
    func testCrashBeforeFirstRenameKeepsOriginalAndPreservesStage() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        try WorkspaceStorage.prepareRestoreJournal(folder: f.live, stage: f.stage, previous: f.previous)
        let restarted = try WorkspaceStorage(folder: f.live)
        XCTAssertEqual(try restarted.load().conversations[0].title, "Original workspace")
        XCTAssertNotNil(restarted.recoveryNotice)
        XCTAssertTrue(FileManager.default.fileExists(atPath: f.stage.path))
        XCTAssertFalse(FileManager.default.fileExists(atPath: WorkspaceStorage.restoreJournalURL(folder: f.live).path))
    }
    func testCrashBetweenRenamesRecoversBeforeInitializerCanCreateEmptyDirectory() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        try WorkspaceStorage.prepareRestoreJournal(folder: f.live, stage: f.stage, previous: f.previous)
        try FileManager.default.moveItem(at: f.live, to: f.previous)
        XCTAssertFalse(FileManager.default.fileExists(atPath: f.live.path))
        let restarted = try WorkspaceStorage(folder: f.live)
        XCTAssertEqual(try restarted.load().conversations[0].title, "Original workspace")
        XCTAssertNotNil(restarted.recoveryNotice)
        XCTAssertEqual(try WorkspaceStorage(folder: f.stage).load().conversations[0].title, "Restored workspace")
    }
    func testCrashAfterInstallBeforeCommitRollsBackAndPreservesNewData() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        try WorkspaceStorage.prepareRestoreJournal(folder: f.live, stage: f.stage, previous: f.previous)
        try FileManager.default.moveItem(at: f.live, to: f.previous)
        try FileManager.default.moveItem(at: f.stage, to: f.live)
        let restarted = try WorkspaceStorage(folder: f.live)
        XCTAssertEqual(try restarted.load().conversations[0].title, "Original workspace")
        XCTAssertEqual(try WorkspaceStorage(folder: f.stage).load().conversations[0].title, "Restored workspace")
        XCTAssertNotNil(restarted.recoveryNotice)
    }
    func testCommittedInstallKeepsNewWorkspaceAndOldRecoveryCopy() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        let storage = try WorkspaceStorage(folder: f.live)
        try storage.installRestore(stage: f.stage, previous: f.previous)
        let restarted = try WorkspaceStorage(folder: f.live)
        XCTAssertNil(restarted.recoveryNotice)
        XCTAssertEqual(try restarted.load().conversations[0].title, "Restored workspace")
        XCTAssertEqual(try WorkspaceStorage(folder: f.previous).load().conversations[0].title, "Original workspace")
    }
    func testMissingRecoverySourcesFailClosedWithoutCreatingEmptyWorkspace() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        try WorkspaceStorage.prepareRestoreJournal(folder: f.live, stage: f.stage, previous: f.previous)
        try FileManager.default.removeItem(at: f.live)
        XCTAssertThrowsError(try WorkspaceStorage(folder: f.live))
        XCTAssertFalse(FileManager.default.fileExists(atPath: f.live.path))
        XCTAssertTrue(FileManager.default.fileExists(atPath: WorkspaceStorage.restoreJournalURL(folder: f.live).path))
        XCTAssertTrue(FileManager.default.fileExists(atPath: f.stage.path))
    }
    func testSecondProcessCannotRecoverAnActiveRestore() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        let lock = try WorkspaceStorage.acquireRestoreLock(folder: f.live)
        defer { flock(lock, LOCK_UN); close(lock) }
        try WorkspaceStorage.prepareRestoreJournal(folder: f.live, stage: f.stage, previous: f.previous)
        XCTAssertThrowsError(try WorkspaceStorage(folder: f.live))
        XCTAssertTrue(FileManager.default.fileExists(atPath: WorkspaceStorage.restoreJournalURL(folder: f.live).path))
        XCTAssertTrue(FileManager.default.fileExists(atPath: f.live.appendingPathComponent("workspace.json").path))
    }
    func testCorruptOrRedirectedJournalFailsClosed() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        let marker = WorkspaceStorage.restoreJournalURL(folder: f.live)
        try Data("not-json".utf8).write(to: marker)
        XCTAssertThrowsError(try WorkspaceStorage(folder: f.live))
        try FileManager.default.removeItem(at: marker)
        let outside = f.root.appendingPathComponent("other.json")
        try Data("keep".utf8).write(to: outside)
        try FileManager.default.createSymbolicLink(at: marker, withDestinationURL: outside)
        XCTAssertThrowsError(try WorkspaceStorage(folder: f.live))
        XCTAssertEqual(try Data(contentsOf: outside), Data("keep".utf8))
    }
    func testJournalCannotReferenceArbitrarySiblingDirectories() throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        let marker = WorkspaceStorage.restoreJournalURL(folder: f.live)
        let bytes = try JSONSerialization.data(withJSONObject: ["liveName": "ModelForum", "stageName": "../../outside", "previousName": "ModelForum-before-restore-" + UUID().uuidString])
        try bytes.write(to: marker)
        XCTAssertThrowsError(try WorkspaceStorage(folder: f.live))
        XCTAssertTrue(FileManager.default.fileExists(atPath: f.live.appendingPathComponent("workspace.json").path))
    }

    @MainActor func testAppStoreRestorePreservesBackupContentResetsConsentAndKeepsPriorWorkspace() async throws {
        let f = try fixture(); defer { try? FileManager.default.removeItem(at: f.root) }
        let storage = try WorkspaceStorage(folder: f.live)
        var archived = SavedWorkspace.initial
        let channel = try archived.createChannel(name: "Backed-up research", repository: "example/research", autoSave: true)
        archived.conversations[0].channelID = channel.id
        archived.conversations[0].title = "Backed-up history"
        let message = ChatMessage(role: "assistant", author: "@gpt", content: "Saved answer with π and a document.", model: "fixture-model", requestContext: "Original request context")
        archived.conversations[0].messages = [message]
        archived.globalInstructions = "Preserve this instruction."
        archived.privacyConfirmations = [ProviderKind.openAI.rawValue: true, ProviderKind.anthropic.rawValue: true]
        archived.providerAccountLabels = [ProviderKind.openAI.rawValue: ProviderAccountLabel(email: "manual@example.test", accountID: "unverified-fixture")]
        let draft = ArtifactDraft(filename: "research.txt", mimeType: "text/plain", data: Data("Exact archived file bytes: π\n".utf8))
        let artifactID = UUID()
        let relativePath = try storage.artifacts.store(draft: draft, id: artifactID)
        let destination = try ArtifactFiles.destination(channel: channel, conversationID: archived.conversations[0].id, artifactID: artifactID, filename: draft.filename)
        var artifact = ArtifactRecord(id: artifactID, conversationID: archived.conversations[0].id, messageID: message.id,
                                      filename: draft.filename, mimeType: draft.mimeType, relativePath: relativePath,
                                      byteCount: draft.data.count, destination: destination)
        artifact.syncState = .uploading
        archived.artifacts = [artifact]
        try storage.save(archived)
        let backup = f.root.appendingPathComponent("backup.json")
        try WorkspaceArchive(workspace: archived, artifacts: storage.artifacts).encoded().write(to: backup)

        // Change both history and local files after the backup, before constructing the store.
        var live = archived
        live.conversations[0].title = "Live work after backup"
        live.conversations[0].messages = [ChatMessage(role: "user", author: "You", content: "New work to preserve separately")]
        live.artifacts = []
        live.channels[0].autoSave = false
        try storage.artifacts.remove(relativePath: relativePath)
        let marker = Data("Prior workspace must survive restore".utf8)
        try marker.write(to: f.live.appendingPathComponent("prior-work.txt"))
        try storage.save(live)
        let priorBytes = try Data(contentsOf: storage.file)
        var uploadCalls = 0
        let store = AppStore(storage: storage, upload: { _, _ in
            uploadCalls += 1
            XCTFail("Restoring a backup must not upload files")
            throw ForumError.message("Unexpected upload")
        })
        defer { store.stopAll() }
        let privacyRevision = store.privacyRevision
        try store.restoreBackup(from: backup)
        for _ in 0..<5 { await Task.yield() }

        let durable = try storage.load()
        let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys]
        for restored in [store.workspace, durable] {
            XCTAssertEqual(try encoder.encode(restored.conversations), try encoder.encode(archived.conversations))
            XCTAssertEqual(restored.globalInstructions, archived.globalInstructions)
            var expectedChannel = channel; expectedChannel.autoSave = false
            XCTAssertEqual(restored.channels, [expectedChannel])
            XCTAssertTrue(restored.privacyConfirmations.values.allSatisfy { !$0 })
            XCTAssertTrue(restored.providerAccountLabels.isEmpty)
            var expectedArtifact = artifact; expectedArtifact.syncState = .pending
            XCTAssertEqual(try encoder.encode(restored.artifacts), try encoder.encode([expectedArtifact]))
        }
        XCTAssertEqual(try storage.artifacts.read(relativePath: relativePath), draft.data)
        XCTAssertGreaterThan(store.privacyRevision, privacyRevision)
        XCTAssertEqual(uploadCalls, 0)
        XCTAssertFalse(store.syncBusy)
        XCTAssertNil(store.error)
        let previousFolders = try FileManager.default.contentsOfDirectory(at: f.root, includingPropertiesForKeys: nil)
            .filter { $0.lastPathComponent.hasPrefix("ModelForum-before-restore-") }
        let previous = try XCTUnwrap(previousFolders.first)
        XCTAssertEqual(previousFolders.count, 1)
        XCTAssertEqual(try Data(contentsOf: previous.appendingPathComponent("workspace.json")), priorBytes)
        XCTAssertEqual(try Data(contentsOf: previous.appendingPathComponent("prior-work.txt")), marker)
        XCTAssertFalse(FileManager.default.fileExists(atPath: WorkspaceStorage.restoreJournalURL(folder: f.live).path))
    }
}
