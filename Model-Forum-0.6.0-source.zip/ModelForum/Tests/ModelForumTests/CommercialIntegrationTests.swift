import XCTest
import ForumCore
@testable import ModelForum

private actor RequestCapture {
    var transcripts: [String] = []
    func add(_ value: String) { transcripts.append(value) }
    func values() -> [String] { transcripts }
}

@MainActor final class CommercialIntegrationTests: XCTestCase {
    private func fixture() throws -> (WorkspaceStorage, AppStore) {
        let storage = try WorkspaceStorage(folder: URL(fileURLWithPath: "/private/tmp/ModelForum-commercial-" + UUID().uuidString))
        let store = AppStore(storage: storage, upload: { _, _ in throw ForumError.message("No upload authorized by fixture") })
        store.workspace.requireNoTraining = false
        return (storage, store)
    }
    private func finish(_ store: AppStore) async throws {
        for _ in 0..<300 {
            if !store.busy { return }
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTFail("Workflow did not finish")
    }
    func testWorkflowHonorsSelectedAnswerAndPersistsInstructionsAndSteps() async throws {
        let (storage, store) = try fixture()
        defer { store.stopAll(); try? FileManager.default.removeItem(at: storage.file.deletingLastPathComponent()) }
        let excluded = ChatMessage(role: "user", author: "You", content: "PRIVATE-EXCLUDED-CONTEXT")
        let answer = ChatMessage(role: "assistant", author: "@local", content: "SELECTED-ANSWER")
        store.workspace.conversations[0].messages = [excluded, answer]
        store.workspace.globalInstructions = "GLOBAL-INSTRUCTION"
        store.workspace.agentInstructions = ["local": "INDIVIDUAL-INSTRUCTION"]
        store.critiqueID = answer.id; store.contextScope = .selected; store.composer = "Review carefully"
        let participant = Participant(alias: "local", provider: .ollama, model: "fixture")
        let capture = RequestCapture()
        store.textRequestOverride = { _, transcript, _ in
            await capture.add(transcript)
            XCTAssertFalse(transcript.contains("PRIVATE-EXCLUDED-CONTEXT"))
            XCTAssertTrue(transcript.contains("SELECTED-ANSWER"))
            XCTAssertTrue(transcript.contains("GLOBAL-INSTRUCTION"))
            XCTAssertTrue(transcript.contains("INDIVIDUAL-INSTRUCTION"))
            return ModelReply(text: "Fixture answer", model: "fixture", inputTokens: 10, outputTokens: 5)
        }
        store.runWorkflow(WorkflowDefinition(draft: participant, critic: participant, reviser: participant))
        try await finish(store)
        let calls = await capture.values()
        XCTAssertEqual(calls.count, 3)
        let saved = try storage.load()
        XCTAssertEqual(saved.workflowRuns.count, 1)
        XCTAssertEqual(saved.usageLedger.records.count, 3)
        let steps = saved.conversations[0].messages.filter { $0.role == "assistant" && $0.id != answer.id }
        XCTAssertEqual(steps.count, 3)
        XCTAssertTrue(steps.allSatisfy { !$0.contextMessageIDs.contains(excluded.id) && $0.contextMessageIDs.contains(answer.id) })
        XCTAssertTrue(steps.allSatisfy { $0.requestContext?.contains("INDIVIDUAL-INSTRUCTION") == true })
    }
    func testWorkflowWithMissingSelectedAnswerDoesNotSendOrAppend() throws {
        let (storage, store) = try fixture()
        defer { store.stopAll(); try? FileManager.default.removeItem(at: storage.file.deletingLastPathComponent()) }
        let participant = Participant(alias: "local", provider: .ollama, model: "fixture")
        store.contextScope = .selected; store.composer = "Review"
        store.textRequestOverride = { _, _, _ in XCTFail("Must not send"); throw CancellationError() }
        store.runWorkflow(WorkflowDefinition(draft: participant, critic: participant, reviser: participant))
        XCTAssertFalse(store.busy); XCTAssertTrue(store.conversation?.messages.isEmpty == true)
        XCTAssertTrue(store.error?.contains("Choose an answer") == true)
    }
    func testUsageReservationIsDurableBeforeRequestAndFailureRetainsCost() async throws {
        let (storage, store) = try fixture()
        defer { store.stopAll(); try? FileManager.default.removeItem(at: storage.file.deletingLastPathComponent()) }
        let participant = Participant(alias: "api", provider: .anthropic, model: "fixture")
        store.workspace.spendingPolicy = SpendingPolicy(prices: [ModelPrice(provider: .anthropic, model: "fixture", inputPerMillionUSD: 1, outputPerMillionUSD: 1)], monthlyCapUSD: 1)
        store.textRequestOverride = { _, _, _ in
            let record = try XCTUnwrap(storage.load().usageLedger.records.first)
            XCTAssertEqual(record.status, .reserved); XCTAssertGreaterThan(record.reservedUSD ?? 0, 0)
            throw ForumError.message("Simulated interrupted request")
        }
        do { _ = try await store.performTextRequest(participant, transcript: "Hello", tokenLimit: 100, sessionID: UUID()); XCTFail("Expected failure") } catch {}
        let record = try XCTUnwrap(storage.load().usageLedger.records.first)
        XCTAssertEqual(record.status, .uncertain); XCTAssertGreaterThan(record.accountedUSD ?? 0, 0)
    }
    func testUnknownPriceBlocksRequestBeforeCallback() async throws {
        let (storage, store) = try fixture()
        defer { store.stopAll(); try? FileManager.default.removeItem(at: storage.file.deletingLastPathComponent()) }
        store.workspace.spendingPolicy = SpendingPolicy(monthlyCapUSD: 1)
        store.textRequestOverride = { _, _, _ in XCTFail("Unknown price must block"); throw CancellationError() }
        do { _ = try await store.performTextRequest(Participant(alias: "api", provider: .anthropic, model: "unknown"), transcript: "Hello", tokenLimit: 100, sessionID: UUID()); XCTFail("Expected rejection") } catch { XCTAssertTrue(error.localizedDescription.contains("price is unknown")) }
        XCTAssertTrue(store.workspace.usageLedger.records.isEmpty)
    }
    func testPermanentChannelDeletionRemovesOnlyItsLocalArtifactsAndPreservesOtherHistory() throws {
        let (storage, store) = try fixture()
        defer { store.stopAll(); try? FileManager.default.removeItem(at: storage.file.deletingLastPathComponent()) }
        let target = try store.workspace.createChannel(name: "Remove this channel", repository: nil, autoSave: false)
        let preserved = try store.workspace.createChannel(name: "Keep this channel", repository: nil, autoSave: false)
        let unfiledID = try XCTUnwrap(store.workspace.conversations.first?.id)
        let targetMessage = ChatMessage(role: "assistant", author: "@fixture", content: "Target history")
        let keepMessage = ChatMessage(role: "assistant", author: "@fixture", content: "Preserved history")
        let targetConversation = Conversation(title: "Remove history", messages: [targetMessage], channelID: target.id)
        let keepConversation = Conversation(title: "Keep history", messages: [keepMessage], channelID: preserved.id)
        store.workspace.conversations += [targetConversation, keepConversation]
        let targetBytes = Data("target bytes".utf8)
        let keepBytes = Data("preserved channel bytes".utf8)
        let unfiledBytes = Data("preserved unfiled bytes".utf8)
        // Identical basenames deliberately exercise the UUID-scoped local paths.
        try store.saveArtifacts([ArtifactDraft(filename: "notes.txt", mimeType: "text/plain", data: targetBytes)], conversationID: targetConversation.id, messageID: targetMessage.id, channel: target)
        try store.saveArtifacts([ArtifactDraft(filename: "notes.txt", mimeType: "text/plain", data: keepBytes)], conversationID: keepConversation.id, messageID: keepMessage.id, channel: preserved)
        let unfiledMessage = ChatMessage(role: "assistant", author: "@fixture", content: "Unfiled history")
        store.workspace.conversations[0].messages.append(unfiledMessage)
        try store.saveArtifacts([ArtifactDraft(filename: "notes.txt", mimeType: "text/plain", data: unfiledBytes)], conversationID: unfiledID, messageID: unfiledMessage.id, channel: nil)
        let removedFile = try XCTUnwrap(store.workspace.artifacts.first { $0.conversationID == targetConversation.id })
        let keptFile = try XCTUnwrap(store.workspace.artifacts.first { $0.conversationID == keepConversation.id })
        let unfiledFile = try XCTUnwrap(store.workspace.artifacts.first { $0.conversationID == unfiledID })
        XCTAssertEqual(try storage.artifacts.read(relativePath: removedFile.relativePath), targetBytes)
        store.permanentlyDeleteChannels([target.id])
        XCTAssertTrue(store.workspace.channels.contains { $0.id == target.id }, "An active channel cannot be permanently deleted")
        XCTAssertEqual(try storage.artifacts.read(relativePath: removedFile.relativePath), targetBytes)
        try store.workspace.deleteChannel(id: target.id)
        // A second deleted channel must also remain untouched unless explicitly selected.
        try store.workspace.deleteChannel(id: preserved.id)
        XCTAssertTrue(store.persist())
        store.permanentlyDeleteChannels([target.id])
        let saved = try storage.load()
        XCTAssertFalse(saved.channels.contains { $0.id == target.id })
        XCTAssertFalse(saved.conversations.contains { $0.id == targetConversation.id })
        XCTAssertFalse(saved.artifacts.contains { $0.id == removedFile.id })
        XCTAssertTrue(saved.pendingFileDeletions.isEmpty)
        XCTAssertThrowsError(try storage.artifacts.read(relativePath: removedFile.relativePath))
        XCTAssertTrue(saved.channels.contains { $0.id == preserved.id && $0.deletedAt != nil })
        XCTAssertEqual(saved.conversations.first { $0.id == keepConversation.id }?.messages.first?.content, "Preserved history")
        XCTAssertTrue(saved.conversations.contains { $0.id == unfiledID })
        XCTAssertEqual(Set(saved.artifacts.map(\.id)), [keptFile.id, unfiledFile.id])
        XCTAssertEqual(try storage.artifacts.read(relativePath: keptFile.relativePath), keepBytes)
        XCTAssertEqual(try storage.artifacts.read(relativePath: unfiledFile.relativePath), unfiledBytes)
    }
    func testImportedTeamConversationDropsPrivateContextAndUsesFreshIDs() throws {
        let (storage, store) = try fixture()
        defer { store.stopAll(); try? FileManager.default.removeItem(at: storage.file.deletingLastPathComponent()) }
        let message = ChatMessage(role: "assistant", author: "@gpt", content: "Visible", contextMessageIDs: [UUID()], requestContext: "PRIVATE")
        let shared = Conversation(title: "Shared", messages: [message], channelID: UUID())
        store.importTeamConversation(shared)
        let imported = try XCTUnwrap(store.conversation)
        XCTAssertNotEqual(imported.id, shared.id); XCTAssertNil(imported.channelID)
        XCTAssertNotEqual(imported.messages[0].id, message.id)
        XCTAssertNil(imported.messages[0].requestContext); XCTAssertTrue(imported.messages[0].contextMessageIDs.isEmpty)
    }
}
