import Foundation
import XCTest
@testable import ModelForum

final class ChatGPTCredentialLockTests: XCTestCase {
    func testCredentialLockExcludesAnotherHandleAndReleasesOnDeinit() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        var first: ChatGPTCredentialLock? = try ChatGPTCredentialLock(directory: directory)
        try withExtendedLifetime(first) {
            XCTAssertThrowsError(try ChatGPTCredentialLock(directory: directory)) { error in
                XCTAssertTrue(error.localizedDescription.contains("Another Model Forum process"))
            }
        }
        first = nil
        XCTAssertNoThrow(try ChatGPTCredentialLock(directory: directory))
    }
    func testCredentialLockRefusesSymbolicLinks() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        let target = directory.appendingPathComponent("target")
        try Data().write(to: target)
        try FileManager.default.createSymbolicLink(at: directory.appendingPathComponent("chatgpt-session.lock"), withDestinationURL: target)
        XCTAssertThrowsError(try ChatGPTCredentialLock(directory: directory))
    }
    func testWorkspaceReplacementDoesNotReplaceTheActiveCredentialLock() throws {
        let applicationSupport = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: applicationSupport) }
        let workspace = applicationSupport.appendingPathComponent("ModelForum", isDirectory: true)
        try FileManager.default.createDirectory(at: workspace, withIntermediateDirectories: true)
        let lockDirectory = ChatGPTCredentialLock.defaultDirectory(applicationSupport: applicationSupport)
        XCTAssertEqual(lockDirectory.deletingLastPathComponent(), workspace.deletingLastPathComponent())
        XCTAssertNotEqual(lockDirectory, workspace)
        let held = try ChatGPTCredentialLock(directory: lockDirectory)
        try withExtendedLifetime(held) {
            try FileManager.default.moveItem(at: workspace, to: applicationSupport.appendingPathComponent("restored-old-workspace"))
            try FileManager.default.createDirectory(at: workspace, withIntermediateDirectories: true)
            XCTAssertThrowsError(try ChatGPTCredentialLock(directory: lockDirectory))
        }
    }
}
