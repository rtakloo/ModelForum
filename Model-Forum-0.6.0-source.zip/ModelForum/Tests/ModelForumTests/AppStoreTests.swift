import XCTest
import ForumCore
@testable import ModelForum

@MainActor final class AppStoreTests: XCTestCase {
    private func storage() throws -> WorkspaceStorage {
        let folder = URL(fileURLWithPath: "/private/tmp", isDirectory: true)
            .appendingPathComponent("ModelForum-AppStoreTests-" + UUID().uuidString)
        return try WorkspaceStorage(folder: folder)
    }
    private func clean(_ storage: WorkspaceStorage) {
        try? FileManager.default.removeItem(at: storage.file.deletingLastPathComponent())
    }
    private func fixture(_ storage: WorkspaceStorage, pendingStates: [ArtifactSyncState] = [], enabled: Bool = true) throws -> (SavedWorkspace, Channel, ChatMessage) {
        var workspace = SavedWorkspace.initial
        let channel = try workspace.createChannel(name: "Research", repository: "owner/repository", autoSave: true)
        workspace.conversations[0].channelID = channel.id
        let message = ChatMessage(role: "assistant", author: "@gpt", content: "A generated document")
        workspace.conversations[0].messages.append(message)
        for state in pendingStates {
            let id = UUID()
            let path = try storage.artifacts.store(draft: draft, id: id)
            let destination = try ArtifactFiles.destination(channel: channel, conversationID: workspace.conversations[0].id, artifactID: id, filename: draft.filename)
            var record = ArtifactRecord(id: id, conversationID: workspace.conversations[0].id, messageID: message.id,
                                        filename: draft.filename, mimeType: draft.mimeType, relativePath: path,
                                        byteCount: draft.data.count, destination: destination)
            record.syncState = state
            workspace.artifacts.append(record)
        }
        workspace.channels[0].autoSave = enabled
        try storage.save(workspace)
        return (workspace, channel, message)
    }
    private var draft: ArtifactDraft {
        ArtifactDraft(filename: "paper.tex", mimeType: "application/x-tex", data: Data("\\documentclass{article}\n\\begin{document}Hello\\end{document}\n".utf8))
    }
    private func eventually(_ description: String, condition: () -> Bool) async throws {
        for _ in 0..<200 {
            if condition() { return }
            try await Task.sleep(nanoseconds: 10_000_000)
        }
        XCTFail("Timed out: " + description)
    }
    private func result(_ destination: ArtifactDestination) -> ArtifactUploadResult {
        ArtifactUploadResult(url: "https://github.com/" + destination.repository + "/blob/" + destination.branch + "/" + destination.path,
                             commitSHA: String(repeating: "a", count: 40))
    }

    func testLocalBytesAndOutboxAreDurableBeforeUploadBegins() async throws {
        let storage = try storage(); defer { clean(storage) }
        let (workspace, channel, message) = try fixture(storage)
        var uploadCalls = 0
        let store = AppStore(storage: storage, upload: { data, destination in
            uploadCalls += 1
            let persisted = try storage.load()
            let record = try XCTUnwrap(persisted.artifacts.first)
            XCTAssertEqual(record.syncState, .uploading)
            XCTAssertEqual(record.destination, destination)
            XCTAssertEqual(record.conversationID, workspace.conversations[0].id)
            XCTAssertEqual(record.messageID, message.id)
            XCTAssertEqual(try storage.artifacts.read(relativePath: record.relativePath), data)
            XCTAssertEqual(data, self.draft.data)
            return self.result(destination)
        })
        defer { store.stopAll() }
        try store.saveArtifacts([draft], conversationID: workspace.conversations[0].id, messageID: message.id, channel: channel)
        try await eventually("upload succeeds") { store.workspace.artifacts.first?.syncState == .uploaded && !store.syncBusy }
        XCTAssertEqual(uploadCalls, 1)
        let saved = try XCTUnwrap(storage.load().artifacts.first)
        XCTAssertEqual(saved.syncState, .uploaded)
        XCTAssertNotNil(saved.remoteURL); XCTAssertEqual(saved.commitSHA, String(repeating: "a", count: 40))
    }

    func testFailedUploadKeepsBytesAndRetryUsesOriginalDestinationAfterMoveAndRename() async throws {
        let storage = try storage(); defer { clean(storage) }
        let (workspace, channel, message) = try fixture(storage)
        var destinations = [ArtifactDestination]()
        let store = AppStore(storage: storage, upload: { _, destination in
            destinations.append(destination)
            if destinations.count == 1 { throw ForumError.message("Simulated offline failure") }
            return self.result(destination)
        })
        defer { store.stopAll() }
        try store.saveArtifacts([draft], conversationID: workspace.conversations[0].id, messageID: message.id, channel: channel)
        try await eventually("first upload fails") { store.workspace.artifacts.first?.syncState == .failed && !store.syncBusy }
        let failed = try XCTUnwrap(storage.load().artifacts.first)
        XCTAssertEqual(failed.syncState, .failed)
        XCTAssertEqual(try storage.artifacts.read(relativePath: failed.relativePath), draft.data)
        XCTAssertTrue(store.saveChannel(id: channel.id, name: "Renamed research", repository: "owner/repository", autoSave: true))
        XCTAssertTrue(store.saveChannel(id: nil, name: "Other", repository: "", autoSave: false))
        let other = try XCTUnwrap(store.workspace.channels.first { $0.name == "Other" })
        store.moveConversation(workspace.conversations[0].id, to: other.id)
        store.retryArtifact(failed.id)
        try await eventually("retry succeeds") { store.workspace.artifacts.first?.syncState == .uploaded && !store.syncBusy }
        XCTAssertEqual(destinations.count, 2)
        XCTAssertEqual(destinations.first, destinations.last)
        XCTAssertEqual(store.workspace.artifacts[0].relativePath, failed.relativePath)
        XCTAssertEqual(store.workspace.artifacts[0].destination, failed.destination)
        XCTAssertEqual(store.workspace.conversations[0].messages[0].id, message.id)
        XCTAssertEqual(try storage.artifacts.read(relativePath: failed.relativePath), draft.data)
    }

    func testStartupResumesPendingAndInterruptedUploadsWithoutRepeatingCompletedRecords() async throws {
        let storage = try storage(); defer { clean(storage) }
        let (workspace, _, _) = try fixture(storage, pendingStates: [.pending, .uploading])
        var paths = [String]()
        let first = AppStore(storage: storage, upload: { _, destination in
            paths.append(destination.path)
            return self.result(destination)
        })
        defer { first.stopAll() }
        try await eventually("startup outbox drains") { first.workspace.artifacts.allSatisfy { $0.syncState == .uploaded } && !first.syncBusy }
        XCTAssertEqual(Set(paths), Set(workspace.artifacts.compactMap { $0.destination?.path }))
        XCTAssertEqual(paths.count, 2)
        first.stopAll()
        let reopened = AppStore(storage: storage, upload: { _, _ in
            XCTFail("Completed uploads must not be sent again after restart")
            throw ForumError.message("Unexpected upload")
        })
        defer { reopened.stopAll() }
        for _ in 0..<5 { await Task.yield() }
        XCTAssertTrue(reopened.workspace.artifacts.allSatisfy { $0.syncState == .uploaded })
        XCTAssertFalse(reopened.syncBusy)
        XCTAssertEqual(reopened.workspace.artifacts.map(\.id), workspace.artifacts.map(\.id))
    }

    func testDisabledOrRelinkedChannelPausesPendingFileUntilOriginalDestinationIsEnabled() async throws {
        let storage = try storage(); defer { clean(storage) }
        let (_, channel, _) = try fixture(storage, pendingStates: [.pending], enabled: false)
        var calls = 0
        let store = AppStore(storage: storage, upload: { _, destination in
            calls += 1
            return self.result(destination)
        })
        defer { store.stopAll() }
        for _ in 0..<5 { await Task.yield() }
        let record = try XCTUnwrap(store.workspace.artifacts.first)
        XCTAssertFalse(store.uploadEnabled(record)); XCTAssertEqual(calls, 0)
        store.retryArtifact(record.id)
        XCTAssertEqual(calls, 0); XCTAssertNotNil(store.error)
        XCTAssertTrue(store.saveChannel(id: channel.id, name: channel.name, repository: "owner/another", autoSave: true))
        XCTAssertFalse(store.uploadEnabled(record))
        store.retryArtifact(record.id)
        for _ in 0..<5 { await Task.yield() }
        XCTAssertEqual(calls, 0)
        XCTAssertEqual(store.workspace.artifacts[0].destination, record.destination)
        XCTAssertTrue(store.saveChannel(id: channel.id, name: channel.name, repository: "owner/repository", autoSave: true))
        try await eventually("restoring original channel resumes upload") { store.workspace.artifacts.first?.syncState == .uploaded && !store.syncBusy }
        XCTAssertEqual(calls, 1)
    }

    func testStoppingUploadLeavesDurablePendingRecordAndLocalFile() async throws {
        let storage = try storage(); defer { clean(storage) }
        _ = try fixture(storage, pendingStates: [.pending])
        var started = false
        let store = AppStore(storage: storage, upload: { _, _ in
            started = true
            try await Task.sleep(nanoseconds: 60_000_000_000)
            XCTFail("The mock upload should be cancelled")
            throw ForumError.message("Unexpected completion")
        })
        defer { store.stopAll() }
        try await eventually("mock upload starts") { started }
        store.stopAll()
        try await eventually("cancelled upload returns to pending") { !store.syncBusy && store.workspace.artifacts.first?.syncState == .pending }
        let persisted = try XCTUnwrap(storage.load().artifacts.first)
        XCTAssertEqual(persisted.syncState, .pending)
        XCTAssertEqual(try storage.artifacts.read(relativePath: persisted.relativePath), draft.data)
    }

    func testOldWorkspaceMigrationBacksUpExactBytesAndPreservesHistory() async throws {
        let storage = try storage(); defer { clean(storage) }
        let message = ChatMessage(role: "user", author: "You", content: "Retain my existing conversation")
        let old = SavedWorkspace(conversations: [Conversation(title: "Existing", messages: [message])],
                                 participants: [Participant(alias: "gpt", provider: .openAI, model: "my-configured-model")], maxOutputTokens: 4096)
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(old)) as? [String: Any])
        object.removeValue(forKey: "schemaVersion"); object.removeValue(forKey: "channels"); object.removeValue(forKey: "artifacts")
        for key in ["globalInstructions", "agentInstructions", "requireNoTraining", "privacyConfirmations", "providerAccountLabels"] { object.removeValue(forKey: key) }
        let originalBytes = try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
        try originalBytes.write(to: storage.file)
        let store = AppStore(storage: storage, upload: { _, _ in
            XCTFail("Migrating old conversations must not upload anything")
            throw ForumError.message("Unexpected upload")
        })
        defer { store.stopAll() }
        let backup = storage.file.deletingLastPathComponent().appendingPathComponent("workspace-before-channels.json")
        XCTAssertEqual(try Data(contentsOf: backup), originalBytes)
        let settingsBackup = storage.file.deletingLastPathComponent().appendingPathComponent("workspace-before-settings.json")
        XCTAssertEqual(try Data(contentsOf: settingsBackup), originalBytes)
        XCTAssertTrue(store.workspace.requireNoTraining)
        XCTAssertTrue(store.workspace.privacyConfirmations.isEmpty)
        XCTAssertEqual(store.workspace.schemaVersion, 5)
        XCTAssertEqual(store.workspace.conversations[0].messages[0].id, message.id)
        XCTAssertEqual(store.workspace.conversations[0].messages[0].content, message.content)
        XCTAssertEqual(store.workspace.participants[0].model, "my-configured-model")
        XCTAssertEqual(store.workspace.maxOutputTokens, 4096)
        XCTAssertTrue(store.persist())
        XCTAssertEqual(try storage.load().conversations[0].messages[0].id, message.id)
        XCTAssertEqual(try Data(contentsOf: backup), originalBytes)
        XCTAssertEqual(try Data(contentsOf: settingsBackup), originalBytes)
        for _ in 0..<5 { await Task.yield() }
    }
    func testArtifactDirectorySymlinkIsRejectedWithoutWritingTarget() throws {
        let storage = try storage(); defer { clean(storage) }
        let (workspace, channel, message) = try fixture(storage)
        let folder = storage.file.deletingLastPathComponent()
        let outside = folder.appendingPathComponent("outside-artifacts", isDirectory: true)
        try FileManager.default.createDirectory(at: outside, withIntermediateDirectories: false)
        try FileManager.default.createSymbolicLink(at: folder.appendingPathComponent("artifacts"), withDestinationURL: outside)
        let store = AppStore(storage: storage, upload: { _, _ in
            XCTFail("Unsafe local artifact paths must never reach the uploader")
            throw ForumError.message("Unexpected upload")
        })
        defer { store.stopAll() }
        XCTAssertThrowsError(try store.saveArtifacts([draft], conversationID: workspace.conversations[0].id, messageID: message.id, channel: channel))
        XCTAssertTrue(store.workspace.artifacts.isEmpty)
        XCTAssertTrue(try storage.load().artifacts.isEmpty)
        XCTAssertTrue(try FileManager.default.contentsOfDirectory(atPath: outside.path).isEmpty)
    }

    func testFailedChannelSavePreservesSelectionAndExistingWorkspace() throws {
        let storage = try storage(); defer { clean(storage) }
        let (workspace, _, _) = try fixture(storage)
        let store = AppStore(storage: storage, upload: { _, _ in
            XCTFail("Creating a channel must not upload without artifacts")
            throw ForumError.message("Unexpected upload")
        })
        defer { store.stopAll() }
        let selectedConversation = store.selectedConversationID
        let selectedChannel = store.selectedChannelID
        // Only this test's private fixture is altered: a directory forces the atomic workspace write to fail.
        try FileManager.default.removeItem(at: storage.file)
        try FileManager.default.createDirectory(at: storage.file, withIntermediateDirectories: false)
        XCTAssertFalse(store.saveChannel(id: nil, name: "Cannot persist", repository: "", autoSave: false))
        XCTAssertEqual(store.selectedConversationID, selectedConversation)
        XCTAssertEqual(store.selectedChannelID, selectedChannel)
        XCTAssertEqual(store.workspace.channels, workspace.channels)
        XCTAssertEqual(store.workspace.conversations[0].messages[0].id, workspace.conversations[0].messages[0].id)
        XCTAssertNotNil(store.error)
    }

    func testDeletingChannelCancelsAndPausesQueueAndRestoreKeepsHistoryWithoutRestartingSaves() async throws {
        let storage = try storage(); defer { clean(storage) }
        let (original, channel, message) = try fixture(storage, pendingStates: [.pending, .pending])
        var calls = 0
        let store = AppStore(storage: storage, upload: { _, _ in
            calls += 1
            try await Task.sleep(nanoseconds: 60_000_000_000)
            throw ForumError.message("The mock should be cancelled before completion")
        })
        defer { store.stopAll() }
        try await eventually("first upload starts") { calls == 1 }
        XCTAssertTrue(store.deleteChannel(channel.id))
        try await eventually("deleted channel queue pauses") { !store.syncBusy }
        XCTAssertEqual(calls, 1)
        XCTAssertTrue(store.activeChannels.isEmpty)
        XCTAssertEqual(store.deletedChannels.map(\.id), [channel.id])
        XCTAssertNil(store.selectedChannelID)
        let deleted = try storage.load()
        XCTAssertNotNil(deleted.channels[0].deletedAt)
        XCTAssertFalse(deleted.channels[0].autoSave)
        XCTAssertTrue(deleted.artifacts.allSatisfy { $0.syncState == .pending })
        XCTAssertEqual(deleted.artifacts.map(\.id), original.artifacts.map(\.id))
        XCTAssertEqual(deleted.artifacts.map(\.destination), original.artifacts.map(\.destination))
        XCTAssertEqual(deleted.conversations[0].messages[0].id, message.id)
        for record in deleted.artifacts { XCTAssertEqual(try storage.artifacts.read(relativePath: record.relativePath), draft.data) }
        store.stopAll()
        let reopened = AppStore(storage: storage, upload: { _, _ in
            XCTFail("Deleting or restoring a channel must keep automatic saves paused")
            throw ForumError.message("Unexpected upload")
        })
        defer { reopened.stopAll() }
        for _ in 0..<5 { await Task.yield() }
        XCTAssertEqual(reopened.deletedChannels.map(\.id), [channel.id])
        XCTAssertTrue(reopened.restoreChannel(channel.id))
        for _ in 0..<5 { await Task.yield() }
        XCTAssertEqual(reopened.activeChannels.map(\.id), [channel.id])
        XCTAssertTrue(reopened.deletedChannels.isEmpty)
        XCTAssertFalse(reopened.workspace.channels[0].autoSave)
        XCTAssertEqual(reopened.selectedConversationID, original.conversations[0].id)
        XCTAssertEqual(reopened.workspace.conversations[0].messages[0].id, message.id)
        XCTAssertEqual(reopened.workspace.artifacts.map(\.destination), original.artifacts.map(\.destination))
        XCTAssertNil(try storage.load().channels[0].deletedAt)
        XCTAssertFalse(try storage.load().channels[0].autoSave)
    }

    func testSavedInstructionsStayIsolatedPerRecipientAndPreviewShowsBoth() throws {
        let storage = try storage(); defer { clean(storage) }
        _ = try fixture(storage)
        let store = AppStore(storage: storage, upload: { _, _ in
            XCTFail("Preparing a conversation must not upload files")
            throw ForumError.message("Unexpected upload")
        })
        defer { store.stopAll() }
        store.workspace.participants = [Participant(alias: "gpt", provider: .openAI, model: "test-model"), Participant(alias: "claude", provider: .anthropic, model: "test-model")]
        XCTAssertTrue(store.savePreferences(global: "GLOBAL-PREFERENCE", agentInstructions: ["gpt": "GPT-ONLY-PREFERENCE", "claude": "CLAUDE-ONLY-PREFERENCE"], requireNoTraining: true, confirmations: [ProviderKind.openAI.rawValue: true]))
        store.composer = "@gpt @claude Analyze the same problem independently."
        let plan = try store.preparedTurn()
        let gpt = try XCTUnwrap(plan.agentTranscripts["gpt"])
        let claude = try XCTUnwrap(plan.agentTranscripts["claude"])
        XCTAssertTrue(gpt.contains("GLOBAL-PREFERENCE")); XCTAssertTrue(claude.contains("GLOBAL-PREFERENCE"))
        XCTAssertTrue(gpt.contains("GPT-ONLY-PREFERENCE")); XCTAssertFalse(gpt.contains("CLAUDE-ONLY-PREFERENCE"))
        XCTAssertTrue(claude.contains("CLAUDE-ONLY-PREFERENCE")); XCTAssertFalse(claude.contains("GPT-ONLY-PREFERENCE"))
        XCTAssertTrue(plan.transcript.contains("RECIPIENT @gpt")); XCTAssertTrue(plan.transcript.contains("RECIPIENT @claude"))
        XCTAssertTrue(plan.transcript.contains(gpt)); XCTAssertTrue(plan.transcript.contains(claude))
        XCTAssertEqual(try storage.load().globalInstructions, "GLOBAL-PREFERENCE")
        XCTAssertEqual(try storage.load().agentInstructions["claude"], "CLAUDE-ONLY-PREFERENCE")
        XCTAssertEqual(try storage.load().privacyConfirmations[ProviderKind.openAI.rawValue], true)
        XCTAssertFalse(store.savePreferences(global: String(repeating: "x", count: AgentPolicy.instructionByteLimit + 1), agentInstructions: [:], requireNoTraining: false, confirmations: [:]))
        XCTAssertEqual(store.workspace.globalInstructions, "GLOBAL-PREFERENCE")
        XCTAssertTrue(store.workspace.requireNoTraining)
        XCTAssertEqual(try storage.load().globalInstructions, "GLOBAL-PREFERENCE")
    }

    func testPrivacyPreflightStopsUnconfirmedLocalProviderBeforeStartingAnyRequest() throws {
        let storage = try storage(); defer { clean(storage) }
        _ = try fixture(storage)
        let store = AppStore(storage: storage, upload: { _, _ in
            XCTFail("Privacy preflight must not upload files")
            throw ForumError.message("Unexpected upload")
        })
        defer { store.stopAll() }
        // This provider has no credential lookup. Stop synchronously before yielding even if a regression schedules work.
        store.workspace.participants = [Participant(alias: "local", provider: .ollama, model: "offline-test-model")]
        store.workspace.requireNoTraining = true
        store.workspace.privacyConfirmations = [:]
        let originalMessages = try XCTUnwrap(store.conversation).messages.map(\.id)
        store.composer = "@local A request which must not be sent"
        store.send()
        let started = store.busy
        store.stopAll()
        XCTAssertFalse(started)
        XCTAssertEqual(store.conversation?.messages.map(\.id), originalMessages)
        XCTAssertTrue(store.error?.contains("No-training account confirmation") == true)
        XCTAssertEqual(store.composer, "@local A request which must not be sent")
        XCTAssertEqual(try storage.load().conversations[0].messages.map(\.id), originalMessages)
    }

    func testCompileMockStoresPDFInSourceConversationAndQueuesItsChannelWithoutChangingSource() async throws {
        let storage = try storage(); defer { clean(storage) }
        let (original, channel, message) = try fixture(storage, pendingStates: [.uploaded])
        let source = try XCTUnwrap(original.artifacts.first)
        let pdfBytes = Data("%PDF-1.4\nMock PDF bytes\n%%EOF\n".utf8)
        var compileCalls = 0, uploadedDestinations = [ArtifactDestination]()
        let store = AppStore(storage: storage, upload: { data, destination in
            XCTAssertEqual(data, pdfBytes)
            uploadedDestinations.append(destination)
            return self.result(destination)
        }, compile: { bytes, filename in
            compileCalls += 1
            XCTAssertEqual(bytes, self.draft.data)
            XCTAssertEqual(filename, source.filename)
            return ArtifactDraft(filename: "paper.pdf", mimeType: "application/pdf", data: pdfBytes)
        })
        defer { store.stopAll() }
        XCTAssertTrue(store.saveChannel(id: nil, name: "Different selected channel", repository: "owner/other", autoSave: true))
        store.newConversation()
        let otherConversationID = store.selectedConversationID
        XCTAssertNotEqual(otherConversationID, source.conversationID)
        store.compilePDF(source)
        try await eventually("compiled PDF is uploaded") {
            !store.busy && !store.syncBusy && store.workspace.artifacts.contains { $0.filename == "paper.pdf" && $0.syncState == .uploaded }
        }
        let pdf = try XCTUnwrap(store.workspace.artifacts.first { $0.filename == "paper.pdf" })
        XCTAssertEqual(compileCalls, 1); XCTAssertEqual(uploadedDestinations.count, 1)
        XCTAssertEqual(pdf.conversationID, source.conversationID)
        XCTAssertEqual(pdf.destination?.repository, channel.repository)
        XCTAssertTrue(pdf.destination?.path.hasPrefix(channel.folder + "/conversations/" + source.conversationID.uuidString.lowercased() + "/") == true)
        XCTAssertEqual(pdf.destination, uploadedDestinations.first)
        XCTAssertEqual(try storage.artifacts.read(relativePath: pdf.relativePath), pdfBytes)
        let sourceAfter = try XCTUnwrap(store.workspace.artifacts.first { $0.id == source.id })
        XCTAssertEqual(sourceAfter.destination, source.destination)
        XCTAssertEqual(sourceAfter.relativePath, source.relativePath)
        XCTAssertEqual(try storage.artifacts.read(relativePath: sourceAfter.relativePath), draft.data)
        let sourceConversation = try XCTUnwrap(store.workspace.conversations.first { $0.id == source.conversationID })
        let compileMessage = try XCTUnwrap(sourceConversation.messages.first { $0.id == pdf.messageID })
        XCTAssertEqual(compileMessage.contextMessageIDs, [message.id])
        XCTAssertEqual(store.workspace.conversations.first { $0.id == otherConversationID }?.messages.count, 0)
        XCTAssertEqual(try storage.load().artifacts.count, 2)
    }

    func testVersionTwoMigrationCreatesSettingsBackupAndKeepsExistingChannelBackup() throws {
        let storage = try storage(); defer { clean(storage) }
        var (workspace, channel, _) = try fixture(storage)
        workspace.schemaVersion = 2
        var object = try XCTUnwrap(JSONSerialization.jsonObject(with: JSONEncoder().encode(workspace)) as? [String: Any])
        for key in ["globalInstructions", "agentInstructions", "requireNoTraining", "privacyConfirmations", "providerAccountLabels"] { object.removeValue(forKey: key) }
        let oldBytes = try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
        try oldBytes.write(to: storage.file)
        let channelBackup = storage.file.deletingLastPathComponent().appendingPathComponent("workspace-before-channels.json")
        let earlierBackup = Data("Earlier backup preserved".utf8)
        try earlierBackup.write(to: channelBackup)
        let migrated = try storage.load()
        XCTAssertEqual(migrated.schemaVersion, 5)
        XCTAssertEqual(migrated.channels[0].id, channel.id)
        XCTAssertTrue(migrated.requireNoTraining)
        XCTAssertTrue(migrated.privacyConfirmations.isEmpty)
        let settingsBackup = storage.file.deletingLastPathComponent().appendingPathComponent("workspace-before-settings.json")
        XCTAssertEqual(try Data(contentsOf: settingsBackup), oldBytes)
        XCTAssertEqual(try Data(contentsOf: channelBackup), earlierBackup)
        try storage.save(migrated)
        _ = try storage.load()
        XCTAssertEqual(try Data(contentsOf: settingsBackup), oldBytes)
        XCTAssertEqual(try Data(contentsOf: channelBackup), earlierBackup)
    }

    func testCredentialChangeInvalidatesDurableConsentAndRejectsStalePreferencesDraft() throws {
        let storage = try storage(); defer { clean(storage) }
        _ = try fixture(storage)
        let store = AppStore(storage: storage, upload: { _, _ in
            XCTFail("Changing account confirmations must not upload files")
            throw ForumError.message("Unexpected upload")
        })
        defer { store.stopAll() }
        let provider = ProviderKind.openAI.rawValue
        let otherProvider = ProviderKind.anthropic.rawValue
        let oldDraft = [provider: true, otherProvider: true]
        let oldRevision = store.privacyRevision
        XCTAssertTrue(store.savePreferences(global: "Original preferences", agentInstructions: [:], requireNoTraining: true,
                                            confirmations: oldDraft, expectedPrivacyRevision: oldRevision))
        var mockCredentialWrites = 0
        if store.credentialsWillChange(.openAI) {
            // Stand in for the caller's credential write. Consent must already be invalidated on disk.
            XCTAssertEqual(try storage.load().privacyConfirmations[provider], false)
            mockCredentialWrites += 1
        }
        XCTAssertEqual(mockCredentialWrites, 1)
        XCTAssertEqual(store.privacyRevision, oldRevision + 1)
        XCTAssertEqual(store.workspace.privacyConfirmations[provider], false)
        XCTAssertEqual(store.workspace.privacyConfirmations[otherProvider], true)
        XCTAssertFalse(store.savePreferences(global: "Stale draft must not overwrite", agentInstructions: [:], requireNoTraining: true,
                                             confirmations: oldDraft, expectedPrivacyRevision: oldRevision))
        XCTAssertEqual(store.workspace.globalInstructions, "Original preferences")
        XCTAssertEqual(store.workspace.privacyConfirmations[provider], false)
        XCTAssertEqual(try storage.load().privacyConfirmations[provider], false)
        let reopened = AppStore(storage: storage, upload: { _, _ in
            XCTFail("Reloading consent state must not upload files")
            throw ForumError.message("Unexpected upload")
        })
        defer { reopened.stopAll() }
        XCTAssertEqual(reopened.workspace.privacyConfirmations[provider], false)
        XCTAssertEqual(reopened.workspace.privacyConfirmations[otherProvider], true)
        XCTAssertTrue(store.savePreferences(global: "Reviewed current account", agentInstructions: [:], requireNoTraining: true,
                                            confirmations: oldDraft, expectedPrivacyRevision: store.privacyRevision))
        XCTAssertEqual(try storage.load().privacyConfirmations[provider], true)
        XCTAssertEqual(try storage.load().globalInstructions, "Reviewed current account")
    }

    func testCredentialChangePersistenceFailurePreventsCallerCredentialWrite() throws {
        let storage = try storage(); defer { clean(storage) }
        _ = try fixture(storage)
        let store = AppStore(storage: storage, upload: { _, _ in
            XCTFail("Failed consent invalidation must not upload files")
            throw ForumError.message("Unexpected upload")
        })
        defer { store.stopAll() }
        XCTAssertTrue(store.savePreferences(global: "", agentInstructions: [:], requireNoTraining: true,
                                            confirmations: [ProviderKind.openAI.rawValue: true], expectedPrivacyRevision: store.privacyRevision))
        // Only the private test fixture is replaced, forcing the required pre-credential save to fail.
        try FileManager.default.removeItem(at: storage.file)
        try FileManager.default.createDirectory(at: storage.file, withIntermediateDirectories: false)
        var mockCredentialWrites = 0
        let mayChangeCredentials = store.credentialsWillChange(.openAI)
        if mayChangeCredentials { mockCredentialWrites += 1 }
        XCTAssertFalse(mayChangeCredentials)
        XCTAssertEqual(mockCredentialWrites, 0)
        XCTAssertEqual(store.workspace.privacyConfirmations[ProviderKind.openAI.rawValue], false)
        XCTAssertEqual(store.privacyRevision, 1)
        XCTAssertNotNil(store.error)
    }

}
