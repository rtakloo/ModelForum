#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD_ROOT="${MODEL_FORUM_BUILD_ROOT:-${TMPDIR:-/tmp}/ModelForum-build}"
APP_PATH="$BUILD_ROOT/Model Forum.app"
ARCHIVE_PATH="$PROJECT_ROOT/../Model-Forum-0.6.0-macOS.zip"
mkdir -p "$BUILD_ROOT/cache" "$BUILD_ROOT/modules"
export CLANG_MODULE_CACHE_PATH="$BUILD_ROOT/modules"
export SWIFTPM_MODULECACHE_OVERRIDE="$BUILD_ROOT/modules"
cd "$PROJECT_ROOT"
swift build --disable-sandbox -c release -debug-info-format none --cache-path "$BUILD_ROOT/cache" --scratch-path "$BUILD_ROOT" -Xswiftc -module-cache-path -Xswiftc "$BUILD_ROOT/modules"
BIN_PATH="$(swift build --disable-sandbox -c release --cache-path "$BUILD_ROOT/cache" --scratch-path "$BUILD_ROOT" --show-bin-path)"
mkdir -p "$APP_PATH/Contents/MacOS" "$APP_PATH/Contents/Resources"
cp "$BIN_PATH/ModelForum" "$APP_PATH/Contents/MacOS/ModelForum"
# SwiftPM's bundled renderer must travel with the executable, including offline math fonts.
RESOURCE_COUNT=0
for RESOURCE_BUNDLE in "$BIN_PATH"/*.bundle; do
    if [[ -d "$RESOURCE_BUNDLE" ]]; then
        /usr/bin/ditto "$RESOURCE_BUNDLE" "$APP_PATH/Contents/Resources/$(basename "$RESOURCE_BUNDLE")"
        RESOURCE_COUNT=$((RESOURCE_COUNT + 1))
    fi
done
if [[ "$RESOURCE_COUNT" -eq 0 || ! -f "$APP_PATH/Contents/Resources/ModelForum_ModelForum.bundle/Contents/Resources/Renderer/index.html" ]]; then
    printf 'Missing SwiftPM renderer resource bundle.\n' >&2
    exit 1
fi
cat > "$APP_PATH/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>ModelForum</string>
<key>CFBundleIdentifier</key><string>com.modelforum.desktop</string>
<key>CFBundleName</key><string>Model Forum</string>
<key>CFBundleDisplayName</key><string>Model Forum</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>0.6.0</string>
<key>CFBundleVersion</key><string>8</string>
<key>LSMinimumSystemVersion</key><string>14.0</string>
<key>NSHighResolutionCapable</key><true/>
<key>NSPrincipalClass</key><string>NSApplication</string>
</dict></plist>
PLIST
# Embed only public update configuration before signing. No signing keys or credentials enter the app.
if [[ -n "${MODEL_FORUM_UPDATE_FEED:-}" || -n "${MODEL_FORUM_UPDATE_PUBLIC_KEY:-}" || -n "${MODEL_FORUM_UPDATE_HOST:-}" ]]; then
    python3 - "$APP_PATH/Contents/Info.plist" <<'PYCONFIG'
import os, sys, plistlib, base64, urllib.parse
feed=os.environ.get("MODEL_FORUM_UPDATE_FEED", "")
key=os.environ.get("MODEL_FORUM_UPDATE_PUBLIC_KEY", "")
host=os.environ.get("MODEL_FORUM_UPDATE_HOST", "")
u=urllib.parse.urlparse(feed)
assert u.scheme == "https" and u.hostname and not u.username and not u.password and host
assert len(base64.b64decode(key,validate=True)) == 32
with open(sys.argv[1],"rb") as f: p=plistlib.load(f)
p.update(ModelForumUpdateFeed=feed,ModelForumUpdatePublicKey=key,ModelForumUpdateHost=host)
with open(sys.argv[1],"wb") as f: plistlib.dump(p,f)
PYCONFIG
fi
# Development builds use ad-hoc signing. Commercial builds require the publisher's stable identity.
# Clear extended attributes only on this generated bundle before signing (cloud folders can attach Finder metadata).
xattr -cr "$APP_PATH"
if [[ -n "${MODEL_FORUM_SIGNING_IDENTITY:-}" ]]; then
    [[ "$MODEL_FORUM_SIGNING_IDENTITY" == "Developer ID Application:"* ]] || { printf 'Use a Developer ID Application identity.\n' >&2; exit 1; }
    codesign --force --options runtime --timestamp --sign "$MODEL_FORUM_SIGNING_IDENTITY" "$APP_PATH"
else
    codesign --force --sign - "$APP_PATH"
fi
codesign --verify --deep --strict "$APP_PATH"
/usr/bin/ditto -c -k --keepParent --norsrc "$APP_PATH" "$ARCHIVE_PATH"
if [[ -n "${MODEL_FORUM_NOTARY_PROFILE:-}" ]]; then
    [[ -n "${MODEL_FORUM_SIGNING_IDENTITY:-}" ]] || { printf 'Notarization requires a Developer ID signed build.\n' >&2; exit 1; }
    xcrun notarytool submit "$ARCHIVE_PATH" --keychain-profile "$MODEL_FORUM_NOTARY_PROFILE" --wait
    xcrun stapler staple "$APP_PATH"
    xcrun stapler validate "$APP_PATH"
    spctl --assess --type execute --verbose "$APP_PATH"
    /usr/bin/ditto -c -k --keepParent --norsrc "$APP_PATH" "$ARCHIVE_PATH"
fi
printf 'Built %s\n' "$APP_PATH"
printf 'Packaged %s\n' "$ARCHIVE_PATH"
